package com.yourfootballcareer.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val navy = Color.rgb(7, 17, 31)
    private val lime = Color.rgb(184, 255, 57)
    private var webView: WebView? = null
    private var root: FrameLayout? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        showLanding()
    }

    private fun showLanding() {
        val frame = FrameLayout(this).apply { setBackgroundColor(navy) }
        root = frame
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(30), dp(28), dp(30))
        }
        val kicker = text("PLAYER CAREER SIMULATOR", 12, lime, true).apply { letterSpacing = .18f }
        val title = text("YOUR\nFOOTBALL CAREER", 34, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = -.02f
        }
        val ball = text("⚽", 76, lime, true).apply { gravity = Gravity.CENTER }
        val subtitle = text("Every decision shapes your legacy.", 16, Color.rgb(185, 197, 211), false).apply {
            gravity = Gravity.CENTER
        }
        val details = text("208 CLUBS  •  10 LEAGUES  •  YOUR STORY", 11, Color.rgb(140, 158, 180), true).apply {
            gravity = Gravity.CENTER
            letterSpacing = .08f
        }
        val button = Button(this).apply {
            text = "START YOUR CAREER  →"
            setTextColor(navy)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            isAllCaps = false
            background = rounded(lime, 18)
            setPadding(dp(22), dp(12), dp(22), dp(12))
            setOnClickListener { openGame() }
        }
        column.addView(kicker, centeredWrap())
        column.addView(ball, centeredWrap().apply { topMargin = dp(22) })
        column.addView(title, centeredWrap().apply { topMargin = dp(12) })
        column.addView(subtitle, centeredWrap().apply { topMargin = dp(16) })
        column.addView(details, centeredWrap().apply { topMargin = dp(28) })
        column.addView(button, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)).apply {
            topMargin = dp(42); leftMargin = dp(8); rightMargin = dp(8)
        })
        val footer = text("UNOFFICIAL COMPANION APP  •  INTERNET REQUIRED", 10, Color.rgb(105, 122, 145), false).apply {
            gravity = Gravity.CENTER
        }
        column.addView(footer, centeredWrap().apply { topMargin = dp(28) })
        frame.addView(column, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)
    }

    private fun openGame() {
        val frame = FrameLayout(this).apply { setBackgroundColor(navy) }
        root = frame
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = false
            max = 100
            progressTintList = android.content.res.ColorStateList.valueOf(lime)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.DKGRAY)
        }
        val web = WebView(this)
        webView = web
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.settings.useWideViewPort = true
        web.settings.loadWithOverviewMode = true
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.settings.setSupportMultipleWindows(false)
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                progress.visibility = View.GONE
            }
            override fun onReceivedError(view: WebView?, request: android.webkit.WebResourceRequest?, error: android.webkit.WebResourceError?) {
                if (request?.isForMainFrame == true) Toast.makeText(this@MainActivity, "Connection problem. Check your internet and retry.", Toast.LENGTH_LONG).show()
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
            }
        }
        frame.addView(web, FrameLayout.LayoutParams(-1, -1))
        frame.addView(progress, FrameLayout.LayoutParams(-1, dp(3), Gravity.TOP))
        setContentView(frame)
        web.loadUrl("https://myfootballcareer.io/")
    }

    override fun onBackPressed() {
        val web = webView
        if (web != null && web.canGoBack()) web.goBack()
        else if (web != null) {
            web.stopLoading()
            web.destroy()
            webView = null
            showLanding()
        } else super.onBackPressed()
    }

    override fun onDestroy() {
        webView?.destroy()
        webView = null
        super.onDestroy()
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(color)
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        gravity = Gravity.CENTER
    }
    private fun centeredWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { gravity = Gravity.CENTER_HORIZONTAL }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
}
