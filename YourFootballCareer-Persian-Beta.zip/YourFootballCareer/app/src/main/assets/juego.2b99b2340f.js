
let _seed = 123456789;
function srand(s){ _seed = (s>>>0) || 1; }
function azarEstado(){ return _seed; }
function azarRestaurar(s){ _seed = (s>>>0) || 1; }

let _seedRelato = 1;
function relatoSemilla(s){ _seedRelato = ((s>>>0) ^ 0x9e3779b9) >>> 0 || 1; }
function relatoEstado(){ return _seedRelato; }
function relatoRestaurar(s){ _seedRelato = (s>>>0) || 1; }
function relato(fn){
  const carrera = _seed;
  _seed = _seedRelato;
  try { return fn(); }
  finally { _seedRelato = _seed; _seed = carrera; }
}
function rnd(){ 
  _seed ^= _seed << 13; _seed >>>= 0;
  _seed ^= _seed >> 17;
  _seed ^= _seed << 5;  _seed >>>= 0;
  return _seed / 4294967296;
}
const R = { f:()=>rnd(),
  i:(a,b)=>a+Math.floor(rnd()*(b-a+1)),
  pick:a=>a[Math.floor(rnd()*a.length)],
  chance:p=>rnd()<p,
  gauss:(m,s)=>{ let u=1-rnd(), v=rnd(); return m+s*Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v); },
  shuffle:a=>{ a=a.slice(); for(let i=a.length-1;i>0;i--){ const j=Math.floor(rnd()*(i+1)); [a[i],a[j]]=[a[j],a[i]]; } return a; }
};
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const EDAD_ES = ['quince','dieciséis','diecisiete','dieciocho','diecinueve','veinte','veintiuno',
  'veintidós','veintitrés','veinticuatro','veinticinco','veintiséis','veintisiete','veintiocho',
  'veintinueve','treinta','treinta y uno','treinta y dos','treinta y tres','treinta y cuatro',
  'treinta y cinco','treinta y seis','treinta y siete','treinta y ocho','treinta y nueve','cuarenta'];
const EDAD_EN = ['fifteen','sixteen','seventeen','eighteen','nineteen','twenty','twenty-one',
  'twenty-two','twenty-three','twenty-four','twenty-five','twenty-six','twenty-seven','twenty-eight',
  'twenty-nine','thirty','thirty-one','thirty-two','thirty-three','thirty-four',
  'thirty-five','thirty-six','thirty-seven','thirty-eight','thirty-nine','forty'];
const EDAD_PT = ['quinze','dezesseis','dezessete','dezoito','dezenove','vinte','vinte e um',
  'vinte e dois','vinte e três','vinte e quatro','vinte e cinco','vinte e seis','vinte e sete','vinte e oito',
  'vinte e nove','trinta','trinta e um','trinta e dois','trinta e três','trinta e quatro',
  'trinta e cinco','trinta e seis','trinta e sete','trinta e oito','trinta e nove','quarenta'];
const enLetras = (n, lang) => ((lang==='en'? EDAD_EN : lang==='pt'? EDAD_PT : EDAD_ES)[clamp(Math.round(n),15,40)-15]) || String(n);
const round=(v,d=0)=>{ const m=Math.pow(10,d); return Math.round(v*m)/m; };

const ATTRS = [
  {k:'rit', n:'Ritmo'},      {k:'def', n:'Definición'},
  {k:'pas', n:'Pase'},       {k:'reg', n:'Regate'},
  {k:'dfs', n:'Defensa'},    {k:'fis', n:'Físico'},
  {k:'aer', n:'Juego aéreo'},{k:'com', n:'Compostura'},
  {k:'peg', n:'Pegada'},     {k:'lid', n:'Liderazgo'},
  {k:'fil', n:'Filigranas'}, {k:'pmm', n:'Pierna mala'}
];

const POSITIONS = {
  DFC:{n:'Defensa central', w:{rit:.06,def:.02,pas:.09,reg:.03,dfs:.31,fis:.21,aer:.13,com:.06,peg:.02,lid:.05,fil:.01,pmm:.01}, gol:.05, asi:.10},
  LAT:{n:'Lateral',         w:{rit:.20,def:.04,pas:.14,reg:.10,dfs:.21,fis:.13,aer:.04,com:.05,peg:.04,lid:.03,fil:.01,pmm:.01}, gol:.12, asi:.45},
  MCD:{n:'Mediocentro def.',w:{rit:.06,def:.03,pas:.21,reg:.08,dfs:.25,fis:.16,aer:.05,com:.06,peg:.03,lid:.05,fil:.01,pmm:.01}, gol:.15, asi:.35},
  MC: {n:'Mediocentro',     w:{rit:.08,def:.08,pas:.27,reg:.17,dfs:.10,fis:.08,aer:.03,com:.07,peg:.04,lid:.05,fil:.02,pmm:.01}, gol:.30, asi:.70},
  MCO:{n:'Mediapunta',      w:{rit:.10,def:.13,pas:.23,reg:.22,dfs:.03,fis:.04,aer:.02,com:.08,peg:.07,lid:.04,fil:.03,pmm:.01}, gol:.55, asi:.85},
  EXT:{n:'Extremo',         w:{rit:.21,def:.15,pas:.12,reg:.24,dfs:.02,fis:.04,aer:.02,com:.07,peg:.05,lid:.03,fil:.04,pmm:.01}, gol:.65, asi:.75},
  DC: {n:'Delantero centro',w:{rit:.13,def:.31,pas:.06,reg:.11,dfs:.01,fis:.11,aer:.12,com:.05,peg:.03,lid:.04,fil:.02,pmm:.01}, gol:1.00,asi:.35}
};
const REMATE = {DFC:1.00, LAT:.30, MCD:.42, MC:.36, MCO:.34, EXT:.28, DC:.88};
const PATEADOR = {DFC:.10, LAT:.45, MCD:.55, MC:.80, MCO:1.00, EXT:.72, DC:.55};

const NATIONS = [
  {n:'Argentina',   f:'🇦🇷', str:5, conf:'SUD'}, {n:'Brasil',     f:'🇧🇷', str:5, conf:'SUD'},
  {n:'España',      f:'🇪🇸', str:5, conf:'EUR'}, {n:'Francia',    f:'🇫🇷', str:5, conf:'EUR'},
  {n:'Inglaterra',  f:'🏴', str:5, conf:'EUR'},  {n:'Alemania',   f:'🇩🇪', str:5, conf:'EUR'},
  {n:'Italia',      f:'🇮🇹', str:4, conf:'EUR'}, {n:'Portugal',   f:'🇵🇹', str:4, conf:'EUR'},
  {n:'Países Bajos',f:'🇳🇱', str:4, conf:'EUR'}, {n:'Uruguay',    f:'🇺🇾', str:4, conf:'SUD'},
  {n:'Colombia',    f:'🇨🇴', str:3, conf:'SUD'}, {n:'Croacia',    f:'🇭🇷', str:3, conf:'EUR'},
  {n:'México',      f:'🇲🇽', str:3, conf:'CON'}, {n:'Japón',      f:'🇯🇵', str:3, conf:'ASI'},
  {n:'Senegal',     f:'🇸🇳', str:3, conf:'AFR'}, {n:'Marruecos',  f:'🇲🇦', str:3, conf:'AFR'},
  {n:'Nigeria',     f:'🇳🇬', str:3, conf:'AFR'}, {n:'Estados Unidos',f:'🇺🇸',str:2,conf:'CON'},
  {n:'Chile',       f:'🇨🇱', str:3, conf:'SUD'}, {n:'Corea del Sur',f:'🇰🇷',str:2,conf:'ASI'},
  {n:'Noruega',     f:'🇳🇴', str:2, conf:'EUR'}, {n:'Ghana',      f:'🇬🇭', str:2, conf:'AFR'},
  {n:'Serbia',      f:'🇷🇸', str:2, conf:'EUR'}, {n:'Australia',  f:'🇦🇺', str:1, conf:'ASI'}
];
const CONF_NAME = {EUR:'Eurocopa', SUD:'Copa América', AFR:'Copa Africana de Naciones', CON:'Copa Oro', ASI:'Copa Asiática'};

const LEAGUES = [
  {id:'ESP', n:'LaLiga',          pais:'España',         str:5, cont:'EUR', money:4, div1:16, copa:'Copa del Rey',          sup:'Supercopa de España', div2n:'Segunda División'},
  {id:'ENG', n:'Premier League',  pais:'Inglaterra',     str:5, cont:'EUR', money:5, div1:16, copa:'FA Cup',                sup:'Community Shield', div2n:'Championship'},
  {id:'ITA', n:'Serie A',         pais:'Italia',         str:4, cont:'EUR', money:4, div1:16, copa:'Coppa Italia',          sup:'Supercoppa Italiana', div2n:'Serie B'},
  {id:'GER', n:'Bundesliga',      pais:'Alemania',       str:4, cont:'EUR', money:4, div1:16, copa:'DFB-Pokal',             sup:'Franz-Beckenbauer-Supercup', div2n:'2. Bundesliga'},
  {id:'FRA', n:'Ligue 1',         pais:'Francia',        str:3, cont:'EUR', money:4, div1:16, copa:'Coupe de France',       sup:'Trophée des Champions', div2n:'Ligue 2'},
  {id:'ARG', n:'Liga Profesional',pais:'Argentina',      str:3, cont:'SUD', money:1, div1:16, copa:'Copa Argentina',        sup:'Trofeo de Campeones', playoff:8, regular:'Tabla anual', div2n:'Primera Nacional'},
  {id:'BRA', n:'Brasileirão',     pais:'Brasil',         str:3, cont:'SUD', money:2, div1:16, copa:'Copa do Brasil',        sup:'Supercopa do Brasil', div2n:'Série B'},
  {id:'SAU', n:'Saudi Pro League',pais:'Arabia Saudita', str:2, cont:null,  money:5, div1:12, copa:"King's Cup",            sup:'Saudi Super Cup', div2n:'Saudi First Division'},
  {id:'USA', n:'MLS',             pais:'Estados Unidos', str:2, cont:'CON', money:3, div1:12, copa:'US Open Cup',           sup:'Campeones Cup', playoff:9, regular:'Supporters\' Shield', div2n:'USL Championship'},
  {id:'MEX', n:'Liga MX',         pais:'México',         str:3, cont:'CON', money:3, div1:12, copa:'Leagues Cup', copaCruza:'USA', sup:'Campeón de Campeones', playoff:8, regular:'Tabla general', div2n:'Liga de Expansión MX'}
];
const _lgById = new Map(LEAGUES.map(l=>[l.id,l]));
const L = id => _lgById.get(id);

const CLUBS = [
  {id:'rma', n:'Real Madrid',        lg:'ESP', tier:5, rep:99},
  {id:'fcb', n:'FC Barcelona',       lg:'ESP', tier:5, rep:96},
  {id:'atm', n:'Atlético de Madrid', lg:'ESP', tier:4, rep:85},
  {id:'sev', n:'Sevilla FC',         lg:'ESP', tier:3, rep:72},
  {id:'ath', n:'Athletic Club',      lg:'ESP', tier:3, rep:70},
  {id:'rso', n:'Real Sociedad',      lg:'ESP', tier:3, rep:68},
  {id:'val', n:'Valencia CF',        lg:'ESP', tier:3, rep:67},
  {id:'vil', n:'Villarreal CF',      lg:'ESP', tier:3, rep:66},
  {id:'bet', n:'Real Betis',         lg:'ESP', tier:3, rep:64},
  {id:'cel', n:'Celta de Vigo',      lg:'ESP', tier:2, rep:55},
  {id:'gir', n:'Girona FC',          lg:'ESP', tier:2, rep:52},
  {id:'osa', n:'CA Osasuna',         lg:'ESP', tier:2, rep:50},
  {id:'get', n:'Getafe CF',          lg:'ESP', tier:2, rep:49},
  {id:'ray', n:'Rayo Vallecano',     lg:'ESP', tier:2, rep:47},
  {id:'mal', n:'RCD Mallorca',       lg:'ESP', tier:2, rep:46},
  {id:'ala', n:'Deportivo Alavés',   lg:'ESP', tier:2, rep:44},
  {id:'esp', n:'RCD Espanyol',       lg:'ESP', tier:2, rep:43},
  {id:'lpa', n:'UD Las Palmas',      lg:'ESP', tier:1, rep:41},
  {id:'lev', n:'Levante UD',         lg:'ESP', tier:1, rep:38},
  {id:'leg', n:'CD Leganés',         lg:'ESP', tier:1, rep:36},
  {id:'spo', n:'Sporting de Gijón',  lg:'ESP', tier:1, rep:35},
  {id:'rzg', n:'Real Zaragoza',      lg:'ESP', tier:1, rep:33},
  {id:'rov', n:'Real Oviedo',        lg:'ESP', tier:1, rep:31},
  {id:'rac2',n:'Racing de Santander',lg:'ESP', tier:1, rep:29},

  {id:'mci', n:'Manchester City',    lg:'ENG', tier:5, rep:96},
  {id:'liv', n:'Liverpool',          lg:'ENG', tier:5, rep:94},
  {id:'ars', n:'Arsenal',            lg:'ENG', tier:4, rep:91},
  {id:'mun', n:'Manchester United',  lg:'ENG', tier:4, rep:90},
  {id:'che', n:'Chelsea',            lg:'ENG', tier:4, rep:88},
  {id:'tot', n:'Tottenham Hotspur',  lg:'ENG', tier:4, rep:80},
  {id:'new', n:'Newcastle United',   lg:'ENG', tier:3, rep:73},
  {id:'avl', n:'Aston Villa',        lg:'ENG', tier:3, rep:71},
  {id:'whu', n:'West Ham United',    lg:'ENG', tier:3, rep:66},
  {id:'bri', n:'Brighton',           lg:'ENG', tier:2, rep:62},
  {id:'eve', n:'Everton',            lg:'ENG', tier:2, rep:59},
  {id:'nfo', n:'Nottingham Forest',  lg:'ENG', tier:2, rep:55},
  {id:'cry', n:'Crystal Palace',     lg:'ENG', tier:2, rep:53},
  {id:'ful', n:'Fulham',             lg:'ENG', tier:2, rep:51},
  {id:'bre', n:'Brentford',          lg:'ENG', tier:2, rep:49},
  {id:'wol', n:'Wolverhampton',      lg:'ENG', tier:2, rep:48},
  {id:'lee', n:'Leeds United',       lg:'ENG', tier:2, rep:46},
  {id:'sou', n:'Southampton',        lg:'ENG', tier:1, rep:42},
  {id:'lei', n:'Leicester City',     lg:'ENG', tier:2, rep:45},
  {id:'shu', n:'Sheffield United',   lg:'ENG', tier:1, rep:38},
  {id:'nor', n:'Norwich City',       lg:'ENG', tier:1, rep:36},
  {id:'sun', n:'Sunderland',         lg:'ENG', tier:1, rep:35},
  {id:'der', n:'Derby County',       lg:'ENG', tier:1, rep:33},
  {id:'bir', n:'Birmingham City',    lg:'ENG', tier:1, rep:31},

  {id:'juv', n:'Juventus',           lg:'ITA', tier:4, rep:89},
  {id:'mil', n:'AC Milan',           lg:'ITA', tier:4, rep:88},
  {id:'int', n:'Inter de Milán',     lg:'ITA', tier:4, rep:87},
  {id:'nap', n:'SSC Napoli',         lg:'ITA', tier:4, rep:79},
  {id:'rom', n:'AS Roma',            lg:'ITA', tier:3, rep:77},
  {id:'ata', n:'Atalanta',           lg:'ITA', tier:3, rep:72},
  {id:'laz', n:'SS Lazio',           lg:'ITA', tier:3, rep:70},
  {id:'fio', n:'Fiorentina',         lg:'ITA', tier:3, rep:65},
  {id:'bol', n:'Bologna',            lg:'ITA', tier:2, rep:58},
  {id:'tor', n:'Torino',             lg:'ITA', tier:2, rep:54},
  {id:'udi', n:'Udinese',            lg:'ITA', tier:2, rep:50},
  {id:'sas', n:'Sassuolo',           lg:'ITA', tier:2, rep:48},
  {id:'gen', n:'Genoa',              lg:'ITA', tier:2, rep:47},
  {id:'sam', n:'Sampdoria',          lg:'ITA', tier:2, rep:45},
  {id:'cag', n:'Cagliari',           lg:'ITA', tier:1, rep:43},
  {id:'emp', n:'Empoli',             lg:'ITA', tier:1, rep:41},
  {id:'ver', n:'Hellas Verona',      lg:'ITA', tier:1, rep:40},
  {id:'lec', n:'US Lecce',           lg:'ITA', tier:1, rep:38},
  {id:'par', n:'Parma',              lg:'ITA', tier:1, rep:37},
  {id:'ven', n:'Venezia',            lg:'ITA', tier:1, rep:34},
  {id:'pis', n:'Pisa',               lg:'ITA', tier:1, rep:32},
  {id:'pal', n:'Palermo',            lg:'ITA', tier:1, rep:31},
  {id:'bar2',n:'SSC Bari',           lg:'ITA', tier:1, rep:29},
  {id:'spa', n:'SPAL',               lg:'ITA', tier:1, rep:27},

  {id:'bay', n:'Bayern de Múnich',   lg:'GER', tier:5, rep:95},
  {id:'bvb', n:'Borussia Dortmund',  lg:'GER', tier:4, rep:84},
  {id:'b04', n:'Bayer Leverkusen',   lg:'GER', tier:4, rep:78},
  {id:'rbl', n:'RB Leipzig',         lg:'GER', tier:3, rep:74},
  {id:'sge', n:'Eintracht Frankfurt',lg:'GER', tier:3, rep:67},
  {id:'vfb', n:'VfB Stuttgart',      lg:'GER', tier:3, rep:63},
  {id:'wob', n:'VfL Wolfsburgo',     lg:'GER', tier:2, rep:60},
  {id:'svw', n:'Werder Bremen',      lg:'GER', tier:2, rep:58},
  {id:'bmg', n:'Borussia M’gladbach',lg:'GER', tier:2, rep:57},
  {id:'fcu', n:'Union Berlin',       lg:'GER', tier:2, rep:53},
  {id:'scf', n:'SC Friburgo',        lg:'GER', tier:2, rep:52},
  {id:'tsg', n:'Hoffenheim',         lg:'GER', tier:2, rep:49},
  {id:'fcm', n:'Mainz 05',           lg:'GER', tier:2, rep:46},
  {id:'fca', n:'FC Augsburgo',       lg:'GER', tier:1, rep:43},
  {id:'boc', n:'VfL Bochum',         lg:'GER', tier:1, rep:40},
  {id:'kol', n:'FC Colonia',         lg:'GER', tier:2, rep:47},
  {id:'hsv', n:'Hamburgo SV',        lg:'GER', tier:1, rep:41},
  {id:'s04', n:'Schalke 04',         lg:'GER', tier:1, rep:39},
  {id:'h96', n:'Hannover 96',        lg:'GER', tier:1, rep:34},
  {id:'kai', n:'Kaiserslautern',     lg:'GER', tier:1, rep:32},

  {id:'psg', n:'Paris Saint-Germain',lg:'FRA', tier:5, rep:91},
  {id:'om',  n:'Olympique de Marsella',lg:'FRA', tier:3, rep:74},
  {id:'ol',  n:'Olympique de Lyon',  lg:'FRA', tier:3, rep:72},
  {id:'mon', n:'AS Mónaco',          lg:'FRA', tier:3, rep:70},
  {id:'lil', n:'Lille OSC',          lg:'FRA', tier:3, rep:65},
  {id:'ren', n:'Stade Rennais',      lg:'FRA', tier:2, rep:58},
  {id:'nic', n:'OGC Niza',           lg:'FRA', tier:2, rep:57},
  {id:'len', n:'RC Lens',            lg:'FRA', tier:2, rep:56},
  {id:'nan', n:'FC Nantes',          lg:'FRA', tier:2, rep:50},
  {id:'str', n:'RC Estrasburgo',     lg:'FRA', tier:2, rep:47},
  {id:'mtp', n:'Montpellier',        lg:'FRA', tier:2, rep:45},
  {id:'tou', n:'Toulouse FC',        lg:'FRA', tier:1, rep:43},
  {id:'bre2',n:'Stade Brestois',     lg:'FRA', tier:1, rep:42},
  {id:'rei', n:'Stade de Reims',     lg:'FRA', tier:1, rep:41},
  {id:'aja', n:'AJ Auxerre',         lg:'FRA', tier:1, rep:38},
  {id:'ang', n:'Angers SCO',         lg:'FRA', tier:1, rep:36},
  {id:'sce', n:'SC Bastia',          lg:'FRA', tier:1, rep:33},
  {id:'sai', n:'Saint-Étienne',      lg:'FRA', tier:2, rep:46},
  {id:'bor', n:'Girondins de Burdeos',lg:'FRA', tier:1, rep:39},
  {id:'cae', n:'SM Caen',            lg:'FRA', tier:1, rep:31},

  {id:'riv', n:'River Plate',        lg:'ARG', tier:4, rep:76},
  {id:'bjr', n:'Boca Juniors',       lg:'ARG', tier:4, rep:75},
  {id:'rac', n:'Racing Club',        lg:'ARG', tier:3, rep:64},
  {id:'ind', n:'Independiente',      lg:'ARG', tier:3, rep:62},
  {id:'sl',  n:'San Lorenzo',        lg:'ARG', tier:2, rep:58},
  {id:'est', n:'Estudiantes',        lg:'ARG', tier:2, rep:58},
  {id:'vel', n:'Vélez Sarsfield',    lg:'ARG', tier:2, rep:57},
  {id:'tal', n:'Talleres',           lg:'ARG', tier:2, rep:54},
  {id:'now', n:"Newell's Old Boys",  lg:'ARG', tier:2, rep:52},
  {id:'roc', n:'Rosario Central',    lg:'ARG', tier:2, rep:52},
  {id:'lan', n:'Lanús',              lg:'ARG', tier:2, rep:48},
  {id:'arg', n:'Argentinos Juniors', lg:'ARG', tier:2, rep:46},
  {id:'def', n:'Defensa y Justicia', lg:'ARG', tier:2, rep:45},
  {id:'hur', n:'Huracán',            lg:'ARG', tier:1, rep:44},
  {id:'ban', n:'Banfield',           lg:'ARG', tier:1, rep:43},
  {id:'gim', n:'Gimnasia La Plata',  lg:'ARG', tier:1, rep:42},
  {id:'col', n:'Colón',              lg:'ARG', tier:1, rep:40},
  {id:'uni', n:'Unión de Santa Fe',  lg:'ARG', tier:1, rep:38},
  {id:'god', n:'Godoy Cruz',         lg:'ARG', tier:1, rep:37},
  {id:'ins', n:'Instituto',          lg:'ARG', tier:1, rep:34},
  {id:'ald', n:'Aldosivi',           lg:'ARG', tier:1, rep:31},
  {id:'tig', n:'Tigre',              lg:'ARG', tier:1, rep:33},
  {id:'plt', n:'Platense',           lg:'ARG', tier:1, rep:30},
  {id:'tem', n:'Temperley',          lg:'ARG', tier:1, rep:28},

  {id:'fla', n:'Flamengo',           lg:'BRA', tier:4, rep:77},
  {id:'pal2',n:'Palmeiras',          lg:'BRA', tier:4, rep:76},
  {id:'spf', n:'São Paulo FC',       lg:'BRA', tier:3, rep:70},
  {id:'cor', n:'Corinthians',        lg:'BRA', tier:3, rep:69},
  {id:'cam', n:'Atlético Mineiro',   lg:'BRA', tier:3, rep:65},
  {id:'flu', n:'Fluminense',         lg:'BRA', tier:3, rep:64},
  {id:'gre', n:'Grêmio',             lg:'BRA', tier:3, rep:64},
  {id:'inter',n:'Internacional',     lg:'BRA', tier:3, rep:62},
  {id:'bot', n:'Botafogo',           lg:'BRA', tier:2, rep:61},
  {id:'san', n:'Santos FC',          lg:'BRA', tier:2, rep:60},
  {id:'cru', n:'Cruzeiro',           lg:'BRA', tier:2, rep:58},
  {id:'vas', n:'Vasco da Gama',      lg:'BRA', tier:2, rep:56},
  {id:'bah', n:'EC Bahia',           lg:'BRA', tier:2, rep:52},
  {id:'ath2',n:'Athletico Paranaense',lg:'BRA',tier:2, rep:51},
  {id:'for', n:'Fortaleza',          lg:'BRA', tier:2, rep:49},
  {id:'cea', n:'Ceará SC',           lg:'BRA', tier:1, rep:44},
  {id:'gois',n:'Goiás',              lg:'BRA', tier:1, rep:42},
  {id:'cori',n:'Coritiba',           lg:'BRA', tier:1, rep:40},
  {id:'spt', n:'Sport Recife',       lg:'BRA', tier:1, rep:39},
  {id:'juv2',n:'EC Juventude',       lg:'BRA', tier:1, rep:36},
  {id:'vit', n:'EC Vitória',         lg:'BRA', tier:1, rep:38},
  {id:'chap',n:'Chapecoense',        lg:'BRA', tier:1, rep:33},
  {id:'pon', n:'Ponte Preta',        lg:'BRA', tier:1, rep:31},
  {id:'ava', n:'Avaí',               lg:'BRA', tier:1, rep:29},

  {id:'hil', n:'Al-Hilal',           lg:'SAU', tier:3, rep:63},
  {id:'nas', n:'Al-Nassr',           lg:'SAU', tier:3, rep:60},
  {id:'itt', n:'Al-Ittihad',         lg:'SAU', tier:2, rep:57},
  {id:'ahl', n:'Al-Ahli',            lg:'SAU', tier:2, rep:55},
  {id:'shb', n:'Al-Shabab',          lg:'SAU', tier:2, rep:50},
  {id:'ett', n:'Al-Ettifaq',         lg:'SAU', tier:2, rep:47},
  {id:'tao', n:'Al-Taawoun',         lg:'SAU', tier:1, rep:44},
  {id:'fat', n:'Al-Fateh',           lg:'SAU', tier:1, rep:42},
  {id:'fay', n:'Al-Fayha',           lg:'SAU', tier:1, rep:40},
  {id:'raed',n:'Al-Raed',            lg:'SAU', tier:1, rep:38},
  {id:'khl', n:'Al-Khaleej',         lg:'SAU', tier:1, rep:36},
  {id:'wed', n:'Al-Wehda',           lg:'SAU', tier:1, rep:35},
  {id:'ryd', n:'Al-Riyadh',          lg:'SAU', tier:1, rep:33},
  {id:'ohd', n:'Ohod Club',          lg:'SAU', tier:1, rep:31},
  {id:'nah', n:'Al-Nahda',           lg:'SAU', tier:1, rep:29},
  {id:'jab', n:'Al-Jabalain',        lg:'SAU', tier:1, rep:27},

  {id:'mia', n:'Inter Miami',        lg:'USA', tier:2, rep:55},
  {id:'lafc',n:'Los Angeles FC',     lg:'USA', tier:2, rep:52},
  {id:'lag', n:'LA Galaxy',          lg:'USA', tier:2, rep:50},
  {id:'sea', n:'Seattle Sounders',   lg:'USA', tier:2, rep:48},
  {id:'atl', n:'Atlanta United',     lg:'USA', tier:2, rep:47},
  {id:'nyc', n:'New York City FC',   lg:'USA', tier:2, rep:46},
  {id:'rbny',n:'New York Red Bulls', lg:'USA', tier:1, rep:44},
  {id:'por', n:'Portland Timbers',   lg:'USA', tier:1, rep:43},
  {id:'phi', n:'Philadelphia Union', lg:'USA', tier:1, rep:42},
  {id:'aus', n:'Austin FC',          lg:'USA', tier:1, rep:40},
  {id:'orl', n:'Orlando City',       lg:'USA', tier:1, rep:39},
  {id:'col2',n:'Columbus Crew',      lg:'USA', tier:1, rep:41},
  {id:'dal', n:'FC Dallas',          lg:'USA', tier:1, rep:37},
  {id:'hou', n:'Houston Dynamo',     lg:'USA', tier:1, rep:35},
  {id:'chi', n:'Chicago Fire',       lg:'USA', tier:1, rep:33},
  {id:'sjo', n:'San Jose Earthquakes',lg:'USA',tier:1, rep:31},

  {id:'ame', n:'Club América',       lg:'MEX', tier:3, rep:60},
  {id:'mty', n:'CF Monterrey',       lg:'MEX', tier:2, rep:56},
  {id:'tig2',n:'Tigres UANL',        lg:'MEX', tier:2, rep:55},
  {id:'chv', n:'Chivas Guadalajara', lg:'MEX', tier:2, rep:53},
  {id:'cru2',n:'Cruz Azul',          lg:'MEX', tier:2, rep:52},
  {id:'pum', n:'Pumas UNAM',         lg:'MEX', tier:2, rep:49},
  {id:'tol', n:'Toluca',             lg:'MEX', tier:2, rep:48},
  {id:'san2',n:'Santos Laguna',      lg:'MEX', tier:1, rep:45},
  {id:'pac', n:'Pachuca',            lg:'MEX', tier:1, rep:44},
  {id:'leo', n:'Club León',          lg:'MEX', tier:1, rep:43},
  {id:'tij', n:'Club Tijuana',       lg:'MEX', tier:1, rep:40},
  {id:'atlas',n:'Atlas FC',          lg:'MEX', tier:1, rep:39},
  {id:'nec', n:'Necaxa',             lg:'MEX', tier:1, rep:36},
  {id:'pue', n:'Puebla FC',          lg:'MEX', tier:1, rep:34},
  {id:'que', n:'Querétaro FC',       lg:'MEX', tier:1, rep:32},
  {id:'maz', n:'Mazatlán FC',        lg:'MEX', tier:1, rep:30}
];
const _clubById = new Map(CLUBS.map(c=>[c.id,c]));
const C = id => _clubById.get(id);

const LEGENDS = [
  {id:'l1', n:'El Enganche de Potrero', sub:'la pelota atada al pie', ic:'🎩', pos:'MCO',
   attr:'reg', boost:26, trait:'gambeta',
   desc:'Se formó en canchas sin líneas, con arcos de piedra y sin árbitro. Aprendió a esquivar antes que a correr, porque frenar dolía.'},
  {id:'l2', n:'El Show de la Banda',    sub:'el que hace levantar a la gente', ic:'🎭', pos:'EXT',
   attr:'fil', boost:28, trait:'espectaculo',
   desc:'Convierte el fútbol en otra cosa. La tribuna no le perdona un partido gris, pero le perdona todo lo demás.'},
  {id:'l3', n:'El Último Hombre',       sub:'de acá no pasa nadie', ic:'🧱', pos:'DFC',
   attr:'dfs', boost:26, trait:'muro',
   desc:'Nunca fue el más rápido ni el más elegante. Simplemente estaba siempre donde tenía que estar, un segundo antes que el otro.'},
  {id:'l4', n:'El Killer del Área',     sub:'no falla adentro', ic:'🎯', pos:'DC',
   attr:'def', boost:27, trait:'sangrefria',
   desc:'Toca tres pelotas por partido y hace dos goles. El resto del tiempo parece que no juega. Después mirás el marcador.'},
  {id:'l5', n:'La Flecha',              sub:'tres metros y se acabó', ic:'⚡', pos:'EXT',
   attr:'rit', boost:28, trait:'turbo',
   desc:'Los laterales piden ayuda desde el calentamiento. Una pelota larga al espacio y el partido ya está roto.'},
  {id:'l6', n:'El Cerebro',             sub:'ve el pase antes que exista', ic:'🧭', pos:'MC',
   attr:'pas', boost:27, trait:'metronomo',
   desc:'Juega con la cabeza levantada antes de recibir. El equipo gira a su alrededor sin que nadie se dé cuenta de por qué.'},
  {id:'l7', n:'El Pulmón',              sub:'noventa minutos al mismo ritmo', ic:'🫁', pos:'MCD',
   attr:'fis', boost:27, trait:'incansable',
   desc:'Corre lo que corren dos. En el minuto 88 sigue yendo a presionar como si recién hubiera entrado.'},
  {id:'l8', n:'El Ambidiestro',         sub:'no tiene pierna mala', ic:'👣', pos:'LAT',
   attr:'pmm', boost:34, trait:'ambidiestro',
   desc:'Nadie sabe con cuál define mejor. Él tampoco. Le da igual de qué lado le caiga la pelota.'},
  {id:'l9', n:'La Torre',               sub:'todo lo que sube, es suyo', ic:'🗼', pos:'DC',
   attr:'aer', boost:29, trait:'torre',
   desc:'Salta y se queda arriba un segundo más que el resto. Cada córner a favor es medio gol y cada córner en contra, medio gol menos.'},
  {id:'l10',n:'El Hombre de Hielo',     sub:'cuanto más pesa, mejor juega', ic:'🧊', pos:'MCO',
   attr:'com', boost:30, trait:'hielo',
   desc:'En un martes cualquiera parece uno más. En una final, con setenta mil personas gritando, es el único que levanta la cabeza y elige bien.'},
  {id:'l11',n:'El Especialista',        sub:'la pelota quieta es suya', ic:'🎯', pos:'MC',
   attr:'peg', boost:30, trait:'pegada',
   desc:'Se queda una hora después del entrenamiento pateando faltas contra una barrera de muñecos. Cuando el árbitro cobra al borde del área, el rival ya sabe lo que viene y no puede hacer nada.'},
  {id:'l12',n:'El Caudillo',            sub:'el equipo es lo que él decide', ic:'🎖️', pos:'MCD',
   attr:'lid', boost:29, trait:'caudillo',
   desc:'No es el más técnico ni el más rápido. Pero cuando el partido se pone feo, todos miran para donde está él, y el equipo entero juega dos escalones por encima de lo que vale.'}
];

const TRAITS = {
  gambeta:    {n:'Gambeta imposible', d:'+ regates en partidos grandes, más faltas recibidas.'},
  espectaculo:{n:'Espectáculo',       d:'Gana hinchada y prensa más rápido.'},
  muro:       {n:'Muro',              d:'Menos lesiones, más resistencia al desgaste.'},
  sangrefria: {n:'Sangre fría',       d:'Rinde más en finales y definiciones.'},
  turbo:      {n:'Turbo',             d:'Ritmo decae más lento con la edad.'},
  metronomo:  {n:'Metrónomo',         d:'Más asistencias y mejor puntuación media.'},
  incansable: {n:'Incansable',        d:'Más minutos por temporada, recupera forma rápido.'},
  ambidiestro:{n:'Ambidiestro',       d:'Se adapta a cualquier posición sin penalización.'},
  torre:      {n:'Torre en el área',  d:'Gana casi todas por arriba: más goles de cabeza.'},
  hielo:      {n:'Sangre de hielo',   d:'No le tiembla el pulso en finales ni en penales.'},
  pegada:     {n:'Pegada de tiro libre', d:'Las faltas y los penales son tuyos en cualquier equipo.'},
  caudillo:   {n:'Arrastra al equipo',d:'Tu club rinde por encima de lo que vale su plantel.'},
  capitan:    {n:'Capitán nato',      d:'Sube la moral del vestuario y tu peso en el club.'},
  polemico:   {n:'Polémico',          d:'Prensa hostil, pero nunca te falta ambición.'},
  cristal:    {n:'Frágil',            d:'Mayor riesgo de lesión.'},
  profesional:{n:'Profesional',       d:'Envejeces mejor y entrenas más eficientemente.'},
  idolo:      {n:'Ídolo',             d:'Vínculo eterno con tu club: rinde más de local.'},
  mercenario: {n:'Mercenario',        d:'Sueldos más altos, la hinchada nunca te perdona.'},
  clutch:     {n:'Aparece siempre',   d:'Bonus en partidos decisivos.'},
  lider:      {n:'Líder de vestuario',d:'Mejor relación con el DT y compañeros.'}
};

const CONTI_PESO  = {EUR:45, SUD:36, CON:24};
const CONTI_BALON = {EUR:1.7, SUD:1.4, CON:1.15};
const CONT_CUP = {
  EUR:'UEFA Champions League',
  SUD:'Copa Libertadores',
  CON:'Concacaf Champions Cup'
};

function baseAttrs(pos){
  const w = POSITIONS[pos].w, a = {};
  ATTRS.forEach(({k})=>{ a[k] = clamp(Math.round(34 + w[k]*40 + R.gauss(0,5)), 20, 62); });
  a.pmm = clamp(Math.round(R.gauss(30,8)),15,55);
  a.aer = clamp(Math.round(22 + a.fis*0.42 + w.aer*45 + R.gauss(0,6)), 20, 64);
  a.com = clamp(Math.round(R.gauss(38,9)), 18, 62);
  a.peg = clamp(Math.round(20 + a.pas*0.30 + w.peg*40 + Math.pow(R.f(),2.2)*46 + R.gauss(0,4)), 15, 70);
  a.lid = clamp(Math.round(R.gauss(32,10)), 15, 58);
  return a;
}

const HEREDABLES = Object.keys(TRAITS).filter(k => k !== 'cristal');
const DINASTIA_MAX_GEN = 20;
const MARCAS_DE_NACIMIENTO = ['heredero', 'apellidoPesado', 'clubDelViejo'];
const FAMA_TECHO = 1;
const ANIO_BASE = 2026, ANIO_MAX = 3026;
const anioValido = a => Number.isInteger(a) && a >= ANIO_BASE && a <= ANIO_MAX && (a - ANIO_BASE) % 4 === 0;
function famaDe(pts){ return pts >= 1750 ? 3 : pts >= 1320 ? 2 : pts >= 950 ? 1 : 0; }
const leyendaDeRasgo = t => LEGENDS.find(l => l.trait === t) || null;
function herenciaValida(h, draft){
  if(h == null) return Array.isArray(draft) && draft.length === 2;
  if(typeof h !== 'object') return false;
  if(!Number.isInteger(h.gen) || h.gen < 2 || h.gen > DINASTIA_MAX_GEN) return false;
  if(!HEREDABLES.includes(h.rasgo)) return false;
  if(!Number.isInteger(h.fama) || h.fama < 0 || h.fama > 3) return false;
  if(!C(h.club)) return false;
  if(h.anio !== undefined && !anioValido(h.anio)) return false;
  if(!Array.isArray(draft) || draft.length !== 1) return false;
  const lg = LEGENDS.find(l => l.id === draft[0]);
  return !lg || lg.trait !== h.rasgo;
}

function createPlayer(o){
  usarCiclos({});
  const nat = NATIONS.find(n=>n.n===o.nat) || NATIONS[0];
  const attrs = baseAttrs(o.pos);
  const pot = {};
  const wPos = POSITIONS[o.pos].w;
  const wMax = Math.max(...ATTRS.map(({k}) => wPos[k] || 0), 0.01);
  const TECHO_LENTO = {com:[28,40], lid:[30,42]};
  ATTRS.forEach(({k})=>{
    const [lo,hi] = TECHO_LENTO[k] || [15,23];
    const rel = (wPos[k] || 0) / wMax;
    pot[k] = clamp(attrs[k] + R.i(lo,hi) + Math.round(rel*11), 30, 92);
  });

  const pot0 = {};
  ATTRS.forEach(({k})=>{ pot0[k] = pot[k]; });

  const traits = [];
  (o.draft||[]).forEach(pickId=>{
    const lg = LEGENDS.find(l=>l.id===pickId);
    if(!lg) return;
    pot[lg.attr] = clamp(pot[lg.attr] + Math.round(lg.boost*1.15), 30, 99);
    attrs[lg.attr] = clamp(attrs[lg.attr] + Math.round(lg.boost*0.30), 20, 75);
    traits.push(lg.trait);
  });
  const her = o.herencia || null;
  if(her && TRAITS[her.rasgo] && !traits.includes(her.rasgo)){
    traits.push(her.rasgo);
    const lh = leyendaDeRasgo(her.rasgo);
    if(lh){
      pot[lh.attr] = clamp(pot[lh.attr] + Math.round(lh.boost*1.15), 30, 99);
      attrs[lh.attr] = clamp(attrs[lh.attr] + Math.round(lh.boost*0.30), 20, 75);
    }
  }
  if(her && her.fama > 0){
    ATTRS.forEach(({k}) => { pot[k] = clamp(pot[k] + FAMA_TECHO*her.fama, 30, 99); });
  }

  const start = o.club? C(o.club) : startingClub(nat, o.pos, attrs, pot);
  const p = {
    name:(o.name||'').trim() || nombrePara(nat.n), nat:nat.n, flag:nat.f, conf:nat.conf, natStr:nat.str,
    pos:o.pos, num:o.num||10, foot:o.foot||'Derecha',
    age:16, year:(her && anioValido(her.anio)) ? her.anio : ANIO_BASE, attrs, pot, traits, stolen:(o.draft||[]).slice(),
    ovr:0, potOvr:0, segundas:0,
    moral:70, forma:60, fitness:100, rep:8, hype:0,
    club:start.id, clubYears:0, contract:3, wage:start.tier<=2? 0.06 : 0.16, value:0.5,
    capital:0,
    fanLove:55, mgrRel:60, injuryTag:null, injuredWeeks:0, retired:false,
    nemesis:null, nemesisAqui:false,
    career:{apps:0,goals:0,assists:0,motm:0,rating:0,ratingN:0,yellow:0,red:0,seasons:0},
    nt:{caps:0,goals:0,status:'ninguna',debut:null},
    adapt:100, loanFrom:null, loanMitades:0, loanTotal:0, loanYears:0,
    ligaPosDic:null, ligaPosFin:null, pot0, resto:{}, reconversion:0,
    qual:undefined, qualClub:null, ofertaPendiente:null,
    curva: R.f()<0.22? 'precoz' : R.f()<0.28? 'tardio' : 'normal',
    compRival:null, mgrFit:0, mgrNuevo:false, lastDev:1,
    difComp:1, difOfertas:1, difLesion:1,
    hidden: clamp(R.gauss(1,0.19), 0.55, 1.38), 
    fragil: R.f()<0.12,                          
    honours:[], seasons:[], timeline:[], momentos:[], bans:[], milestones:[],
    world:[], rivals:initRivals(),
    balones:0, botas:0, botasOro:0, mvpFinal:0, mvpMundial:0,
    ligas:0, copas:0, contis:0, contis2:0, mundiales:0, contiSel:0, cwc:0, inter:0,
    seenEvents:[], flags:{}, mem:{}, retireReason:null, peakOvr:0, peakClubRep:0
  };
  if(her){
    p.dinastia = {gen:her.gen, fama:her.fama, club:her.club};
    p.flags.heredero = true;
    if(her.fama >= 2) p.flags.apellidoPesado = true;
    p.hype = clamp(p.hype + 5*her.fama, 0, 100);
    p.rep = clamp(p.rep + 2*her.fama, 0, 100);
    if(p.club === her.club){ p.fanLove = clamp(p.fanLove + 8, 0, 100); p.flags.clubDelViejo = true; }
  }
  recalc(p);
  p.timeline.push({y:p.year, k:'Debuta en las inferiores de {club}', v:{club:C(p.club).n}, ic:'⚽'});
  p.ruta = [p.club];
  return p;
}

function startingClub(nat, pos, attrs, pot){
  const potAvg = ATTRS.reduce((s,{k})=>s+pot[k],0)/ATTRS.length;
  const home = CLUBS.filter(c=>L(c.lg).pais===nat.n);
  const pool = home.length? home : CLUBS.filter(c=>c.tier<=2);
  const maxTier = potAvg>66? 4 : potAvg>58? 3 : 2;
  const cands = pool.filter(c=>c.tier<=maxTier);
  return R.pick(cands.length?cands:pool);
}

const POS_CAL = {DFC:.955, LAT:.985, MCD:.975, MC:1.0, MCO:1.0, EXT:.995, DC:1.0};
function calcOvr(attrs, pos){
  const w = POSITIONS[pos].w;
  let s = 0; ATTRS.forEach(({k})=>{ s += attrs[k]*w[k]; });
  return clamp(Math.round(s*1.06*POS_CAL[pos] + 5), 30, 99);
}
function recalc(p){
  p.ovr = calcOvr(p.attrs, p.pos);
  p.potOvr = calcOvr(p.pot, p.pos);
  p.peakOvr = Math.max(p.peakOvr, p.ovr);
  p.value = marketValue(p);
}
function marketValue(p){
  const ageF = p.age<=20? 1.30 : p.age<=23? 1.34 : p.age<=26? 1.15 : p.age<=28? .95
             : p.age<=30? .70 : p.age<=32? .45 : p.age<=34? .24 : p.age<=36? .10 : .04;
  const base = Math.pow(Math.max(0,p.ovr-45)/10, 3.15) * 0.95;
  const v = base*ageF*(1+p.rep/260)*(1+p.hype/420);
  return round(clamp(v, 0.03, 250), v<1? 2 : 1);
}
const LG_WAGE = {1:0.34, 2:0.62, 3:1.0, 4:1.32, 5:1.75};
let GOLFO_SUELDO = 1.15;
function wageFor(value, lg, tier){
  let w = value*0.065*LG_WAGE[lg.money]*(0.55+tier*0.15);
  if(lg.id==='SAU') w *= GOLFO_SUELDO;
  return round(clamp(w, 0.02, 90), w<1? 2 : 1);
}
function squadLevel(club){ return 52 + club.tier*6 + (club.rep-50)*0.16; }
function has(p,t){ return p.traits.includes(t); }

function chanceDeQueSalga(p, k, mas){
  let v = (p.attrs[k] || 40) + (mas || 0);
  if(k==='com') v += temple(p)*8;
  v = clamp(v, 15, 105);
  let q = (v - 20) / 75;
  q += (p.forma - 60) * 0.0035;
  q += (p.moral - 60) * 0.0022;
  return clamp(q, 0.15, 0.90);
}
function resolverRiesgo(p, k, mas){ return R.f() < chanceDeQueSalga(p, k, mas); }

function temple(p){
  let t = ((p.attrs.com||40) - 50)/50;
  if(has(p,'hielo'))      t += 0.18;
  if(has(p,'clutch'))     t += 0.12;
  if(has(p,'sangrefria')) t += 0.08;
  return clamp(t, -1, 1.25);
}
function golesAereos(p, teamAtk){
  const dominio = clamp(((p.attrs.aer||40) - 46)/54, 0, 1);
  return (REMATE[p.pos]||.30) * dominio * 0.115 * teamAtk * (has(p,'torre')?1.25:1);
}
function jerarquiaPateador(p, club){
  let j = clamp(0.20 + ((p.attrs.peg||35) - squadLevel(club))/28, 0.03, 1);
  if(has(p,'pegada')) j = clamp(j + 0.30, 0, 1);
  if(has(p,'capitan') || has(p,'caudillo')) j = clamp(j + 0.10, 0, 1);
  return j;
}
function golesParados(p, club, teamAtk){
  const pegada = clamp(((p.attrs.peg||35) - 44)/56, 0, 1);
  return (PATEADOR[p.pos]||.40) * pegada * jerarquiaPateador(p, club) * 0.30 * teamAtk;
}
function arrastre(p){
  let a = (((p.attrs.lid||32) - 50)/50);
  if(has(p,'caudillo')) a += 0.20;
  if(has(p,'capitan'))  a += 0.10;
  if(has(p,'lider'))    a += 0.08;
  return clamp(a, -1, 1.30);
}

function scoutBand(p, k){
  const seed = ((p.name.charCodeAt(0)||65)*31 + k.charCodeAt(0)*7 + k.charCodeAt(1)*3) % 17;
  const unc = clamp(20 - (p.age-16)*1.35 - p.career.seasons*0.5, 3, 20);
  const mid = p.pot[k] + (seed-8)*0.9;
  return { lo: clamp(Math.round(mid-unc), p.attrs[k], 99),
           hi: clamp(Math.round(mid+unc), p.attrs[k]+1, 99) };
}

const POS_PEAK = {DC:27, EXT:26, MCO:27, MC:29, MCD:29, LAT:27, DFC:30};
const CURVAS = {
  precoz: {shift:-2, joven:1.28, tarde:0.80, n:'Precoz',  d:'Explotás muy joven y te apagás antes.'},
  normal: {shift: 0, joven:1.00, tarde:1.00, n:'Normal',  d:'Un desarrollo sin sobresaltos.'},
  tardio: {shift:+3, joven:0.72, tarde:1.34, n:'Tardío',  d:'Tardás en arrancar, pero seguís creciendo cuando otros ya bajaron.'}
};
const peakAgeOf = p => (POS_PEAK[p.pos]||28) + (CURVAS[p.curva||'normal'].shift);
function growthRate(p){
  const peak = peakAgeOf(p), a = p.age, c = CURVAS[p.curva||'normal'];
  if(a >= peak) return 0;                       
  const faltan = peak - a;
  let r = a<=18? .34 : a<=21? .30 : a<=24? .22 : clamp(0.05 + faltan*0.045, 0.02, 0.20);
  r *= (a<=21? c.joven : c.tarde);
  return r;
}
function sumarAtributo(p, k, g){
  if(!p.resto) p.resto = {};
  const bruto = p.attrs[k] + g + (p.resto[k] || 0);
  const nuevo = clamp(Math.round(bruto), 15, 99);
  p.resto[k] = clamp(bruto - nuevo, -0.99, 0.99);
  p.attrs[k] = nuevo;
  return nuevo;
}

const MARGEN_RECONVERSION = 16;
const TEMPORADAS_RECONVERSION = 3;
function reconvertir(p){
  const w = POSITIONS[p.pos].w;
  if(!p.pot0) p.pot0 = {...p.pot};
  ATTRS.forEach(({k})=>{
    if((w[k]||0) < 0.18) return;              
    const objetivo = clamp(p.attrs[k] + MARGEN_RECONVERSION, 15, 92);
    if(objetivo > p.pot[k]){
      p.pot[k] = objetivo;
      p.pot0[k] = Math.max(p.pot0[k] || 0, objetivo);
    }
  });
  p.reconversion = TEMPORADAS_RECONVERSION;
}

function develop(p, focus, minutesShare){
  if(p.age<=21) minutesShare = Math.max(minutesShare, 0.34);
  const rate = growthRate(p);
  const azar = 0.70 + R.f()*0.60;
  const mult = (0.30 + minutesShare*1.05)
             * (0.60 + p.moral/240)
             * (0.80 + p.mgrRel/420)
             * (1 + (C(p.club).tier-3)*0.06)
             * (has(p,'profesional')?1.12:1)
             * (p.hidden||1) * azar
             * (p.injuredWeeks>14?0.40:1);
  p.lastDev = mult;
  if(p.reconversion > 0) p.reconversion--;
  p.devWhy = mult>=1.42? 'despegue' : mult>=1.05? 'bien'
           : mult<=0.40? 'perdido'  : 'flojo';
  p.devCausa = p.injuredWeeks>14? 'lesion' : minutesShare<0.25? 'minutos'
             : p.moral<45? 'moral' : p.mgrRel<45? 'tecnico' : 'trabajo';
  const TECHO_EXTRA = 10;
  if(focus) focus.forEach(k=>{
    if(p.pot[k] == null || p.age > peakAgeOf(p)) return;
    const nacido = (p.pot0 && p.pot0[k] != null) ? p.pot0[k] : p.pot[k];
    const tope = nacido + TECHO_EXTRA;
    if(p.pot[k] < tope)
      p.pot[k] = clamp(Math.min(p.pot[k] + 0.7 * clamp(minutesShare, 0, 1), tope), 15, 99);
  });

  const gained = {};
  const wPuesto = POSITIONS[p.pos].w;
  const aprendiendo = k => (p.reconversion||0) > 0 && (wPuesto[k]||0) >= 0.18;
  ATTRS.forEach(({k})=>{
    if(k==='com' || k==='lid') return;               
    const gap = p.pot[k]-p.attrs[k];
    const rateK = aprendiendo(k) ? Math.max(rate, 0.22) : rate;
    let g = gap>0 ? gap*rateK*mult*(0.52 + 0.48*clamp(gap/26,0,1)) : 0;
    g *= (focus && focus.includes(k)) ? 2.30 : 0.52;   
    const peak = peakAgeOf(p);
    if(p.age > peak){
      const decl = {rit:1.85, fis:1.5, reg:1.05, aer:.80, fil:.7, dfs:.42, pas:.10, def:.30, peg:.06, pmm:.08}[k];
      let d = decl*(p.age-peak)*0.44;
      if(k==='rit' && has(p,'turbo')) d*=0.55;
      if(has(p,'profesional')) d*=0.75;
      if(has(p,'muro')) d*=0.85;
      if(focus && focus.includes(k)) d *= 0.50;
      g -= d;
    }
    const before=p.attrs[k];
    p.attrs[k] = sumarAtributo(p, k, g);
    gained[k]=p.attrs[k]-before;
  });
  const crecerLento = (k, roce) => {
    const antes = p.attrs[k], gap = p.pot[k] - p.attrs[k];
    if(gap > 0){
      const trabajo = (focus && focus.includes(k)) ? 1.75 : 0.80;
      sumarAtributo(p, k, Math.min(gap, roce*trabajo*(0.45 + 0.55*clamp(gap/24,0,1))));
    }
    gained[k] = p.attrs[k] - antes;
  };
  const finales = (p.honours||[]).filter(h=>h.tipo==='conti'||h.tipo==='conti2'||h.tipo==='seleccion').length;
  crecerLento('com', 1.0 + Math.min(p.career.seasons,15)*0.14 + Math.min(finales,8)*0.32);
  crecerLento('lid', 1.05
    + clamp(p.age-19, 0, 14)*0.22
    + Math.min(p.clubYears||0, 8)*0.28
    + (p.mgrRel>68?0.60:0) + (p.fanLove>70?0.60:0)
    + (has(p,'capitan')||has(p,'lider')||has(p,'caudillo') ? 1.70 : 0)
    + (p.nt && p.nt.status==='capitán' ? 1.10 : 0));
  if(p.age<=22 && p.forma>82 && R.chance(0.16)){
    const donde = (focus && focus.length) ? R.pick(focus) : R.pick(ATTRS).k;
    p.pot[donde] = clamp(p.pot[donde] + R.i(1,3), 30, 99);
  }
  recalc(p);
  return gained;
}

function squadUpdate(p){
  const club = C(p.club);
  if(p.compRival){
    p.compRival.age++;
    if(p.compRival.age>=33 || R.chance(0.22)) p.compRival = null;      
    else if(p.compRival.age<=26) p.compRival.ovr = clamp(p.compRival.ovr + R.i(0,2), 40, 93);
  }
  const pr = clamp(0.09 + club.tier*0.045 - (p.ovr-squadLevel(club))*0.010, 0.03, 0.38) * (p.difComp||1);
  if(!p.compRival && R.chance(pr)){
    const [nat,flag,pool] = R.pick(NAT_POOL);
    p.compRival = { name:`${R.pick(NAMES_F[pool])} ${R.pick(NAMES_L[pool])}`, flag,
                    ovr: clamp(Math.round(squadLevel(club) + R.i(-4,5)), 48, 92), age: R.i(20,28), nuevo:true };
  } else if(p.compRival) p.compRival.nuevo = false;
  p.nemesisAqui = false;
  if(R.chance(0.30)){
    p.mgrRel = clamp(R.i(38,66), 0, 100);
    p.mgrFit = R.i(-9, 9);
    p.mgrNuevo = true;
    nemesisAlBanco(p);
  } else p.mgrNuevo = false;
  guardarNemesis(p);
}

function guardarNemesis(p){
  if(p.mgrRel >= 25 || p.nemesis) return;
  const [nat,flag,pool] = R.pick(NAT_POOL);
  p.nemesis = { name:`${R.pick(NAMES_F[pool])} ${R.pick(NAMES_L[pool])}`, flag,
                desde: p.year, club: C(p.club) ? C(p.club).n : '' };
}
function nemesisAlBanco(p){
  if(!p.nemesis) return;
  const club = C(p.club);
  const vueltas = p.nemesis.vueltas || 0;
  if(p.nemesis.ultima != null && p.year - p.nemesis.ultima < 3) return;
  const pr = (0.07 + (club ? club.tier*0.018 : 0)) * Math.pow(0.45, vueltas);
  if(!R.chance(pr)) return;
  p.mgrRel = clamp(R.i(8, 22), 0, 100);
  p.mgrFit = R.i(-14, -4);
  p.nemesisAqui = true;
  p.nemesis.vueltas = vueltas + 1;
  p.nemesis.ultima = p.year;
}
function minutosProyectados(p, club){
  const sq = varaDe(p, club, squadLevel(club));
  let s = 0.30 + (p.ovr - sq)*0.062;
  s += (p.mgrRel!=null ? 58-60 : 0)*0.0040;       
  s += (p.forma-60)*0.0020;
  s += p.rep*0.0012;
  s += arrastre(p)*0.032;
  s -= penaEdad(p, club);
  if(p.age>=33) s -= (p.age-32)*0.075;
  if(has(p,'incansable')) s += 0.07;
  s += ajusteFilosofia(p, club);
  s -= 0.09;
  s = 0.318 + 0.535*s;
  return clamp(s, 0.05, 0.90);
}
function rolPorMinutos(m){
  return m>=0.72 ? 'Figura del equipo'
       : m>=0.52 ? 'Titular indiscutido'
       : m>=0.32 ? 'Rotación de lujo'
       : 'Suplente con proyección';
}
function minutesShare(p){
  const club = C(p.club), sq = squadLevel(club);
  const vara = varaDe(p, club, p.compRival? Math.max(sq, p.compRival.ovr - 3) : sq);
  let s = 0.30 + (p.ovr - vara)*0.062;
  s += (p.mgrFit||0)*0.011;
  s += (p.mgrRel-60)*0.0040;
  s += (p.forma-60)*0.0020;
  s += p.rep*0.0012;
  s += arrastre(p)*0.032;          
  s -= penaEdad(p, club);
  if(p.age>=33) s -= (p.age-32)*0.075;
  if(has(p,'incansable')) s += 0.07;
  if(has(p,'idolo') && p.clubYears>=4) s += 0.05;
  s += ajusteFilosofia(p, club);
  return clamp(s, 0.02, 0.97);
}
function varaDe(p, club, base){
  if(p.age > 21) return base;
  const f = filosofiaDe(club);
  return base + (f==='cantera' ? -7 : f==='vender' ? -3 : f==='comprar' ? 4 : -1);
}
function ajusteFilosofia(p, club){
  const f = filosofiaDe(club);
  const veterano = p.age >= 32;
  if(f === 'cantera') return veterano ? -0.04 : 0.01;
  if(f === 'comprar') return veterano ?  0.02 : 0;
  if(f === 'vender')  return veterano ? -0.05 : 0;
  return 0.02;   
}
function penaEdad(p, club){
  let pen = p.age<=17 ? 0.24 : p.age===18 ? 0.17 : p.age===19 ? 0.10 : p.age===20 ? 0.04 : 0;
  if(!pen) return 0;
  const f = filosofiaDe(club);
  return pen * (f==='cantera' ? 0.40 : f==='vender' ? 0.70 : f==='comprar' ? 1.35 : 0.85);
}

function injuryRoll(p){
  let base = 0.19 + (p.age>=31?(p.age-30)*0.035:0) + (p.age<=18?0.04:0);
  base *= (100-p.fitness)/100*0.9 + 0.75;
  if(has(p,'muro')) base *= 0.62;
  if(has(p,'cristal')) base *= 1.85;
  if(p.fragil) base *= 1.55;
  if(has(p,'incansable')) base *= 0.85;
  if(!R.chance(base*(p.difLesion||1))) return null;
  const t = R.f();
  if(t<0.50) return {n:'Desgarro muscular', w:R.i(3,7)};
  if(t<0.72) return {n:'Esguince de tobillo', w:R.i(4,9)};
  if(t<0.86) return {n:'Fractura de peroné', w:R.i(10,18)};
  if(t<0.95) return {n:'Rotura de meniscos', w:R.i(14,24)};
  return {n:'Rotura de ligamento cruzado', w:R.i(26,40)};
}

const CONT_CUP2 = { EUR:'UEFA Europa League', SUD:'Copa Sudamericana' };
const FIFA_CWC   = 'Mundial de Clubes';
const FIFA_INTER = 'Copa Intercontinental';
const CWC_PLAZAS = {EUR:8, SUD:5, CON:3};
const INTER_RONDAS = ['Derbi de las Américas'];
const _rankCache = {};
function leagueRank(club){
  if(_rankCache[club.id]) return _rankCache[club.id];
  const misma = CLUBS.filter(c=>c.lg===club.lg && enSegunda(c)===enSegunda(club));
  misma.slice().sort((a,b)=>b.rep-a.rep).forEach((c,i)=>{ _rankCache[c.id]=i+1; });
  return _rankCache[club.id] || 1;
}

function contiSlots(lg){
  if(!lg.cont) return [0,0];
  if(lg.cont==='EUR') return lg.str>=5? [4,3] : lg.str>=4? [4,2] : [3,2];
  if(lg.cont==='SUD'){
    return lg.id === 'BRA' ? [6,4] : [5,4];
  }
  return [3,0];                       
}
function qualifyFrom(club, pos, cupWin, wonContiA){
  if(enSegunda(club)) return null;
  const lg = L(club.lg), [a,b] = contiSlots(lg);
  const hay2 = !!CONT_CUP2[lg.cont];
  if(wonContiA) return 'A';                    
  if(pos<=a)    return 'A';
  if(!hay2)     return null;
  if(cupWin)    return 'B';                    
  if(pos<=a+b)  return 'B';
  return null;
}
function defaultQual(club){
  return qualifyFrom(club, leagueRank(club), false, false);
}
function currentQual(p, club){
  if(enSegunda(club)) return null;
  if(p && p.qualClub===club.id && p.qual!==undefined) return p.qual;
  return defaultQual(club);
}

let _div2 = {};                     
const _primeraCache = {};           
function usarDivisiones(d){
  _div2 = d || {};
  Object.keys(_rankCache).forEach(k=>{ delete _rankCache[k]; });
  Object.keys(_primeraCache).forEach(k=>{ delete _primeraCache[k]; });
  Object.keys(_sizeCache).forEach(k=>{ delete _sizeCache[k]; });
}
const paisConLiga = p => LEAGUES.some(l => l.pais === p.nat);
const lejosDeCasa = p => !!(p.ruta && p.ruta.length && p.ruta[0] !== p.club && C(p.ruta[0]));
const enPrimera = club => !_div2[club.id];
const enSegunda = club => !!_div2[club.id];
function clubesDe(lgId){
  return _primeraCache[lgId] || (_primeraCache[lgId] = CLUBS.filter(c=>c.lg===lgId && !_div2[c.id]));
}

function iniciarDivisiones(p){
  const d = {};
  LEAGUES.forEach(lg=>{
    const cl = CLUBS.filter(c=>c.lg===lg.id).slice().sort((a,b)=>b.rep-a.rep);
    cl.slice(lg.div1).forEach(c=>{ d[c.id] = true; });
  });
  p.div2 = d;
  usarDivisiones(d);
  return d;
}

const BAJAN = 2;
function moverDivisiones(p, tablas, tablas2){
  if(!p.div2) iniciarDivisiones(p);
  const movidos = [];
  LEAGUES.forEach(lg=>{
    const tabla = tablas && tablas[lg.id];
    if(!tabla || tabla.length < 6) return;
    const orden = tabla.map(r => Array.isArray(r) ? r[0] : r.id);
    const bajan = orden.slice(-BAJAN);
    const t2 = tablas2 && tablas2[lg.id];
    const abajo = CLUBS.filter(c=>c.lg===lg.id && p.div2[c.id])
      .slice().sort((a,b)=>clubPower(b)-clubPower(a));
    const suben = (t2 && t2.length >= BAJAN)
      ? t2.slice(0, BAJAN).map(r => Array.isArray(r) ? r[0] : r.id)
      : abajo.slice(0, BAJAN).map(c=>c.id);
    bajan.forEach(id=>{ p.div2[id] = true;  movidos.push({id, sube:false, lg:lg.id}); });
    suben.forEach(id=>{ delete p.div2[id];  movidos.push({id, sube:true,  lg:lg.id}); });
  });
  usarDivisiones(p.div2);
  return movidos;
}

const _sizeCache = {};
function leagueSize(club){
  const k = club.lg + (enSegunda(club)?'2':'1');
  return _sizeCache[k] != null ? _sizeCache[k]
    : (_sizeCache[k] = CLUBS.filter(c=>c.lg===club.lg && enSegunda(c)===enSegunda(club)).length);
}

function compsFor(p, club){
  const lg = L(club.lg);
  const key = currentQual(p, club);
  const conti = key==='A' ? CONT_CUP[lg.cont] : key==='B' ? CONT_CUP2[lg.cont] : null;
  const liga = enSegunda(club) ? (lg.div2n || (lg.n+' · 2ª')) : lg.n;
  return {
    liga, copa: lg.copa, sup: lg.sup, rank: leagueRank(club),
    conti, contiKey:key, cont: lg.cont,
    gLiga: 38, gCopa: 4 + (club.tier>=4?2:0), gConti: conti? (key==='A'?10:8) : 0
  };
}
const clubComps = club => compsFor(null, club);
function totalGames(p, club){ const c=compsFor(p,club); return c.gLiga+c.gCopa+c.gConti; }

function contiRivals(p, club){
  const lg = L(club.lg), key = currentQual(p, club);
  if(!key) return [];
  const sameConf = CLUBS.filter(c=>L(c.lg).cont===lg.cont && c.id!==club.id);
  let pool = sameConf.filter(c=>defaultQual(c)===key);
  if(pool.length<6) pool = pool.concat(sameConf.filter(c=>!pool.includes(c) && defaultQual(c)));
  if(!pool.length) pool = sameConf;
  const fuera = pool.filter(c=>L(c.lg).pais!==lg.pais);
  const casa  = pool.filter(c=>L(c.lg).pais===lg.pais);
  const elegidos = fuera.length? fuera.slice() : pool.slice();
  elegidos.compatriotas = casa;
  return elegidos;
}

function expectedPos(p, club){
  const cuota = clamp(minutesShare(p)*1.3, 0.12, 1);
  const bruto = p.ovr>squadLevel(club) ? (p.ovr-squadLevel(club))/9.5 : (p.ovr-squadLevel(club))/16;
  const boost = bruto * cuota;
  return clamp(leagueRank(club) + 0.35 - boost - arrastre(p)*0.55, 0.6, leagueSize(club));
}

function money0(v){
  if(v>=10) return `US$${Math.round(v)}M`;
  if(v>=1)  return `US$${v.toFixed(1)}M`;
  return `US$${Math.round(v*1000)}K`;
}
function poisson(l){
  let k=0, pr=1, e=Math.exp(-l);
  do { k++; pr*=R.f(); } while(pr>e && k<12);
  return k-1;
}
const COMP_LABEL = {liga:'LIGA', copa:'COPA', conti:'CONT', res:'RES'};
const CONT_ROUNDS = {
  EUR: {
    A:['Fase de liga','Fase de liga','Fase de liga','Fase de liga','Play-off','Octavos','Cuartos','Cuartos','Semifinal','FINAL'],
    B:['Fase de liga','Fase de liga','Fase de liga','Play-off','Octavos','Cuartos','Semifinal','FINAL']
  },
  SUD: {
    A:['Fase de grupos','Fase de grupos','Fase de grupos','Octavos','Octavos','Cuartos','Cuartos','Semifinal','Semifinal','FINAL'],
    B:['Fase de grupos','Fase de grupos','Play-off','Octavos','Cuartos','Cuartos','Semifinal','FINAL']
  },
  CON: {
    A:['Primera ronda','Primera ronda','Octavos','Octavos','Cuartos','Cuartos','Semifinal','Semifinal','FINAL','FINAL'],
    B:['Primera ronda','Octavos','Octavos','Cuartos','Cuartos','Semifinal','Semifinal','FINAL']
  }
};
const rondasDe = (cont, key) => (CONT_ROUNDS[cont] || CONT_ROUNDS.EUR)[key==='A'?'A':'B'];

function buildHalf(p, h){
  const club = C(h.clubId), lg = L(club.lg), cp = compsFor(p, club);
  const ms = [];
  const domestic = CLUBS.filter(c=>c.lg===lg.id && c.id!==club.id);
  const mismos = domestic.filter(c=>enSegunda(c)===enSegunda(club));
  const liguero = mismos.length? mismos : domestic;
  const copaPool = lg.copaCruza
    ? domestic.concat(CLUBS.filter(c=>c.lg===lg.copaCruza))
    : domestic;
  const contiPool = contiRivals(p, club);
  const rounds = rondasDe(lg.cont, cp.contiKey);
  const offset = h.half===0? 0 : Math.ceil(rounds.length/2);

  const add = (comp, pool, ronda) => {
    const paisanos = pool.compatriotas || [];
    const eliminatoria = ronda && !/grupos|fase de liga/i.test(ronda);
    const usar = (comp==='conti' && eliminatoria && paisanos.length && R.chance(0.18)) ? paisanos : pool;
    const opp = R.pick(usar.length? usar : liguero);
    ms.push({comp, opp:opp.id, oppN:opp.n, home:R.chance(0.5), ronda,
             g:0, a:0, gf:0, ga:0, rat:0, oppPow: clubPower(opp)});
  };
  (h.comps||[]).forEach(c=>{
    if(!c.apps) return;
    if(c.n===cp.liga)  for(let i=0;i<c.apps;i++) add('liga', liguero);
    else if(c.n===cp.copa) for(let i=0;i<c.apps;i++) add('copa', copaPool, cp.copa);
    else for(let i=0;i<c.apps;i++) add('conti', contiPool, rounds[Math.min(offset+i, rounds.length-1)]);
  });
  (h.comps||[]).forEach(c=>{
    const own = ms.filter(m=>
      (c.n===cp.liga && m.comp==='liga') ||
      (c.n===cp.copa && m.comp==='copa') ||
      (c.n===cp.conti && m.comp==='conti'));
    if(!own.length) return;
    for(let i=0;i<c.goals;i++)   own[Math.floor(R.f()*own.length)].g++;
    for(let i=0;i<c.assists;i++) own[Math.floor(R.f()*own.length)].a++;
  });
  const totalMitad = Math.round(totalGames(p, club)/2);
  const faltan = Math.max(0, totalMitad - (h.apps||0));
  if(faltan){
    const porLesion = clamp(Math.round(faltan * clamp((p.injuredWeeks||0)/19, 0, 1)), 0, faltan);
    const share = (h.share||0)/100;
    const pesos = [cp.gLiga, cp.gCopa].concat(cp.conti? [cp.gConti] : []);
    const reparto = splitByComp(faltan, pesos);
    let n = 0;
    reparto.forEach((cant, idx)=>{
      const comp = idx===0? 'liga' : idx===1? 'copa' : 'conti';
      const pool = comp==='conti'? contiPool : comp==='copa'? copaPool : liguero;
      for(let i=0;i<cant;i++){
        const opp = R.pick(pool.length? pool : liguero);
        const motivo = n < porLesion ? 'lesion'
                     : (R.chance(clamp(0.30 + share*1.15, 0.08, 0.94)) ? 'banco' : 'fuera');
        n++;
        ms.push({comp, opp:opp.id, oppN:opp.n, home:R.chance(0.5), ronda:null,
                 g:0, a:0, gf:0, ga:0, rat:0, oppPow:clubPower(opp),
                 noJugado:true, motivo});
      }
    });
  }

  if(h.resApps){
    const res=[];
    for(let i=0;i<h.resApps;i++){
      const opp=R.pick(liguero.length?liguero:CLUBS);
      res.push({comp:'res', opp:opp.id, oppN:opp.n, home:R.chance(0.5), ronda:'Reserva',
                g:0, a:0, gf:0, ga:0, rat:0, oppPow:clubPower(opp)*0.55, reserva:true});
    }
    for(let i=0;i<h.resGoals;i++) res[Math.floor(R.f()*res.length)].g++;
    for(const m of res) ms.splice(Math.floor(R.f()*(ms.length+1)), 0, m);
  }
  const myPow = clubPower(club);
  const tem = temple(p);
  ms.forEach(m=>{
    const edge = (myPow - m.oppPow)/26 + (m.home?0.34:-0.16);
    const extra = poisson(Math.max(0.15, 0.95 + edge*0.42));
    m.gf = Math.max(m.g + m.a, m.g + m.a + extra - Math.round(m.a*0.6));
    m.ga = poisson(Math.max(0.12, 1.05 - edge*0.44));
    m.res = m.gf>m.ga? 'G' : m.gf===m.ga? 'E' : 'P';
    const peso = m.ronda==='FINAL' ? 1.00
               : (m.ronda && !/grupos|Reserva/i.test(m.ronda)) ? 0.55
               : m.comp==='conti' ? 0.22 : 0;
    const hostil = m.home? 0 : 0.20;
    m.rat = round(clamp(h.rating + R.gauss(0,0.45) + m.g*0.55 + m.a*0.32
             + (m.res==='G'?0.12:m.res==='P'?-0.18:0)
             + tem*(peso*0.62 + hostil*0.55), 4.4, 10), 1);
    if(m.ronda==='FINAL') m.decisiva = true;
  });
  return ms;
}

function runningTotals(ms, i){
  let g=0,a=0,pj=0,rs=0,rpj=0,rg=0,gan=0,banco=0,lesion=0,fuera=0;
  for(let k=0;k<=i;k++){ const m=ms[k];
    if(m.noJugado){
      if(m.motivo==='lesion') lesion++; else if(m.motivo==='banco') banco++; else fuera++;
    } else if(m.reserva){ rpj++; rg+=m.g; }
    else { pj++; g+=m.g; a+=m.a; rs+=m.rat; if(m.res==='G') gan++; } }
  return {pj, g, a, gan, rat: pj? round(rs/pj,2) : 0, rpj, rg, banco, lesion, fuera};
}

function splitByComp(total, weights){
  const sum = weights.reduce((a,b)=>a+b,0);
  if(!sum || !total) return weights.map(()=>0);
  const raw = weights.map(w=>total*w/sum);
  const out = raw.map(v=>Math.floor(v));
  let rest = total - out.reduce((a,b)=>a+b,0);
  const order = raw.map((v,i)=>[v-Math.floor(v), i]).sort((a,b)=>b[0]-a[0]);
  for(let k=0; rest>0; k++, rest--) out[order[k%order.length][1]]++;
  return out;
}

function startSeasonPlan(p){
  moverCiclos(p);
  p.ligaPosDic = null; p.ligaPosFin = null;
  const inj = injuryRoll(p);
  p.injuryTag = inj? inj.n : null;
  p.injuredWeeks = inj? inj.w : 0;
  return {inj};
}

const G_TOPES = {
  goles:       { veces: 0, recorte: 0, muro: 0 },
  asistencias: { veces: 0, recorte: 0, muro: 0 }
};
function topesLimpiar(){
  for(const k in G_TOPES) G_TOPES[k] = { veces: 0, recorte: 0, muro: 0 };
}
function topesLeer(){ return JSON.parse(JSON.stringify(G_TOPES)); }

const SEMANAS_MITAD = 19;
function semanasPerdidas(p, half){
  const total = p.injuredWeeks || 0;
  return half === 0 ? Math.min(total, SEMANAS_MITAD)
                    : Math.max(0, Math.min(total, SEMANAS_MITAD * 2) - SEMANAS_MITAD);
}

function simHalf(p, half){
  const club = C(p.club), lg = L(club.lg), cp = compsFor(p, club);
  const share0 = minutesShare(p);
  const adaptPen = p.adapt<100 ? (100-p.adapt)/100*0.22 : 0;
  const availability = clamp(1 - semanasPerdidas(p, half)/SEMANAS_MITAD, 0.06, 1);
  const share = clamp(share0*availability*(1-adaptPen), 0.01, 0.97);

  const games = Math.round(totalGames(p, club)/2);
  const apps = clamp(Math.round(games*share), 0, games);
  const min90 = apps*(0.72+share*0.28);

  const perf = (p.ovr - 55)/45;
  const teamAtk = 0.72 + club.tier*0.11;
  const lgDif = 1.18 - lg.str*0.05;
  const formF = 0.80 + p.forma/300;
  const moralF = 0.88 + p.moral/500;
  const P = POSITIONS[p.pos];

  let gpg = P.gol * (0.10 + Math.pow(clamp(perf,0,1),1.45)*1.02) * teamAtk * lgDif * formF * moralF;
  let apg = P.asi * (0.06 + Math.pow(clamp(perf,0,1),1.45)*0.50) * teamAtk * lgDif * formF;
  if(has(p,'metronomo')) apg *= 1.18;
  if(has(p,'sangrefria')) gpg *= 1.10;
  if(has(p,'gambeta')) { gpg*=1.05; apg*=1.06; }
  gpg += golesAereos(p, teamAtk) + golesParados(p, club, teamAtk);

  let goals   = Math.max(0, Math.round(R.gauss(gpg*min90, Math.sqrt(Math.max(1,gpg*min90))*1.15)));
  let assists = Math.max(0, Math.round(R.gauss(apg*min90, Math.sqrt(Math.max(1,apg*min90))*1.1)));
  if(apps===0){ goals=0; assists=0; }
  const blando = (v, techo, dureza, muro, quien) => {
    if(v <= techo) return v;
    const r = Math.min(Math.round(techo + (v - techo) * dureza), Math.round(muro));
    const t = G_TOPES[quien];
    t.veces++; t.recorte += v - r; if(v >= muro) t.muro++;
    return r;
  };
  goals   = blando(goals,   apps*1.05, 0.45, apps*1.60, 'goles');
  assists = blando(assists, apps*0.90, 0.45, apps*1.35, 'asistencias');

  const tem = temple(p);
  const rating = clamp(5.55 + perf*1.55 + (p.forma-60)*0.006
    + R.gauss(0, 0.16*(1 - tem*0.30)) + tem*0.055
    - adaptPen*1.6*(1 - Math.max(0,tem)*0.35) + (has(p,'metronomo')?0.08:0)
    + (goals+assists)/Math.max(8,apps)*0.42, 4.6, 9.6);

  const names   = [cp.liga, cp.copa].concat(cp.conti? [cp.conti] : []);
  const weights = [cp.gLiga, cp.gCopa].concat(cp.conti? [cp.gConti] : []);
  const wa = weights.map((w,i)=> w * (i===2? 1.05 : 1));   
  const aSplit = splitByComp(apps, wa);
  const gSplit = splitByComp(goals, aSplit.map(a=>Math.max(a,0.01)));
  const sSplit = splitByComp(assists, aSplit.map(a=>Math.max(a,0.01)));
  const comps = names.map((n,i)=>({n, apps:aSplit[i], goals:gSplit[i], assists:sSplit[i]}));

  const nT = leagueSize(club);
  const esperada = expectedPos(p, club);
  const ancla = half === 0 || p.ligaPosDic == null
    ? esperada
    : (esperada + p.ligaPosDic) / 2;
  const pos = clamp(Math.round(R.gauss(ancla, 2.3)), 1, nT);
  if(half === 0) p.ligaPosDic = pos;
  p.ligaPosFin = pos;                 
  const pj = Math.round(cp.gLiga/2);
  const pts = clamp(Math.round(pj*(2.42 - (pos-1)/nT*1.75) + R.gauss(0,2)), 4, pj*3);

  let resApps=0, resGoals=0;
  if(p.age<=21 && apps<14){
    resApps = clamp(Math.round((15-apps)*(0.55+R.f()*0.55)), 0, 15);
    const rg = POSITIONS[p.pos].gol*0.50*clamp((p.ovr-42)/28, 0.25, 1.7);
    resGoals = Math.max(0, Math.round(R.gauss(rg*resApps, 1.6)));
  }

  return {half, clubId:p.club, club:club.n, league:lg.n, apps, goals, assists,
          comps, ligaPos:pos, ligaPts:pts, ligaPj:pj, resApps, resGoals,
          rating:round(rating,2), share:round(share*100,0)};
}

function mergeComps(halves){
  const map = new Map();
  halves.forEach(h=>(h.comps||[]).forEach(c=>{
    const e = map.get(c.n) || {n:c.n, apps:0, goals:0, assists:0};
    e.apps+=c.apps; e.goals+=c.goals; e.assists+=c.assists;
    map.set(c.n, e);
  }));
  return [...map.values()];
}

function finishSeason(p, halves){
  const club = C(p.club), lg = L(club.lg), cp = compsFor(p, club);
  const apps    = halves.reduce((s,h)=>s+h.apps,0);
  const goals   = halves.reduce((s,h)=>s+h.goals,0);
  const assists = halves.reduce((s,h)=>s+h.assists,0);
  const rating  = apps          ? round(halves.reduce((s,h)=>s+h.rating*h.apps,0)/apps,2)
                : halves.length ? round(halves.reduce((s,h)=>s+h.rating,0)/halves.length,2)
                : 6.0;
  const share   = Math.round(halves.reduce((s,h)=>s+h.share,0)/halves.length);
  const P = POSITIONS[p.pos];

  const motm = Math.max(0, Math.round((rating-6.4)*apps*0.13 + R.gauss(0,1)));
  const yellow = Math.round(apps*(0.09 + P.w.dfs*0.35)*R.f()*2);
  const red = R.chance(0.10+P.w.dfs*0.25)?1:0;

  const nT = leagueSize(club), exp = expectedPos(p, club);
  const titles = [];
  const leaguePos = clamp(p.ligaPosFin != null ? p.ligaPosFin : Math.round(exp), 1, nT);
  let ligaWin;
  if(lg.playoff && enPrimera(club)){
    const entra = leaguePos <= lg.playoff;
    const nervio0 = 1 + temple(p)*0.20;
    ligaWin = entra && R.chance(clamp((0.42 - (leaguePos-1)*0.052)*nervio0, 0.03, 0.52));
    if(entra && !ligaWin && leaguePos===1) titles.push({n:lg.regular, tipo:'regular'});
  } else {
    ligaWin = leaguePos===1;
  }
  if(ligaWin){
    if(enSegunda(club)){
      titles.push({n:lg.div2n || (lg.n+' · 2ª'), tipo:'segunda'});
      p.segundas = (p.segundas||0) + 1;
    } else {
      titles.push({n:lg.n, tipo:'liga'});
      p.ligas++;
    }
  }

  const nervio = 1 + temple(p)*0.20;
  const arr = arrastre(p);   

  const expCopa = enSegunda(club) ? exp + clubesDe(club.lg).length : exp;
  if(R.chance(clamp((0.33 - (expCopa-1)*0.050)*nervio, 0.02, 0.38))){ titles.push({n:lg.copa, tipo:'copa'}); p.copas++; }

  if(cp.conti){
    const rivales = contiRivals(p, club).length + 1;
    const fuerza = clamp((squadLevel(club) + (p.ovr>squadLevel(club)?(p.ovr-squadLevel(club))*0.5:0) - 58)/26, 0.05, 1.6);
    const base = cp.contiKey==='A' ? 1.5/rivales : 2.3/rivales;
    if(R.chance(clamp(base*fuerza*(1.25-lg.str*0.05)*nervio, 0.01, 0.46))){
      titles.push({n:cp.conti, tipo: cp.contiKey==='A'?'conti':'conti2'});
      if(cp.contiKey==='A') p.contis++; else p.contis2 = (p.contis2||0)+1;
    }
  }
  if(titles.some(t=>t.tipo==='liga'||t.tipo==='conti') && R.chance(0.35)){
    titles.push({n:lg.sup, tipo:'super'});
  }

  const primas = titles.reduce((s,t)=>
    s + (t.tipo==='conti'?0.9 : t.tipo==='liga'?0.6 : t.tipo==='conti2'?0.35 : 0.2), 0) * p.wage * 0.5;
  const tren = p.wage * clamp(0.42 + p.rep/260 + p.hype/900, 0.42, 0.78);
  p.capital = round(Math.max(0, (p.capital||0) + p.wage + primas - tren), 2);

  const ntRes = simNational(p, rating, goals, apps);

  const awards = [];
  const brilliance = (rating-6.2)*2.4 + goals*0.055 + assists*0.045 + titles.length*0.75
                   + (p.ovr-72)*0.10 + (club.tier-3)*0.35 + (ligaWin?0.9:0) + p.hype*0.012;
  if(apps>18){
    if(P.gol>=.5 && goals>=24 && R.chance(clamp((goals-23)/40,0,0.60))){
      awards.push('Máximo goleador de la '+cp.liga); p.botas++; }
    if(goals>=30 && R.chance(clamp((goals-29)/26,0,0.55)*(lg.str>=4?1.2:0.7))
       && lg.cont==='EUR' && !enSegunda(club)){
      awards.push('🥇 Bota de Oro'); p.botasOro++; }
    if(R.chance(clamp((brilliance-2.2)/8,0,0.45))) awards.push('MVP de la '+cp.liga);
    if(p.age<=21 && R.chance(clamp((brilliance-0.8)/5.5,0,0.55))) awards.push('Joya del Año');
    if(R.chance(clamp((brilliance-1.6)/6,0,0.60))) awards.push('Once Ideal Mundial');
    const contiTitle = titles.find(t=>t.tipo==='conti'||t.tipo==='conti2');
    const copaG = mergeComps(halves).find(c=>c.n===cp.copa);
    if(P.gol>=.5 && copaG && copaG.goals>=3 && R.chance(clamp((copaG.goals-2)/6,0,0.40)))
      awards.push('Máximo goleador de la '+cp.copa);
    if(cp.conti){
      const cg = mergeComps(halves).find(c=>c.n===cp.conti);
      if(P.gol>=.5 && cg && cg.goals>=5 && R.chance(clamp((cg.goals-4)/9,0,0.42)))
        awards.push('Máximo goleador de la '+cp.conti);
      if(contiTitle && R.chance(clamp((rating-6.1)*0.75*nervio, 0, 0.75))){
        awards.push('MVP de la final de la '+cp.conti); p.mvpFinal++; }
    }
    const escaparate = (lg.str-4)*0.80 + (cp.conti? 0.55 : -0.85);
    const aporte = goals + assists*0.75;
    const escala = lg.str>=4 ? 1 : lg.str>=3 ? 1.45 : 2.0;   
    const porNumeros = P.gol>=.5  ? aporte >= 26*escala      
                     : P.gol>=.25 ? aporte >= 19*escala      
                     : false;                                
    const porGesta   = ntRes.majorTitle && rating>=7.45;     
    const temporadaEnorme = rating>=7.05 && apps>=30 && (porNumeros || porGesta);
    const balonP = temporadaEnorme
      ? clamp((brilliance + escaparate - 6.4)/11, 0, 0.34)
        * (ntRes.majorTitle?1.9:1)
        * (titles.some(t=>t.tipo==='conti') ? (CONTI_BALON[lg.cont] || 1.7) : 1)
      : 0;
    if(R.chance(balonP)){ awards.push('🏆 Balón de Oro'); p.balones++; }
  }
  if(ntRes.mundialRun){
    if(R.chance(clamp((rating-6.9)*0.30 + (ntRes.majorTitle?0.26:0), 0, 0.34))){
      awards.push('⚽ Balón de Oro del Mundial'); p.mvpMundial++; }
    if(P.gol>=.5 && R.chance(clamp((rating-6.4)*0.30, 0, 0.28)))
      awards.push('Máximo goleador del Mundial');
  }

  p.career.apps+=apps; p.career.goals+=goals; p.career.assists+=assists; p.career.motm+=motm;
  p.career.rating+=rating*apps; p.career.ratingN+=apps;
  p.career.yellow+=yellow; p.career.red+=red; p.career.seasons++;

  const repGain = (rating-6.3)*4 + titles.length*4 + awards.length*5 + (goals+assists)*0.10
                + (club.tier-3)*1.6 + ntRes.repGain;
  p.rep = clamp(round(p.rep + repGain,0), 0, 100);
  p.hype = clamp(round(p.hype*0.62 + repGain*1.4,0), 0, 100);
  p.forma = clamp(round(55 + (rating-6.3)*22 + R.gauss(0,6),0), 20, 99);
  p.moral = clamp(round(p.moral*0.55 + 45 + titles.length*7 + (rating-6.4)*14 - (p.injuredWeeks>12?12:0) + arr*6,0),5,100);
  p.fitness = clamp(round(100 - Math.max(0,p.age-28)*3 - p.injuredWeeks*0.8 + (has(p,'muro')?6:0),0),35,100);
  p.fanLove = clamp(round(p.fanLove + (rating-6.4)*9 + titles.length*6 + goals*0.16 - 3,0),0,100);
  p.mgrRel = clamp(round(p.mgrRel + (rating-6.5)*10 - red*8 + (has(p,'lider')?4:0) + arr*7,0),0,100);
  p.adapt = clamp(p.adapt + 34 + Math.max(0,arr)*18, 0, 100);
  p.peakClubRep = Math.max(p.peakClubRep, club.rep);

  titles.forEach(t=>p.honours.push({y:p.year, n:t.n, club:club.n, tipo:t.tipo}));
  awards.forEach(a=>p.honours.push({y:p.year, n:a, club:club.n, tipo:'individual'}));
  ntRes.titles.forEach(t=>p.honours.push({y:p.year, n:t, club:p.nat, tipo:'seleccion'}));

  const rec = {
    year:p.year, age:p.age, club:club.n, clubId:club.id, league:lg.n,
    apps, goals, assists, rating, motm, yellow, red,
    leaguePos, titles:titles.map(t=>t.n), awards, ovr:p.ovr,
    comps: mergeComps(halves),
    injury: p.injuryTag || null, injuryWeeks: p.injuredWeeks || 0,
    nt: ntRes.summary, ntCaps:ntRes.caps, ntGoals:ntRes.goals, ntTorneo:ntRes.torneo,
    ntTitles:ntRes.titles, share,
    resApps: halves.reduce((s,h)=>s+(h.resApps||0),0),
    resGoals: halves.reduce((s,h)=>s+(h.resGoals||0),0),
    clubes: [...new Set(halves.map(h=>h.club))],
    prestamo: !!p.loanFrom
  };
  const wonContiA = titles.some(t=>t.tipo==='conti');
  const wonCopa   = titles.some(t=>t.tipo==='copa');
  p.qual = qualifyFrom(club, leaguePos, wonCopa, wonContiA);
  p.qualClub = club.id;
  rec.qualNext = p.qual;
  rec.contiJugada = cp.conti;

  p.seasons.push(rec);
  return rec;
}

function clubOutlook(club, ovr, potOvr, natName){
  const sq = squadLevel(club);
  const lg = L(club.lg), cp = clubComps(club);
  const extranjero = lg.pais !== natName;
  const proj = ovr + (potOvr-ovr)*0.58;
  let mins = clamp(0.30 + (proj - sq)*0.062, 0.05, 0.95);
  const pros = [], cons = [];
  if(mins>=0.60) pros.push('Titular indiscutido en pocos años');
  else if(mins>=0.35) pros.push('Vas a tener tus minutos');
  else cons.push('Vas a pelear cada minuto');
  const fil = filosofiaDe(club);
  if(fil==='cantera') pros.push('Creen en los pibes de la casa');
  if(fil==='vender'){ pros.push('Te van a dar lugar para lucirte'); cons.push('Te forman para venderte'); }
  if(fil==='comprar') cons.push('Traen hecho: al pibe le cuesta el doble');
  if(fil==='obrero'){ pros.push('Contratos largos y nadie te apura'); cons.push('Sueldos de club chico'); }
  if(club.tier>=4){ pros.push('Entrenás con los mejores'); cons.push('Presión máxima desde el debut'); }
  if(club.tier<=2){ pros.push('Podés equivocarte sin que sea noticia'); cons.push('Menos vidriera y menos títulos'); }
  if(club.rep>=80) pros.push('Peleás títulos todos los años');
  if(club.rep<55) cons.push('Difícil salir campeón');
  if(lg.str>=4) pros.push('Liga de máximo nivel');
  if(lg.money>=4) pros.push('Sueldos altos');
  if(lg.money<=1) cons.push('Sueldos bajos');
  if(extranjero){
    cons.push('Adaptación dura: idioma, comida, distancia');
    cons.push('Lejos de tu familia y de la selección');
    pros.push('Te ven los ojeadores de todo el mundo');
  } else pros.push('En tu país, con los tuyos cerca');
  return {
    mins: Math.round(mins*100),
    dificultad: clamp(Math.round((sq - proj)*4.5 + club.tier*8), 5, 99),
    exposicion: Math.round(clamp(club.rep*0.7 + lg.str*6, 0, 100)),
    adaptacion: extranjero? (lg.pais==='Arabia Saudita'||lg.pais==='Japón'? 32 : 48) : 100,
    torneos: [lg.n, lg.copa].concat(cp.conti? [cp.conti] : []),
    extranjero, pros:pros.slice(0,3), cons:cons.slice(0,3)
  };
}

function startingOptions(natName, pos, attrs, pot){
  const ovr = calcOvr(attrs,pos), potOvr = calcOvr(pot,pos);
  const home = CLUBS.filter(c=>L(c.lg).pais===natName);
  const out = [];
  if(home.length){
    const grande = home.filter(c=>c.tier>=3).sort((a,b)=>b.rep-a.rep)[0];
    const medio  = home.filter(c=>c.tier===2).sort((a,b)=>b.rep-a.rep)[R.i(0,1)] || home.find(c=>c.tier===2);
    const chico  = home.slice().sort((a,b)=>a.rep-b.rep)[0];
    [grande,medio,chico].forEach(c=>{ if(c && !out.includes(c)) out.push(c); });
    home.filter(c=>!out.includes(c)).slice(0,1).forEach(c=>out.push(c));
  }
  const techo = potOvr>=76? 4 : potOvr>=68? 3 : 2;
  const fuera = R.shuffle(CLUBS.filter(c=>L(c.lg).pais!==natName && c.tier<=techo && c.tier>=2));
  fuera.slice(0, 4-Math.min(2,out.length)+1).forEach(c=>{ if(out.length<6) out.push(c); });
  while(out.length<5){ const c=R.pick(CLUBS.filter(x=>x.tier<=2 && !out.includes(x))); if(c) out.push(c); else break; }
  return out.slice(0,6).map(c=>({club:c, ...clubOutlook(c, ovr, potOvr, natName)}));
}

function clubParaOferta(p, tipo){
  const act = C(p.club), lgAct = L(act.lg);
  let pool = [];
  if(tipo==='golfo')   pool = CLUBS.filter(c=>L(c.lg).money>=5 && !L(c.lg).cont && c.id!==act.id);
  if(tipo==='europa')  pool = CLUBS.filter(c=>L(c.lg).cont==='EUR' && c.tier>=3 && c.rep>act.rep+3);
  if(tipo==='gigante') pool = CLUBS.filter(c=>c.tier>=5 && c.id!==act.id);
  if(tipo==='rival')   pool = CLUBS.filter(c=>c.lg===act.lg && c.id!==act.id && Math.abs(c.rep-act.rep)<14);
  if(tipo==='casa'){
    const cuna = p.ruta && p.ruta.length ? C(p.ruta[0]) : null;
    pool = cuna ? [cuna]
                : CLUBS.filter(c=>L(c.lg).pais===p.nat && c.id!==act.id && c.rep>=58);
  }
  if(tipo==='chico'){
    pool = CLUBS.filter(c=>L(c.lg).pais===p.nat && c.rep<56 && c.id!==act.id);
    if(!pool.length) pool = CLUBS.filter(c=>c.rep<56 && c.id!==act.id);
  }
  if(tipo==='nat')     pool = CLUBS.filter(c=>L(c.lg).pais===p.nat && c.id!==act.id);
  if(tipo==='menor')   pool = CLUBS.filter(c=>c.id!==act.id && squadLevel(c) < p.ovr-2);
  if(!pool.length) pool = CLUBS.filter(c=>c.id!==act.id);
  return R.pick(pool.slice().sort((a,b)=>
    Math.abs(squadLevel(a)-p.ovr) - Math.abs(squadLevel(b)-p.ovr)).slice(0, Math.max(3, Math.ceil(pool.length/3))));
}

function ficharPorEvento(p, tipo, prestamo){
  const desde = C(p.club);
  const club  = clubParaOferta(p, tipo);
  const lg    = L(club.lg);
  if(prestamo){
    if(!p.loanFrom){
      p.loanFrom = p.club;
      p.loanYears = p.clubYears || 0;   
    }
    p.loanTotal = p.loanMitades = 2;
    p.club = club.id;
    p.clubYears = 0;
    p.qual = undefined; p.qualClub = null; p.compRival = null; if(p.flags) delete p.flags.capitan;   
    p.fanLove = clamp(50+R.i(-5,10), 0, 100);
    p.mgrRel  = clamp(60+R.i(-6,10), 0, 100);
    p.adapt   = lg.pais!==p.nat ? clamp(p.adapt-28, 0, 100) : 100;
    p.timeline.push({y:p.year, k:'{a} → {b} (cedido)', v:{a:desde.n,b:club.n}, ic:'🔁'});
    return club;
  }
  p.club = club.id;
  p.wage = wageFor(p.value, lg, club.tier);
  p.contract = R.i(3,5);
  p.clubYears = 0;
  p.qual = undefined; p.qualClub = null;
  p.compRival = null; if(p.flags) delete p.flags.capitan;   
  p.fanLove = clamp(48 + R.i(-6,12), 0, 100);
  p.mgrRel  = clamp(58 + R.i(-8,12), 0, 100);
  p.adapt   = lg.pais!==p.nat ? clamp(p.adapt-34, 0, 100) : 100;
  p.timeline.push({y:p.year, k:'{a} → {b}', v:{a:desde.n,b:club.n}, ic:'✈️'});
  return club;
}

function winterMarket(p){
  const out = {traspasos:[], prestamos:[], mensaje:null};
  const share = minutesShare(p);
  const club = C(p.club);

  if(p.age<=23 && share<0.24 && p.clubYears>=1 && !p.loanFrom){
    const pool = R.shuffle(CLUBS.filter(c=>c.id!==p.club && c.tier<=Math.max(2,club.tier-1)));
    pool.slice(0,6).forEach(c=>{
      if(out.prestamos.length>=2) return;
      if(!R.chance(0.08)) return;
      const lg=L(c.lg);
      const larga = R.chance(0.35);
      out.prestamos.push({clubId:c.id, club:c.n, league:lg.n, tier:c.tier, rep:c.rep,
        mitades: larga ? 2 : 1,
        duracion: larga ? 'Hasta diciembre' : 'Media temporada',
        wage: round(wageFor(p.value,lg,c.tier)*0.55,2),
        minutos: Math.round(clamp(0.30+(p.ovr-squadLevel(c))*0.062,0.1,0.95)*100),
        pitch: larga
          ? '«Un año entero. Te queremos para armar el equipo alrededor tuyo.»'
          : '«Venís seis meses, jugás todo y volvés siendo otro.»'});
    });
  }
  const pool = R.shuffle(CLUBS.filter(c=>c.id!==p.club)).slice(0,14);
  for(const c of pool){
    if(out.traspasos.length>=1) break;
    if(p.loanFrom) break;
    if(p.rep<25) break;
    if(!R.chance(interest(p,c)*0.07)) continue;
    const lg=L(c.lg);
    out.traspasos.push({clubId:c.id, club:c.n, league:lg.n, tier:c.tier, rep:c.rep,
      wage: round(wageFor(p.value,lg,c.tier)*(0.9+R.f()*0.4),2),
      fee: round(p.value*(1.0+R.f()*0.6),1), years:R.i(3,5),
      min: Math.round(minutosProyectados(p,c)*100),
      rol: rolPorMinutos(minutosProyectados(p,c)),
      pitch:'«No podemos esperar a junio. Te queremos ahora.»'});
  }
  if(!out.traspasos.length && !out.prestamos.length){
    out.mensaje = share>0.6
      ? 'Tu club cerró la puerta: sos intransferible en el mercado corto.'
      : 'Enero pasó sin novedades. Nadie llamó y el club tampoco te movió.';
  }
  return out;
}


function simNational(p, rating, goals, apps){
  const out = {caps:0, goals:0, titles:[], repGain:0, summary:'Sin convocatorias', majorTitle:false, mundialRun:false, torneo:null, debut:false};
  const nat = NATIONS.find(n=>n.n===p.nat);
  const need = 67 + nat.str*4.4; 
  const callUp = p.ovr >= need - p.rep*0.14 && apps>10;
  if(!callUp){
    if(p.nt.caps>0) out.summary='Fuera de la lista';
    return out;
  }
  if(!p.nt.debut){ out.debut=true; p.nt.debut=p.year; p.timeline.push({y:p.year, k:'Debut con {sel}', v:{sel:p.nat}, ic:'🎽'}); }
  const caps = R.i(4,8);
  const gpg = POSITIONS[p.pos].gol*0.32*clamp((p.ovr-58)/40,0.05,1.1);
  const gls = Math.max(0,Math.round(R.gauss(gpg*caps, 1.2)));
  p.nt.caps+=caps; p.nt.goals+=gls;
  out.caps=caps; out.goals=gls; out.repGain=2+gls*0.5;

  const cycle = p.year % 4;
  const teamPow = nat.str*11 + (p.ovr-70)*0.9 + p.rep*0.12;
  const nervio = 1 + temple(p)*0.26;
  if(cycle===2){ 
    out.mundialRun = true;
    const pw = clamp((teamPow-40)/130*nervio,0.01,0.38);
    if(R.chance(pw)){ out.titles.push('🌍 Copa del Mundo'); p.mundiales++; out.majorTitle=true; out.repGain+=22; out.torneo='Mundial'; out.summary='Campeón del Mundo'; }
    else { const fase=R.pick(['Eliminado en octavos','Eliminado en cuartos','Subcampeón del Mundo','Semifinalista del Mundial','Fase de grupos']);
           out.torneo='Mundial'; out.summary='Mundial: '+fase; out.repGain+= fase.includes('Subcampeón')?9:fase.includes('Semi')?6:2; }
  } else if(cycle===0){ 
    const pw = clamp((teamPow-35)/95*nervio,0.02,0.46);
    if(R.chance(pw)){ out.titles.push('🏅 '+CONF_NAME[p.conf]); p.contiSel++; out.majorTitle=true; out.repGain+=11; out.torneo=CONF_NAME[p.conf]; out.summary='Campeón continental'; }
    else { out.torneo=CONF_NAME[p.conf]; out.summary=CONF_NAME[p.conf]+': eliminado'; }
  } else {
    out.summary=`Eliminatorias (${caps} PJ, ${gls} G)`;
  }
  if(p.nt.caps>=40 && p.nt.status!=='capitán' && p.rep>60 && (p.attrs.lid||32)>=62){ p.nt.status='capitán'; }
  else if(p.nt.caps>0 && p.nt.status==='ninguna') p.nt.status='titular';
  return out;
}

function generateOffers(p){
  const cur = C(p.club);
  const offers = [];
  if(p.ofertaPendiente==='casa' && !lejosDeCasa(p)) p.ofertaPendiente = null;
  if(p.ofertaPendiente){
    const c = clubParaOferta(p, p.ofertaPendiente), lg = L(c.lg);
    offers.push({
      clubId:c.id, club:c.n, league:lg.n, tier:c.tier, rep:c.rep,
      wage: round(wageFor(p.value,lg,c.tier)*(0.95+R.f()*0.35),2),
      fee: round(p.value*(0.85+R.f()*0.7),1), years:R.i(3,5),
      min: Math.round(minutosProyectados(p,c)*100),
      rol: rolPorMinutos(minutosProyectados(p,c)),
      pitch: '«Hablamos hace unos meses. Seguimos interesados.»',
      prometida: true
    });
    p.ofertaPendiente = null;
  }
  const pool = R.shuffle(CLUBS.filter(c=>{
    if(c.id===p.club) return false;
    if(enPrimera(c)) return true;
    return p.ovr < squadLevel(c) + 6;      
  }));
  for(const c of pool){
    if(offers.length>=3) break;
    const lg = L(c.lg);
    const wants = interest(p, c);
    if(!R.chance(wants)) continue;
    const wage = round(wageFor(p.value, lg, c.tier)*(0.85+R.f()*0.42), 2);
    const fee = round(p.value*(0.80+R.f()*0.75)*(c.tier>=4?1.18:1), 1);
    const pf = pitchFor(p,c,cur);
    offers.push({
      clubId:c.id, club:c.n, league:lg.n, tier:c.tier, rep:c.rep,
      wage, fee, years:R.i(3,5),
      min: Math.round(minutosProyectados(p,c)*100),
      rol: rolPorMinutos(minutosProyectados(p,c)),
      pitch: pf.t, pv: pf.v
    });
  }
  return offers.sort((a,b)=>b.rep-a.rep);
}
function interest(p, c){
  const gap = p.ovr - squadLevel(c);
  let base = clamp(0.06 + gap*0.045 + p.rep*0.0032 + p.hype*0.003, 0.005, 0.72) * (p.difOfertas||1);
  if(c.tier===5) base *= clamp((p.rep-46)/42,0.01,1);   
  if(c.tier===4) base *= clamp((p.rep-26)/40,0.02,1);
  if(p.age>=33) base *= 0.42;
  const fMio = filosofiaDe(C(p.club));
  if(fMio === 'vender')  base *= 1.30;
  if(fMio === 'comprar') base *= 0.82;
  if(fMio === 'cantera' && p.age<=21) base *= 0.85;
  if(p.age>=36) base *= 0.35;
  if(!L(c.lg).cont && L(c.lg).money>=5) base *= p.age>=30 ? 1.7 : p.age>=27 ? 0.8 : 0.35;
  if(p.injuredWeeks>18) base *= 0.55;
  return base;
}
function pitchFor(p,c,cur){
  const opts = [
    ['«Queremos construir el proyecto alrededor tuyo.»', {}],
    ['«Vas a jugar la {copa} todos los años.»',          {copa:CONT_CUP[L(c.lg).cont]}],
    ['«{club} lleva años esperando un {puesto} como vos.»', {club:c.n, pos:p.pos}],
    ['«Acá vas a cobrar lo que realmente valés.»',       {}],
    ['«En {club} ya ganaste todo. Vení a ganarlo de nuevo, pero más difícil.»', {club:cur.n}],
    ['«El técnico te pidió personalmente.»',             {}]
  ];
  const [t,v] = R.pick(opts);
  return {t, v};
}
function renewOffer(p){
  const c = C(p.club);
  const f = filosofiaDe(c);
  const base = { wage: round(wageFor(p.value, L(c.lg), c.tier)*(0.88+R.f()*0.30), 2),
                 years: p.age>=32? R.i(1,2) : R.i(3,5) };
  if(f === 'obrero'){  base.wage = round(base.wage*0.82,2); base.years = Math.min(6, base.years+2); }
  if(f === 'comprar'){ base.wage = round(base.wage*1.14,2); }
  if(f === 'vender'){  base.years = Math.max(1, base.years-1); }
  return base;
}

function retireCheck(p){
  if(p.ultimaTemporada) return 'decision';
  const last = p.seasons[p.seasons.length-1];
  if(p.age>=24 && p.injuredWeeks>=32 && R.chance(0.28)) return 'lesion';
  if(p.age>=26 && last && last.apps<5 && p.ovr<62 && R.chance(0.32)) return 'abandono';
  if(p.age<32) return null;
  let pr = (p.age-31)*0.10;
  if(p.ovr < 62) pr += 0.30;
  if(last && last.apps < 10) pr += 0.34;
  if(p.injuredWeeks>=26) pr += 0.30;
  if(has(p,'profesional')) pr -= 0.09;
  if(has(p,'muro')) pr -= 0.05;
  if(p.age>=40) return 'edad';
  if(R.chance(clamp(pr,0,0.95))) return p.injuredWeeks>=26? 'lesion' : p.ovr<64? 'nivel' : 'edad';
  return null;
}
const RETIRE_TXT = {
  edad:'El cuerpo dijo basta a tiempo. Te fuiste cuando quisiste.',
  nivel:'El nivel ya no daba. Preferiste irte antes de que te lo dijeran.',
  lesion:'Una lesión decidió por vos. No es como te lo imaginabas.',
  abandono:'Meses sin jugar, sin llamados, sin ofertas. El fútbol se apaga así, en silencio.',
  decision:'Nadie te empujó. Elegiste el día, y eso lo consiguen muy pocos.'
};

function puntosPlata(c){ return Math.min(90, Math.round(26 * Math.log(1 + Math.max(0, c) / 5))); }
function puntosContinentales(p){
  const cf = {}; Object.entries(CONT_CUP).forEach(([k,n])=>{ cf[n] = k; });
  const suyas = (p.honours||[]).filter(h=>h.tipo==='conti' && cf[h.n]);
  if(suyas.length !== p.contis) return p.contis*45;
  return suyas.reduce((t,h)=>t + CONTI_PESO[cf[h.n]], 0);
}
function legendScore(p){
  const c = p.career;

  const posGol  = {DFC:4.5, LAT:3.2, MCD:2.6, MC:1.5, MCO:1.15, EXT:1.05, DC:1.0}[p.pos] || 1.0;
  const posAsis = {DFC:2.8, LAT:2.1, MCD:1.9, MC:1.2, MCO:1.0, EXT:1.0, DC:0.95}[p.pos] || 1.0;

  const notaMedia = c.ratingN > 0 ? c.rating / c.ratingN : 6.0;
  const bonusNota = Math.max(0, (notaMedia - 6.2) * 170);

  const rep = 0.7 + (p.peakClubRep || 50) * 0.006;

  const s =
    c.goals*posGol + c.assists*0.7*posAsis + c.apps*0.08 + bonusNota +
    p.ligas*22*rep + p.copas*10*rep +
    puntosContinentales(p) + (p.contis2||0)*18 + p.contiSel*40 +
    (p.cwc||0)*55 + (p.inter||0)*20 + (p.segundas||0)*6 +
    p.mundiales*130 + p.balones*95 +
    p.botas*18 + (p.botasOro||0)*40 + (p.mvpMundial||0)*50 +
    p.honours.filter(h=>h.n.includes('Once Ideal')).length*10 +
    p.honours.filter(h=>h.n.includes('MVP')).length*14 +
    p.nt.goals*posGol + p.nt.caps*0.5 +
    p.peakOvr*4.2 + p.rep*2.0 + c.motm*1.6 +
    puntosPlata(p.capital||0);

  const posCal = {MCO:0.86, DC:0.90, MC:0.95, DFC:1.04, MCD:1.06, EXT:1.09, LAT:1.17}[p.pos] || 1;
  const CALIBRA = 0.800;
  return Math.round(s * posCal * CALIBRA);
}
const TIERS = [
  {min:2350, t:'INMORTAL',       d:'Se discute si fuiste el mejor de la historia. La discusión nunca se cierra.'},
  {min:1750, t:'LEYENDA GLOBAL', d:'Tu nombre define una era. Los chicos imitan tu festejo sin saber quién sos.'},
  {min:1320, t:'CLASE MUNDIAL',  d:'Estuviste en la conversación de los mejores del planeta durante años.'},
  {min:950,  t:'ESTRELLA',       d:'Una gran carrera al máximo nivel. Titular en cualquier equipo grande.'},
  {min:640,  t:'ÍDOLO DE CLUB',  d:'No conquistaste el mundo, pero una tribuna todavía canta tu nombre.'},
  {min:400,  t:'PROFESIONAL SÓLIDO', d:'Carrera digna, larga y respetada. Muchos quisieran la mitad.'},
  {min:200,  t:'OBRERO DEL FÚTBOL', d:'Viviste del fútbol. No es poco.'},
  {min:0,    t:'PROMESA TRUNCA', d:'El talento estaba. Algo se rompió en el camino.'}
];
function legendTier(score){ return TIERS.find(t=>score>=t.min); }

const DISTINCIONES = [
  {id:'quinientos', n:'Los seiscientos', d:'Seiscientos partidos en las piernas. Eso no se improvisa.',
   cumple:(p,s)=>s.pj >= 600},
  {id:'veinte', n:'Veinte temporadas', d:'Veinte años viviendo de esto. Muy pocos aguantan tanto.',
   cumple:(p,s)=>s.temporadas >= 20},
  {id:'regular', n:'El que nunca bajó', d:'Una nota media que casi nadie sostiene tantos años.',
   cumple:(p,s)=>s.avg >= 6.75 && s.temporadas >= 12},
  {id:'unclub', n:'Un solo club', d:'Una camiseta, toda la vida. Hoy eso casi no existe.',
   cumple:(p,s)=>s.clubsPlayed.length === 1 && s.temporadas >= 10},
  {id:'pasaporte', n:'El pasaporte', d:'Siete ligas distintas. Te hiciste entender en todas.',
   cumple:(p,s)=>new Set(p.seasons.map(x=>x.league)).size >= 7},
  {id:'casa', n:'Volviste a casa', d:'Te fuiste, diste la vuelta al mundo, y terminaste donde empezaste.',
   cumple:(p,s)=>s.clubsPlayed.length >= 3 && p.seasons.length > 1
      && p.seasons[0].clubId === p.seasons[p.seasons.length-1].clubId},
  {id:'nunca', n:'Nunca te fuiste', d:'Toda la carrera en tu país. Te ofrecieron irte y dijiste que no.',
   cumple:(p,s)=>s.temporadas >= 12 && p.seasons.every(x=>{
      const c = C(x.clubId); return c && L(c.lg).pais === p.nat; })},
  {id:'seleccion', n:'La camiseta de tu país', d:'Cuarenta veces te cantaron el himno. Cuarenta.',
   cumple:(p)=>(p.nt && p.nt.caps || 0) >= 40},
  {id:'limpio', n:'Nunca te echaron', d:'Una carrera entera sin ver una roja. Duro y limpio.',
   cumple:(p,s)=>s.temporadas >= 12 && p.seasons.reduce((n,x)=>n+(x.red||0),0) === 0},
  {id:'volvio', n:'Te levantaste', d:'Una lesión te partió la temporada y volviste a jugar mejor que antes.',
   cumple:(p)=>{
      const i = p.seasons.findIndex(x=>(x.injuryWeeks||0) >= 14);
      return i >= 0 && p.seasons.slice(i+1).some(x=>(x.rating||0) >= 7.0);
   }},
  {id:'ascenso', n:'Sacaste al club de abajo', d:'Jugaste en segunda y volviste a subir. Ésa no la cuenta la vitrina.',
   cumple:(p)=>{
      const seg = p.seasons.findIndex(x=>{ const c = C(x.clubId); return c && enSegunda(c); });
      return seg >= 0 && p.seasons.slice(seg+1).some(x=>{ const c = C(x.clubId); return c && !enSegunda(c); });
   }},
  {id:'titular', n:'Te ganaste el lugar', d:'Catorce temporadas de titular indiscutido. Nunca tuviste que pelear el puesto dos veces.',
   cumple:(p,s)=>p.seasons.filter(x=>(x.share||0) >= 68).length >= 14},
  {id:'mudo', n:'El goleador silencioso', d:'Doscientos goles sin levantar una copa. El fútbol es injusto.',
   cumple:(p,s)=>s.goles >= 200 && (s.ligas+s.copas+s.contis+s.contis2+s.mundiales+s.contiSel) === 0}
];

function distincionesDe(p, s){
  return DISTINCIONES.filter(d => { try{ return !!d.cumple(p, s); }catch(e){ return false; } });
}

const EVENTS = [
{id:'e1', w:3, st:['ini'], when:p=>p.age<=19,
 t:'La primera práctica con el plantel principal',
 d:p=>`El técnico de ${C(p.club).n} te sube a entrenar con los grandes. En el primer rondo te tiran un caño y todo el círculo se ríe. Tenés la pelota en el pie y sesenta ojos encima.`,
 c:[
  {t:'Devolvés el caño en la jugada siguiente', ef:{reg:2, moral:8, mgrRel:6, hype:4}, r:'Silencio, después aplausos. El capitán te palmea la nuca. Existís.'},
  {t:'Bajás la cabeza y jugás simple una semana entera', ef:{pas:2, mgrRel:9, moral:-3}, r:'Nadie te aplaude, pero el técnico anota tu nombre. Los humildes duran más.'},
  {t:'Te enojás y entrás fuerte al que se rió', ef:{fis:2, mgrRel:-12, moral:4, trait:'polemico'}, r:'Lo dejás en el piso. Te ganás un enemigo y una reputación. Las dos cosas pesan.'}
 ]},
{id:'e2', w:3, st:['ini'], when:p=>p.age<=20 && p.rep<25,
 t:'El representante de traje caro',
 d:p=>`Aparece en la puerta del vestuario. Habla rápido, promete ${enLigaEuropea(p) ? 'un club grande' : 'Europa'}, te muestra fotos con jugadores que conocés de la tele. Tu viejo desconfía. Tu vieja quiere creerle.`,
 c:[
  {t:'Firmás con él', ef:{hype:14, rep:4, moral:5, flag:'agente'}, r:'Al mes tenés tres pruebas agendadas. También un contrato con letra chica que nadie te leyó.'},
  {t:'Seguís con el representante del barrio', ef:{moral:6, fanLove:6, hype:-4}, r:'Menos puertas, más lealtad. Vas a llegar igual, pero caminando.'},
  {t:'Le pedís a tu viejo que se ocupe', ef:{moral:9, mgrRel:3, hype:-2}, r:'Tu papá aprende de contratos a los cincuenta años. Le sale mejor de lo que esperabas.'}
 ]},
{id:'e3', w:2, st:['ini'], when:p=>p.age<=21,
 t:'La final de la Reserva',
 d:p=>`Tu categoría juega la final. El primer equipo te quiere en el banco ese mismo día, por si acaso. No podés estar en los dos lugares.`,
 c:[
  {t:'Jugás la final con tus amigos', ef:{moral:14, fanLove:8, mgrRel:-7, forma:8}, r:'Ganan. Te llevan en andas. El técnico del primer equipo no dice nada, pero tampoco olvida.'},
  {t:'Vas al banco del primer equipo', ef:{mgrRel:12, rep:3, moral:-6}, r:'No entrás ni un minuto. Pero desde ese día tu nombre está en la lista.'}
 ]},

{id:'e4', w:4, st:['asc','ple'], when:p=>p.age>=18 && p.age<=30,
 t:'El preparador que nadie quiere',
 d:p=>`Un preparador físico obsesivo se ofrece a trabajar con vos por fuera del club. Levantarte a las 5:30. Todos los días. Tus compañeros se burlan del tema.`,
 c:[
  {t:'Aceptás', ef:{fis:4, rit:2, fitness:8, moral:-4, trait:'profesional'}, r:'Seis meses después sos el último que camina en el minuto 88. Las burlas se transformaron en preguntas.'},
  {t:'Preferís descansar', ef:{moral:6, forma:4}, r:'Dormís bien. Tu cuerpo te lo agradece ahora y te lo cobra a los 31.'}
 ]},
{id:'e5', w:3, st:['asc','ple'], when:p=>p.attrs.pmm<55 && p.age<=28,
 t:'La pierna que no existe',
 d:p=>`Un periodista escribe que jugás "con una sola pierna y media". Es injusto, es exagerado, y es bastante cierto.`,
 c:[
  {t:'Media hora extra de pierna mala, cada día', ef:{pmm:9, moral:-3}, r:'Al año siguiente metés un gol imposible con la zurda. Buscás al periodista con la mirada.'},
  {t:'Lo ignorás y perfeccionás lo tuyo', ef:{reg:3, def:2, moral:3}, r:'Si sólo tenés un arma, que sea nuclear.'},
  {t:'Le respondés en redes', ef:{hype:10, rep:2, mgrRel:-6, trait:'polemico'}, r:'Trending topic por dos días. El club emite un comunicado que no te gusta.'}
 ]},

{id:'e6', w:4, st:['asc','ple','vet'], when:p=>p.age>=20 && p.mgrRel<50,
 t:'El técnico te saca del equipo',
 d:p=>`Tres partidos en el banco sin explicación. En la conferencia dice que "hay cosas que se resuelven puertas adentro". Un compañero te dice que hables con él.`,
 c:[
  {t:'Golpeás la puerta de su oficina', ef:{mgrRel:16, moral:6}, r:'Discuten cuarenta minutos. Salís titular el domingo. A veces alcanza con aparecer.'},
  {t:'Entrenás el doble y no decís nada', ef:{fis:3, mgrRel:8, moral:-5, forma:6}, r:'Vuelve a ponerte por cansancio. Funciona, pero tardó.'},
  {t:'Pedís salir del club', ofr:{t:'menor',cuando:'ventana'}, ef:{mgrRel:-20, hype:12, fanLove:-14, flag:'quiereIrse', mem:{plantes:1}}, r:'Se filtra a la prensa. La hinchada te silba en el calentamiento.'}
 ]},
{id:'e7', w:3, st:['ple','vet'], when:p=>p.age>=23 && p.rep>=30,
 t:'La cinta de capitán',
 d:p=>`Se va el capitán histórico. El vestuario está dividido entre vos y un veterano que jugó doscientos partidos más.`,
 c:[
  {t:'Peleás por la cinta', ef:{mgrRel:6, moral:8, rep:4, trait:'capitan', flag:'capitan'}, r:'Te la dan. La mitad del vestuario te felicita; la otra mitad te mide cada semana.'},
  {t:'Se la ofrecés al veterano', ef:{flag:'pupilo', mgrRel:10, moral:5, trait:'lider'}, r:'Él te abraza delante de todos. Ganaste algo más difícil de conseguir que una cinta.'}
 ]},
{id:'e8', w:3, st:['asc','ple','vet'], when:p=>p.age>=21,
 t:'Cambio de entrenador',
 d:p=>`Llega un técnico nuevo con ideas nuevas. En su esquema, tu posición no existe tal como la conocés.`,
 c:[
  {t:'Te adaptás a lo que pide', ef:{pas:3, dfs:3, mgrRel:14, moral:-3}, r:'Aprendés a jugar de otra forma. Tu juego se vuelve más completo y menos vistoso.'},
  {t:'Seguís jugando como sabés', ef:{reg:2, fil:2, mgrRel:-14, forma:-5}, r:'Cuando entrás, brillás. El problema es entrar.'},
  {t:'Hablás con él y proponés un plan', ef:{mgrRel:8, pas:2, moral:6}, r:'Acepta a medias. En el fútbol, a medias es un triunfo.'}
 ]},

{id:'e9', w:4, st:['asc'], when:p=>p.age>=19 && p.rep>=12 && C(p.club).tier<=3,
 t:'Un club grande manda un ojeador a cada partido',
 d:p=>`Sabés que está en la tribuna. Tu representante te lo confirma antes de cada partido. Todo lo que hacés durante noventa minutos tiene un testigo.`,
 c:[
  {t:'Jugás para él: caños, lujos, la tuya', ef:{fil:4, reg:2, hype:14, mgrRel:-8, fanLove:-4}, r:'Le gustás. A tu técnico no. Ganás una vidriera y perdés un aliado.'},
  {t:'Jugás para el equipo', ef:{pas:3, mgrRel:8, fanLove:8, rep:4}, r:'Escribe en su informe: "entiende el juego". Vale más que diez caños.'},
  {t:'Te olvidás de que está', ef:{moral:8, forma:8}, r:'Sin peso encima jugás el mejor partido del año. La cabeza también es técnica.'}
 ]},
{id:'e10', w:3, st:['ple','vet'], when:p=>p.clubYears>=1 && p.fanLove>=60,
 t:'Bandera en la popular con tu nombre',
 d:p=>`La hinchada cuelga una bandera de veinte metros. Dice tu apellido y abajo, en letras chicas: "uno de nosotros". Justo la semana en que llegó una oferta.`,
 c:[
  {t:'Renovás sin escuchar la oferta', ef:{fanLove:22, moral:14, rep:-3, trait:'idolo', contrato:4}, r:'El estadio explota. Vas a ser eterno acá aunque nunca ganes nada afuera.'},
  {t:'Escuchás la oferta igual', ofr:{t:'europa',cuando:'ventana'}, ef:{moral:-4, hype:8, flag:'tentado'}, r:'Nadie se entera, pero vos sabés que la escuchaste. Eso ya cambia algo.'}
 ]},
{id:'e11', w:5, st:['ple','vet'], when:p=>p.age>=25 && p.rep>=45,
 t:'La llamada del dinero',
 d:p=>`Un club de la Liga del Golfo ofrece triplicar tu sueldo. Nadie va a verte jugar. Tu familia estaría cubierta por tres generaciones.`,
 c:[
  {t:'Rechazás sin dudar', ef:{moral:8, fanLove:10, rep:3}, r:'Tu representante no te habla por una semana. Vos dormís bien.'},
  {t:'Lo pensás seriamente', ef:{moral:-5, hype:10, flag:'golfo'}, r:'La duda se instala. Vuelve cada vez que pisás mal el césped.'},
  {t:'Te asegurás el futuro', ofr:{t:'golfo',cuando:'ya'}, ef:{moral:10, fanLove:-18, rep:-8, trait:'mercenario'}, r:'Comprás la casa de tus viejos. Nunca más te aplaude una liga grande.'}
 ]},

{id:'e12', w:3, st:['asc','ple','vet','oca'], when:p=>p.injuredWeeks>=14,
 t:'Rehabilitación',
 d:p=>`${p.injuryTag}. Cinco meses de gimnasio vacío, conos y un fisioterapeuta que te repite que hay que tener paciencia. Nunca odiaste tanto una palabra.`,
 c:[
  {t:'Volvés antes de tiempo', ef:{forma:-14, fitness:-12, moral:6, trait:'cristal', mem:{infiltraciones:1}}, r:'Jugás. Y volvés a romperte tres meses después. El cuerpo no negocia.'},
  {t:'Respetás cada plazo', ef:{fis:3, fitness:10, moral:-6, trait:'profesional'}, r:'Volvés tarde y entero. Nadie te aplaude la paciencia hasta que ven que seguís jugando a los 35.'},
  {t:'Estudiás video toda la recuperación', ef:{pas:4, dfs:3, moral:3}, r:'Volvés más lento y más inteligente. El cambio es rentable.'}
 ]},
{id:'e13', w:2, st:['asc','ple','vet'], when:p=>p.age>=22 && p.forma<50,
 t:'La sequía',
 d:p=>`Once partidos sin gol ni asistencia. La prensa cuenta los días. Vos también, aunque digas que no.`,
 c:[
  {t:'Te quedás una hora más pateando al arco', ef:{def:4, forma:10, moral:-4}, r:'Al doceavo partido entra un rebote. Festejás como si fuera una final.'},
  {t:'Cortás con todo: nada de redes, nada de diarios', ef:{moral:12, forma:8}, r:'La cabeza se ordena. El fútbol vuelve solo.'},
  {t:'Cambiás de rol: empezás a asistir', ef:{pas:5, forma:6, moral:4}, r:'Descubrís que el pase final da tanta adrenalina como el gol.'}
 ]},
{id:'e14', w:2, st:['asc','ple','vet'], when:p=>p.age>=20,
 t:'Un cántico de más',
 d:p=>`Una tribuna rival te insulta durante noventa minutos con algo que cruza todos los límites. El árbitro no escucha. Tus compañeros sí.`,
 c:[
  {t:'Pedís que se suspenda el partido', ef:{rep:6, moral:-6, hype:16}, r:'El partido se detiene ocho minutos. La imagen da la vuelta al mundo. Cambiaste algo más que un resultado.'},
  {t:'Metés un gol y festejás en su cara', ef:{moral:10, hype:14, fanLove:6, trait:'polemico'}, r:'Amarilla, portada y una deuda pendiente con esa hinchada para siempre.'},
  {t:'Seguís jugando como si nada', ef:{moral:-8, mgrRel:5, rep:2}, r:'Te tragás todo. Esa noche no dormís.'}
 ]},

{id:'e15', w:3, st:['ple','vet'], when:p=>p.hype>=35,
 t:'La marca deportiva',
 d:p=>`Contrato millonario para una campaña global. Filmación de dos semanas en plena pretemporada.`,
 c:[
  {t:'Firmás y filmás', ef:{hype:20, rep:5, fitness:-8, mgrRel:-8}, r:'Tu cara en las paradas de colectivo del mundo. Empezás la temporada dos kilos pasado.'},
  {t:'Negociás para filmar en vacaciones', ef:{hype:12, rep:4, moral:4}, r:'Menos plata, cero conflicto. Tu representante aprende a respetarte.'},
  {t:'Rechazás: primero el fútbol', ef:{mgrRel:10, forma:8, hype:-6, fanLove:12}, r:'El técnico lo cuenta en conferencia. Los hinchas te adoptan.'}
 ]},
{id:'e16', w:2, st:['asc','ple'], when:p=>p.age>=23,
 t:'Tres de la mañana, foto filtrada',
 d:p=>`Una foto tuya en un boliche a horas indebidas, cuarenta y ocho antes de un clásico. Es vieja, pero nadie lo aclara.`,
 c:[
  {t:'Pedís disculpas públicas', ef:{mgrRel:8, fanLove:4, hype:-4, moral:-4}, r:'El tema muere en tres días. La humildad es barata y efectiva.'},
  {t:'Aclarás que la foto es de hace un año', ef:{rep:3, hype:6}, r:'Nadie te cree del todo. Pero era verdad.'},
  {t:'No decís nada y metés dos en el clásico', ef:{moral:16, fanLove:20, hype:22, trait:'clutch'}, r:'La mejor respuesta se da con la pelota. Nadie volvió a mencionar la foto.'}
 ]},
{id:'e17', w:2, st:['ple','vet'], when:p=>p.age>=25,
 t:'Un pibe del club te pide consejo',
 d:p=>`Diecisiete años, talento evidente, y una oferta para irse ${enLigaEuropea(p) ? 'a un grande de otra liga' : 'a Europa'} la semana que viene. Te busca a vos porque hiciste ese camino.`,
 c:[
  {t:'Le decís que se quede un año más', ef:{moral:8, fanLove:8, trait:'lider'}, r:'Se queda. Explota en el club. Nunca olvida quién le dio ese consejo.'},
  {t:'Le decís que se vaya ya', ef:{rep:3, moral:4}, r:'Se va. Le va bien. También hubiera estado bien quedarse.'},
  {t:'Le decís que no hay respuesta correcta', ef:{flag:'pupilo', moral:6, mgrRel:4}, r:'Le contás tus dos errores más grandes. Es lo más útil que le dijo alguien.'}
 ]},

{id:'e18', w:4, st:['ple','vet'], when:p=>p.rep>=40 && p.age>=22,
 t:'Penal en el minuto 92',
 d:p=>`Final. Empate. Penal a favor. El capitán mira al piso. El goleador mira al costado. Vos mirás la pelota.`,
 c:[
  {t:'Agarrás la pelota', tira:'com', mas:-4, ef:{rep:5, hype:10},
   bien:{ef:{moral:14, fanLove:16, rep:2, hype:6, trait:'clutch'}, r:'Al medio, a media altura, sin mirar. Adentro. Hay noches que definen una carrera entera.'},
   mal:{ef:{moral:-16, fanLove:-12, forma:-8, flag:'penalerrado'}, r:'Le pegás con el cuerpo cerrado y la pelota se va a la tribuna. El silencio de un estadio propio es lo más fuerte que vas a escuchar.'}},
  {t:'Se la dejás al capitán', ef:{mgrRel:8, moral:-3}, r:'Lo mete. Festejás igual. Pero algo en vos sabe que era tu turno.'}
 ]},
{id:'e19', w:3, st:['ple','vet'], when:p=>p.age>=24 && p.nt.caps>=10,
 t:'El técnico de la Selección te llama por teléfono',
 d:p=>`Te quiere de titular en un puesto que no es el tuyo. Dice que es la única forma de que entres al once.`,
 c:[
  {t:'Aceptás jugar donde sea', ef:{pas:3, dfs:3, mgrRel:5, rep:6}, r:'Jugás incómodo pero jugás. La camiseta pesa más que la posición.'},
  {t:'Le decís que jugás en tu puesto o nada', ef:{rep:-4, moral:6, trait:'polemico'}, r:'Te deja afuera dos convocatorias. Después te llama de vuelta, en tu puesto.'}
 ]},
{id:'e20', w:3, st:['vet','oca'], when:p=>p.age>=29,
 t:'La rodilla que avisa',
 d:p=>`Después de cada partido, hielo. Después de cada entrenamiento, hielo. El médico te dice que se puede manejar. Manejar, no curar.`,
 c:[
  {t:'Infiltraciones para seguir jugando todo', ef:{moral:6, fitness:-14, trait:'cristal', mem:{infiltraciones:1}}, r:'Jugás la temporada completa. El precio se paga después, y se paga caro.'},
  {t:'Dosificás: mitad de los partidos', ef:{fitness:12, moral:-6, mgrRel:-6}, r:'Menos partidos, más años. El cuerpo agradece la matemática.'},
  {t:'Cambiás tu juego: menos correr, más pensar', ef:{pas:6, dfs:3, rit:-3, moral:5}, r:'Te reinventás. Los inteligentes juegan hasta los cuarenta.'}
 ]},
{id:'e21', w:2, st:['vet','oca'], when:p=>p.age>=31 && p.rep>=50,
 t:'Ofrecen retirar tu número',
 d:p=>`El club quiere retirar tu camiseta cuando dejes de jugar. También te ofrecen un rol en las inferiores. Todavía te quedan años.`,
 c:[
  {t:'Aceptás el homenaje futuro', ef:{fanLove:18, moral:10, trait:'idolo'}, r:'Firmás un vínculo de por vida. Ya no sos un jugador del club: sos el club.'},
  {t:'Pedís que esperen: todavía jugás', ef:{moral:12, forma:10, rep:3}, r:'"Los homenajes son para los que terminaron." Te quedan dos temporadas enormes.'}
 ]},
{id:'e22', w:3, st:['asc','ple'], when:p=>p.age>=20 && p.age<=32,
 t:'El clásico',
 d:p=>`Semana de clásico. Un rival declaró que sos "sobrevalorado" y que "en el barrio hay diez mejores que él".`,
 c:[
  {t:'Le contestás en la conferencia', ef:{hype:14, moral:6, trait:'polemico'}, r:'Se arma. Noventa mil personas van a estar pendientes de ese duelo personal.'},
  {t:'Silencio hasta el domingo', ef:{forma:8, moral:8, mgrRel:6}, r:'Jugás con una calma helada. Ganan. Al final, le das la mano y no decís nada.'},
  {t:'Lo buscás en el campo desde el primer minuto', tira:'fis', mas:2, ef:{fis:3, mgrRel:-5},
   bien:{ef:{dfs:2, moral:4, fanLove:8}, r:'Duelo brutal. Los dos terminan amonestados y con respeto mutuo.'},
   mal:{ef:{moral:-10, forma:-8, mgrRel:-8, fanLove:-6}, r:'A los veinte minutos ya estás amonestado y jugando a otra cosa. Te expulsan a los sesenta y pierden con uno menos.'}}
 ]},
{id:'e23', w:3, st:['ple'], when:p=>C(p.club).tier>=3 && p.age>=22,
 t:'Competencia en tu puesto',
 d:p=>`El club ficha a un jugador de tu misma posición por una cifra récord. La prensa dice que llegó para reemplazarte.`,
 c:[
  {t:'Lo ayudás a adaptarse', ef:{moral:8, mgrRel:10, trait:'lider'}, r:'Terminan siendo amigos y jugando juntos. El técnico encuentra la forma.'},
  {t:'Guerra fría: le ganás el puesto', ef:{forma:12, fis:2, moral:6, mgrRel:4}, r:'Tres meses de entrenamientos brutales. Salís titular vos.'},
  {t:'Pedís garantías al club', ef:{moral:-6, mgrRel:-10, hype:8}, r:'El club se molesta. Te dicen que el puesto se gana en la cancha.'}
 ]},
{id:'e24', w:2, st:['ple','vet'], when:p=>p.age>=26 && p.rep>=35,
 t:'Fundación con tu nombre',
 d:p=>`Querés devolver algo. Un club de barrio, canchas, becas. Requiere plata y tiempo que no tenés.`,
 c:[
  {t:'La armás en serio', ef:{capital:-0.5, rep:8, moral:12, fanLove:12, hype:6}, r:'Doscientos chicos con botines nuevos. Nada de lo que ganes en una cancha se va a sentir así.'},
  {t:'Ponés plata, delegás la gestión', ef:{capital:-0.3, rep:4, moral:5}, r:'Funciona bien. Vos seguís concentrado en jugar.'},
  {t:'Lo dejás para después de retirarte', ef:{forma:6}, r:'Es lo razonable. También es lo que dicen todos los que nunca lo hacen.'}
 ]},
{id:'e25', w:3, st:['asc','ple','vet'], when:p=>p.age>=19,
 t:'Concentración eterna',
 d:p=>`Diez días encerrados en un predio antes de una serie clave. El vestuario está tenso y alguien tiene que romper el clima.`,
 c:[
  {t:'Organizás un torneo de truco', ef:{moral:12, mgrRel:5, forma:6}, r:'El grupo se afloja. Ganan la serie. Nunca subestimes una baraja.'},
  {t:'Te concentrás solo, video y descanso', ef:{pas:2, dfs:2, forma:8}, r:'Jugás el mejor partido de la serie. Cada uno se prepara como puede.'}
 ]},
{id:'e26', w:2, st:['ini','asc'], when:p=>p.age>=18 && p.age<=24 && !p.loanFrom && minutesShare(p)<0.3,
 t:'Cesión a préstamo',
 d:p=>`No estás jugando. El club propone una cesión a un equipo más chico donde serías titular seguro.`,
 c:[
  {t:'Aceptás la cesión', ofr:{t:'menor',cuando:'ya',prestamo:true}, ef:{moral:-4, forma:10}, r:'Jugás treinta partidos. Volvés siendo otro jugador.'},
  {t:'Te quedás a pelearla', ef:{moral:6, mgrRel:6, forma:-6}, r:'Entrás doce minutos por partido. Aprendés a aprovecharlos.'}
 ]},
{id:'e27', w:2, st:['asc','ple','vet'], when:p=>p.age>=22,
 t:'Una noche mala del árbitro',
 d:p=>`Te anulan dos goles legítimos y te expulsan por protestar. El VAR confirma después que ambos eran válidos.`,
 c:[
  {t:'Explotás en zona mixta', ef:{hype:14, rep:-3, trait:'polemico', mgrRel:-6, mem:{polemicas:1}}, r:'Tres fechas de suspensión adicionales. Valía la pena, decís.'},
  {t:'"Prefiero no hablar del árbitro"', ef:{rep:5, mgrRel:6, moral:-6, contrato:1}, r:'Clase pura. El club te lo agradece con una renovación mejorada.'}
 ]},
{id:'e28', w:3, st:['ple','vet'], when:p=>p.age>=24 && p.moral<85,
 t:'El cansancio que no es físico',
 d:p=>`No es el cuerpo. Es levantarte y no tener ganas de ir a entrenar. Nunca te había pasado y no sabés cómo se llama.`,
 c:[
  {t:'Hablás con un psicólogo deportivo', ef:{moral:22, forma:8, rep:4}, r:'Tardás en aceptarlo y después no entendés cómo aguantaste tanto solo.'},
  {t:'Te lo bancás en silencio', ef:{moral:-10, forma:-8, fitness:-4}, r:'Se transforma en una temporada gris que la prensa atribuye a la falta de gol.'},
  {t:'Te tomás dos semanas fuera de todo', ef:{moral:14, forma:6, mgrRel:-6}, r:'El club no lo entiende del todo. Vos volvés entero.'}
 ]},
{id:'e29', w:2, st:['vet','oca'], when:p=>p.age>=30 && p.rep>=45 && lejosDeCasa(p),
 t:'Un club chico te pide una mano',
 d:p=>`El equipo donde te formaste está a punto de descender y no puede pagar sueldos. Te piden que vuelvas seis meses, casi gratis.`,
 c:[
  {t:'Volvés', ofr:{t:'casa',cuando:'ya'}, ef:{fanLove:24, moral:16, rep:6, trait:'idolo', value:-10, wage:-40}, r:'La salvación llega en la última fecha. Nunca te van a olvidar en ese barrio.'},
  {t:'Mandás plata pero no volvés', ef:{rep:4, moral:4}, r:'Pagás tres meses de sueldos del plantel. Se enteran años después.'},
  {t:'Les decís que no', ef:{moral:-6}, r:'Es la decisión profesional correcta. También la que más te va a molestar recordar.'}
 ]},
{id:'e30', w:3, st:['asc','ple'], when:p=>p.age>=21 && p.age<=33,
 t:'Cambio de posición',
 d:p=>`El cuerpo técnico ve algo en vos: creen que rendirías más retrasado unos metros. Es un cambio de identidad futbolística.`,
 c:[
  {t:'Probás el cambio', ef:{special:'reposicion', pas:4, dfs:4, moral:-4}, r:'Al principio es incómodo. Después descubrís que ves el partido entero por primera vez.'},
  {t:'Te negás', ef:{moral:6, mgrRel:-8}, r:'Seguís siendo lo que siempre fuiste. A veces es lo correcto.'}
 ]},
{id:'e31', w:2, st:['ple','vet'], when:p=>p.nt.caps>=15,
 t:'La cinta de la Selección',
 d:p=>`El capitán histórico se retira. El técnico te consulta a vos y a otros tres referentes quién debería llevarla.`,
 c:[
  {t:'Te proponés', ef:{rep:8, moral:10, trait:'capitan', flag:'capitan'}, r:'Salís al campo con la cinta y el himno se escucha distinto.'},
  {t:'Proponés al arquero', ef:{moral:6, rep:3, trait:'lider'}, r:'Buena decisión. El grupo se ordena solo.'}
 ]},
{id:'e32', w:2, st:['ple','vet'], when:p=>p.age>=25 && p.hype>=28,
 t:'Documental sobre tu vida',
 d:p=>`Una plataforma quiere filmar tu temporada completa, con cámaras en tu casa y en el vestuario.`,
 c:[
  {t:'Abrís todas las puertas', ef:{hype:24, rep:6, mgrRel:-10, moral:-4}, r:'Éxito mundial. Algunos compañeros no te perdonan las cámaras en el vestuario.'},
  {t:'Sólo fuera del club', ef:{hype:12, rep:4}, r:'Un producto más chico y más honesto. Nadie se enoja.'},
  {t:'Rechazás', ef:{forma:6, mgrRel:6, hype:-8}, r:'"Mi vida no es un contenido." La frase se hace viral igual.'}
 ]},
{id:'e33', w:3, st:['asc','ple','vet'], when:p=>p.age>=20,
 t:'Bonus por objetivos',
 d:p=>`El club ofrece renegociar: menos sueldo fijo, bonus enormes por goles y títulos. Es apostar a vos mismo.`,
 c:[
  {t:'Aceptás la apuesta', ef:{moral:8, forma:10, wage:-4, flag:'bonus'}, r:'Presión autoimpuesta. Rendís mejor bajo presión de la que te ponés vos.'},
  {t:'Preferís lo seguro', ef:{wage:4, moral:2}, r:'Duermes tranquilo. Nada mal.'}
 ]},
{id:'e34', w:2, st:['asc','ple'], when:p=>p.age>=22 && C(p.club).tier<=3 && enPrimera(C(p.club)),
 t:'Descenso en juego',
 d:p=>`Última fecha. Si pierden, el club baja de categoría por primera vez en su historia. Tenés una cláusula que te libera si eso pasa.`,
 c:[
  {t:'Jugás como si fuera una final', ef:{moral:12, fanLove:18, forma:10, rep:4}, r:'Ganan 1-0. El gol lo hacés vos. La ciudad no duerme esa noche.'},
  {t:'Te cuidás pensando en tu próximo club', ofr:{t:'menor',cuando:'ya'}, ef:{moral:-12, fanLove:-22, rep:-4, bajaTuClub:true, trait:'mercenario'}, r:'Pierden y bajan. Vos te vas con la cláusula. Cada vez que volvés a esa ciudad, alguien te lo recuerda.'}
 ]},
{id:'e35', w:2, st:['ple','vet'], when:p=>p.age>=27 && (p.balones>=1 || p.rep>=88),
 t:'El peso de la corona',
 d:p=>`Ganaste el premio más grande. Ahora cada partido normal es una decepción y cada crítica es sobre "el declive".`,
 c:[
  {t:'Te obsesionás con ganarlo de nuevo', ef:{forma:12, moral:-8, fitness:-6}, r:'Rendís a un nivel salvaje durante un año. El cuerpo pasa factura.'},
  {t:'Jugás para el equipo y que hablen', ef:{pas:4, mgrRel:10, moral:10}, r:'Ganás títulos en vez de premios. Es una forma más difícil de ser grande.'}
 ]},
{id:'e36', w:2, st:['asc'], when:p=>p.age>=19 && p.age<=26,
 t:'La lesión de un compañero',
 d:p=>`Se rompe el referente del equipo. El vestuario queda huérfano de liderazgo en la mitad de una pelea de campeonato.`,
 c:[
  {t:'Tomás las riendas', ef:{flag:'mentor', moral:10, mgrRel:12, rep:6, trait:'lider'}, r:'A los 22 años empezás a hablar en las charlas. Nadie te discute.'},
  {t:'Seguís enfocado en lo tuyo', ef:{forma:8, def:2}, r:'Metés goles y callás. También es una forma de liderar.'}
 ]},
{id:'e37', w:2, st:['ple','vet'], when:p=>p.age>=23 && p.fanLove<40,
 t:'La hinchada no te quiere',
 d:p=>`Silbidos cada vez que tocás la pelota. Un grupo espera al plantel en el predio.`,
 c:[
  {t:'Vas a hablar con ellos personalmente', ef:{fanLove:20, moral:6, rep:4}, r:'Una hora de charla incómoda. Al domingo siguiente te aplauden al salir.'},
  {t:'Respondés con goles', ef:{forma:12, def:3, fanLove:10}, r:'El fútbol es el único idioma que no admite discusión.'},
  {t:'Pedís salir', ofr:{t:'menor',cuando:'ventana'}, ef:{flag:'quiereIrse', moral:-6, fanLove:-14, hype:8, mem:{plantes:1}}, r:'Se termina la relación. A veces no hay reconciliación posible.'}
 ]},
{id:'e38', w:2, st:['oca'], when:p=>p.age>=33,
 t:'Los años que quedan',
 d:p=>`El cuerpo aguanta pero la cabeza empieza a hacer cuentas. Un directivo te ofrece un puesto de dirigente para cuando dejes.`,
 c:[
  {t:'Aceptás planificar el futuro', ef:{moral:10, forma:-4}, r:'Tranquilidad. Jugás más suelto sabiendo que hay vida después.'},
  {t:'No querés pensar en el final', ef:{forma:10, moral:-6}, r:'Cada partido lo jugás como si fuera el último. Porque en algún momento lo va a ser.'}
 ]},
{id:'e39', w:2, st:['ple','vet'], when:p=>p.age>=21 && p.rep>=30,
 t:'Un país en crisis',
 d:p=>`Tu país atraviesa una situación grave. Los periodistas te preguntan en zona mixta. Tenés micrófonos y millones de seguidores.`,
 c:[
  {t:'Te pronunciás con claridad', ef:{rep:8, hype:16, moral:6, mgrRel:-4}, r:'Se genera un debate enorme. Algunos te agradecen para siempre; otros no te perdonan.'},
  {t:'"Soy futbolista, no opino de eso"', ef:{rep:-2, moral:-4}, r:'Te critican por tibio. Vos elegís tus batallas.'},
  {t:'Actuás sin declarar: donás y organizás', ef:{capital:-0.2, rep:6, moral:10}, r:'Se enteran meses después por otros. Es la forma que más te representa.'}
 ]},
{id:'e40', w:3, st:['asc','ple'], when:p=>p.age>=20 && p.age<=30,
 t:'Semifinal continental, ida y vuelta',
 d:p=>`Perdieron 2-0 de visitante. En casa hay que dar vuelta la serie con el estadio lleno.`,
 c:[
  {t:'Prometés públicamente la remontada', ef:{hype:18, moral:8, forma:8, trait:'clutch'}, r:'3-0. Metés uno y asistís otro. Esas noches se guardan para siempre.'},
  {t:'Preferís no prometer nada', ef:{forma:6, mgrRel:6}, r:'La remontada llega igual. La diferencia es quién se lleva las tapas.'}
 ]},
{id:'e41', w:2, st:['asc'], when:p=>p.age<=23 && p.ovr>=68,
 t:'"El nuevo fenómeno"',
 d:p=>`Te comparan con leyendas que no viste jugar. La presión de una generación entera sobre ${enLetras(p.age)} años de edad.`,
 c:[
  {t:'Abrazás la comparación', ef:{hype:18, moral:8, forma:-4}, r:'Te gusta el ruido. Ahora hay que sostenerlo diez años.'},
  {t:'"Yo soy yo"', ef:{moral:10, rep:4, hype:-4}, r:'Frase que se hace remera. Bajás la expectativa y subís el rendimiento.'},
  {t:'Te aislás de todo', ef:{forma:12, moral:-4, hype:-10}, r:'Sin redes, sin diarios, sin entrevistas. Sólo fútbol. Funciona.'}
 ]},
{id:'e42', w:5, st:['ple','vet'], when:p=>p.age>=24 && p.contis===0 && C(p.club).tier>=3,
 t:'La final que te falta',
 d:p=>`Es tu tercera final continental. Perdiste las dos anteriores. La prensa lo repite en cada nota.`,
 c:[
  {t:'"Esta la gano o me retiro"', tira:'com', ef:{hype:16},
   bien:{ef:{forma:14, moral:4, trait:'clutch'}, r:'Frase peligrosa. También la que necesitaba el vestuario: la ganan y nadie vuelve a hablar de las dos anteriores.'},
   mal:{ef:{moral:-18, forma:-10, fanLove:-10}, r:'Pierden la tercera. La frase queda grabada y te la van a repetir en cada nota hasta el día que te retires.'}},
  {t:'Trabajás en silencio con el grupo', ef:{moral:10, mgrRel:8, forma:8}, r:'Sin ruido, sin promesas. Sólo una semana de trabajo perfecto.'}
 ]},
{id:'e43', w:2, st:['ple','vet'], when:p=>p.age>=26 && p.clubYears<=1 && L(C(p.club).lg).pais!==p.nat,
 t:'Adaptación a un país nuevo',
 d:p=>`Idioma nuevo, comida distinta, tu familia extrañando. En la cancha se nota.`,
 c:[
  {t:'Estudiás el idioma tres horas por día', ef:{moral:10, mgrRel:10, pas:2}, r:'A los seis meses das una entrevista sin traductor. El vestuario te adopta.'},
  {t:'Traés a toda tu familia', ef:{moral:16, forma:6}, r:'Con los tuyos cerca, todo funciona. El fútbol también.'},
  {t:'Te encerrás en el fútbol', ef:{forma:10, moral:-10}, r:'Rendís bien y vivís mal. Es un intercambio que muchos hacen.'}
 ]},
{id:'e44', w:2, st:['vet'], when:p=>p.age>=29 && p.ovr>=72,
 t:'El último gran contrato',
 d:p=>`Tenés 29 y una oferta de cinco años. Es probablemente el último contrato largo de tu carrera.`,
 c:[
  {t:'Firmás los cinco años', ef:{moral:10, wage:6, mgrRel:6, contrato:5}, r:'Estabilidad total. También la obligación de rendir hasta los 34.'},
  {t:'Firmás dos, con opción', ef:{flag:'tentado', moral:4, hype:6, contrato:2}, r:'Te dejás una puerta abierta. En el fútbol las puertas abiertas valen oro.'}
 ]},
{id:'e45', w:2, st:['ple','vet'], when:p=>p.age>=22,
 t:'Un compañero en problemas',
 d:p=>`Un compañero está apostando fuerte y perdiendo. Te lo cuenta a vos y a nadie más.`,
 c:[
  {t:'Lo acompañás a pedir ayuda', ef:{moral:12, rep:4, trait:'lider'}, r:'Le salvás la carrera y probablemente algo más. Nunca se hizo público.'},
  {t:'Se lo contás al club', ef:{moral:4, mgrRel:8, fanLove:-4}, r:'El club actúa a tiempo. Él tarda años en volver a hablarte.'},
  {t:'Guardás el secreto y nada más', ef:{moral:-8}, r:'La cosa termina mal. Vos cargás con haberlo sabido.'}
 ]}
];

const EVENTS2 = [

{id:'i1', w:3, st:['ini'],
 t:'La última materia',
 d:p=>`Te quedan tres materias para terminar el secundario y los entrenamientos son a la mañana. El club dice que te arregla el tema. Tu vieja no quiere ni escuchar la palabra "arreglar".`,
 c:[
  {t:'Terminás el colegio como sea', ef:{moral:8, pas:2, trait:'profesional'}, r:'Rendís libre en diciembre. Diez años después vas a agradecer tener ese papel guardado.'},
  {t:'Dejás: el fútbol es ahora', ef:{fis:3, forma:6, moral:-4}, r:'Ganás tres horas por día. También una carta que nunca vas a poder jugar si esto no sale.'}
 ]},
{id:'i2', w:3, st:['ini'],
 t:'Dormís en la pensión',
 d:p=>`Cuarto compartido con cuatro pibes de distintas provincias. Uno llora todas las noches. Otro ya avisó que se vuelve. Vos tenés ${enLetras(p.age)} y quinientos kilómetros de distancia con tu casa.`,
 c:[
  {t:'Te convertís en el que sostiene al grupo', ef:{flag:'pupilo', moral:10, trait:'lider', fis:-2}, r:'Los cuatro llegan a debutar. Dos siguen siendo tus amigos veinte años después.'},
  {t:'Te enfocás en vos y en nada más', ef:{forma:10, def:2, moral:-6}, r:'Sos el primero de la pensión en firmar contrato. También el que menos llamadas recibe.'},
  {t:'Te volvés unos meses a tu casa', ef:{moral:14, forma:-10, mgrRel:-8}, r:'Volvés entero. Perdiste medio año y ganaste una cabeza que funciona.'}
 ]},
{id:'i3', w:3, st:['ini'],
 t:'El día del debut',
 d:p=>`Faltan doce minutos, van perdiendo y el técnico dice tu apellido. Te sacás la pechera con las manos temblando. Sesenta mil personas y tus viejos en la popular.`,
 c:[
  {t:'Pedís la pelota desde el primer toque', ef:{moral:12, hype:12, mgrRel:6, reg:2}, r:'Tocás nueve pelotas y no perdés ninguna. Al otro día estás en todas las portadas deportivas.'},
  {t:'Jugás corto y seguro', ef:{pas:3, mgrRel:8, moral:6}, r:'Nadie escribe sobre vos. El técnico sí se acuerda: te pone de titular la fecha siguiente.'},
  {t:'Intentás un caño en la primera', tira:'com', mas:-8, ef:{mgrRel:-10},
   bien:{ef:{reg:3, hype:10, fanLove:6}, r:'Sale. La tribuna estalla. El técnico te grita igual, porque perdieron.'},
   mal:{ef:{moral:-10, hype:-4, fanLove:-6}, r:'Te la roban en la mitad y de ese robo sale el segundo gol. Doce minutos de debut y ya sos el pibe del caño.'}}
 ]},
{id:'i4', w:2, st:['ini'],
 t:'Un veterano te toma de punto',
 d:p=>`El referente del plantel te hace la vida imposible en cada entrenamiento. Te esconde los botines, te grita por errores que no cometiste, te deja último en todo.`,
 c:[
  {t:'Le aguantás sin decir una palabra', ef:{fis:3, mgrRel:6, moral:-8}, r:'A los dos meses te invita a comer a su casa. Era una prueba. Una prueba de mierda, pero una prueba.'},
  {t:'Lo encarás delante de todos', ef:{moral:10, fis:2, mgrRel:-6, trait:'polemico'}, r:'Casi se van a las manos. El vestuario se divide. A vos nadie te vuelve a tocar nada.'},
  {t:'Le contás al técnico', ef:{mgrRel:4, moral:-4, fanLove:-4}, r:'Se corta el problema. También te ganás la fama de que corrés a llorar.'}
 ]},
{id:'i5', w:3, st:['ini'],
 t:'La prueba en el exterior',
 d:p=>`Diez días entrenando con las inferiores de un club grande del exterior. Frío, idioma que no entendés, y treinta pibes compitiendo por dos lugares.`,
 c:[
  {t:'Jugás a lo que sos: descarado', ef:{reg:3, hype:12, moral:6}, r:'Te dicen que sos "demasiado individualista" y que te quieren igual. Contradicción europea clásica.'},
  {t:'Estudiás cómo juegan y te adaptás', ef:{pas:3, dfs:2, mgrRel:6, moral:4}, r:'El informe dice "inteligencia táctica superior a la media". Te quieren para el año siguiente.'},
  {t:'Jugás a no equivocarte: ni una pelota perdida', ef:{pas:2, dfs:2, moral:-2, hype:-8}, r:'El informe dice "correcto, sin riesgo". Nadie tiene nada malo que decir de vos y nadie se acuerda de tu nombre.'}
 ]},
{id:'i6', w:2, st:['ini'],
 t:'El primer contrato',
 d:p=>`Te ponen un papel adelante. Cinco años, cláusula alta, sueldo que para vos es una fortuna y para el club es nada. Tu representante dice que firmes ya.`,
 c:[
  {t:'Firmás sin leer', ef:{moral:10, wage:15, hype:6, contrato:5}, r:'Comprás el primer auto de tu vida. Dos años después descubrís lo que significa una cláusula de recompra.'},
  {t:'Pedís una semana para que lo mire un abogado', ef:{moral:4, mgrRel:-4, wage:5, trait:'profesional', contrato:5}, r:'Sacás dos cláusulas venenosas. El club se molesta y te respeta al mismo tiempo.'},
  {t:'Negociás menos años a cambio de más libertad', ef:{moral:6, hype:8, mgrRel:-6, contrato:2}, r:'Contrato corto. Si explotás, en dos años elegís vos. Si no, quedás en la calle.'}
 ]},
{id:'i7', w:2, st:['ini'],
 t:'El gol que subieron a internet',
 d:p=>`Un gol tuyo de la Séptima llega a dos millones de reproducciones. De un día para el otro, gente que no sabe tu nombre te pide fotos.`,
 c:[
  {t:'Aprovechás y armás tus redes en serio', ef:{hype:16, moral:6, mgrRel:-6}, r:'Cien mil seguidores antes de debutar. Presión gratis que nadie te pidió.'},
  {t:'No abrís nada y seguís entrenando', ef:{forma:8, mgrRel:8, hype:-4}, r:'El video se olvida en dos semanas. Vos seguís exactamente donde tenías que estar.'}
 ]},
{id:'i8', w:2, st:['ini'],
 t:'Estirón',
 d:p=>`Creciste once centímetros en un año. No coordinás, te duelen las rodillas, y de golpe sos lento con tu propio cuerpo.`,
 c:[
  {t:'Trabajo de coordinación con el kinesiólogo', ef:{fis:4, rit:3, moral:-4}, r:'Seis meses feos. Después salís del otro lado siendo más grande y más ágil que antes.'},
  {t:'Forzás para seguir el ritmo del grupo', ef:{rit:2, fis:2, fitness:-12, trait:'cristal'}, r:'Aguantás. Las rodillas se acuerdan de esta temporada durante toda tu carrera.'}
 ]},
{id:'i9', w:2, st:['ini'],
 t:'Un amigo queda libre',
 d:p=>`Tu compañero de habitación, el que jugaba mejor que vos a los catorce, queda libre. Se vuelve al pueblo el domingo. Te pide que no lo acompañes a la terminal.`,
 c:[
  {t:'Lo acompañás igual', ef:{moral:6, trait:'lider'}, r:'No se dicen casi nada en el viaje. Es lo mejor que hiciste en todo el año.'},
  {t:'Respetás lo que pidió', ef:{moral:-4, forma:6}, r:'Entrenás esa mañana como un animal. El fútbol también se juega con culpa.'}
 ]},
{id:'i10', w:2, st:['ini','asc'],
 t:'Convocatoria juvenil',
 d:p=>`Te llaman a la selección juvenil. El club prefiere que no vayas: hay partidos importantes esas mismas fechas.`,
 c:[
  {t:'Vas a la selección', ef:{rep:8, moral:10, mgrRel:-10}, r:'Jugás un torneo entero y te ven todos los ojeadores del mundo. Volvés a un técnico enojado.'},
  {t:'Te quedás en el club', ef:{mgrRel:14, forma:6, rep:-3}, r:'El técnico no lo olvida. Te da la titularidad que le pediste sin pedírsela.'}
 ]},
{id:'i11', w:2, st:['ini'],
 t:'"Es muy chico para esto"',
 d:p=>`Un periodista influyente escribe que te están quemando, que no tenés físico para primera y que en dos años nadie se va a acordar de tu nombre.`,
 c:[
  {t:'Lo recortás y lo pegás en tu cuarto', ef:{moral:8, forma:10, fis:2}, r:'Lo mirás todos los días durante cuatro años. Después le mandás una foto del recorte con una copa al lado.'},
  {t:'No lo leés y seguís', ef:{moral:6, mgrRel:4}, r:'La indiferencia también es una forma de blindaje.'}
 ]},
{id:'i12', w:2, st:['ini'],
 t:'La barra quiere hablar con el plantel',
 d:p=>`Después de tres derrotas, un grupo aparece en el predio. El capitán junta a todos. A vos te dicen que te quedes atrás y no hables.`,
 c:[
  {t:'Te quedás atrás como te dijeron', ef:{moral:-6, mgrRel:4}, r:'Escuchás cosas que ningún pibe de esa edad debería escuchar. Aprendés dónde estás parado.'},
  {t:'Das un paso al frente con los grandes', ef:{moral:6, fanLove:8, mgrRel:6, rep:3}, r:'El capitán te mira distinto desde ese día. Coraje mal usado, pero coraje.'}
 ]},
{id:'i13', w:2, st:['ini'],
 t:'Sos suplente del suplente',
 d:p=>`Tercera opción en tu puesto. Entrenás toda la semana para mirar los partidos desde arriba.`,
 c:[
  {t:'Pedís jugar en Reserva todos los fines de semana', ef:{forma:12, fis:3, mgrRel:4}, r:'Treinta partidos en las piernas mientras los otros dos se oxidan en el banco.'},
  {t:'Aguantás en el plantel principal', ef:{pas:2, dfs:2, moral:-6}, r:'Entrenás con los mejores y no jugás con nadie. Vas a tardar más, pero vas a llegar mejor.'}
 ]},
{id:'i14', w:2, st:['ini'],
 t:'Primera pretemporada de verdad',
 d:p=>`Doble turno, treinta y ocho grados, y un preparador que parece disfrutarlo. Dos pibes vomitaron. Uno abandonó.`,
 c:[
  {t:'Terminás primero en todos los trabajos', ef:{fis:5, rit:2, mgrRel:8, fitness:-4}, r:'El técnico anota tu nombre en una libreta. Ese verano te ganaste el banco de suplentes.'},
  {t:'Dosificás para no romperte', ef:{fitness:8, fis:2, mgrRel:-4}, r:'Llegás entero a agosto. El técnico piensa que te falta hambre.'}
 ]},

{id:'a1', w:3, st:['asc'],
 t:'La cláusula',
 d:p=>`Un club europeo pagó tu cláusula sin avisarle a nadie. El teléfono no para. Tenés setenta y dos horas para decidir tu vida.`,
 c:[
  {t:'Te vas ya mismo', ofr:{t:'europa',cuando:'ya'}, ef:{hype:18, moral:8, fanLove:-10, rep:6}, r:'Adiós en Instagram, foto en el aeropuerto, presentación en cuarenta y ocho horas. Todo pasa demasiado rápido.'},
  {t:'Pedís quedarte seis meses más', ofr:{t:'europa',cuando:'ventana'}, ef:{fanLove:16, moral:6, hype:-4}, r:'El club europeo acepta. Te vas siendo campeón y despedido de pie por el estadio entero.'},
  {t:'Rechazás: no te sentís listo', ef:{moral:-4, forma:10, fanLove:12, rep:-4}, r:'Todos dicen que estás loco. Un año después llegan tres ofertas mejores.'}
 ]},
{id:'a2', w:3, st:['asc'], when:p=>L(C(p.club).lg).pais!==p.nat,
 t:'El vestuario de otro país',
 d:p=>`Llegaste. Y en el vestuario hay ocho idiomas, tres grupitos y nadie con demasiadas ganas de hacerte lugar.`,
 c:[
  {t:'Te acercás al grupo de los que hablan tu idioma', ef:{moral:10, forma:4, pas:1}, r:'Comodidad inmediata. También un techo: nunca terminás de integrarte del todo.'},
  {t:'Te obligás a comer con gente distinta cada día', ef:{moral:6, mgrRel:8, pas:3, trait:'lider'}, r:'A los seis meses sos el que traduce para los que llegan. El vestuario es tuyo.'},
  {t:'Hablás poco y jugás mucho', ef:{forma:12, moral:-6}, r:'El respeto llega por el rendimiento. Es más lento y menos cálido, pero llega.'}
 ]},
{id:'a3', w:3, st:['asc'],
 t:'Tu primer clásico de verdad',
 d:p=>`Te enterás de lo que significa cuando ves llorar a un utilero de sesenta años en la charla previa.`,
 c:[
  {t:'Salís a comerte la cancha', ef:{fis:3, forma:10, fanLove:12, mgrRel:4}, r:'Corrés como nunca. No hacés goles pero la gente canta tu nombre igual.'},
  {t:'Jugás frío, sin dejarte llevar', ef:{pas:3, mgrRel:8, moral:4}, r:'Das la asistencia del gol del triunfo. La cabeza fría gana clásicos.'}
 ]},
{id:'a4', w:2, st:['asc'], when:p=>L(C(p.club).lg).pais!==p.nat && !p.loanFrom && paisConLiga(p),
 t:'Primer año sin explotar',
 d:p=>`Doce partidos, cero goles, y la prensa local ya escribió dos veces la palabra "fracaso" al lado de tu apellido.`,
 c:[
  {t:'Pedís al club un plan de adaptación en serio', ef:{moral:12, mgrRel:8, pas:2}, r:'Psicólogo, profesor de idioma, casa más cerca del predio. Al semestre siguiente sos otro.'},
  {t:'Pedís volver a préstamo a tu país', ofr:{t:'nat',cuando:'ya',prestamo:true}, ef:{forma:14, moral:10, rep:-4, hype:-8}, r:'Un año en casa te devuelve el fútbol. Volvés a tu club sin miedo.'},
  {t:'Te la bancás en silencio', ef:{moral:-10, forma:-6, fis:3}, r:'Temporada perdida. Pero al año siguiente ya nada te asusta.'}
 ]},
{id:'a5', w:2, st:['asc'],
 t:'La novia, el país y la distancia',
 d:p=>`Tu pareja no quiere mudarse. Tiene su carrera, su familia, su vida. Y vos acabás de firmar por cuatro años a diez mil kilómetros.`,
 c:[
  {t:'Priorizás la relación y armás una rutina de viajes', ef:{moral:10, fitness:-6, forma:-4}, r:'Vivís en aviones. Funciona en lo personal y te cuesta en las piernas.'},
  {t:'Lo dejan acá', ef:{moral:-12, forma:8}, r:'Te volcás entero al fútbol. Rendís mejor que nunca y dormís peor que nunca.'},
  {t:'Ella se muda y vos te comprometés en serio', ef:{moral:16, forma:6}, r:'Se casan al año siguiente. Tener la vida ordenada afuera se nota adentro.'}
 ]},
{id:'a6', w:2, st:['asc'],
 t:'Te ofrecen la 10',
 d:p=>`Se fue el dueño del número histórico del club. El utilero te pregunta si la querés. Tenés ${enLetras(p.age)}.`,
 c:[
  {t:'La agarrás', ef:{hype:14, moral:8, fanLove:6, forma:-4}, r:'Pesa. Los primeros meses jugás mirando la espalda de un fantasma. Después es tuya.'},
  {t:'Te quedás con la tuya', ef:{moral:6, fanLove:8, mgrRel:4}, r:'"Los números se ganan, no se heredan." A la gente le encanta la frase.'}
 ]},
{id:'a7', w:2, st:['asc'],
 t:'La cancha vacía',
 d:p=>`Sanción al club: tres partidos a puertas cerradas. Se escucha todo: los gritos del banco, los insultos, tu propia respiración.`,
 c:[
  {t:'Usás el silencio para hablar y ordenar al equipo', ef:{mgrRel:10, pas:2, trait:'lider'}, r:'Descubrís que tenés voz de conductor. El técnico lo escucha desde el banco.'},
  {t:'Te metés para adentro: auriculares hasta el pitazo', ef:{forma:8, moral:4, lid:-3}, r:'Aislado de un ruido que no está, rendís. El vestuario nota que en tres partidos raros no dijiste una sola palabra.'}
 ]},
{id:'a8', w:2, st:['asc'], veta:'clausulaPais',
 t:'Un club rival te ofrece el doble',
 d:p=>`Y es el clásico rival. La oferta deportiva y económica es claramente superior. La hinchada te destrozaría.`,
 c:[
  {t:'Ni lo escuchás', ef:{fanLove:20, moral:8, wage:-3, trait:'idolo'}, r:'La tribuna se entera y te lo devuelve durante años.'},
  {t:'Aceptás: es tu carrera', ofr:{t:'rival',cuando:'ya'}, ef:{flag:'tentado', wage:18, hype:22, fanLove:-40, rep:5, trait:'mercenario'}, r:'Te cambia la vida económica y te marca para siempre. Dos hinchadas: una te odia, la otra desconfía.'}
 ]},
{id:'a9', w:2, st:['asc'],
 t:'Sos el cuarto en la fila',
 d:p=>`Hay tres jugadores antes que vos en el puesto y todos son internacionales. El técnico te dice, honestamente, que este año no vas a jugar.`,
 c:[
  {t:'Te quedás a robarles el puesto entrenando', ef:{fis:4, dfs:2, forma:6, moral:-6}, r:'Dos se lesionan en noviembre. Cuando llega tu chance, estás listo.'},
  {t:'Buscás salida a un club donde jugar', ofr:{t:'menor',cuando:'ventana'}, ef:{forma:14, moral:8, rep:-2, flag:'quiereIrse', mem:{plantes:1}}, r:'Treinta y cinco partidos en un club chico. A los veintitrés valés el triple.'}
 ]},
{id:'a10', w:2, st:['asc'],
 t:'La barbaridad del representante',
 d:p=>`Tu agente declara públicamente que el club "no está a tu altura". Vos no sabías nada. El vestuario lo leyó antes que vos.`,
 c:[
  {t:'Salís a desmentirlo y lo echás', ef:{mgrRel:12, fanLove:10, moral:-6, hype:-6}, r:'Perdés al que te consiguió todo. Ganás un vestuario entero.'},
  {t:'No decís nada y dejás que hierva', ef:{mgrRel:-14, hype:12, fanLove:-10}, r:'Se instala que querés irte. La temporada se te hace larguísima.'}
 ]},
{id:'a11', w:2, st:['asc'],
 t:'Debut en la Champions',
 d:p=>`Suena el himno. Mirás para arriba y el estadio es un anillo de luz. Tenés ${enLetras(p.age)} años y las piernas de cemento.`,
 c:[
  {t:'Pedís la pelota en el primer minuto', tira:'com', mas:14, ef:{hype:8},
   bien:{ef:{moral:12, hype:6, reg:2, rep:5}, r:'Encarás, te la sacan, y volvés a pedirla. Eso es lo que ven los que saben.'},
   mal:{ef:{moral:-12, forma:-6, mgrRel:-6}, r:'La primera te tiembla, la segunda la regalás y a la tercera el técnico te grita que juegues simple. Te cambian a los sesenta.'}},
  {t:'Entrás de a poco al partido', ef:{pas:3, mgrRel:6, moral:6}, r:'Segundo tiempo enorme. Terminás siendo la figura del equipo.'}
 ]},
{id:'a12', w:2, st:['asc'],
 t:'Tres goles en un partido',
 d:p=>`Póker perdido por poco: hiciste tres y te anularon el cuarto. El estadio te pide que te lleves la pelota firmada.`,
 c:[
  {t:'Se la regalás a un pibe de la platea', ef:{fanLove:16, moral:8, hype:8}, r:'La foto da la vuelta al mundo. El pibe la tiene enmarcada veinte años después.'},
  {t:'La firman todos y te la quedás', ef:{moral:10, def:2}, r:'Primera pelota de tu vitrina. Vas a juntar varias más.'}
 ]},

{id:'p1', w:3, st:['ple'],
 t:'Te quiere el club más grande del mundo',
 d:p=>`No es una oferta cualquiera. Es *ese* club. El presidente te llama por teléfono personalmente un martes a la noche.`,
 c:[
  {t:'Aceptás sin negociar nada', ofr:{t:'gigante',cuando:'ya'}, ef:{hype:24, rep:10, moral:10, wage:12}, r:'Presentación con estadio lleno. Ahora cada partido tuyo es un juicio público.'},
  {t:'Negociás rol, número y proyecto', ofr:{t:'gigante',cuando:'ya'}, ef:{hype:16, rep:8, mgrRel:8, moral:8}, r:'Llegás con condiciones claras. Los que llegan así duran el doble.'},
  {t:'Rechazás: acá sos feliz', ef:{fanLove:22, moral:12, rep:-4, trait:'idolo'}, r:'La ciudad entera te lo agradece. Vas a preguntarte "y si" durante años.'}
 ]},
{id:'p2', w:3, st:['ple'],
 t:'Final de la Champions',
 d:p=>`Es el partido más importante de tu vida. Dormiste cuatro horas. En el túnel, un rival te dice al oído que hoy no existís.`,
 c:[
  {t:'Jugás para vos: te la jugás', tira:'com', ef:{hype:8},
   bien:{ef:{moral:10, reg:2, hype:8, trait:'clutch'}, r:'Encarás nueve veces. Ganás cuatro. Una termina en el gol que define todo.'},
   mal:{ef:{moral:-14, forma:-8, fanLove:-6}, r:'Encarás nueve veces y perdés ocho. La única final de tu vida, y la imagen que va a quedar de vos es esa.'}},
  {t:'Jugás para el equipo, sin brillar', ef:{mgrRel:12, pas:3, moral:8}, r:'Corrés doce kilómetros y tocás simple. El técnico dice que fuiste clave. Nadie te vota.'},
  {t:'Le pedís al técnico que no estés en la lista de penales', ef:{moral:6, forma:6, hype:-12, rep:-4}, r:'Jugás noventa minutos limpios y útiles. La tanda la patean otros y el héroe es otro. Nadie se enteró nunca de lo que pediste, y vos no te lo olvidaste.'}
 ]},
{id:'p3', w:2, st:['ple'],
 t:'Nace tu primer hijo',
 d:p=>`En plena temporada. La primera noche entera sin dormir de tu vida no fue por un partido.`,
 c:[
  {t:'Reordenás todo alrededor de tu familia', ef:{moral:18, forma:-6, fitness:-4, trait:'profesional', flag:'padre'}, r:'Jugás distinto: menos ansioso, más sereno. La gente lo nota y no sabe por qué.'},
  {t:'Seguís el mismo ritmo profesional', ef:{forma:10, moral:-6, flag:'padre'}, r:'No te perdés un entrenamiento. Te perdés otras cosas.'}
 ]},
{id:'p4', w:2, st:['ple'],
 t:'El técnico se va por vos',
 d:p=>`Se rompió la relación. El club elige. Se va él. El vestuario sabe que fue tu peso el que decidió.`,
 c:[
  {t:'Asumís el poder que tenés', ef:{rep:8, moral:8, mgrRel:-6, trait:'capitan', flag:'capitan'}, r:'Ahora sos el que manda de verdad. También el único responsable si esto sale mal.'},
  {t:'Pedís públicamente que se quede', ef:{mgrRel:16, fanLove:8, rep:4}, r:'Se va igual, pero te agradece delante de todos. Ganaste algo que no se mide.'}
 ]},
{id:'p5', w:2, st:['ple'], when:p=>p.nt.caps>=10,
 t:'Cuestionan tu nivel en la selección',
 d:p=>`En tu club sos intocable. En tu país dicen que no rendís lo mismo con esa camiseta y que hay otros que la merecen más.`,
 c:[
  {t:'Pedís asumir el peso: querés el 10 y los penales', ef:{rep:8, moral:6, trait:'clutch'}, r:'Te hacés cargo de todo. Si sale bien sos eterno; si sale mal, culpable único.'},
  {t:'Jugás sin protagonismo, al servicio del equipo', ef:{pas:4, rep:4, moral:4}, r:'La crítica baja de a poco. Los números no gritan pero se acumulan.'},
  {t:'Te bajás de una convocatoria', ef:{moral:8, rep:-10, hype:8, trait:'polemico'}, r:'Se arma un escándalo nacional. Vuelve a llamarte el técnico siguiente.'}
 ]},
{id:'p6', w:2, st:['ple'],
 t:'La huelga de futbolistas',
 d:p=>`El sindicato pide parar por los sueldos impagos de las categorías chicas. A vos no te deben un peso. Te piden que des la cara porque sos el más conocido.`,
 c:[
  {t:'Encabezás el reclamo', ef:{rep:10, moral:8, hype:14, mgrRel:-8}, r:'Los clubes te odian y trescientos jugadores cobran. Elegiste bien.'},
  {t:'Apoyás en silencio, sin exponerte', ef:{moral:4, rep:2}, r:'Firmás todo lo que hay que firmar sin salir en ninguna foto.'},
  {t:'Te mantenés al margen', ef:{mgrRel:6, rep:-6, moral:-6}, r:'Nadie te lo reprocha en público. Algunos colegas no te lo perdonan en privado.'}
 ]},
{id:'p7', w:2, st:['ple'],
 t:'Récord del club a tiro',
 d:p=>`Te faltan cuatro goles para el récord histórico de la institución. Quedan tres fechas y el equipo ya no se juega nada.`,
 c:[
  {t:'Vas por el récord con todo', ef:{def:3, moral:10, mgrRel:-6, fanLove:8}, r:'Lo rompés en la última fecha, de penal, con el estadio de pie. Algunos compañeros no aplauden.'},
  {t:'Jugás normal, si viene que venga', ef:{mgrRel:8, moral:4, pas:2}, r:'Te quedás a uno. El récord sigue esperando. Vos también.'}
 ]},
{id:'p8', w:2, st:['ple'],
 t:'Una lesión en el peor momento',
 d:p=>`Faltan cinco semanas para el torneo más importante de tu vida y el médico dice ocho.`,
 c:[
  {t:'Rehabilitación agresiva para llegar', ef:{fitness:-16, moral:10, trait:'cristal', mem:{infiltraciones:1}}, r:'Llegás al 70%. Jugás igual. El cuerpo te pasa la factura durante dos temporadas.'},
  {t:'Aceptás que te lo perdés', ef:{moral:-16, fitness:10, fis:3}, r:'Lo ves por televisión. Es el peor mes de tu carrera y el más sano de tu cuerpo.'}
 ]},
{id:'p9', w:2, st:['ple'],
 t:'Te quieren de imagen de una apuesta deportiva',
 d:p=>`La cifra es enorme. También sabés lo que están haciendo esas empresas con la gente de tu barrio.`,
 c:[
  {t:'Rechazás y explicás por qué', ef:{rep:12, moral:10, hype:12}, r:'Se genera un debate nacional. Otros jugadores empiezan a rechazar contratos parecidos.'},
  {t:'Firmás: es trabajo', ef:{wage:14, moral:-8, fanLove:-8}, r:'Cobrás muchísimo. Cada vez que ves la publicidad, cambiás de canal.'}
 ]},
{id:'p10', w:2, st:['ple'],
 t:'El club vende a tu mejor amigo',
 d:p=>`Se van del vestuario el tipo con el que compartiste todo. Se enteró por Twitter.`,
 c:[
  {t:'Reclamás a la dirigencia públicamente', ef:{moral:6, fanLove:10, mgrRel:-10, trait:'polemico'}, r:'No cambia nada, pero el plantel sabe que si pasa de nuevo, alguien va a hablar.'},
  {t:'Lo acompañás en privado y seguís', ef:{moral:4, mgrRel:6}, r:'Se van juntos a comer la última noche. El fútbol es esto, también.'}
 ]},
{id:'p11', w:2, st:['ple'],
 t:'Un pibe de la cantera te pide el puesto',
 d:p=>`Tiene dieciocho, hace cosas que vos no hacés, y el técnico ya lo puso dos veces antes que a vos.`,
 c:[
  {t:'Le enseñás todo lo que sabés', ef:{moral:10, mgrRel:10, trait:'lider', forma:-4}, r:'Termina siendo el mejor del club. Y en cada entrevista dice tu nombre.'},
  {t:'Le hacés sentir el peso de la jerarquía', ef:{forma:10, fis:2, moral:-6, mgrRel:-6}, r:'Le ganás el puesto un año más. El vestuario toma nota de cómo lo hiciste.'}
 ]},
{id:'p12', w:2, st:['ple'],
 t:'Ofrecen comprarte una liga entera',
 d:p=>`Un proyecto nuevo, sin historia, con dinero infinito. Serías la cara del campeonato. Nadie que te importe te vería jugar en directo.`,
 c:[
  {t:'Rechazás y renovás donde estás', ef:{fanLove:14, moral:8, rep:5, contrato:3}, r:'"Todavía tengo cosas que ganar acá." La frase se vuelve remera.'},
  {t:'Escuchás y usás la oferta para negociar', ef:{wage:16, moral:4, fanLove:-6, contrato:2}, r:'Te mejoran el contrato para retenerte. Funcionó, pero dejó gusto a chantaje.'}
 ]},

{id:'v1', w:3, st:['vet'],
 t:'Ya no llegás a esa pelota',
 d:p=>`Una pelota dividida que hace tres años ganabas siempre. Hoy llegaste medio segundo tarde y lo notaste vos antes que nadie.`,
 c:[
  {t:'Ajustás tu juego: posición en vez de velocidad', ef:{pas:5, dfs:4, rit:-2, moral:6, trait:'profesional'}, r:'Empezás a leer el partido tres jugadas antes. Envejecer bien es un talento aparte.'},
  {t:'Trabajás el doble para recuperar el ritmo', ef:{rit:2, fis:2, fitness:-12}, r:'Recuperás algo durante un año. Después el cuerpo cobra los intereses.'},
  {t:'Lo negás y seguís igual', ef:{moral:6, forma:-8, mgrRel:-6}, r:'Te siguen ganando esa pelota. Todos lo ven menos vos.'}
 ]},
{id:'v2', w:2, st:['vet'],
 t:'El nuevo técnico tiene 38 años',
 d:p=>`Es más joven que algunos de tus compañeros y tiene ideas que no existían cuando debutaste. Pide que corras el doble y toques la mitad.`,
 c:[
  {t:'Te ponés a estudiar de nuevo', ef:{dfs:4, pas:3, mgrRel:14, moral:6}, r:'A los treinta aprendés a jugar de otra manera. Te alarga la carrera tres años.'},
  {t:'Le hacés sentir tu jerarquía', ef:{moral:6, mgrRel:-16, forma:-6}, r:'Ganás la pulseada en el vestuario y perdés minutos en la cancha.'}
 ]},
{id:'v3', w:2, st:['vet'],
 when:p=>lejosDeCasa(p),
 t:'La oferta para volver a casa',
 d:p=>`El club de tus amores te quiere de vuelta. Menos plata, peor liga, mucho más ruido. Tu viejo no dice nada pero se le nota.`,
 c:[
  {t:'Volvés', ofr:{t:'casa',cuando:'ya'}, ef:{moral:18, fanLove:26, wage:-30, rep:-4, trait:'idolo'}, r:'Estadio lleno un martes para verte firmar. Nunca vas a jugar más liviano.'},
  {t:'Te quedás un par de años más donde estás', ef:{wage:6, rep:4, moral:-6}, r:'Lo profesional manda. La vuelta queda pendiente y el club sigue esperando.'}
 ]},
{id:'v4', w:2, st:['vet'],
 t:'Te dejan afuera de la lista continental',
 d:p=>`El club puede inscribir a un número limitado de jugadores. Te dejan afuera para meter a un refuerzo joven.`,
 c:[
  {t:'Lo aceptás y sostenés al grupo desde adentro', ef:{mgrRel:14, moral:-8, trait:'lider'}, r:'Nadie te ve, pero el plantel llega a semifinales con vos empujando desde el vestuario.'},
  {t:'Explotás y pedís salir en enero', ofr:{t:'menor',cuando:'ventana'}, ef:{moral:6, mgrRel:-18, hype:12, flag:'quiereIrse', mem:{plantes:1}}, r:'Te vas en el mercado de invierno. Tenías razón y no te sirvió de nada.'}
 ]},
{id:'v5', w:2, st:['vet'],
 t:'El curso de entrenador',
 d:p=>`Un ex compañero te dice que empieces la licencia ahora, mientras todavía jugás. Son dos años de cursada arriba de todo lo demás.`,
 c:[
  {t:'Te anotás', ef:{pas:3, dfs:3, moral:6, forma:-4, trait:'profesional'}, r:'Empezás a ver el fútbol desde afuera mientras seguís adentro. Te vuelve mejor jugador.'},
  {t:'Después del retiro', ef:{forma:8, moral:2}, r:'Sensato. También es lo que dicen los que después no lo hacen.'}
 ]},
{id:'v6', w:3, st:['vet'], when:p=>p.nt.caps>=48,
 t:'Cincuenta partidos con la selección',
 d:p=>`Llegás a la cifra redonda. Te dan una camiseta enmarcada en el vestuario antes del partido.`,
 c:[
  {t:'Hablás y agradecés a los que ya no están', ef:{moral:14, rep:6, trait:'capitan', flag:'capitan'}, r:'Se te quiebra la voz nombrando a tu primer técnico de infantiles. Todo el plantel de pie.'},
  {t:'Agradecés corto y salís a jugar', ef:{forma:10, moral:6}, r:'Partido enorme. Los homenajes se cobran en la cancha.'}
 ]},
{id:'v7', w:2, st:['vet'],
 t:'Una lesión que no termina de irse',
 d:p=>`Molestia en el pubis desde hace ocho meses. Se va con infiltraciones y vuelve con cada partido.`,
 c:[
  {t:'Operación y cinco meses afuera', ef:{fitness:16, fis:3, moral:-12, forma:-14}, r:'Te perdés media temporada. Volvés sin dolor por primera vez en un año.'},
  {t:'Convivís con el dolor hasta fin de temporada', ef:{fitness:-14, moral:6, trait:'cristal', mem:{infiltraciones:1}}, r:'Terminás el año. El cuerpo nunca vuelve a ser el de antes.'}
 ]},
{id:'v8', w:2, st:['vet'],
 t:'Te ofrecen ser capitán general del club',
 d:p=>`No es solo la cinta. Es hablar con la dirigencia, ordenar el vestuario, dar la cara cuando se pierde.`,
 c:[
  {t:'Aceptás todo el paquete', ef:{rep:8, mgrRel:12, moral:6, forma:-4, trait:'capitan', flag:'capitan'}, r:'Sos el puente entre tres mundos que se odian. Agotador y honroso.'},
  {t:'Sólo la parte deportiva', ef:{moral:8, forma:8, mgrRel:4}, r:'Liderás en la cancha y dejás la política para otros. Se puede.'}
 ]},
{id:'v9', w:2, req:'padre', st:['vet'],
 t:'Tu hijo empieza a jugar',
 d:p=>`Siete años, y en cada partido de infantiles hay diez padres filmándolo porque es tu hijo.`,
 c:[
  {t:'Lo sacás del club y lo mandás a uno de barrio', ef:{moral:14, rep:4}, r:'Juega tranquilo por primera vez. Nadie lo filma. Vuelve a divertirse.'},
  {t:'Lo dejás y le enseñás a bancarse la presión', ef:{moral:6, trait:'lider'}, r:'Aprende joven lo que a vos te tocó a los veinte. Para bien y para mal.'}
 ]},
{id:'v10', w:2, st:['vet'],
 t:'Los últimos años valen oro',
 d:p=>`Tenés ${enLetras(p.age)} y dos caminos: un contrato enorme en una liga sin exigencia, o dos años más peleando arriba por menos plata.`,
 c:[
  {t:'La plata', ofr:{t:'golfo',cuando:'ya'}, ef:{wage:35, moral:6, rep:-8, fanLove:-12, trait:'mercenario'}, r:'Asegurás a tu familia para siempre. El fútbol de élite se olvida de vos en seis meses.'},
  {t:'La competencia', ef:{moral:10, forma:10, rep:6}, r:'Dos años más de exigencia máxima. Terminás la carrera donde querías terminarla.'}
 ]},

{id:'o1', w:3, st:['oca'],
 t:'Cada vez tardás más en recuperarte',
 d:p=>`Antes jugabas miércoles y domingo sin pensarlo. Ahora el martes todavía te duele el domingo anterior.`,
 c:[
  {t:'Hablás con el técnico para jugar un partido por semana', ef:{fitness:14, moral:4, mgrRel:6}, r:'Menos minutos, mejor nivel en cada uno. Estirás la carrera dos años.'},
  {t:'Seguís jugando todo', ef:{fitness:-16, moral:8, forma:-6}, r:'Orgullo puro. El cuerpo lo va a cobrar antes de lo que pensás.'}
 ]},
{id:'o2', w:3, st:['oca'],
 t:'La despedida',
 d:p=>`El club quiere organizarte un partido homenaje con estadio lleno y todos tus ex compañeros. Vos todavía no dijiste que te retirás.`,
 c:[
  {t:'Aceptás y ponés fecha a tu retiro', ef:{moral:16, fanLove:22, rep:6, retiro:1}, r:'Sabés exactamente cuántos partidos te quedan. Los jugás todos como si fueran finales.'},
  {t:'Pedís que esperen', ef:{forma:10, moral:8}, r:'"Cuando sienta que se terminó, aviso yo." Nadie discute.'}
 ]},
{id:'o3', w:2, st:['oca'],
 t:'Un pibe te pide la camiseta al final',
 d:p=>`Un rival de diecinueve años te frena en el túnel. Te dice que creció mirándote. Vos te sentís viejo y homenajeado al mismo tiempo.`,
 c:[
  {t:'Se la das y le decís algo que le sirva', ef:{moral:12, rep:4, trait:'lider'}, r:'Diez años después él cuenta esa charla en una entrevista. Se acuerda de cada palabra.'},
  {t:'Se la das y no decís nada', ef:{moral:6}, r:'Suficiente. Los gestos hablan.'}
 ]},
{id:'o4', w:2, st:['oca'],
 t:'Ofrecen que juegues en la liga de tu ciudad',
 d:p=>`Un club chico, sin presión, cerca de tu casa. Cobrarías casi nada. Llenarían la cancha todos los domingos.`,
 c:[
  {t:'Aceptás y jugás por el gusto', ofr:{t:'chico',cuando:'ya'}, ef:{moral:20, fanLove:16, wage:-60, rep:-6}, r:'Volvés a disfrutar como a los quince. Ningún periodista entiende la decisión y a vos no te importa.'},
  {t:'Preferís terminar arriba', ef:{moral:4, rep:4}, r:'Un año más en la elite. Terminar donde empezó todo, pero al máximo nivel.'}
 ]},
{id:'o5', w:2, st:['oca'],
 t:'Te sientan por primera vez en años',
 d:p=>`Suplente. Vos, que hace quince años no mirás un partido desde el banco.`,
 c:[
  {t:'Aceptás el rol y ayudás desde afuera', ef:{mgrRel:12, moral:-6, trait:'lider'}, r:'Sos el mejor suplente que tuvo el club. Los pibes aprenden más de vos sentado que jugando.'},
  {t:'Pedís salir a jugar a otro lado', ef:{moral:8, mgrRel:-12, flag:'quiereIrse', mem:{plantes:1}}, ofr:{t:'menor', cuando:'ventana'}, r:'Todavía te queda hambre. Es lo único que importa a esta edad.'},
  {t:'Anunciás el retiro a fin de temporada', ef:{moral:10, forma:-6, fanLove:10, retiro:1}, r:'Preferís irte jugando que sobrando. Es una manera muy digna de terminar.'}
 ]},
{id:'o6', w:2, st:['oca'],
 t:'El último clásico',
 d:p=>`Sabés que es el último que vas a jugar. La hinchada también lo sabe. Se cantó tu nombre durante los noventa minutos.`,
 c:[
  {t:'Salís a dejar todo lo que te queda', ef:{moral:16, fanLove:20, forma:10, fitness:-8}, r:'Corrés hasta que las piernas no dan más. Te sacan a los ochenta y el estadio entero se pone de pie.'},
  {t:'Lo jugás con calma, disfrutando', ef:{moral:12, pas:2, fanLove:12}, r:'Manejás el partido como un director de orquesta. Ganaron. Fue perfecto.'}
 ]},
{id:'o7', w:2, st:['oca'],
 t:'Ofrecen un puesto en el cuerpo técnico',
 d:p=>`El club te quiere desde el año que viene. Significa que ésta sería tu última temporada como jugador.`,
 c:[
  {t:'Aceptás y te retirás', ef:{moral:12, rep:6, retiro:1}, r:'Pasás del vestuario al pizarrón sin escala. Muy pocos hacen esa transición sin caerse.'},
  {t:'Pedís una temporada más', ef:{forma:8, moral:8}, r:'Te guardan el puesto. Jugás un año sabiendo exactamente qué viene después.'}
 ]},
{id:'o8', w:2, st:['oca'],
 t:'Nadie llama',
 d:p=>`Julio, sin club, sin ofertas. El teléfono suena sólo para publicidad. Entrenás solo en un parque a las siete de la mañana.`,
 c:[
  {t:'Seguís entrenando por si acaso', ef:{fitness:8, moral:-10, fis:2}, ofr:{t:'menor', cuando:'ventana'}, r:'En septiembre llama un club por una lesión de otro. Estabas listo. Casi nadie lo está.'},
  {t:'Aceptás que se terminó', ef:{moral:6, retiro:1}, r:'Ninguna despedida, ningún estadio. Una mañana simplemente no vas a entrenar. Así termina la mayoría.'}
 ]},

{id:'x1', w:2, st:['asc','ple','vet'],
 t:'Cambio de dueños en el club',
 d:p=>`Un fondo de inversión compra la institución. Prometen todo. En la primera reunión con el plantel hablan de "activos" y no de jugadores.`,
 c:[
  {t:'Te plantás como referente del grupo', ef:{rep:6, moral:6, mgrRel:8, trait:'capitan', flag:'capitan'}, r:'Conseguís garantías para el plantel entero. Los nuevos dueños te marcan en rojo.'},
  {t:'Te adaptás al nuevo mundo', ef:{wage:10, moral:4}, r:'Aprendés a hablar su idioma. Te va bien económicamente.'}
 ]},
{id:'x2', w:2, st:['ple','vet','oca'],
 t:'Racismo en la tribuna',
 d:p=>`Le pasa a un compañero. El árbitro quiere seguir jugando. El estadio hace como que no escuchó.`,
 c:[
  {t:'Te llevás al equipo al vestuario', ef:{rep:14, moral:8, hype:20, mgrRel:-4}, r:'El partido se suspende. La federación abre expediente. Tu compañero no te lo va a olvidar nunca.'},
  {t:'Exigís que lo anuncien por altavoz', ef:{rep:8, moral:6, hype:10}, r:'Protocolo activado por primera vez en ese estadio. Se sienta un precedente.'},
  {t:'Terminan el partido y hablan después', ef:{moral:-8, rep:-2}, r:'Comunicado tibio, dos semanas de ruido y nada cambia.'}
 ]},
{id:'x3', w:2, st:['asc','ple'],
 t:'Doble sesión secreta',
 d:p=>`Descubrís que dos compañeros entrenan aparte a la tarde, sin avisarle a nadie. Te invitan.`,
 c:[
  {t:'Te sumás', ef:{fis:3, def:3, forma:8, fitness:-4}, r:'Los tres terminan siendo los mejores del equipo esa temporada. Nadie supo por qué.'},
  {t:'Preferís descansar bien', ef:{fitness:8, moral:4}, r:'La recuperación también es entrenamiento. Los otros dos se lesionan en marzo.'}
 ]},
{id:'x4', w:2, st:['ini','asc','ple','vet','oca'],
 t:'Un hincha te para en la calle',
 d:p=>`Te cuenta que su viejo se murió el mes pasado y que el último partido que vieron juntos fue uno donde vos hiciste dos goles. Te abraza y llora.`,
 c:[
  {t:'Te quedás con él el tiempo que haga falta', ef:{moral:12, fanLove:10, rep:3}, r:'Cuarenta minutos parados en una esquina. Después vas a manejar en silencio hasta tu casa.'},
  {t:'Le firmás algo y seguís', ef:{fanLove:4, moral:-2}, r:'Es lo que se hace normalmente. Igual te queda dando vueltas toda la semana.'}
 ]},
{id:'x5', w:2, st:['asc','ple','vet'],
 t:'Te acusan de simular un penal',
 d:p=>`Las repeticiones son ambiguas. El árbitro lo cobró. El partido se definió con ese gol y el rival te trata de tramposo en todos los canales.`,
 c:[
  {t:'Reconocés públicamente que no fue penal', ef:{rep:12, moral:6, mgrRel:-8, fanLove:-8}, r:'Nadie lo esperaba. La mitad del país te aplaude y tu propia hinchada te putea.'},
  {t:'Sostenés que fue falta', ef:{moral:4, hype:8, rep:-4}, r:'Se apaga en dos semanas. Vos sabés lo que pasó.'},
  {t:'No hablás del tema', ef:{moral:-4, mgrRel:4}, r:'El silencio es cómodo. También es una respuesta.'}
 ]},
{id:'x6', w:2, st:['ple','vet'],
 t:'Tu club está en crisis institucional',
 d:p=>`Tres meses de sueldos atrasados, dirigentes que renuncian y un plantel que habla de no entrenar.`,
 c:[
  {t:'Ponés plata de tu bolsillo para el plantel menor', ef:{capital:-0.3, moral:12, fanLove:20, rep:8}, r:'Utileros, juveniles y empleados cobran gracias a vos. Se enteran igual, siempre se enteran.'},
  {t:'Encabezás la negociación con los dirigentes', ef:{rep:8, mgrRel:6, trait:'capitan', flag:'capitan', moral:4}, r:'Conseguís un plan de pagos. Reuniones interminables y ningún gol de por medio.'},
  {t:'Buscás salida antes de que se hunda', ef:{moral:-4, fanLove:-14, hype:6, flag:'quiereIrse', mem:{plantes:1}}, r:'Es lo más lógico. También lo que la gente menos perdona.'}
 ]}
];
EVENTS.push(...EVENTS2);

const EVENTS3 = [

{id:'g1', w:3, req:'agente', st:['asc','ple'], t:'La letra chica',
 d:'Un abogado amigo de tu viejo lee el contrato que firmaste con tu representante. Levanta la vista antes de terminar la segunda hoja. Veintidós por ciento de todo. De todo, incluido lo que ganes cuando él ya no esté.',
 c:[
  {t:'Pagás y seguís', ef:{wage:-14, moral:-6, flag:'agenteFiel'}, r:'Te sale caro. También te consigue reuniones que nadie más te consigue.'},
  {t:'Le mandás carta documento', ef:{moral:-10, hype:8, flag:'pleitoAgente'}, r:'Se corta la relación de golpe. Ahora atendés vos el teléfono.'},
  {t:'Renegociás cara a cara', ef:{moral:4, rep:2, wage:-6, flag:'agenteFiel'}, r:'Baja al catorce. Te mira distinto: ya no sos el pibe que firma sin leer.'}
 ]},
{id:'g2', w:3, req:'pleitoAgente', st:['asc','ple','vet'], t:'El juicio que no querías',
 d:'Tu ex representante te reclama comisiones de traspasos en los que ni participó. La audiencia cae en plena pretemporada. Tu abogado te dice que se puede arreglar por la mitad y en una tarde.',
 c:[
  {t:'Arreglás y te sacás el peso', ef:{wage:-10, moral:10, unflag:'pleitoAgente'}, r:'Firmás, pagás y te olvidás. La cabeza vale más que la plata.'},
  {t:'Vas hasta el final', ef:{moral:-8, forma:-8, rep:3}, r:'Dos años de audiencias. Ganás el juicio y perdés dos pretemporadas.'}
 ]},
{id:'g3', w:2, req:'agenteFiel', st:['ple','vet'], t:'Tu representante mueve una ficha',
 d:'Te llama un martes cualquiera. Dice que tiene algo hablado, que no pregunte con quién, que sólo diga sí o no antes del viernes.',
 c:[
  {t:'Confiás a ciegas', ofr:{t:'europa',cuando:'ventana'}, ef:{hype:14, moral:6}, r:'Le confiaste tu carrera a un llamado de dos minutos. Esta vez salió bien.'},
  {t:'Pedís saber todo primero', ef:{moral:2, mgrRel:4}, r:'Se enfría. Te enterás en diciembre de que era el club de tu vida.'}
 ]},

{id:'g4', w:16, req:'golfo', st:['ple','vet','oca'], t:'Vuelven, y con el doble',
 d:'Seis meses después el número creció tanto que ya no es una oferta: es una jubilación. Tu mujer no opina. Tu viejo tampoco. Los dos esperan que hables vos.',
 c:[
  {t:'Esta vez sí', ofr:{t:'golfo',cuando:'ya'}, ef:{moral:8, fanLove:-20, rep:-9, unflag:'golfo'}, r:'Te vas. El fútbol sigue sin vos y vos seguís sin el fútbol.'},
  {t:'Cerrás la puerta para siempre', ef:{moral:12, fanLove:16, rep:5, unflag:'golfo', trait:'lider'}, r:'Lo decís en cámara. La tribuna te lo devuelve durante años.'},
  {t:'Seguís sin contestar', ef:{moral:-8, hype:10, flag:'golfoFiltrado'}, r:'La duda ya no es una duda: es una manera de vivir.'}
 ]},
{id:'g5', w:14, req:'golfoFiltrado', st:['ple','vet','oca'], t:'Se filtró que lo estás pensando',
 d:'Un periodista publica capturas de los mensajes de tu entorno. Al otro día hay una bandera en la popular con tu nombre y una cifra al lado.',
 c:[
  {t:'Salís a dar la cara', ef:{fanLove:10, hype:8, moral:4, unflag:'golfoFiltrado'}, r:'No te creen del todo, pero valoran que hayas ido vos y no un comunicado.'},
  {t:'Te encerrás y jugás', ef:{moral:-6, forma:8, fanLove:-6}, r:'Tres goles en dos partidos. El silencio también es una respuesta.'},
  {t:'Culpás a tu entorno', ef:{moral:-4, rep:-6, fanLove:-10}, r:'Nadie te cree. Tu entorno tampoco te lo perdona.'}
 ]},

{id:'g6', w:5, req:'quiereIrse', st:['asc','ple','vet'], t:'A entrenar con la reserva',
 d:'El club acepta tu pedido de salida a su manera: te separan del plantel. Entrenás a las siete de la mañana con los juveniles, en la cancha de atrás, sin fotógrafos.',
 c:[
  {t:'Bajás la cabeza y pedís perdón', ef:{mgrRel:22, moral:-6, fanLove:8, unflag:'quiereIrse', flag:'reconciliado'}, r:'Volvés al grupo el jueves. Nadie lo menciona nunca más.'},
  {t:'Aguantás sin quebrarte', ef:{moral:-12, fitness:6, flag:'apartado', mem:{plantes:1}}, r:'Tres meses solo. Salís más fuerte y más frío.'},
  {t:'Lo contás todo en una entrevista', ef:{hype:18, rep:4, mgrRel:-25, fanLove:-12, flag:['apartado','enLaMira'], mem:{plantes:1}}, r:'La nota es un éxito. El vestuario se entera por Twitter.'}
 ]},
{id:'g7', w:14, req:'apartado', st:['asc','ple','vet'], t:'Se cerró el mercado y seguís acá',
 d:'Última noche de mercado. El teléfono no suena, la oferta que esperabas nunca llegó y el club no te va a regalar el pase. Quedan seis meses de esto.',
 c:[
  {t:'Te tragás el orgullo', ef:{mgrRel:16, moral:4, unflag:'apartado', flag:'reconciliado'}, r:'Volvés al banco primero y al equipo después. El fútbol perdona rápido cuando rendís.'},
  {t:'Cumplís el contrato en silencio', ef:{moral:-14, forma:-10, rep:-4}, r:'Seis meses de tu carrera que no van a figurar en ninguna estadística.'},
  {t:'Te rebajás el sueldo para que te dejen ir', ofr:{t:'menor',cuando:'ventana'}, ef:{wage:-22, moral:8, unflag:'apartado'}, r:'Pagás por irte. Es más común de lo que la gente cree.'}
 ]},
{id:'g8', w:3, req:'reconciliado', st:['ple','vet'], t:'El técnico te devuelve la cinta',
 d:'El mismo que te mandó a la reserva te llama a su oficina y te ofrece la capitanía. Dice que el grupo te eligió, que él sólo firma.',
 c:[
  {t:'La aceptás', ef:{moral:14, rep:8, mgrRel:10, trait:'capitan', flag:'capitan'}, r:'Salís primero al campo con la cinta que casi te cuesta el puesto.'},
  {t:'La rechazás con respeto', ef:{moral:6, mgrRel:4, fanLove:4}, r:'Preferís no deberle nada a nadie. Él lo entiende mejor de lo que esperabas.'}
 ]},

{id:'g9', w:16, st:['asc','ple'], when:p=>!!p.loanFrom, t:'Te quieren de vuelta antes de tiempo',
 d:'Estás jugando los mejores partidos de tu vida en el club que te pidió prestado. El club dueño activa una cláusula para llevarte en enero, al banco, pero con ellos.',
 c:[
  {t:'Volvés: es tu club', ef:{moral:-6, rep:4, forma:-8, volver:true}, r:'Doce partidos, seis de titular. Nadie recuerda lo que estabas haciendo antes.'},
  {t:'Te negás y terminás la cesión', ef:{moral:10, forma:12, mgrRel:-16, flag:'plantado', mem:{plantes:1}}, r:'Terminás la temporada donde jugabas. En tu club te lo van a cobrar.'}
 ]},
{id:'g10', w:14, req:'plantado', st:['asc','ple','vet'], t:'Volvés al club que dejaste esperando',
 d:'Julio. Pretemporada. El técnico que te reclamó en enero ya no está y el nuevo no sabe nada de aquello. El presidente sí.',
 c:[
  {t:'Hablás con el presidente de frente', ef:{rep:6, mgrRel:6, moral:6, unflag:'plantado'}, r:'Se sincera: en enero necesitaban una foto, no un jugador. Quedan a mano.'},
  {t:'Dejás que el tiempo lo tape', ef:{moral:-4, mgrRel:-6}, r:'Nadie lo menciona. Todos se acuerdan.'}
 ]},

{id:'g11', w:3, req:'tentado', st:['asc','ple'], t:'El capitán te encara en el vestuario',
 d:'Se sienta al lado tuyo cuando ya no queda nadie. No te acusa de nada. Sólo dice que él escuchó una oferta a tu edad y que todavía se acuerda de la cara del técnico cuando se enteró.',
 c:[
  {t:'Le contás todo', ef:{moral:8, mgrRel:8, rep:2, unflag:'tentado', flag:'pupilo'}, r:'Te guarda el secreto y te guarda la espalda. Los dos aprenden algo.'},
  {t:'Le decís que no pasó nada', ef:{moral:-6, mgrRel:-4}, r:'Te mira dos segundos de más. No vuelve a sentarse al lado tuyo.'}
 ]},
{id:'g12', w:2, req:'pupilo', st:['ple','vet'], t:'Ahora el que escucha sos vos',
 d:'Un pibe de veinte se sienta al lado tuyo en el mismo banco donde se sentó tu capitán. No dice nada. Espera.',
 c:[
  {t:'Le contás tu propia historia', ef:{moral:10, rep:6, fanLove:6, trait:'lider', flag:'mentor'}, r:'Se queda. Tres años después lo vas a ver debutar en una selección.'},
  {t:'Le decís que decida solo', ef:{moral:2}, r:'Se va a los diez minutos. Tal vez era lo que necesitaba escuchar.'}
 ]},

{id:'g13', w:4, req:'bonus', st:['asc','ple','vet'], t:'Te faltan dos goles y quedan tres fechas',
 d:'El bonus por el que resignaste sueldo está a dos goles. El equipo ya no se juega nada. Vos sí.',
 c:[
  {t:'Salís a buscarlos', ef:{moral:-4, forma:8, mgrRel:-8, unflag:'bonus'}, r:'Tirás siete veces al arco en un partido. Entra una. Alcanzó.'},
  {t:'Jugás para el equipo', ef:{moral:6, mgrRel:12, rep:4, wage:-6, unflag:'bonus', trait:'capitan', flag:'capitan'}, r:'Das dos asistencias y perdés la plata. El vestuario lo vio todo.'}
 ]},

{id:'g14', w:3, st:['ple','vet'], when:p=>p.age>=24, t:'Algo raro en la rodilla',
 d:'No duele. Cruje. El médico dice que si aguantás el dolor podés jugar el clásico y operarte en junio. Faltan cinco meses para junio.',
 c:[
  {t:'Jugás igual', ef:{fitness:-12, moral:6, fanLove:10, flag:'rodilla', mem:{infiltraciones:1}}, r:'Jugás el clásico. También los treinta partidos siguientes.'},
  {t:'Parás y te operás ya', ef:{fitness:8, moral:-10, forma:-14, flag:'rodillaOperada'}, r:'Tres meses afuera en el peor momento. La rodilla te lo agradece diez años.'}
 ]},
{id:'g15', w:5, req:'rodilla', st:['ple','vet','oca'], t:'La rodilla vuelve a hablar',
 d:'Se hincha después de cada partido. Te infiltrás los jueves para llegar a los domingos. Nadie del club te lo pide: lo arreglaste vos con el médico.',
 c:[
  {t:'Seguís infiltrándote', ef:{fitness:-16, forma:6, moral:-6, mem:{infiltraciones:1}}, r:'Llegás a todos los partidos. Vas a pagarlo cuando dejes de jugar.'},
  {t:'Frenás y te operás', ef:{fitness:14, forma:-16, moral:-8, unflag:'rodilla', flag:'rodillaOperada'}, r:'Tarde, pero a tiempo. Volvés distinto: más lento y más entero.'},
  {t:'Se lo contás al cuerpo médico', ef:{fitness:6, mgrRel:-8, moral:2, unflag:'rodilla'}, r:'Te bajan la carga. El técnico empieza a mirarte como a un jugador frágil.'}
 ]},
{id:'g16', w:4, req:'rodillaOperada', st:['ple','vet','oca'], t:'El primer partido después',
 d:'Ocho meses. Entrás a los setenta y ocho minutos con el resultado resuelto. El estadio se para antes de que toques la pelota.',
 c:[
  {t:'Salís a demostrar en veinte minutos', ef:{forma:10, moral:8, fitness:-6}, r:'Encarás tres veces. Dos salen mal y la gente igual grita.'},
  {t:'Jugás simple y llegás entero', ef:{fitness:10, forma:4, moral:6, unflag:'rodillaOperada'}, r:'Ocho pases, ningún riesgo, cero molestias. La carrera continúa.'}
 ]},

{id:'g17', w:3, st:['asc','ple'], when:p=>p.hype>=20, t:'Te tratan de sobrevalorado en televisión',
 d:'Un panelista dice que sos un invento del marketing y que en un equipo grande no jugarías. El video tiene doscientas mil reproducciones antes del entrenamiento.',
 c:[
  {t:'Le contestás en público', ef:{hype:16, moral:6, rep:2, flag:'enLaMira', mem:{polemicas:1}}, r:'Tu respuesta tiene más reproducciones que la crítica. Ahora sos parte del circo.'},
  {t:'No decís nada', ef:{moral:-4, forma:6, rep:3}, r:'Contestás con dos meses de buen fútbol. Es más lento y funciona mejor.'},
  {t:'Lo llamás por teléfono', ef:{moral:4, hype:4, rep:5}, r:'Hablan veinte minutos. Nunca más te pega, y vos nunca lo contás.'}
 ]},
{id:'g18', w:4, req:'enLaMira', st:['asc','ple','vet'], t:'Ahora te esperan en cada rueda de prensa',
 d:'Ya no te preguntan por el partido. Te preguntan por lo que dijo otro para ver si volvés a morder. Tu jefe de prensa te pide por favor que contestes en tres palabras.',
 c:[
  {t:'Contestás en tres palabras', ef:{hype:-8, rep:4, moral:2, unflag:'enLaMira'}, r:'Se aburren en dos semanas. Volvés a ser un futbolista.'},
  {t:'Les das lo que quieren', ef:{hype:20, rep:-4, fanLove:6, mem:{polemicas:1}}, r:'Vendés camisetas y entrevistas. También te ganás enemigos en cada vestuario.'},
  {t:'Dejás de ir a las conferencias', ef:{hype:6, rep:-6, mgrRel:-10, mem:{polemicas:1}}, r:'El club paga las multas. El técnico se cansa de responder por vos.'}
 ]},
{id:'g19', w:3, req:'enLaMira', st:['ple','vet'], when:p=>new Set(p.seasons.map(s=>s.clubId)).size>=2, t:'Una frase tuya, sin contexto',
 d:'Dijiste que en tu club anterior "no había nivel para pelear nada". Salió cortado en el minuto exacto que hacía falta. Jugás contra ellos en once días.',
 c:[
  {t:'Aclarás antes del partido', ef:{rep:4, moral:4, hype:-6}, r:'La aclaración no la levanta nadie. Igual dormís mejor.'},
  {t:'Te bancás el silbido', ef:{moral:-6, forma:10, hype:10}, r:'Noventa minutos de silbidos y un gol tuyo. Lo festejás mirando la tribuna.'},
  {t:'Pedís disculpas públicas', ef:{rep:6, fanLove:8, hype:-10, unflag:'enLaMira'}, r:'Costó decirlo. Se terminó ahí.'}
 ]},

{id:'g20', w:3, st:['ple','vet'], when:p=>p.rep>=52 && p.clubYears>=1, veta:'capitan',
 t:'El técnico te ofrece la cinta',
 d:'Te lo dice caminando hacia el micro, como si no fuera nada. Que a partir del domingo salís primero vos.',
 c:[
  {t:'Aceptás', ef:{rep:8, moral:10, mgrRel:8, trait:'capitan', flag:'capitan'}, r:'La primera vez que la levantás no sabés dónde mirar.'},
  {t:'Preferís que la lleve otro', ef:{moral:4, mgrRel:-4}, r:'Se la dan a un compañero. Sigue preguntándote las cosas a vos igual.'}
 ]},
{id:'g21', w:4, req:'capitan', st:['ple','vet'], t:'El vestuario se parte en dos',
 d:'Media docena de jugadores quiere ir a plantarle al presidente por las primas atrasadas. La otra mitad dice que es una locura a tres fechas del final. Los dos grupos te miran a vos.',
 c:[
  {t:'Encabezás el reclamo', ef:{rep:8, mgrRel:-12, moral:6, fanLove:-6}, r:'Cobran todos. El presidente no te lo perdona nunca.'},
  {t:'Frenás a los tuyos', ef:{mgrRel:16, rep:4, moral:-6}, r:'Terminan la temporada en paz. Cuatro compañeros dejan de hablarte.'},
  {t:'Buscás un punto medio', ef:{rep:6, mgrRel:6, moral:4, trait:'lider'}, r:'Consiguen la mitad ahora y la mitad en junio. Nadie queda contento y todos siguen jugando.'}
 ]},
{id:'g22', w:3, req:'capitan', st:['vet','oca'], t:'Te toca decirle a un compañero que se va',
 d:'El club decide no renovarle a un tipo de treinta y cuatro que estuvo doce años acá. Nadie quiere decírselo. El técnico te pide que vayas vos, que a vos te lo va a aceptar.',
 c:[
  {t:'Vas y se lo decís', ef:{moral:-8, rep:6, mgrRel:8, flag:'mentor'}, r:'Llora en el vestuario vacío. Te agradece que hayas sido vos.'},
  {t:'Te negás: no es tu trabajo', ef:{moral:4, mgrRel:-10}, r:'Se lo dicen por teléfono un martes. No se lo perdonás al club ni a vos.'}
 ]},

{id:'g23', w:3, req:'mentor', st:['vet','oca'], t:'El pibe que apadrinaste te pasa por arriba',
 d:'Juega tu puesto, tiene veintiuno y el técnico lo puso de titular contra vos. En la charla previa lo nombra a él para explicar el movimiento que inventaste vos.',
 c:[
  {t:'Le seguís enseñando', ef:{moral:6, rep:8, fanLove:10, trait:'lider'}, r:'Se lo vas a ver hacer en una final. Vos vas a estar en la tribuna y vas a saber de dónde salió.'},
  {t:'Peleás el puesto sin regalar nada', ef:{forma:12, moral:4, mgrRel:-6}, r:'Le ganás el puesto dos meses. Después el fútbol hace lo que hace siempre.'}
 ]},

{id:'g24', w:4, st:['asc','ple'], when:p=>p.attrs.aer<62,
 t:'El preparador te mide el salto',
 d:'Te pone contra una pared con una cinta métrica y te hace saltar diez veces. Anota. Después te muestra el número del central que juega en tu puesto en el equipo de arriba: once centímetros más que vos.',
 c:[
  {t:'Pliometría a las siete de la mañana, todo el año', ef:{aer:8, fis:2, forma:-6, moral:-4}, r:'Once meses de cajones y sentadillas antes de que salga el sol. En marzo ganás una pelota que el año pasado ni ibas a disputar.'},
  {t:'Trabajás el tiempo del salto, no la altura', ef:{aer:5, com:2}, r:'Te enseña que el que salta primero pierde. Empezás a llegar medio segundo después que todos y a ganarles igual.'},
  {t:'No es lo tuyo y no va a serlo', ef:{reg:3, moral:4}, r:'Te dedicás a lo que sabés hacer. Hay carreras enteras construidas al ras del piso.'}
 ]},
{id:'g25', w:3, st:['ple','vet'], when:p=>p.attrs.aer>=68,
 t:'Te piden que subas a todos los córners',
 d:'El técnico vio los números: ganás el 71% de las que disputás arriba. Quiere que subas a cada pelota parada, también a las de los últimos minutos con el partido empatado.',
 c:[
  {t:'Subís siempre, pase lo que pase', ef:{aer:4, def:2, fanLove:10, dfs:-2}, r:'Metés cuatro goles en la temporada. También te agarran dos contras que terminan en gol con tu zona vacía.'},
  {t:'Subís sólo cuando el partido lo pide', ef:{aer:2, com:3, mgrRel:6}, r:'Elegís bien y el técnico lo nota. El gol que hacés en abril vale tres puntos.'},
  {t:'Preferís quedarte atrás', ef:{dfs:3, mgrRel:-6}, r:'No te encontrás un gol en todo el año. Tampoco te encuentran a vos de contra.'}
 ]},

{id:'g26', w:4, st:['ple','vet'], t:'El penal que te va a perseguir',
 d:'Último minuto, semifinal, empate. Agarrás la pelota porque nadie más la quiere. Tomás carrera. El arquero ni se mueve: la mandás a la tribuna.',
 c:[
  {t:'Pedís patear el próximo, sea cuando sea', ef:{com:7, moral:-6, rep:5, flag:'penalerrado'}, r:'Nadie te aplaude por decirlo. Lo importante es que lo dijiste en voz alta, delante de todos.'},
  {t:'No volvés a agarrar una pelota en el punto', ef:{com:-5, moral:-10}, r:'Nunca más. Cada tanda que se define sin vos te recuerda por qué.'},
  {t:'Te encerrás a patear penales solo, de noche', ef:{com:5, def:3, forma:-4, flag:'penalerrado'}, r:'Doscientos penales contra un arco vacío en un estadio apagado. Nadie se entera. Vos sí.'}
 ]},
{id:'g27', w:3, req:'penalerrado', st:['ple','vet'], t:'Hay otro penal, y es tuyo',
 d:'Un año y medio después. Final, minuto ochenta y ocho, cero a cero. El árbitro señala el punto. El estadio entero sabe lo del otro penal: hay treinta mil personas silbando tu nombre.',
 c:[
  {t:'Agarrás la pelota sin mirar a nadie', tira:'com', mas:4, ef:{com:5, rep:8, hype:14},
   bien:{ef:{moral:18, rep:4, fanLove:18, trait:'hielo', unflag:'penalerrado'}, r:'Mismo palo que la vez anterior. Esta vez adentro. No festejás: te quedás parado mirando el arco, como si le debieras algo.'},
   mal:{ef:{moral:-20, fanLove:-14, forma:-10}, r:'Otra vez. El mismo palo, la misma altura, afuera otra vez. Treinta mil personas que ya lo sabían, y vos también.'}},
  {t:'Se la das al capitán', ef:{com:-3, moral:-4, mgrRel:4}, r:'La mete él. Ganan la final. En la foto del festejo estás, pero un poco atrás.'}
 ]},

{id:'g28', w:4, st:['asc','ple'], t:'La barrera de muñecos',
 d:'Terminó el entrenamiento y quedan cinco pelotas en el círculo central. El que patea las faltas en tu equipo tiene treinta y cuatro años y le queda una temporada, dos como mucho.',
 c:[
  {t:'Te quedás una hora más, todos los días', ef:{peg:9, fis:-2, forma:-4}, r:'Doscientas faltas por semana durante dos años. Un martes de marzo el técnico mira alrededor, no dice nada, y la pelota queda en tus manos.'},
  {t:'Le pedís al veterano que te enseñe', ef:{peg:6, lid:3, mgrRel:6}, r:'Te muestra dónde apoya el pie de base y por qué mira el pasto antes que el arco. Te la cede él mismo, un año después.'},
  {t:'Te vas al vestuario con los demás', ef:{moral:4}, r:'Nadie te lo reprocha. Las faltas las va a seguir pateando otro por el resto de tu carrera.'}
 ]},
{id:'g29', w:3, st:['ple','vet'], when:p=>p.attrs.peg>=70,
 t:'Dos que quieren la pelota',
 d:'Falta al borde del área, minuto ochenta, uno a uno. Llega el nueve, agarra la pelota y te dice que esta la patea él. Vos la venís metiendo desde hace tres meses.',
 c:[
  {t:'Se la sacás de las manos', tira:'peg', ef:{mgrRel:-8},
   bien:{ef:{peg:3, hype:12, moral:6}, r:'Al ángulo. El nueve te abraza igual, porque hay que abrazarse. Después, en el vestuario, no se hablan durante dos semanas.'},
   mal:{ef:{moral:-12, hype:-6, mgrRel:-6}, r:'A la barrera, y de rebote sale el contragolpe del empate. El nueve no dice una palabra, que es peor que si dijera algo.'}},
  {t:'Se la dejás y no discutís', ef:{lid:4, mgrRel:8, hype:-4}, r:'La tira a la tribuna. En el próximo tiro libre nadie discute nada: la pelota es tuya y ya no hay que decirlo.'},
  {t:'Lo arreglan ahí mismo: la próxima es del otro', ef:{lid:6, com:3, mgrRel:6}, r:'Diez segundos de charla con el árbitro esperando. La metés vos. El pacto se cumple el mes siguiente y el vestuario aprende algo del tipo que sos.'}
 ]},

{id:'g30', w:4, st:['ple','vet'], t:'Se pudrió el vestuario y nadie habla',
 d:'Cuatro derrotas seguidas. Hay dos grupos que almuerzan en mesas distintas y un técnico que ya no sabe qué decir. En la charla previa al clásico se hace un silencio largo y todos miran para abajo.',
 c:[
  {t:'Te parás y hablás vos', tira:'lid', mas:6, ef:{lid:5},
   bien:{ef:{lid:3, rep:6, mgrRel:10, moral:8, trait:'lider'}, r:'No decís nada memorable: decís lo que hay que decir. Ganan dos a cero y el técnico te busca con la mirada antes que a nadie.'},
   mal:{ef:{moral:-12, mgrRel:-8, rep:-4}, r:'Hablás dos minutos y nadie levanta la cabeza. Un veterano suelta un "¿y vos quién sos para decirnos eso?" y no le contesta nadie, ni vos.'}},
  {t:'Hablás con cada uno por separado', ef:{lid:6, mgrRel:6, moral:6}, r:'Doce charlas de cinco minutos en tres días. Más lento, más incómodo y bastante más efectivo que un discurso.'},
  {t:'No es tu rol: vos jugás', ef:{forma:8, lid:-4, fanLove:-4}, r:'Hacés tu partido y te vas a tu casa. El equipo termina la temporada roto y vos terminás con buenos números.'}
 ]},
{id:'g31', w:3, req:'mentor', veta:'capitan', st:['vet'], t:'Te ofrecen la cinta',
 d:'El capitán se fue en junio. El técnico te llama a su oficina, apoya la cinta sobre el escritorio y no dice nada. Sabés que adentro hay dos que la quieren y que uno lleva más años que vos en el club.',
 c:[
  {t:'La agarrás', ef:{lid:9, rep:10, mgrRel:8, moral:8, trait:'capitan', flag:'capitan'}, r:'Te la ponés y salís a entrenar sin anunciarlo. A la semana ya nadie se acuerda de que hubo una discusión.'},
  {t:'Proponés que la vote el plantel', ef:{lid:7, rep:6, moral:6, trait:'lider'}, r:'Ganás por catorce votos a seis. Vale mucho más que si te la hubieran dado.'},
  {t:'Se la das al que lleva más años', ef:{lid:4, mgrRel:-4, fanLove:8}, r:'Llora en el vestuario delante de todos. Nunca vas a tener que pedirle nada dos veces.'}
 ]}
];
EVENTS.push(...EVENTS3);

const EVENTS4 = [

{id:'n5', w:3, st:['ini'], when:p=>p.age<=19,
 t:'El micro sale a las cinco de la mañana',
 d:p=>`Ocho horas hasta la cancha, un sándwich por cabeza y el partido a las tres de la tarde. El delegado reparte los asientos: atrás van los que se quejan.`,
 c:[
  {t:'Dormís todo el viaje sin decir nada', ef:{fis:2, mgrRel:5, moral:-2}, r:'Bajás entero mientras el resto baja roto. El técnico lo ve y no lo dice.'},
  {t:'Organizás al plantel para pedir un micro mejor', ef:{lid:4, rep:2, mgrRel:-6, moral:5}, r:'Conseguís el micro. También conseguís que el delegado sepa tu nombre, y no para bien.'},
  {t:'Te la pasás jodiendo en el fondo', ef:{moral:8, fis:-2, mgrRel:-4}, r:'El viaje se hace corto y el partido largo. Valió la pena igual.'}
 ]},

{id:'n6', w:3, st:['ini'], when:p=>p.age<=20,
 t:'Tu viejo dejó de ir a verte',
 d:p=>`Fue a todos los partidos desde que tenés seis años. Hace un mes que no aparece. Tu vieja te dice que está trabajando doble turno para bancar los viajes.`,
 c:[
  {t:'Le pagás el turno que pierde con tu primer sueldo', ef:{moral:12, fanLove:4, lid:2}, r:'Vuelve al alambrado el sábado siguiente. Grita como si tuvieras seis años otra vez.'},
  {t:'No decís nada y jugás para él', ef:{com:4, moral:6, forma:5}, r:'Cada pelota que tocás esa tarde es una carta que no vas a mandar.'},
  {t:'Te lo guardás y te enfría', ef:{moral:-8, com:2, def:2}, r:'Aprendés a jugar con un peso en el pecho. Algunos nunca se lo sacan.'}
 ]},

{id:'n7', w:3, st:['ini'], when:p=>p.age<=20,
 t:'El utilero te elige la camiseta',
 d:p=>`Tiene sesenta años y treinta en el club. Te tira una camiseta usada y te dice: «esta era del último pibe que llegó de la cantera al primer equipo, a ver si te trae suerte». Le falta el número.`,
 c:[
  {t:'La usás toda la pretemporada', ef:{moral:7, fanLove:6, mgrRel:4}, r:'Los veteranos lo notan. En este club esas cosas se cuentan durante años.'},
  {t:'Pedís una nueva, con tu número', ef:{hype:5, rep:3, fanLove:-5}, r:'Nadie te dice nada. El utilero tampoco te vuelve a hablar de suerte.'},
  {t:'La enmarcás y la colgás en tu casa', ef:{moral:9, com:3}, r:'La mirás cada mañana antes de salir. Funciona mejor que cualquier charla técnica.'}
 ]},

{id:'n8', w:3, st:['ini','asc'], when:p=>p.age<=21,
 t:'Un mensaje de alguien del otro lado',
 d:p=>`Te escribe el capitán del equipo al que le metiste dos el domingo. No te putea: te felicita, y te pregunta con quién entrenás los martes.`,
 c:[
  {t:'Le contestás y se hacen amigos', ef:{lid:3, rep:4, moral:6, hype:3}, r:'Con los años ese tipo va a estar en tu casamiento. El fútbol es más chico de lo que parece.'},
  {t:'Lo dejás en visto', ef:{com:3, moral:-2}, r:'Preferís no deberle nada a nadie. Es una manera de andar, aunque sea más sola.'},
  {t:'Le mandás la captura al grupo del plantel', ef:{hype:7, moral:4, rep:-4, mgrRel:-3}, r:'Se ríen dos días. A él le llega, porque siempre llega.'}
 ]},

{id:'n9', w:2, st:['ini'], when:p=>p.age<=19,
 t:'Te ofrecen cambiar de puesto para entrar',
 d:p=>`El técnico de la Reserva te lo dice de frente: en tu puesto hay tres y no jugás nunca. En el otro hay uno lesionado y arrancás el sábado.`,
 c:[
  {t:'Aceptás y aprendés algo nuevo', ef:{special:'reposicion', def:3, pas:3, fis:2, moral:4}, r:'Jugás doce partidos ahí. Ninguno cómodo, todos útiles.'},
  {t:'Decís que no y esperás tu lugar', ef:{com:5, moral:-5, mgrRel:-6}, r:'Seis meses en el banco defendiendo una idea. A veces eso es carácter y a veces es terquedad.'},
  {t:'Pedís jugar en los dos', ef:{fis:-3, pas:2, def:2, mgrRel:6, forma:-4}, r:'Terminás fundido en marzo, pero el técnico te tiene siempre en la lista.'}
 ]},

{id:'n10', w:2, st:['ini','asc'], when:p=>p.age<=22,
 t:'La primera nota en un diario',
 d:p=>`Un periodista de la sección deportiva quiere media hora. Es tu primera nota de verdad, con foto. Te avisan que va a preguntarte por el técnico.`,
 c:[
  {t:'Hablás sólo de fútbol', ef:{rep:5, mgrRel:5, hype:2}, r:'Sale una nota aburrida y perfecta. El técnico la recorta y la deja en tu casillero.'},
  {t:'Decís lo que pensás del técnico', ef:{hype:12, rep:4, mgrRel:-14, moral:3, trait:'polemico', mem:{polemicas:1}}, r:'Titular a cinco columnas. Al otro día entrenás separado del grupo.'},
  {t:'La cancelás por consejo del club', ef:{mgrRel:8, hype:-6, moral:-3}, r:'El club te protege. También te enseña que tu voz todavía no es tuya.'}
 ]},

{id:'n11', w:2, st:['asc','ple','vet'],
 t:'Cambian una regla y te toca a vos',
 d:p=>`La federación aprueba una modificación que afecta directo a cómo jugás tu puesto. Media liga está en contra. A vos te cambia el trabajo desde el sábado.`,
 c:[
  {t:'Te adaptás antes que nadie', ef:{def:3, pas:2, forma:6, rep:5}, r:'Tres meses después todos hacen lo que vos ya hacías en agosto.'},
  {t:'Firmás la carta de los que protestan', ef:{lid:5, rep:4, moral:4, forma:-4}, r:'La regla queda igual. Tu nombre queda en una lista que algunos dirigentes guardan.'},
  {t:'Seguís jugando como siempre', ef:{com:4, forma:-6, moral:2}, r:'Te cuesta un semestre entero. Después el fútbol vuelve a parecerse a vos.'}
 ]},

{id:'n12', w:2, st:['ple','vet'],
 t:'Un torneo nuevo con mucho dinero detrás',
 d:p=>`Aparece una competición inventada por unos fondos de inversión. Pagan una fortuna por jugarla. Media Europa dice que es una estafa y la otra media ya firmó.`,
 c:[
  {t:'Vas por la plata y lo decís sin vueltas', ef:{wage:14, rep:-8, fanLove:-10, hype:8, trait:'mercenario'}, r:'Cobrás como nunca. En tu cancha te lo van a recordar durante dos años.'},
  {t:'Te negás públicamente', ef:{rep:10, fanLove:12, lid:5, wage:-4}, r:'Te ponen de ejemplo en cuarenta países. Tu contador no comparte el entusiasmo.'},
  {t:'No opinás y hacés lo que diga el club', ef:{mgrRel:6, moral:-4, com:3}, r:'Nadie te aplaude ni te putea. Hay carreras enteras que se construyen así.'}
 ]},

{id:'n13', w:2, st:['ple','vet'],
 t:'Un compañero de otro club denuncia algo grave',
 d:p=>`Un jugador que conocés de las juveniles cuenta públicamente lo que pasaba en su club de formación. Le están cayendo encima. Un periodista te pregunta si vos sabías algo.`,
 c:[
  {t:'Salís a bancarlo con nombre y apellido', ef:{lid:8, rep:8, fanLove:6, moral:5, hype:6}, r:'Se destapa todo. Él te llama a la noche y no puede hablar de la emoción.'},
  {t:'Decís que no te consta y cambiás de tema', ef:{com:3, moral:-7, rep:-3}, r:'Nadie te reprocha nada. Vos sí, cada tanto, cuando te acordás.'},
  {t:'Lo llamás por privado sin decir nada en público', ef:{moral:4, lid:3}, r:'Él agradece la llamada. La pelea la sigue dando solo.'}
 ]},

{id:'n14', w:2, st:['asc','ple','vet'],
 t:'Se juega con la cancha impracticable',
 d:p=>`Llovió tres días. El campo es un barrial y hay televisación internacional. Los capitanes de los dos equipos piden suspender; la organización dice que se juega.`,
 c:[
  {t:'Encabezás la protesta y no salís al campo', ef:{lid:9, rep:6, fanLove:-6, mgrRel:-8}, r:'Se suspende. Te comés una multa y un mes de discusión en la televisión.'},
  {t:'Salís y jugás el partido más feo de tu vida', ef:{fis:3, com:5, forma:-5, fanLove:8}, r:'Ganan 1-0 con un gol que entró rodando. Los hinchas hablan de esa tarde para siempre.'},
  {t:'Jugás sin arriesgar el físico', ef:{com:3, forma:-3, mgrRel:-5, fis:1}, r:'Salís entero. También salís señalado por los que se tiraron de cabeza.'}
 ]},

{id:'n15', w:2, st:['asc','ple'], when:p=>p.age>=23,
 t:'Tu mejor amigo de la infancia te pide plata',
 d:p=>`No es poca. Dice que es para un negocio y que te la devuelve en un año. Es el mismo que te acompañaba a entrenar en bici cuando no tenías nada.`,
 c:[
  {t:'Se la das sin contrato', ef:{moral:6, capital:-0.25}, r:'No te la devuelve. Tampoco te vuelve a hablar, que duele bastante más.'},
  {t:'Se la das con papeles firmados', ef:{moral:2, com:4}, r:'Se ofende el primer mes y te lo agradece el segundo año. El negocio anda.'},
  {t:'Le decís que no', ef:{moral:-9, com:6}, r:'Perdés al amigo y ganás una lección sobre lo que vale decir que no.'}
 ]},

{id:'n16', w:2, st:['ple','vet'], when:p=>p.age>=26,
 t:'No estás en el nacimiento',
 d:p=>`Se adelanta el parto y estás a nueve mil kilómetros, concentrado para el partido más importante del semestre. El técnico te dice que la decisión es tuya y que no va a haber represalias.`,
 c:[
  {t:'Tomás el primer vuelo', ef:{moral:14, fanLove:-4, mgrRel:-5, forma:-6}, r:'Llegás cuarenta minutos tarde. Igual es el mejor día de tu vida.'},
  {t:'Te quedás y jugás', ef:{moral:-10, forma:8, mgrRel:9, rep:4}, r:'Hacés un partidazo. Veinte años después seguís sin saber si valió la pena.'},
  {t:'Te quedás pero pedís no jugar', ef:{moral:-3, mgrRel:2, com:4}, r:'Mirás el partido desde el hotel con el teléfono en la mano. Nadie sale ganando.'}
 ]},

{id:'n17', w:2, st:['ple','vet'],
 t:'Te reconocen en el peor momento',
 d:p=>`Estás en una sala de espera de un hospital, por algo de tu familia, y alguien te pide una foto. Insiste. Hay más gente mirando.`,
 c:[
  {t:'Te sacás la foto y sonreís', ef:{fanLove:6, moral:-6, com:3}, r:'La foto circula. Nadie sabe qué había del otro lado de esa puerta.'},
  {t:'Pedís que te dejen en paz', ef:{moral:4, fanLove:-8, hype:5}, r:'Alguien lo cuenta mal en internet. Aprendés que no hay momentos privados.'},
  {t:'Le explicás en voz baja por qué estás ahí', ef:{fanLove:10, moral:3, lid:2}, r:'El tipo se disculpa, se va, y no lo cuenta nunca. Todavía queda gente así.'}
 ]},

{id:'n18', w:2, st:['vet','oca'], when:p=>p.age>=31,
 t:'Aprendés a hacer otra cosa',
 d:p=>`Un compañero que se retiró el año pasado te cuenta que se levanta a las once y no sabe qué hacer con el día. Te deja pensando toda la semana.`,
 c:[
  {t:'Te anotás a estudiar algo que no es fútbol', ef:{moral:8, com:5, forma:-3}, r:'Dos noches por semana en un aula con gente que no sabe quién sos. Te hace bien.'},
  {t:'Empezás a invertir en serio, con asesor', ef:{capital:0.4, moral:4, com:2}, r:'A los cuarenta vas a agradecer esta conversación más que muchos goles.'},
  {t:'Preferís no pensarlo todavía', ef:{forma:5, moral:-4}, r:'Un año más de no mirar la puerta. Después la puerta te mira a vos.'}
 ]},

{id:'n19', w:2, st:['asc','ple','vet'],
 t:'El club no paga hace tres meses',
 d:p=>`No sos el más perjudicado: los que la están pasando mal son los empleados y los pibes de las inferiores. El plantel se junta a decidir qué hacer.`,
 c:[
  {t:'Proponés no entrenar hasta que cobren todos', ef:{lid:10, rep:6, fanLove:8, mgrRel:-8}, r:'Cobran a la semana. Los empleados del club no se olvidan más de tu nombre.'},
  {t:'Adelantás plata tuya para los sueldos chicos', ef:{lid:6, fanLove:14, moral:8, capital:-0.5}, r:'Pedís que no se sepa. Se sabe igual, porque esas cosas siempre se saben.'},
  {t:'Entrenás y dejás que lo resuelvan los dirigentes', ef:{mgrRel:5, moral:-5, fanLove:-6}, r:'Se resuelve tarde y mal. Vos ya estabas pensando en el partido del domingo.'}
 ]},

{id:'n20', w:2, st:['ple','vet'],
 t:'El hijo del presidente entrena con el plantel',
 d:p=>`Tiene veinte años, no está a la altura y todo el mundo lo sabe. El técnico lo pone en la lista de concentrados para el domingo.`,
 c:[
  {t:'Lo ayudás en cada práctica', ef:{lid:6, moral:4, mgrRel:4}, r:'No llega a jugador, pero se convierte en el mejor amigo que tenés en la dirigencia.'},
  {t:'Se lo decís al técnico en privado', ef:{com:4, mgrRel:-6, rep:3}, r:'El técnico está de acuerdo y no puede hacer nada. Los dos aprenden lo mismo.'},
  {t:'Lo pasás por arriba en el primer entrenamiento', ef:{fis:2, hype:4, mgrRel:-10, moral:3}, r:'No vuelve. El presidente tampoco te vuelve a saludar.'}
 ]},

{id:'n21', w:2, st:['asc','ple'],
 t:'Descubren algo raro en un estudio de rutina',
 d:p=>`El médico del club te llama aparte. No es grave, pero quiere repetir los estudios y pide que no salga del vestuario hasta saber.`,
 c:[
  {t:'Te hacés todos los estudios y parás lo que haga falta', ef:{fis:-3, forma:-8, moral:6, com:5}, r:'No era nada. Perdiste seis semanas y ganaste dormir tranquilo diez años.'},
  {t:'Jugás mientras esperás los resultados', ef:{forma:6, moral:-6, fis:-4}, r:'Salís a la cancha con una duda adentro. Los ochenta minutos más largos de tu vida.'},
  {t:'Pedís una segunda opinión afuera del club', ef:{com:4, mgrRel:-5, moral:4}, r:'El club se ofende. Vos dormís mejor. Es un intercambio que volverías a hacer.'}
 ]},

{id:'n22', w:2, st:['ple','vet'], when:p=>p.age>=27,
 t:'Te piden que bajes el sueldo por el bien del club',
 d:p=>`El director deportivo te lo plantea sin rodeos: si vos resignás una parte, entran dos refuerzos. Si no, se va tu compañero de la banda.`,
 c:[
  {t:'Bajás el sueldo', ef:{wage:-16, fanLove:14, lid:7, mgrRel:8, moral:5}, r:'Llegan los refuerzos. Nadie te lo agradece por escrito y todos lo saben.'},
  {t:'Decís que no', ef:{moral:-4, com:5, fanLove:-8, rep:-3}, r:'Se va tu compañero. Cada vez que te cruzás con él te acordás de esta charla.'},
  {t:'Aceptás sólo si toda la plana mayor hace lo mismo', ef:{lid:9, wage:-8, rep:6, mgrRel:3}, r:'Tres se suman y dos se niegan. El vestuario queda partido, pero honesto.'}
 ]},

{id:'n23', w:2, st:['vet','oca'], when:p=>p.age>=32 && lejosDeCasa(p),
 t:'Un club te quiere de jugador y de algo más',
 d:p=>`La oferta incluye dos años jugando y después un cargo en el club. Es una salida ordenada, escrita, con fecha. Nunca nadie te ofreció el final antes de que llegue.`,
 c:[
  {t:'Firmás las dos cosas', ef:{moral:10, com:6, rep:4, forma:-3, contrato:2}, ofr:{t:'casa', cuando:'ventana'}, r:'Sabés exactamente cómo termina esto. Se juega distinto sabiendo eso.'},
  {t:'Firmás sólo lo de jugador', ef:{moral:3, forma:5, com:2, contrato:2}, ofr:{t:'casa', cuando:'ventana'}, r:'Preferís no ponerle fecha. El día que llegue, va a doler más.'},
  {t:'Rechazás todo: querés seguir compitiendo arriba', ef:{forma:8, moral:6, fis:-4, rep:3}, r:'Dos años más de exigencia real. El cuerpo pasa la factura, la cabeza lo agradece.'}
 ]},

{id:'n24', w:2, st:['ple','vet'],
 t:'Un rival te pide la camiseta antes del partido',
 d:p=>`Es un pibe de veinte del equipo chico que viene a jugar a tu cancha. Te lo pide en el túnel, con vergüenza, antes de que empiece.`,
 c:[
  {t:'Se la das ahí mismo', ef:{fanLove:6, moral:6, lid:3}, r:'Le juegan un partido perfecto encima y pierden 4-0. Él sale con la camiseta igual.'},
  {t:'Le decís que al final, si se la gana', ef:{com:4, hype:3, moral:2}, r:'Te hace un partido bárbaro para merecerla. Se la das y le decís por qué.'},
  {t:'Le decís que no, que estás concentrado', ef:{forma:5, fanLove:-5, moral:-3}, r:'Ganás el partido. La cara del pibe en el túnel te vuelve a la cabeza a veces.'}
 ]},

{id:'n1', w:3, st:['ini','asc'], when:p=>p.age<=21 && !p.flags.promesa,
 t:'El cartel en la entrada del predio',
 d:p=>`Pusieron una foto tuya de dos metros en el hall del predio de ${C(p.club).n}, con una frase debajo sobre el futuro del club. Pasás por delante cuatro veces por día.`,
 c:[
  {t:'Te lo tomás como una deuda que hay que pagar', ef:{com:5, forma:6, moral:4, flag:'promesa'}, r:'Cada mañana lo mirás dos segundos y seguís. Es el mejor combustible que vas a tener.'},
  {t:'Pedís que lo saquen', ef:{com:7, hype:-6, mgrRel:4, flag:'promesa'}, r:'Lo sacan. El técnico te mira distinto: los que piden eso a los veinte suelen durar.'},
  {t:'Te sacás una foto delante y la subís', ef:{hype:12, rep:4, moral:6, mgrRel:-4}, r:'Se hace viral. Ahora hay dos metros de expectativa y una captura que va a volver.'}
 ]},

{id:'n2', w:4, req:'promesa', st:['asc','ple'], when:p=>p.age>=23,
 t:'Ya no sos la promesa de nadie',
 d:p=>`Sacaron el cartel hace rato y nadie lo notó. En la previa del partido, un comentarista dice tu nombre sin agregarle «el joven». Es la primera vez.`,
 c:[
  {t:'Te hacés cargo del equipo esta temporada', ef:{lid:7, rep:8, forma:6, moral:5, flag:'estrella'}, r:'Empezás a pedir la pelota en los minutos en que antes te escondías. Se nota en la tabla.'},
  {t:'Seguís jugando igual, sin pensarlo', ef:{forma:4, com:5, moral:3, flag:'estrella'}, r:'No cambia nada por fuera. Por dentro sabés que el margen se acabó.'},
  {t:'Te pesa y jugás con miedo dos meses', ef:{moral:-8, forma:-6, com:8}, r:'Salís del pozo en noviembre, con una calma que antes no tenías. Costó cara.'}
 ]},

{id:'n3', w:4, req:'estrella', st:['ple','vet'], when:p=>p.age>=27,
 t:'El vestuario te mira a vos cuando las cosas van mal',
 d:p=>`Perdieron tres seguidos. El técnico termina la charla y se va. Quedan veinticinco tipos en silencio y todos, sin ponerse de acuerdo, miran para el mismo lado. Que sos vos.`,
 c:[
  {t:'Hablás', ef:{lid:10, rep:6, moral:6, mgrRel:5, flag:'liderazgo', trait:'caudillo'}, r:'No decís nada brillante. Decís lo que hay que decir. El domingo ganan.'},
  {t:'No hablás: te ponés a trabajar el lunes a las siete', ef:{lid:7, fis:3, forma:7, flag:'liderazgo'}, r:'A la semana hay ocho entrenando a las siete. Hay maneras de hablar sin hablar.'},
  {t:'Se lo dejás al capitán, que para eso está', ef:{com:5, mgrRel:-4, moral:-5}, r:'El capitán habla y no alcanza. Todos se acuerdan de para dónde estaban mirando.'}
 ]},

{id:'n4', w:4, req:'liderazgo', st:['vet','oca'], when:p=>p.age>=31,
 t:'Le ponen tu nombre a algo',
 d:p=>`El club decide bautizar con tu nombre el campo tres del predio, donde entrenan los chicos de trece. No es el estadio ni una estatua: es la cancha donde se hacen los que vienen.`,
 c:[
  {t:'Vas a la inauguración y te quedás a entrenarlos una tarde', ef:{lid:8, fanLove:16, moral:12, rep:6, trait:'idolo'}, r:'Cuarenta pibes con tu apellido en la espalda. Uno de ellos va a debutar en ocho años.'},
  {t:'Pedís que le pongan el nombre del utilero que te dio la primera camiseta', ef:{fanLove:20, lid:6, moral:10, rep:8}, r:'El viejo no lo puede creer. Es lo mejor que hiciste con una carrera entera.'},
  {t:'Agradecés y no vas', ef:{com:4, moral:-4, fanLove:-6}, r:'No te gustan los homenajes en vida. El campo lleva tu nombre igual.'}
 ]}

];
EVENTS.push(...EVENTS4);

const EVENTS5 = [

{id:'m1', w:2, st:['asc','ple','vet'],
 t:'Un torneo se juega en un país donde no deberían jugarse torneos',
 d:p=>`La sede se decidió hace años y hoy todo el mundo sabe cómo. Hay periodistas presos y obreros muertos levantando los estadios. Vos estás convocado.`,
 c:[
  {t:'Vas y usás cada cámara para hablar del tema', ef:{rep:10, lid:8, hype:12, moral:5, forma:-4}, r:'Te amenazan con sanciones que nunca llegan. Dos compañeros de otras selecciones te copian.'},
  {t:'Vas y jugás sin opinar', ef:{forma:6, moral:-8, rep:-4}, r:'Hacés un buen torneo. Durante años, cuando te lo recuerden, vas a cambiar de tema.'},
  {t:'No vas', ef:{lid:6, rep:6, moral:-6, hype:10, mgrRel:-10}, r:'Perdés el torneo de tu vida por una idea. Nadie te va a devolver ese verano.'}
 ]},

{id:'m2', w:2, st:['asc','ple','vet'],
 t:'Un fondo compra la mitad de los clubes de tu liga',
 d:p=>`El mismo dueño en seis camisetas distintas. Cuando juegan entre ellos, la gente ya no sabe qué está mirando. Los futbolistas son los últimos en enterarse de nada.`,
 c:[
  {t:'Salís a decir en voz alta que eso no es un campeonato', ef:{lid:8, rep:8, hype:8, mgrRel:-8}, r:'Te cae encima medio periodismo deportivo. También te llaman de cuatro sindicatos.'},
  {t:'Te callás: tu club es uno de los seis', ef:{moral:-6, com:5, wage:4}, r:'Cobrás en fecha todos los meses. Es más de lo que puede decir la mitad de la liga.'},
  {t:'Pedís que el sindicato lo lleve a los tribunales', ef:{lid:6, rep:5, moral:3}, r:'Tres años de expediente. Gana el fondo, pero queda escrito lo que pasó.'}
 ]},

{id:'m3', w:2, st:['ple','vet'],
 t:'Se muere un jugador en una cancha',
 d:p=>`Pasó el domingo, en otro país, en un partido que nadie miraba. Tenía veinticuatro años y un hijo de meses. El lunes hay que entrenar igual.`,
 c:[
  {t:'Proponés que no se juegue la fecha', ef:{lid:7, rep:5, moral:-4}, r:'Se suspende en dos ligas y en las demás no. El fútbol es mucho fútbol y poca gente.'},
  {t:'Organizás una colecta del plantel para la familia', ef:{lid:6, moral:6, fanLove:8}, r:'Juntan más de lo que esperaban. La mujer manda una carta que se lee en el vestuario.'},
  {t:'Te hacés todos los estudios cardíacos esa semana', ef:{fis:2, moral:-5, com:4}, r:'Salís bien. Igual tardás un mes en volver a correr sin pensar en eso.'}
 ]},

{id:'m4', w:2, st:['asc','ple','vet'],
 t:'Una guerra suspende un torneo entero',
 d:p=>`Tres clubes quedan fuera de la competición de un día para el otro. Un compañero tuyo tiene a toda su familia ahí y no puede hablar con nadie desde el jueves.`,
 c:[
  {t:'Le abrís tu casa hasta que sepa algo', ef:{moral:6, lid:6, forma:-3}, r:'Duerme en tu sillón dos semanas. Nunca hablan del tema y no hace falta.'},
  {t:'Movés lo que podés para sacar a su familia', ef:{lid:8, rep:6, moral:8, capital:-0.4}, r:'Tardás cuarenta días y una cantidad de llamadas que no vas a contar nunca. Salen.'},
  {t:'Le decís que te avise si necesita algo', ef:{moral:-4, com:3}, r:'No te avisa. La gente que más lo necesita casi nunca avisa.'}
 ]},

{id:'m5', w:2, st:['ple','vet'],
 t:'Descubren que media liga arreglaba partidos',
 d:p=>`Cae una investigación con escuchas. Hay nombres que conocés, dos de ellos jugaron con vos. Te llaman de la fiscalía como testigo, no como acusado.`,
 c:[
  {t:'Contás todo lo que viste', ef:{rep:10, lid:6, moral:4, fanLove:-6, hype:10}, r:'Dos clubes descienden por tu declaración. En dos canchas te van a silbar de por vida.'},
  {t:'Decís que no te consta nada', ef:{com:5, moral:-8, rep:-4}, r:'Es técnicamente cierto y completamente falso. Convivís con eso.'},
  {t:'Pedís que el sindicato hable por todos', ef:{lid:4, moral:2, rep:2}, r:'Sale un comunicado tibio. Nadie queda mal y nadie arregla nada.'}
 ]},

{id:'m6', w:2, st:['asc','ple','vet'],
 t:'El calendario se llena de partidos que nadie pidió',
 d:p=>`Suman ocho fechas más al año. La cuenta oficial dice que es bueno para el fútbol; la de los médicos dice que las lesiones musculares subieron un tercio.`,
 c:[
  {t:'Encabezás la protesta de los capitanes', ef:{lid:9, rep:7, fis:2, mgrRel:-6}, r:'Consiguen quitar dos fechas. Es poco y es más de lo que nadie había conseguido.'},
  {t:'Aceptás y te cuidás vos', ef:{fis:3, com:4, moral:-3}, r:'Llegás entero a mayo. Tres compañeros no.'},
  {t:'Jugás todo lo que te pongan', ef:{forma:8, rep:5, fis:-6, moral:4}, r:'Sesenta y dos partidos. El cuerpo te lo va a cobrar, pero no este año.'}
 ]},

{id:'m7', w:2, st:['ple','vet'],
 t:'Una liga nueva paga cifras que no existían',
 d:p=>`Un país que hace diez años no tenía fútbol profesional ofrece cuatro veces lo que ganás. Van seis nombres grandes en dos mercados. A vos te llaman en enero.`,
 c:[
  {t:'Vas', ef:{wage:60, value:-14, rep:-10, forma:-6, moral:6, trait:'mercenario'}, ofr:{t:'golfo', cuando:'ventana'}, r:'Tu familia no vuelve a preocuparse por dinero. Tu carrera deportiva termina antes de que termine.'},
  {t:'Decís que no y lo explicás', ef:{rep:8, fanLove:10, moral:4, lid:4}, r:'Te aplauden mucho los que nunca tuvieron que elegir.'},
  {t:'Lo usás para renegociar donde estás', ef:{wage:22, mgrRel:-5, fanLove:-4, com:4}, r:'Te suben el sueldo y te miran distinto. Las dos cosas eran previsibles.'}
 ]},

{id:'m8', w:2, st:['asc','ple'],
 t:'Un desastre natural en tu país',
 d:p=>`Un terremoto, y la ciudad donde te criaste está adentro del mapa. Tu familia está bien. Muchos vecinos no.`,
 c:[
  {t:'Organizás a los jugadores del país entero', ef:{lid:12, rep:8, fanLove:16, moral:8, forma:-5}, r:'Juntan seis camiones. Vas a repartirlos vos, sin cámaras, y volvés distinto.'},
  {t:'Donás en silencio', ef:{moral:8, capital:-0.2, com:3}, r:'Nadie se entera. Es exactamente lo que querías.'},
  {t:'Dedicás el gol del domingo', ef:{fanLove:6, hype:6, moral:2}, r:'Sale en todos lados. Sirve para algo, aunque no para lo que hace falta.'}
 ]},

{id:'m9', w:2, st:['ple','vet'],
 t:'El árbitro del domingo tiene una empresa con el presidente del rival',
 d:p=>`Lo publica un diario chico el sábado a la noche. Nadie de la federación contesta el teléfono. El partido se juega igual a las cuatro.`,
 c:[
  {t:'Salís con el brazalete y lo decís en la previa', ef:{lid:7, rep:6, hype:9, mgrRel:-4}, r:'Le cambian el árbitro cuarenta minutos antes. Ganás el partido y una enemistad larga.'},
  {t:'Jugás y ganás para que no haya excusa', ef:{forma:8, com:6, rep:4}, r:'2-0 y ni una protesta. Es la única respuesta que no se puede discutir.'},
  {t:'Dejás que se queje el club', ef:{mgrRel:4, moral:-3}, r:'El club manda una nota que nadie lee. Perdés 1-0 con un penal dudoso.'}
 ]},

{id:'m10', w:2, st:['asc','ple','vet'],
 t:'Prohíben a las mujeres entrar a la cancha en el próximo torneo',
 d:p=>`Es una sede internacional y la norma es local. Los organizadores dicen que es la cultura del país. Tu hermana te pregunta si vas a decir algo.`,
 c:[
  {t:'Decís algo, y fuerte', ef:{lid:8, rep:8, hype:12, moral:6}, r:'Te contestan cuatro federaciones. Dos meses después la norma cambia a medias.'},
  {t:'Jugás y te lo guardás', ef:{forma:5, moral:-8}, r:'Cuando volvés, tu hermana te pregunta cómo te fue y hablás del partido.'},
  {t:'Salís con una cinta y sin declaraciones', ef:{lid:5, rep:4, hype:6, moral:3}, r:'La foto da la vuelta al mundo sin que digas una palabra. A veces alcanza.'}
 ]},

{id:'m11', w:2, st:['ple','vet'],
 t:'Se retira el jugador con el que te comparaban',
 d:p=>`Toda tu carrera estuvo esa comparación. Hoy se retira él, con más títulos que vos, y en la nota de despedida te nombra como el rival que más lo obligó.`,
 c:[
  {t:'Vas a su despedida', ef:{rep:6, moral:10, fanLove:6, lid:4}, r:'Te aplaude su cancha. Es el aplauso más raro y más limpio de tu carrera.'},
  {t:'Le escribís en privado', ef:{moral:8, com:4}, r:'Se contestan tres mensajes largos. Nadie se entera y está bien así.'},
  {t:'Usás el año para pasarlo en algo', ef:{forma:9, fis:-3, moral:4, rep:5}, r:'Terminás la temporada con un número suyo superado. Él es el primero en felicitarte.'}
 ]},

{id:'m12', w:2, st:['asc','ple','vet'],
 t:'Tu federación no paga a la selección femenina',
 d:p=>`Llevan ocho meses sin cobrar y acaban de clasificar a un mundial. La selección masculina, o sea vos, cobra en fecha.`,
 c:[
  {t:'No jugás el próximo amistoso hasta que cobren', ef:{lid:10, rep:8, fanLove:10, mgrRel:-10, hype:10}, r:'Cobran en once días. La capitana te llama y no te deja pedir disculpas por haber tardado.'},
  {t:'Firmás el comunicado con los demás', ef:{lid:4, rep:4, moral:3}, r:'Sale en los diarios un martes. El viernes ya nadie habla del tema.'},
  {t:'No te metés: no es tu pelea', ef:{com:3, moral:-7, rep:-4}, r:'Tenés razón en lo técnico. Con los años vas a pensar distinto.'}
 ]},

{id:'m13', w:3, st:['oca'], when:p=>p.age>=33,
 t:'Te enterás por el diario de que no te renuevan',
 d:p=>`Doce años en el club. La decisión estaba tomada hacía un mes y nadie te la dijo. Lo leés un miércoles a la mañana, en el teléfono, antes de entrenar.`,
 c:[
  {t:'Entrás al vestuario y entrenás como siempre', ef:{com:9, lid:6, fanLove:10, moral:-6}, r:'No decís una palabra en seis meses. La gente lo nota y eso vale más que cualquier discurso.'},
  {t:'Le pedís explicaciones al presidente delante de todos', ef:{lid:4, hype:10, moral:5, mgrRel:-10, fanLove:6}, r:'No hay explicación buena y él lo sabe. Salís de esa oficina con menos club y más dignidad.'},
  {t:'Pedís rescindir esa misma tarde', ef:{moral:-10, com:5, fanLove:-8}, ofr:{t:'menor', cuando:'ya'}, r:'Te vas sin despedida, sin aplauso y sin última vuelta al campo. Fue tu decisión y también fue la de ellos.'}
 ]},

{id:'m14', w:3, st:['oca'], when:p=>p.age>=34,
 t:'El médico te dice el número',
 d:p=>`No es un diagnóstico: es una cuenta. Le pedís que sea honesto y te dice cuántos partidos más cree que te quedan si seguís así. El número es más chico de lo que pensabas.`,
 c:[
  {t:'Se lo contás al técnico y planifican juntos', ef:{mgrRel:10, fis:3, com:6, forma:-4}, r:'Te dosifican. Llegás a jugar el doble de los que él había calculado.'},
  {t:'No se lo decís a nadie', ef:{com:8, moral:-6, fis:-4}, r:'Cargás la cuenta vos solo. Cada partido que jugás lo restás en silencio.'},
  {t:'Elegís la fecha de tu retiro esa misma noche', ef:{moral:8, com:9, lid:5, forma:3, retiro:1}, r:'Saber cuándo termina te saca un peso de encima que no sabías que tenías.'}
 ]},

{id:'m15', w:2, st:['oca'], when:p=>p.age>=33,
 t:'Un pibe del club te copia hasta cómo atás los botines',
 d:p=>`Tiene diecisiete y hace todo lo que hacés vos: la rutina, el orden del vestuario, la manera de encarar al técnico. Alguien te lo cuenta riéndose y no te da risa.`,
 c:[
  {t:'Le enseñás en serio, todos los días', ef:{lid:8, moral:8, rep:4, flag:'mentor'}, r:'Ocho años después ese pibe va a decir tu nombre en su primera nota grande.'},
  {t:'Le decís que se copie de otro y se busque lo suyo', ef:{lid:6, com:5, moral:4}, r:'Se ofende un mes y te lo agradece toda la vida.'},
  {t:'Lo dejás, ya se le va a pasar', ef:{com:3, moral:-3}, r:'Se le pasa. También se le pasan las ganas de preguntarte nada.'}
 ]},

{id:'m16', w:2, st:['oca'],
 t:'Te ofrecen jugar un partido de exhibición con los de antes',
 d:p=>`Media cancha de leyendas y una recaudación para las inferiores del club. Vos todavía estás en actividad y tu preparador dice que no es buena idea en diciembre.`,
 c:[
  {t:'Jugás', ef:{fanLove:12, moral:10, fis:-4, forma:-4}, r:'Sesenta mil personas para un partido que no cuenta. Es de las mejores tardes de tu vida.'},
  {t:'Vas pero no jugás', ef:{fanLove:6, moral:4, com:3}, r:'Firmás camisetas dos horas. Nadie te reprocha nada.'},
  {t:'Decís que no: estás compitiendo', ef:{forma:6, fis:2, fanLove:-6}, r:'Tenés razón y quedás como un tipo raro. Las dos cosas a la vez.'}
 ]},

{id:'m17', w:2, st:['oca'], when:p=>p.age>=34,
 t:'Tu último contrato tiene una cláusula de partidos',
 d:p=>`Cobrás una parte grande sólo si llegás a veinte partidos. Vas por catorce y quedan seis fechas. El técnico no lo sabe, o hace como que no.`,
 c:[
  {t:'Se lo decís al técnico', ef:{com:7, mgrRel:6, moral:4, wage:-4}, r:'Te dice que va a poner al que esté mejor. Juega tres y no llegás. Te da la mano igual.'},
  {t:'No decís nada y aceptás lo que venga', ef:{com:9, lid:5, moral:-4}, r:'Llegás a diecinueve. Un partido. Nunca se lo contás a nadie.'},
  {t:'Le pedís al representante que lo negocie', ef:{wage:6, mgrRel:-6, moral:-3, rep:-3}, r:'Se resuelve por escrito. También se filtra, y en el vestuario se comenta.'}
 ]},

{id:'m18', w:2, st:['oca'],
 t:'Alguien escribe tu obituario deportivo antes de tiempo',
 d:p=>`Una revista publica un balance de tu carrera como si ya te hubieras retirado. Está bien escrito, es cariñoso, y usa el pasado en cada frase. Todavía te quedan seis meses.`,
 c:[
  {t:'Lo compartís y agradecés', ef:{fanLove:8, moral:4, hype:4}, r:'Se hace viral en dos días. Alguien pone en los comentarios "todavía juega, ¿no?".'},
  {t:'Lo usás de combustible', ef:{forma:9, moral:5, fis:-2}, r:'Cerrás la temporada con el mejor semestre en cuatro años. La revista tiene que escribirlo dos veces.'},
  {t:'No lo leés', ef:{com:6, moral:2}, r:'Te lo guarda tu mujer en un cajón. Lo leés a los cuarenta y cinco y llorás.'}
 ]},

{id:'m19', w:2, st:['oca'], when:p=>p.age>=34,
 t:'El vestuario ya no habla tu idioma',
 d:p=>`Escuchan otra música, se ríen de cosas que no entendés y hacen bromas con referencias que no te tocan. No hay maldad. Simplemente no sos de ahí.`,
 c:[
  {t:'Preguntás y te dejás enseñar', ef:{moral:8, lid:6, forma:3}, r:'Terminás en un grupo de chat con veinte pibes que te mandan cosas a las dos de la mañana.'},
  {t:'Te armás tu rincón con los otros dos veteranos', ef:{com:5, moral:2, lid:-3}, r:'Se está cómodo ahí. También se está lejos.'},
  {t:'Imponés cómo se hacían las cosas antes', ef:{lid:6, com:5, mgrRel:-8, moral:-5}, r:'Vuelve el silencio en las charlas y la puntualidad en los horarios. También vuelve la distancia, y el técnico te lo hace notar.'}
 ]},

{id:'m20', w:2, st:['oca'],
 t:'Te piden que juegues de otra cosa para durar dos años más',
 d:p=>`El técnico te lo plantea con papeles: en tu puesto ya no llegás, pero atrás, con tu lectura, podrías jugar hasta los treinta y ocho.`,
 c:[
  {t:'Aceptás y aprendés un puesto a los treinta y cinco', ef:{special:'reposicion', def:6, dfs:5, pas:3, rit:-3, moral:5, com:6}, r:'Los primeros diez partidos son un desastre. Del once en adelante, no te sacan más.'},
  {t:'Preferís terminar donde siempre jugaste', ef:{moral:6, com:5, forma:-5}, r:'Un año menos de carrera y ni un partido fuera de tu lugar. Es una manera legítima de irse.'},
  {t:'Lo probás en pretemporada y decidís después', ef:{com:4, def:2, moral:2}, r:'Lo probás, no te convence, y volvés. Al menos ahora sabés.'}
 ]},

{id:'m21', w:2, req:'padre', st:['oca'], when:p=>p.age>=35,
 t:'Tu hijo te ve jugar mal por primera vez',
 d:p=>`Tiene ocho años y siempre te vio ser el mejor de la cancha. El domingo te sacaron a los cincuenta minutos y en el auto te pregunta por qué la gente gritaba.`,
 c:[
  {t:'Le explicás la verdad entera', ef:{moral:8, com:8, lid:4}, r:'Le decís que te estás poniendo viejo y que está bien. Aprende algo que le va a servir más que verte ganar.'},
  {t:'Le decís que fue decisión del técnico', ef:{moral:6, fanLove:2, com:-5}, r:'Se lo cree y sigue mirándote como antes. Un año más de ser invencible para alguien, comprado a crédito.'},
  {t:'Le prometés que el próximo va a ser distinto', ef:{forma:8, moral:4, fis:-3}, r:'Le hacés un gol el domingo siguiente. Los dos sabían que era prestado.'}
 ]},

{id:'m22', w:2, st:['oca'],
 t:'Se retira el compañero con el que jugaste toda la vida',
 d:p=>`Debutaron el mismo año, en el mismo club. Él lo deja en junio. En la charla de despedida dice tu nombre tres veces y se le quiebra la voz en la tercera.`,
 c:[
  {t:'Anunciás que este es tu último año también', ef:{moral:10, fanLove:12, com:7, forma:-4, retiro:1}, r:'Se van juntos, como empezaron. La foto de esa tarde queda en el museo del club.'},
  {t:'Le decís que vas a seguir por los dos', ef:{forma:8, lid:5, moral:6, fis:-3}, r:'Jugás dos años más con su número tatuado en la muñeca.'},
  {t:'Te lo guardás y seguís', ef:{com:6, moral:-5}, r:'No vas a la despedida por no llorar delante de nadie. Te arrepentís esa misma noche.'}
 ]},

{id:'m23', w:2, st:['vet','oca'], when:p=>p.age>=32,
 t:'Te ofrecen dirigir el club donde te formaste, cuando dejes',
 d:p=>`No es un puesto en el cuerpo técnico: es el proyecto entero de inferiores, con presupuesto y con firma. Te lo ofrecen ahora para que lo pienses dos años.`,
 c:[
  {t:'Decís que sí y empezás a estudiar en paralelo', ef:{lid:8, com:6, moral:8, forma:-4}, r:'Te pasás las noches con apuntes. Los últimos dos años de jugador los ves con otros ojos.'},
  {t:'Pedís tiempo hasta el final', ef:{com:5, moral:3}, r:'Te lo guardan. Cuando llegue el momento vas a saber mejor qué querés.'},
  {t:'Decís que no: no querés terminar en una oficina', ef:{moral:5, com:4, rep:-2}, r:'Se lo dan a otro. Cada tanto pasás por el predio y mirás desde el alambrado.'}
 ]},

{id:'m24', w:2, st:['oca'], when:p=>p.age>=35,
 t:'La última pretemporada',
 d:p=>`Sabés que es la última y no se lo dijiste a nadie. Los tests de fondo, las dobles sesiones, el barro de enero. Todo por última vez y todo igual de duro.`,
 c:[
  {t:'La hacés entera, sin pedir nada', ef:{fis:5, lid:8, mgrRel:8, moral:6}, r:'Terminás segundo en el test de doce minutos, detrás de un pibe de veinte. Se abrazan al final.'},
  {t:'Pedís un plan aparte para llegar bien a la temporada', ef:{fis:3, forma:6, lid:-4, com:4}, r:'Llegás mejor que nunca a agosto. Algunos en el vestuario lo entienden y otros no.'},
  {t:'La disfrutás sin exigirte', ef:{moral:10, fis:-3, forma:-4}, r:'Te reís en cada ejercicio. Es la pretemporada que más vas a recordar y la que peor te dejó.'}
 ]},

{id:'m25', w:2, st:['oca'],
 t:'Un club de tu país se está por ir a la quiebra y te llaman',
 d:p=>`No pueden pagarte casi nada. Te ofrecen seis meses para intentar salvarlos del descenso. Es el club donde tu abuelo era socio.`,
 c:[
  {t:'Vas, y cobrás lo mínimo', ef:{wage:-40, fanLove:20, lid:10, moral:12, rep:6}, ofr:{t:'chico', cuando:'ya'}, r:'Se salvan en la última fecha. Nunca vas a pagar una entrada en esa cancha.'},
  {t:'Vas pero pedís lo que valés', ef:{wage:-8, fanLove:6, moral:2, rep:-3}, ofr:{t:'chico', cuando:'ya'}, r:'Se salvan igual. La gente te lo agradece un poco menos de lo que podría.'},
  {t:'Decís que no', ef:{moral:-6, com:4}, r:'Descienden. Ves el resumen en tu casa un domingo y apagás la tele antes del final.'}
 ]},

{id:'m26', w:2, st:['oca'], when:p=>p.age>=34,
 t:'Nadie te avisa que es tu último partido',
 d:p=>`No hay homenaje ni cámara ni pancarta. Un martes cualquiera, contra un rival cualquiera, entrás veinte minutos. Después viene la lesión y ya no volvés. Eso lo sabés meses más tarde.`,
 c:[
  {t:'Te hacés una despedida propia, con tu gente', ef:{moral:10, fanLove:8, com:5, retiro:1}, r:'Cuarenta personas en un potrero. Vale más que un estadio lleno.'},
  {t:'Pedís al club una despedida en serio', ef:{fanLove:12, hype:6, moral:6, rep:3, retiro:1}, r:'Te la dan seis meses después, en un entretiempo. Salís al campo de traje y te aplauden ocho minutos.'},
  {t:'Lo dejás así: el fútbol termina como termina', ef:{com:10, moral:-4, retiro:1}, r:'Sin última vuelta ni ramo de flores. Hay algo honesto en eso, aunque duela.'}
 ]},

{id:'m27', w:2, st:['vet','oca'], when:p=>p.nt.caps>=20,
 t:'Te llaman de la selección para una despedida, no para jugar',
 d:p=>`Quieren que estés en la lista del amistoso, que salgas de titular y que te cambien a los diez minutos para que el estadio te aplauda. Es un gesto y es un poco una postal.`,
 c:[
  {t:'Aceptás y lo disfrutás', ef:{moral:12, fanLove:10, rep:4}, r:'Diez minutos y una ovación de pie. Tu vieja llora en la tribuna y vos también.'},
  {t:'Pedís jugar los noventa o no ir', ef:{com:7, forma:5, moral:-4, rep:2}, r:'Jugás los noventa. Se nota que te cuesta y se nota que quisiste.'},
  {t:'Decís que no: preferís que se acuerden de cómo jugabas', ef:{com:8, rep:5, moral:-5, fanLove:-6}, r:'No hay foto de despedida. La última imagen tuya con esa camiseta es jugando.'}
 ]},

{id:'m28', w:2, st:['oca'],
 t:'Encontrás una caja con todo',
 d:p=>`Mudanza. Aparecen las botas del debut, la primera camiseta que intercambiaste y una libreta de cuando tenías quince donde habías escrito lo que querías conseguir. Cumpliste la mitad.`,
 c:[
  {t:'Ponés la lista en la heladera para lo que queda', ef:{forma:8, moral:8, fis:-2}, r:'Tachás dos más en lo que queda. Los otros se quedan sin tachar y está bien.'},
  {t:'Se la das a un pibe del club', ef:{moral:10, lid:4}, r:'La lee entera esa noche. Al otro día escribe la suya.'},
  {t:'La guardás sin leerla del todo', ef:{com:6, moral:-2}, r:'Hay cosas que a los quince se prometen y a los treinta y cinco es mejor no releer.'}
 ]},

{id:'m29', w:2, st:['oca'], when:p=>p.age>=33,
 t:'El club te pide que decidas antes de diciembre',
 d:p=>`Necesitan saber si seguís para armar el plantel. Te piden la respuesta cinco meses antes de que termine la temporada. Todavía no la sabés ni vos.`,
 c:[
  {t:'Decís que seguís y te obligás a cumplirlo', ef:{forma:6, fis:-4, moral:4, mgrRel:6}, r:'Cumplís. El último tramo lo jugás con una convicción que no tenías en marzo.'},
  {t:'Anunciás que es tu último año', ef:{fanLove:16, moral:8, lid:6, rep:4, retiro:1}, r:'Cada cancha visitante te aplaude por última vez. Es una vuelta olímpica de nueve meses.'},
  {t:'Pedís esperar a marzo', ef:{mgrRel:-6, com:5, moral:-3}, r:'El club arma el plantel sin vos por las dudas. Aprendés que no decidir también es decidir.'}
 ]},

{id:'m30', w:2, st:['oca'],
 t:'Te ofrecen entrenar a los pibes mientras todavía jugás',
 d:p=>`Dos tardes por semana con la categoría de trece, sin cobrar. El preparador dice que te va a quitar energía para los partidos. El que te lo propone es el que te entrenaba a vos a esa edad.`,
 c:[
  {t:'Vas las dos tardes', ef:{lid:9, moral:10, fanLove:8, fis:-3, forma:-3}, r:'Llegás a los partidos más cansado y con la cabeza en otro lado, en el mejor sentido.'},
  {t:'Vas una tarde y cuidás el cuerpo', ef:{lid:5, moral:5, com:3}, r:'Un equilibrio razonable, y los razonables casi nunca se arrepienten.'},
  {t:'Le decís que cuando te retires', ef:{forma:4, fis:2, moral:-4}, r:'Cuando te retirás, él ya no está. Ese entrenamiento no se recupera.'}
 ]}

];
EVENTS.push(...EVENTS5);

const EVENTS6 = [

{id:'j1', w:3, st:['ini'], when:p=>p.age<=19,
 t:'El nutricionista te abre la heladera de tu casa',
 d:p=>`Viene a hacer un informe. Adentro hay lo que hay: fideos, milanesas y una gaseosa de tres litros. Tu vieja lo mira desde la puerta, con una vergüenza que no le corresponde.`,
 c:[
  {t:'Cambiás todo y bancás el gasto vos', todo:true, ef:{fis:4, forma:5, moral:-4, capital:-0.02}, r:'Comés distinto en seis semanas. En tu casa se come distinto para siempre.'},
  {t:'Le pedís que hable con vos y no delante de ella', ef:{com:6, lid:3, fis:2, moral:5}, r:'Entiende, se disculpa y vuelve el martes solo. A tu vieja no le vuelve a pasar.'},
  {t:'Comés en el club y en tu casa comés lo que hay', ef:{fis:2, moral:6, forma:-2}, r:'Un arreglo raro que funciona. Las cenas de tu casa siguen siendo las cenas de tu casa.'}
 ]},

{id:'j2', w:3, st:['ini'], when:p=>p.age<=20,
 t:'La primera lesión de verdad',
 d:p=>`No es un golpe. Es algo que se rompió adentro y que tiene nombre en latín. Tres meses. Tenés ${enLetras(p.age)} años y nunca estuviste tres meses sin jugar a nada.`,
 c:[
  {t:'Vas al club todos los días igual, aunque no entrenes', ef:{lid:5, mgrRel:8, moral:4, fis:-2}, r:'Aprendés el juego mirándolo. Cuando volvés, ves cosas que antes no veías.'},
  {t:'Te encerrás y hacés la rehabilitación al pie de la letra', ef:{fis:6, com:5, moral:-6}, r:'Volvés dos semanas antes de lo previsto. También volvés con miedo a la pierna.'},
  {t:'Volvés antes de tiempo porque no aguantás más', ef:{forma:6, moral:8, fis:-7, trait:'cristal'}, r:'Jugás el partido que querías jugar. Y te lesionás otra vez en octubre.'}
 ]},

{id:'j3', w:2, st:['ini'], when:p=>p.age<=19,
 t:'Dormís cinco horas',
 d:p=>`Entrenás a las ocho, estudiás a la tarde y te acostás a las dos porque es el único rato del día que es tuyo. El preparador te lo nota en los tests antes de que se lo cuentes.`,
 c:[
  {t:'Ordenás los horarios aunque pierdas lo tuyo', ef:{fis:5, forma:4, moral:-5}, r:'Rendís mejor en un mes. También te aburrís como nunca en tu vida.'},
  {t:'Mentís y decís que dormís ocho', ef:{moral:2, fis:-4, mgrRel:-4}, r:'Te descubren en dos semanas: los números no mienten aunque vos sí.'},
  {t:'Le contás la verdad y armás un plan con él', ef:{fis:4, mgrRel:8, com:4, moral:3}, r:'Te cambia el horario de la tarde. Nadie te lo había preguntado antes.'}
 ]},

{id:'j4', w:2, st:['ini','asc'], when:p=>p.age<=21,
 t:'Un compañero te ofrece algo para rendir más',
 d:p=>`Dice que lo toma medio plantel de otra categoría y que no da positivo. Tiene veinte años y te lo ofrece con la naturalidad de quien ofrece un caramelo.`,
 c:[
  {t:'Decís que no y no decís nada más', ef:{com:8, moral:4, fis:2}, r:'Él se ríe y cambia de tema. Seis meses después lo suspenden dos años.'},
  {t:'Se lo contás al médico del club', ef:{com:5, mgrRel:8, rep:4, moral:-6}, r:'Se arma un lío enorme y nadie sabe que fuiste vos. Vos sí, cada vez que lo cruzás.'},
  {t:'Le decís que se cuide, y lo dejás ahí', ef:{moral:2, com:4, lid:2}, r:'Te agradece la preocupación y sigue. A veces avisar es todo lo que se puede hacer.'}
 ]},

{id:'j5', w:2, st:['ini'], when:p=>p.age<=20,
 t:'Te miden todo y te sale un número feo',
 d:p=>`Test de resistencia delante de toda la categoría, con los resultados en una pizarra. Quedás anteúltimo. El último es el arquero.`,
 c:[
  {t:'Te quedás a correr después de cada práctica', ef:{fis:7, forma:4, moral:-3, mgrRel:6}, r:'En el test de marzo quedás sexto. Nadie se acuerda del de agosto salvo vos.'},
  {t:'Argumentás que tu juego no va por ahí', ef:{com:5, reg:2, pas:2, mgrRel:-6}, r:'Tenés parte de razón. La parte que no tenés te la van a cobrar a los veintiocho.'},
  {t:'Le pedís al preparador un plan hecho para vos', ef:{fis:5, com:3, mgrRel:5, moral:3}, r:'Se sorprende de que alguien de tu edad pida eso. Te lo arma esa misma tarde.'}
 ]},

{id:'j6', w:3, st:['ini'], when:p=>p.age<=19,
 t:'El primer sueldo',
 d:p=>`No es mucho, pero es más de lo que gana tu viejo. Está en la cuenta un jueves a la mañana y lo mirás en el teléfono cuatro veces antes de entrenar.`,
 c:[
  {t:'Se lo das entero a tu familia', ef:{moral:10, fanLove:4, lid:3}, r:'Tu vieja llora y no lo quiere agarrar. Se lo dejás arriba de la mesa y te vas a entrenar.'},
  {t:'Te comprás lo primero que quisiste siempre', ef:{moral:12, hype:4, com:-4}, r:'Un gasto que no se justifica y que no te vas a arrepentir de haber hecho.'},
  {t:'Lo guardás entero sin tocarlo', ef:{com:7, capital:0.05, moral:-3}, r:'A los treinta vas a tener una casa por decisiones como esta. A los dieciocho es sólo un número en una pantalla.'}
 ]},

{id:'j7', w:2, st:['ini'], when:p=>p.age<=20,
 t:'Alguien del barrio te ofrece un auto',
 d:p=>`No te lo vende: te lo presta «hasta que puedas». No te pide nada. Todo el mundo sabe de dónde sale la plata de ese tipo y nadie lo dice en voz alta.`,
 c:[
  {t:'Decís que no', ef:{com:9, moral:-4, rep:3}, r:'Seguís yendo en colectivo dos años más. Es la mejor decisión de tu vida y no lo vas a saber hasta mucho después.'},
  {t:'Lo aceptás', ef:{moral:8, hype:4, com:-7, rep:-6, trait:'polemico'}, r:'Es cómodo seis meses. Después empiezan los favores, que era de lo que se trataba.'},
  {t:'Se lo contás al club', ef:{com:6, mgrRel:8, moral:-5, fanLove:-4}, r:'El club se ocupa. En tu barrio, durante un tiempo, sos el que fue con el cuento.'}
 ]},

{id:'j8', w:2, st:['ini','asc'], when:p=>p.age<=21,
 t:'Tu familia empieza a depender de vos',
 d:p=>`Tu viejo deja el trabajo porque «ahora se puede». Nadie lo habló con vos. Tenés ${enLetras(p.age)} años y de golpe cuatro personas comen de lo que hacés los domingos.`,
 c:[
  {t:'Lo aceptás y no decís nada', ef:{com:6, moral:-8, forma:-3, lid:3}, r:'Jugás cada partido con una mochila que nadie ve. Rendís igual, que es lo asombroso.'},
  {t:'Hablás con él de frente', ef:{com:7, moral:6, lid:5}, r:'Es la conversación más incómoda que tuvieron. Vuelve a trabajar medio horario y los dos duermen mejor.'},
  {t:'Armás las cuentas con un contador', ef:{com:5, capital:0.1, moral:4}, r:'Números claros, roles claros. Aburrido y salvador.'}
 ]},

{id:'j9', w:2, st:['ini'], when:p=>p.age<=20,
 t:'Te piden que firmes algo que no entendés',
 d:p=>`Tres hojas, letra chica y un bolígrafo sobre la mesa. Te dicen que es un trámite y que todos lo firman. No hay nadie tuyo en esa oficina.`,
 c:[
  {t:'Decís que lo firmás mañana, con alguien que lo lea', ef:{com:9, mgrRel:-5}, r:'Se ponen nerviosos, que ya es una respuesta. Tenía una cláusula de cinco años.'},
  {t:'Firmás', ef:{moral:4, mgrRel:6, flag:'agente', contrato:5}, r:'Firmaste tu carrera hasta los veinticuatro sin saberlo. Te vas a enterar cuando quieras irte.'},
  {t:'Llamás a tu viejo desde el pasillo', ef:{com:6, moral:6, lid:2}, r:'Llega en cuarenta minutos con un vecino abogado. No firmás nada ese día.'}
 ]},

{id:'j10', w:3, st:['ini'], when:p=>p.age<=19,
 t:'El día que echan a media categoría',
 d:p=>`Los llaman de a uno a la oficina. Salen y van directo al vestuario a buscar el bolso. De veinte que empezaron el año, siguen seis. Vos sos uno de los seis.`,
 c:[
  {t:'Salís a acompañarlos hasta la puerta', ef:{lid:6, moral:-5, fanLove:4}, r:'Ninguno te dice nada y todos se acuerdan. En este mundo eso se paga con años.'},
  {t:'Te quedás en el vestuario sin saber qué hacer', ef:{com:5, moral:-6}, r:'Escuchás los bolsos, la puerta y el silencio. No te lo sacás de encima en meses.'},
  {t:'Te concentrás en lo tuyo: para eso trabajaste', ef:{forma:6, com:6, moral:-3, lid:-3}, r:'Es cierto, y es lo que hay que hacer. También es la primera vez que te ves un poco frío.'}
 ]},

{id:'j11', w:2, st:['ini','asc'], when:p=>p.age<=21,
 t:'El mejor de tu categoría deja el fútbol',
 d:p=>`Era mucho mejor que vos a los quince y todo el mundo lo sabía. Se cansó, o le pesó, o las dos cosas. Te manda un mensaje diciendo que se alegra por vos.`,
 c:[
  {t:'Vas a verlo', ef:{moral:8, lid:4, com:5}, r:'Tomás un café de dos horas. Te cuenta cosas que ningún preparador te va a contar.'},
  {t:'Le contestás y seguís', ef:{moral:2, com:3}, r:'Se pierden el rastro. Lo vas a googlear cada tanto durante diez años.'},
  {t:'Lo llevás al club a hablar con el técnico', ef:{lid:7, moral:6, mgrRel:4}, r:'No vuelve a jugar, pero termina trabajando ahí. A veces el fútbol devuelve por otro lado.'}
 ]},

{id:'j12', w:2, st:['ini'], when:p=>p.age<=20,
 t:'Traen a uno de afuera para tu puesto',
 d:p=>`Un pibe de otra provincia, un año menor, con una carpeta de videos y un representante caro. Le dan tu lugar en el equipo antes de verlo entrenar una semana.`,
 c:[
  {t:'Le hacés la vida imposible en las prácticas', ef:{fis:3, forma:4, mgrRel:-7, lid:-4}, r:'Le ganás el puesto en dos meses. También te ganás fama de difícil, que dura más.'},
  {t:'Le mostrás el club y te hacés amigo', ef:{lid:6, moral:6, mgrRel:5, forma:-3}, r:'Juegan juntos ocho años, en tres clubes distintos. Empezó ese día.'},
  {t:'Trabajás en silencio y esperás', ef:{com:7, forma:5, moral:-3}, r:'Se lesiona en abril y entrás vos. No es como querías ganarlo, pero entraste.'}
 ]},

{id:'j13', w:2, st:['ini'], when:p=>p.age<=19,
 t:'Tu compañero de habitación no la está pasando bien',
 d:p=>`Hace tres semanas que no habla en la cena y ayer lo escuchaste llorar del otro lado de la pared. Tiene dieciséis años y su familia está a mil kilómetros.`,
 c:[
  {t:'Golpeás la puerta esa misma noche', ef:{lid:7, moral:6, com:4}, r:'Hablan hasta las tres. Al otro día entrena distinto y vos también.'},
  {t:'Se lo decís al psicólogo del club', ef:{lid:5, mgrRel:6, moral:3}, r:'Lo atienden esa semana. Él nunca sabe que fuiste vos y no hace falta.'},
  {t:'Hacés como que no escuchaste', ef:{com:4, moral:-8, lid:-4}, r:'Se vuelve a su casa en junio. Te vas a acordar de esa pared muchas veces.'}
 ]},

{id:'j14', w:3, st:['ini'], when:p=>p.age<=19,
 t:'Te ofrecen dejar todo por el fútbol',
 d:p=>`El club te propone un plan de entrenamiento doble que no es compatible con terminar el colegio. Te dicen que los que llegan hacen esto. Tu vieja dice que no delante de ellos.`,
 c:[
  {t:'Terminás el colegio, aunque te cueste el puesto', ef:{com:8, moral:6, forma:-5, mgrRel:-6}, r:'Perdés medio año de fútbol y ganás un papel que a los treinta y cinco vale una carrera entera.'},
  {t:'Dejás y vas con todo', ef:{fis:5, forma:8, moral:4, com:-5}, r:'Ganás dos años de ventaja. Si el fútbol sale bien, fue lo correcto. Si no, no.'},
  {t:'Negociás un plan a medias', ef:{com:5, fis:3, forma:3, moral:3, mgrRel:2}, r:'Dormís poco dos años. Llegás a las dos cosas, más justo en las dos.'}
 ]},

{id:'j15', w:2, st:['ini','asc'], when:p=>p.age<=21,
 t:'Tus amigos de siempre ya no te llaman',
 d:p=>`No se pelearon. Simplemente vos no podés salir los viernes, no vas a los cumpleaños y hace ocho meses que no aparecés. Dejaron de invitarte para no hacerte sentir mal.`,
 c:[
  {t:'Vas al próximo, aunque juegues el domingo', ef:{moral:10, fanLove:3, forma:-5}, r:'Te acostás a las cuatro y el domingo jugás mal. Volvés a tener amigos, que es un activo.'},
  {t:'Les explicás y los llamás vos', ef:{moral:7, lid:4, com:3}, r:'Se arregla con una llamada de veinte minutos. Casi todo se arregla así y casi nadie la hace.'},
  {t:'Lo aceptás como el precio', ef:{com:7, forma:4, moral:-8}, r:'Llegás muy alto y muy solo. Es un intercambio que mucha gente hizo antes que vos.'}
 ]},

{id:'j16', w:2, st:['ini'], when:p=>p.age<=20,
 t:'Un profesor te baja de un examen por un partido',
 d:p=>`Le pediste cambiar la fecha por una final juvenil y te dijo que no delante de todos, con una frase sobre los que se creen que van a vivir de la pelota.`,
 c:[
  {t:'Rendís, y sacás la mejor nota del curso', ef:{com:9, moral:8, forma:-4, rep:2}, r:'Se la dejás en el escritorio sin decir nada. La cara de él vale los dos días sin dormir.'},
  {t:'Faltás y jugás la final', ef:{forma:7, moral:6, com:-4}, r:'Ganan y hacés el segundo gol. Rendís en diciembre y raspando.'},
  {t:'Vas con tu vieja a hablar con el director', ef:{com:5, moral:4, lid:3}, r:'Consiguen la fecha nueva. Aprendés que las puertas se abren si alguien golpea.'}
 ]},

{id:'j17', w:2, st:['ini','asc'], when:p=>p.age<=21,
 t:'La chica del barrio se va a estudiar afuera',
 d:p=>`Se van el mismo mes, cada uno para su lado. Ella te pregunta si tiene sentido intentarlo a distancia y te lo pregunta en serio, esperando una respuesta de verdad.`,
 c:[
  {t:'Le decís que sí y lo intentan', ef:{moral:9, forma:-4, com:3}, r:'Dos años de aeropuertos y llamadas a deshora. Funciona, contra todo pronóstico.'},
  {t:'Le decís la verdad: no vas a poder', ef:{com:8, moral:-6, forma:4}, r:'Se lo agradece años después. En ese momento se va llorando.'},
  {t:'No decidís y dejás que pase', ef:{moral:-7, com:-3, forma:2}, r:'Se apaga sola en cuatro meses, de la peor manera: sin que nadie diga nada.'}
 ]},

{id:'j18', w:3, st:['ini'], when:p=>p.age<=20,
 t:'Volvés a jugar a la cancha de tierra',
 d:p=>`El club de tu barrio hace un partido a beneficio y te invitan. Es la cancha donde aprendiste, con el mismo alambrado y el mismo señor cortando el pasto. Tu club te pide que no vayas por el riesgo.`,
 c:[
  {t:'Vas y jugás los noventa', ef:{fanLove:14, moral:12, mgrRel:-8, fis:-3}, r:'Cuatrocientas personas y una emoción que no tiene nada que ver con el profesionalismo.'},
  {t:'Vas, saludás y no jugás', ef:{fanLove:6, moral:5, mgrRel:2}, r:'Firmás pelotas dos horas. Los pibes se van iguales de contentos.'},
  {t:'Le hacés caso al club', ef:{mgrRel:6, fis:2, moral:-7, fanLove:-8}, r:'Es lo profesional. En tu barrio se comenta de otra manera.'}
 ]},

{id:'j19', w:2, st:['ini','asc'], when:p=>p.age<=21 && (p.capital||0) >= 0.05,   

 t:'El que te llevaba a entrenar en su auto',
 d:p=>`Un vecino te llevó cuatro años, tres veces por semana, sin cobrarte un peso ni pedirte nada. Ahora tenés tu primer contrato y él sigue con el mismo auto y el mismo trabajo.`,
 c:[
  {t:'Le comprás un auto nuevo', ef:{moral:10, fanLove:8, capital:-0.05, lid:3}, r:'No lo quiere aceptar. Se lo dejás en la puerta con las llaves y una nota de cuatro renglones.'},
  {t:'Le pedís que trabaje con vos', ef:{moral:8, lid:5, com:3}, r:'Te maneja, te acompaña y te dice las verdades que nadie te dice. Lo mejor que contrataste nunca.'},
  {t:'Le agradecés y seguís', ef:{moral:2, com:2, fanLove:-3}, r:'Él nunca esperó nada. Vos vas a pensar en esto en algún momento, a los treinta.'}
 ]},

{id:'j20', w:2, st:['ini'], when:p=>p.age<=20,
 t:'Los pibes del barrio te esperan en la esquina',
 d:p=>`Son diez, tienen entre ocho y trece años y te esperan cada vez que venís. No te piden nada: te preguntan cosas. Uno te trae un cuaderno para que le firmes.`,
 c:[
  {t:'Te armás un entrenamiento con ellos los sábados', ef:{fanLove:12, lid:6, moral:8, fis:-2}, r:'Van creciendo con eso. Dos llegan a jugar en tercera división y los dos cuentan lo mismo.'},
  {t:'Les firmás y te vas', ef:{fanLove:4, moral:2}, r:'Siguen viniendo igual. Los pibes son leales por defecto.'},
  {t:'Les regalás botines a los que no tienen', todo:true, ef:{fanLove:10, moral:7, capital:-0.01}, r:'Uno de esos pares aparece en una foto once años después, colgados de un cable.'}
 ]},

{id:'j21', w:2, st:['ini','asc'], when:p=>p.age<=21,
 t:'Un club grande te ofrece pagarle la mudanza a tu familia',
 d:p=>`No es sólo tu ficha: es una casa, un trabajo para tu viejo y colegio para tu hermana. A mil kilómetros de todo lo que conocen. Tu vieja dice que decidas vos.`,
 c:[
  {t:'Se van todos', ef:{forma:6, rep:6, moral:-5, com:4}, r:'A tu hermana le cuesta dos años. A tu vieja no se le pasa nunca del todo.'},
  {t:'Vas solo', ef:{com:9, moral:-8, fis:3, forma:4}, r:'Aprendés a vivir solo a los diecinueve. Es más caro de lo que parece y sirve para siempre.'},
  {t:'Te quedás donde estás', ef:{moral:8, fanLove:8, forma:-4, rep:-5}, r:'Un año más en casa. La carrera va más despacio y la cabeza va mejor.'}
 ]},

{id:'j22', w:2, st:['ini'], when:p=>p.age<=20,
 t:'Te toca la mesa de los grandes',
 d:p=>`En el comedor hay una mesa donde comen los seis que juegan siempre. Un día te dicen que te sientes ahí. Los pibes con los que comías te miran desde la otra punta.`,
 c:[
  {t:'Te sentás con ellos', ef:{rep:5, mgrRel:5, lid:2, moral:3}, r:'Aprendés en dos meses lo que no se enseña. Perdés a tres amigos.'},
  {t:'Decís que gracias y seguís donde estabas', ef:{lid:6, moral:6, rep:-3}, r:'Los grandes te respetan más por eso que si te hubieras sentado.'},
  {t:'Te llevás a los pibes a esa mesa', ef:{lid:9, moral:7, rep:2, mgrRel:-3}, r:'Se arma un lío de sillas y una foto que se cuenta durante años en ese club.'}
 ]},

{id:'j23', w:2, st:['ini','asc'], when:p=>p.age<=21,
 t:'El técnico te grita delante de todos por un error',
 d:p=>`Fue un pase de veinte metros que salió mal en un entrenamiento. La reacción es desproporcionada y todos lo saben, incluido él.`,
 c:[
  {t:'Bajás la cabeza y seguís', ef:{com:6, mgrRel:5, moral:-5}, r:'Se le pasa en diez minutos. A vos te dura una semana y no se lo decís a nadie.'},
  {t:'Le contestás', ef:{lid:4, moral:6, mgrRel:-12, hype:3, trait:'polemico'}, r:'Se hace un silencio de cinco segundos. Nunca más te grita, y nunca más te pone tranquilo.'},
  {t:'Vas a hablarlo a solas después', ef:{com:7, lid:5, mgrRel:8, moral:4}, r:'Te pide disculpas en su oficina. Aprendés que la puerta cerrada arregla lo que la cancha no.'}
 ]},

{id:'j24', w:2, st:['ini'], when:p=>p.age<=19,
 t:'Te toca lavar la ropa de todos',
 d:p=>`Es la tradición del club con los que suben: los más chicos ordenan el vestuario y cargan las bolsas. Uno de tu categoría se niega el primer día.`,
 c:[
  {t:'Lo hacés sin chistar', ef:{mgrRel:6, lid:3, moral:-2, rep:2}, r:'Dos meses después nadie se acuerda. Los veteranos sí se acuerdan de quién no chistó.'},
  {t:'Lo hacés y arrastrás al que se negó', ef:{lid:8, moral:5, mgrRel:5}, r:'Termina ayudándote y riéndose. Resolviste algo que el cuerpo técnico no sabía cómo resolver.'},
  {t:'Te negás vos también', ef:{lid:2, moral:6, mgrRel:-8, rep:-4}, r:'Tenés razón en el fondo y perdés en la forma. En ese vestuario tardás un año en entrar de verdad.'}
 ]},

{id:'j25', w:2, st:['ini'], when:p=>p.age<=20,
 t:'Te dan un número que no es el tuyo',
 d:p=>`Jugaste toda la vida con un número y en el primer equipo lo tiene un referente. Te ofrecen el 32. Un utilero te dice por lo bajo que podés pedir el que quieras si insistís.`,
 c:[
  {t:'Te quedás con el 32 y lo hacés tuyo', ef:{com:6, moral:4, fanLove:4}, r:'Cinco años después ese número se vende en la tienda del club. Era tuyo desde el principio.'},
  {t:'Insistís hasta que te lo den', ef:{moral:6, hype:4, mgrRel:-6, rep:-2}, r:'Te lo dan. El referente no te lo perdona en toda la temporada.'},
  {t:'Se lo pedís al referente en persona', ef:{lid:6, com:4, moral:5, mgrRel:3}, r:'Te dice que no, pero te invita a comer. Ganaste algo mejor que un número.'}
 ]},

{id:'j26', w:2, st:['ini'], when:p=>p.age<=20,
 t:'La primera concentración',
 d:p=>`Hotel, habitación compartida y el teléfono entregado a las once. Es tu primera vez y no sabés si podés bajar a desayunar antes que los demás o si eso se hace.`,
 c:[
  {t:'Preguntás todo sin vergüenza', ef:{lid:4, moral:6, mgrRel:4}, r:'Los veteranos te explican con paciencia. Preguntar a los dieciocho es gratis; a los veinticinco ya no.'},
  {t:'Copiás lo que hacen los demás', ef:{com:5, moral:2}, r:'Funciona. También te pasás la noche entera mirando qué hace el resto.'},
  {t:'Te quedás en la habitación hasta que te llamen', ef:{com:3, moral:-4, lid:-3}, r:'Nadie te llama. Bajás último al desayuno y te sentás solo.'}
 ]},

{id:'j27', w:2, st:['ini','asc'], when:p=>p.age<=21 && !p.loanFrom,
 t:'Te ponen en la lista y no entrás',
 d:p=>`Nueve partidos seguidos concentrado, calentando media hora cada uno, y ni un minuto. El décimo domingo, mientras calentás, la gente detrás tuyo empieza a pedir que entres.`,
 c:[
  {t:'Le pedís al técnico que te explique', ef:{com:5, mgrRel:6, moral:4}, r:'Te dice la verdad: le faltan dos centímetros a tu juego. Te dice cuáles.'},
  {t:'Seguís calentando como si fueras a entrar siempre', ef:{com:8, fis:3, forma:5, moral:-3}, r:'El domingo doce entrás a los sesenta y das una asistencia. Estabas listo porque nunca dejaste de estarlo.'},
  {t:'Pedís que te cedan a préstamo', ofr:{t:'menor',cuando:'ya',prestamo:true}, ef:{moral:5, forma:6, mgrRel:-4, rep:-2}, r:'Jugás treinta partidos en otro lado. Volvés siendo otro y te miran distinto.'}
 ]},

{id:'j28', w:2, st:['ini'], when:p=>p.age<=19,
 t:'Un video tuyo de los quince años se hace viral',
 d:p=>`Alguien sube una jugada tuya de un torneo infantil. Tiene tres millones de reproducciones en dos días y los comentarios dicen que sos el próximo fenómeno. Todavía no debutaste.`,
 c:[
  {t:'Cerrás todas tus redes por un año', ef:{com:9, forma:5, hype:-8, moral:-3}, r:'Nadie te encuentra. Entrenás en paz doce meses y eso vale más que tres millones de nada.'},
  {t:'Aprovechás y firmás con una marca', ef:{hype:14, wage:6, capital:0.1, mgrRel:-5, com:-4}, r:'Tenés zapatillas gratis a los diecisiete y una expectativa que no pediste.'},
  {t:'Lo dejás pasar sin hacer nada', ef:{com:5, hype:4, moral:2}, r:'A las tres semanas ya nadie habla de eso. Internet olvida rápido, por suerte.'}
 ]},

{id:'j29', w:2, st:['ini'], when:p=>p.age<=20,
 t:'El técnico de la Reserva te dice que no vas a llegar',
 d:p=>`Se lo dice a todos los que cree que no van a llegar, para ahorrarles años. Lo dice sin maldad, con un café en la mano, un martes a las diez de la mañana.`,
 c:[
  {t:'Le agradecés y le demostrás que se equivoca', ef:{forma:8, com:7, moral:6, fis:2}, r:'Debutás nueve meses después. Él es el primero en abrazarte y no le sale la voz.'},
  {t:'Le preguntás qué le falta a tu juego', ef:{com:6, pas:2, def:2, mgrRel:6, moral:2}, r:'Te hace una lista de cuatro cosas. Trabajás en tres y las tres te sirven diez años.'},
  {t:'Te lo tomás mal y pedís irte del club', ef:{moral:-6, hype:3, forma:4, mgrRel:-8}, ofr:{t:'menor', cuando:'ventana'}, r:'Te vas a un club más chico y jugás. A veces la salida enojada es la salida correcta.'}
 ]},

{id:'j30', w:2, st:['ini'], when:p=>p.age<=19,
 t:'Elegís de qué lado del vestuario colgás el bolso',
 d:p=>`Es la primera vez que entrás al vestuario del primer equipo. Hay un lado donde se cambian los que juegan y otro donde se cambian los que esperan. Nadie te dice nada; todos miran.`,
 c:[
  {t:'Del lado de los que juegan', ef:{lid:6, rep:4, moral:5, mgrRel:-4}, r:'Uno de los grandes levanta una ceja y se corre un poco. Con eso alcanza.'},
  {t:'Del lado de los que esperan', ef:{com:6, mgrRel:5, lid:-2, moral:2}, r:'Nadie lo comenta y todos lo registran. Vas a moverte de lugar cuando toque.'},
  {t:'Preguntás dónde te toca', ef:{moral:3, mgrRel:6, com:4, rep:-2}, r:'El capitán te señala un lugar y te dice el nombre de todos. La manera más simple, y casi nadie la usa.'}
 ]}

];
EVENTS.push(...EVENTS6);

const EVENTS7 = [

{id:'c1', w:16, st:['ini','asc','ple'], when:p=>!!p.loanFrom,
 t:'Te toca jugar contra el club que te tiene',
 d:p=>`Está en el contrato de la cesión: podés jugar contra ellos o no, y la decisión es tuya. Del otro lado hay veinte tipos con los que desayunaste seis meses.`,
 c:[
  {t:'Jugás', ef:{forma:8, com:6, rep:5, moral:-4}, r:'Les hacés un partido serio y no lo festejás si sale. Los dos clubes te miran distinto.'},
  {t:'Pedís no jugar', ef:{moral:6, fanLove:-8, mgrRel:-8}, r:'El vestuario donde estás lo entiende a medias. Los hinchas, nada.'},
  {t:'Jugás y lo festejás como si fuera cualquier partido', ef:{forma:6, hype:9, moral:6, lid:4}, r:'Se arma un revuelo de dos días. Tu club dueño toma nota, y no para bien.'}
 ]},

{id:'c2', w:12, st:['ini','asc','ple'], when:p=>!!p.loanFrom,
 t:'Tu club dueño te manda un plan de entrenamiento',
 d:p=>`Llega un documento de catorce páginas con lo que tenés que hacer cada día. No coincide en casi nada con lo que hace el club donde estás jugando. Los dos preparadores se enteran a la vez.`,
 c:[
  {t:'Seguís el del club donde jugás', ef:{fis:4, forma:6, mgrRel:6}, r:'Entrenás con el grupo y jugás mejor. En tu club dueño lo anotan en una carpeta.'},
  {t:'Seguís el de tu club dueño', ef:{fis:5, mgrRel:-8, forma:-4, moral:-3}, r:'Hacés doble trabajo y quedás bien con quien decide tu futuro. Y mal con quien decide tu domingo.'},
  {t:'Los sentás a los dos a hablar', ef:{lid:7, com:5, fis:3, moral:4}, r:'Sale un plan mezclado que funciona. Nadie había intentado eso nunca.'}
 ]},

{id:'c3', w:14, st:['ini','asc','ple'], when:p=>!!p.loanFrom,
 t:'El club donde estás cedido quiere comprarte',
 d:p=>`Están jugando la mejor temporada en años y vos sos parte de eso. Ponen sobre la mesa lo que haga falta. Tu club dueño todavía no contestó el teléfono.`,
 c:[
  {t:'Decís públicamente que te querés quedar', ef:{fanLove:14, moral:8, rep:4, mgrRel:-6}, r:'La hinchada te adopta esa misma tarde. En tu club dueño se lo toman como una traición chica.'},
  {t:'No opinás: que lo arreglen los clubes', ef:{com:7, moral:-3}, r:'Se cae la operación en marzo por dos millones. Nadie te preguntó nunca qué querías.'},
  {t:'Le pedís a tu representante que fuerce la salida', ef:{value:-3, moral:5, rep:-4, hype:6}, r:'Se hace, y se hace mal: los tres quedan enojados y vos te quedás donde querías.'}
 ]},

{id:'c4', w:12, st:['asc','ple'], when:p=>!!p.loanFrom,
 t:'En tu club dueño cambió el técnico',
 d:p=>`El que te mandó a préstamo se fue. El que llega no te vio jugar nunca y armó la lista de la pretemporada sin tu nombre. Tampoco lo sacó.`,
 c:[
  {t:'Le mandás un mensaje presentándote', ef:{mgrRel:8, com:5, moral:4}, r:'Contesta a los dos días con tres líneas. Es más de lo que la mayoría consigue.'},
  {t:'Te concentrás en jugar donde estás', ef:{forma:9, com:6, moral:2}, r:'Metés ocho goles en cuatro meses. Ese mensaje se lo mandan los números.'},
  {t:'Pedís que tu representante lo llame', ef:{rep:3, mgrRel:-4, hype:3}, r:'Lo llama y le cae mal. A veces el intermediario es el problema.'}
 ]},

{id:'c5', w:12, st:['ini','asc'], when:p=>!!p.loanFrom,
 t:'Sos el de afuera',
 d:p=>`En el vestuario donde estás cedido nadie es malo con vos, pero tampoco nadie te cuenta nada. Sos el que se va en junio y todos lo saben desde el primer día.`,
 c:[
  {t:'Te comportás como si te fueras a quedar diez años', ef:{lid:6, fanLove:8, mgrRel:6, moral:5}, r:'A los dos meses ya sos uno más. En junio te despiden como si te hubieras criado ahí.'},
  {t:'Mantenés la distancia: es una escala', ef:{com:7, forma:4, moral:-6, lid:-3}, r:'Cumplís y te vas. Nadie te va a llamar nunca por tu cumpleaños.'},
  {t:'Se lo decís de frente al capitán', ef:{lid:5, moral:6, com:3}, r:'Se ríe, te pide disculpas y esa misma noche te invita a comer con seis más.'}
 ]},

{id:'c6', w:13, st:['asc','ple'], when:p=>!!p.loanFrom,
 t:'Una cláusula te obliga a jugar cierta cantidad de partidos',
 d:p=>`Si llegás a veinticinco, el club donde estás tiene que comprarte. Van veinte, quedan seis fechas, y el técnico acaba de dejarte en el banco dos partidos seguidos.`,
 c:[
  {t:'Le preguntás si es por la cláusula', ef:{com:5, mgrRel:-6, moral:-4}, r:'Te dice que no y los dos saben que sí. Entrás los últimos cuatro, veinte minutos cada uno.'},
  {t:'Entrenás como si nada y esperás', ef:{com:8, forma:5, moral:-3}, r:'Llegás a veinticuatro. Un partido. Volvés a tu club dueño en junio.'},
  {t:'Se lo contás a la prensa', ef:{hype:12, rep:-5, mgrRel:-12, fanLove:6}, r:'Se arma un escándalo y te ponen de titular las seis fechas. Ganaste, y nadie te va a volver a prestar.'}
 ]}

];
EVENTS.push(...EVENTS7);

const afuera = p => L(C(p.club).lg).pais !== p.nat;
const enEuropa = p => !!compsFor(p, C(p.club)).conti;
const enLigaEuropea = p => { const c = C(p.club); return !!(c && L(c.lg) && L(c.lg).cont === 'EUR'); };
const conVitrina = p => (p.ligas||0) + (p.copas||0) + (p.contis||0) > 0;

const EVENTS8 = [

{id:'x7', w:4, st:['asc','ple'], when:p=>afuera(p) && p.adapt<90,
 t:'El idioma no te entra',
 d:p=>`Ocho meses y seguís asintiendo en las charlas técnicas sin entender la mitad. Ayer el técnico pidió que alguien tradujera y se hizo un silencio incómodo.`,
 c:[
  {t:'Clases todos los días, aunque te saquen horas de descanso', ef:{pas:2, mgrRel:8, moral:6, fis:-3}, r:'A los cuatro meses discutís una jugada en la pizarra. El vestuario te aplaude en broma y en serio.'},
  {t:'Te apoyás en el compañero que habla lo tuyo', ef:{moral:8, lid:-3, mgrRel:-4}, r:'Sobrevivís cómodo. También quedás pegado a él para todo, y el día que se va quedás mudo.'},
  {t:'Pedís que te den las charlas por escrito', ef:{com:6, def:2, mgrRel:3, moral:-3}, r:'Te las dan. Sos el único que estudia el partido en papel, y se te empieza a notar en la cancha.'}
 ]},

{id:'x8', w:3, st:['asc','ple','vet'], when:p=>afuera(p),
 t:'La primera Navidad lejos',
 d:p=>`Acá se juega el 26 y no hay parate. Tu familia te llama a las nueve de la noche, ya cenados, y te muestran la mesa por la pantalla.`,
 c:[
  {t:'Te los traés a todos, cueste lo que cueste', ef:{moral:14, capital:-0.03, forma:-3}, r:'Duermen ocho personas en tu departamento. Es el mejor diciembre de tu vida y jugás peor el 26.'},
  {t:'Te vas al vestuario y cenás con los que también están solos', ef:{lid:6, moral:8, mgrRel:4}, r:'Terminan cinco extranjeros comiendo comida de cinco países. Se hace tradición cuatro años seguidos.'},
  {t:'Te lo bancás solo y entrenás el 25', ef:{fis:4, forma:6, moral:-9}, r:'El 26 hacés un partidazo. En la habitación del hotel, después, no tanto.'}
 ]},

{id:'x9', w:2, st:['asc','ple'], when:p=>afuera(p),
 t:'La prensa de acá no te va a querer',
 d:p=>`No es por vos: hay un tono con los que vienen de afuera. Cada error tuyo se cuenta con una palabra distinta que la que usan para los de casa, y lo notás porque lo notás.`,
 c:[
  {t:'Lo decís en una entrevista', ef:{hype:10, rep:4, moral:6, fanLove:-8}, r:'Se arma tres días. Después bajan el tono, aunque nadie lo va a admitir nunca.'},
  {t:'Aprendés el idioma lo suficiente para dar notas sin traductor', ef:{rep:8, fanLove:10, moral:5, pas:2}, r:'Cambia todo. Nada compra más rápido a un país que hablarle en su idioma.'},
  {t:'Dejás que hablen y jugás', ef:{com:7, forma:5, moral:-4}, r:'Tres temporadas después te ponen en la portada como «uno de los nuestros». No pediste disculpas nunca.'}
 ]},

{id:'x10', w:2, st:['ple','vet'], when:p=>afuera(p) && p.age>=25,
 t:'Volvés de visita y sos un extraño',
 d:p=>`Diez días en tu ciudad. Tus amigos te tratan con un respeto raro, tu barrio cambió, y alguien te dice sin maldad que ya hablás distinto.`,
 c:[
  {t:'Te quedás una semana más y hacés vida normal', ef:{moral:10, forma:-4, fanLove:6}, r:'Al cuarto día vuelven a tratarte como siempre. Era cuestión de tiempo, no de distancia.'},
  {t:'Volvés antes y te metés a entrenar', ef:{forma:8, fis:3, moral:-6}, r:'Llegás en forma a enero. Algo se te enfría por dentro y no sabés bien qué.'},
  {t:'Comprás algo en tu barrio: una casa, un local, lo que sea', ef:{moral:8, capital:-0.5, fanLove:8, lid:3}, r:'Tener una llave de allá te ordena la cabeza más de lo que esperabas.'}
 ]},

{id:'x11', w:2, st:['asc','ple'], when:p=>afuera(p),
 t:'Un compatriota nuevo en el vestuario',
 d:p=>`Llega con diecinueve años, sin una palabra del idioma y con la misma cara que tenías vos. Nadie le explicó nada todavía.`,
 c:[
  {t:'Lo adoptás', ef:{lid:8, moral:8, mgrRel:4, forma:-2}, r:'Vive en tu casa dos meses. A los cinco años él hace lo mismo con otro y cuenta que se lo enseñaste vos.'},
  {t:'Le presentás gente y lo dejás caminar solo', ef:{lid:4, moral:4}, r:'Se las arregla. Te agradece igual, que es lo que hacen los que se las arreglan.'},
  {t:'Preferís no mezclarte: te costó salir de ese rincón', ef:{com:5, forma:4, moral:-6, lid:-4}, r:'Tenés tus razones y son buenas. Él se vuelve en junio.'}
 ]},

{id:'x12', w:2, st:['ple','vet'], when:p=>afuera(p) && p.adapt>=85,
 t:'Te ofrecen la nacionalidad de acá',
 d:p=>`Llevás los años que hacen falta. El trámite es rápido y hay quien sugiere, sin decirlo del todo, que también abriría una puerta con esta selección.`,
 c:[
  {t:'La sacás, por comodidad y nada más', ef:{moral:6, com:4, rep:2}, r:'Un pasaporte más en el cajón. Te ahorra colas en los aeropuertos y poco más.'},
  {t:'La sacás y decís que jugarías para acá si te llaman', ef:{hype:14, rep:6, fanLove:12, moral:-8}, r:'En tu país se arma una discusión que dura un mes. Algunos no te lo perdonan.'},
  {t:'Decís que no', ef:{moral:10, fanLove:-4, com:6}, r:'Te complicás la vida con los papeles durante años. Dormís perfecto.'}
 ]},

{id:'x13', w:3, st:['asc','ple','vet'], when:p=>afuera(p) && p.adapt<85,
 t:'Tu pareja quiere volverse',
 d:p=>`Dejó su trabajo para venir con vos y acá no encuentra nada. Lo dice sin reproche, que es lo que lo hace difícil: no te está pidiendo que elijas.`,
 c:[
  {t:'Se vuelve y lo intentan a distancia', ef:{moral:-10, forma:6, com:5}, r:'Aguantan catorce meses. Después no.'},
  {t:'Le buscás algo acá con todo lo que tenés', ef:{moral:8, forma:-3, lid:3}, r:'Consigue trabajo en seis semanas. Nunca le decís cuántas llamadas hiciste.'},
  {t:'Pedís al club que te busque salida a un país donde ella pueda trabajar', ef:{moral:6, rep:-4, mgrRel:-6}, r:'Te escuchan y te lo cobran en el próximo mercado. Volverías a hacerlo.'}
 ]},

{id:'x14', w:2, req:'padre', st:['ple','vet'], when:p=>afuera(p) && p.age>=27,
 t:'Tus hijos hablan otro idioma que vos',
 d:p=>`Se pelean entre ellos en el idioma de acá y se olvidan palabras del tuyo. En la cena hacen un puente para que entiendas, y ese puente te duele un poco.`,
 c:[
  {t:'Impostás las cenas en tu idioma, sin excepciones', ef:{moral:8, com:4}, r:'Se quejan tres años. A los veinte te lo agradecen los dos.'},
  {t:'Los dejás: son de acá y está bien', ef:{moral:4, com:6, lid:2}, r:'Aprendés el idioma de tus hijos a los treinta. Es una manera rara y linda de emigrar.'},
  {t:'Empezás a pensar en volver', ef:{moral:6, rep:-3, forma:-4}, r:'Cambia cómo mirás cada oferta a partir de ese día.'}
 ]},

{id:'q1', w:3, st:['asc','ple','vet'], when:p=>!enEuropa(p) && p.age>=23,
 t:'Los jueves libres',
 d:p=>`Este año no hay copa. Media liga juega entre semana y vos mirás por televisión. El técnico dice que es una ventaja: se entrena mejor, se llega más entero.`,
 c:[
  {t:'Lo usás: entrenás como nunca', ef:{fis:6, forma:8, def:2, moral:-4}, r:'Llegás a mayo volando y el equipo también. Igual los jueves siguen siendo largos.'},
  {t:'Le decís al club que querés irte a un lugar donde se juegue', ef:{moral:5, mgrRel:-8, rep:3, hype:6}, r:'Lo entienden y no les gusta. Queda anotado para junio.'},
  {t:'Te hacés cargo de que este equipo vuelva', ef:{lid:8, forma:6, moral:6, fis:-3}, r:'Clasifican en la última fecha. Esa noche vale más que tres octavos de final.'}
 ]},

{id:'q2', w:3, st:['asc','ple'], when:p=>enEuropa(p),
 t:'Jueves, nueve de la noche, cinco horas de avión',
 d:p=>`Un pueblo del que no habías oído hablar, ocho grados bajo cero y cuatro mil personas. Nadie mira este partido y hay que ganarlo igual.`,
 c:[
  {t:'Lo tomás como el partido más importante del mes', ef:{forma:7, lid:6, mgrRel:6, fis:-3}, r:'Ganan 2-0 y hacés uno. En esos partidos se construye la fama de profesional.'},
  {t:'Pedís descansar para el domingo', ef:{fis:5, forma:-4, mgrRel:-5, lid:-3}, r:'Descansás y el domingo jugás bien. Los que viajaron a menos ocho no te lo dicen, pero lo saben.'},
  {t:'Vas y te lo tomás como un paseo', ef:{moral:6, forma:-6, fanLove:-5}, r:'Empatan y quedan complicados. La vuelta en avión son cinco horas de silencio.'}
 ]},

{id:'q3', w:2, st:['ple','vet'], when:p=>enEuropa(p),
 t:'El sorteo imposible',
 d:p=>`Te toca el equipo del que todos hablan, en un grupo donde el segundo puesto ya sería una hazaña. La prensa lo da por perdido antes del primer partido.`,
 c:[
  {t:'Salís a decir que los vas a pasar', ef:{hype:12, lid:6, moral:6, com:-3}, r:'Los pasan en la última fecha. Esa frase se recuerda quince años.'},
  {t:'Bajás el perfil y trabajás', ef:{com:7, forma:6, mgrRel:5}, r:'Quedan segundos por un gol. Nadie los subestima al año siguiente.'},
  {t:'Aceptás que la copa no es este año y pensás en la liga', ef:{forma:5, fis:4, moral:-4, fanLove:-6}, r:'Sale bien en la tabla y mal en la memoria. Los hinchas quieren las dos cosas.'}
 ]},

{id:'q4', w:3, st:['ple','vet'], when:p=>enEuropa(p) && p.age>=25,
 t:'Eliminados en la primera fase',
 d:p=>`Fuera en diciembre, sin discusión, con un punto de dieciocho. El vestuario está mudo y hay cuatro meses de temporada por delante.`,
 c:[
  {t:'Hablás vos en el vestuario', ef:{lid:9, moral:6, forma:6, rep:4}, r:'Ganan siete de los diez siguientes. La liga se salva por lo que dijiste un miércoles a la noche.'},
  {t:'Pedís perdón públicamente en nombre del plantel', ef:{fanLove:12, rep:6, lid:5, moral:-5}, r:'La gente lo valora. Los compañeros, algunos sí y algunos no.'},
  {t:'Te encerrás a trabajar sin decir nada', ef:{forma:8, fis:3, moral:-6, lid:-3}, r:'Hacés tu mejor semestre individual en un equipo que no levanta.'}
 ]},

{id:'q5', w:2, st:['ple','vet'], when:p=>!enEuropa(p) && conVitrina(p),
 t:'De jugar la copa grande a no jugar nada',
 d:p=>`Hace dos años estabas en octavos. Hoy el club pelea la mitad de la tabla y el objetivo de la temporada, dicho en voz alta, es «ordenarse».`,
 c:[
  {t:'Te quedás a reconstruir', ef:{lid:9, fanLove:14, moral:6, rep:-4}, r:'Tres años después vuelven a clasificar y sos el único que estuvo todo el trayecto.'},
  {t:'Pedís salir a un club que juegue algo', ef:{rep:5, moral:4, fanLove:-12, mgrRel:-6, flag:'quiereIrse', mem:{plantes:1}}, r:'Es legítimo y la gente no lo perdona igual. Los años buenos pesan menos que la salida.'},
  {t:'Te quedás pero avisás que es el último año', ef:{com:6, moral:3, fanLove:-4, lid:3}, r:'Jugás doce meses de despedida anunciada. Raro y honesto.'}
 ]},

{id:'q6', w:2, st:['asc','ple'], when:p=>enEuropa(p) && p.age<=24,
 t:'Tu primera noche grande de verdad',
 d:p=>`Ochenta mil personas y un himno que escuchaste toda la vida por televisión. En el túnel, el capitán del otro equipo es alguien cuyo póster tuviste en la pared.`,
 c:[
  {t:'Le pedís la camiseta antes de empezar', ef:{moral:10, hype:6, forma:-5, rep:-3}, r:'Te la da y te la firma. También te pasa por arriba durante noventa minutos.'},
  {t:'No lo mirás a la cara en todo el partido', ef:{com:8, forma:7, lid:4}, r:'Le ganás el duelo. Al final te busca él a vos para cambiar la camiseta.'},
  {t:'Salís a jugar como si fuera un partido más', ef:{forma:6, com:6, moral:4}, r:'Es la única manera de que no te tiemblen las piernas, y funciona.'}
 ]},

{id:'q7', w:2, st:['ple','vet'], when:p=>enEuropa(p) && p.age>=27,
 t:'Un final continental y no estás en la lista',
 d:p=>`Llegaron hasta acá y el técnico te deja fuera de los convocados por una decisión táctica. Se lo dice a todos el día antes, de a uno, en su oficina.`,
 c:[
  {t:'Salís a la cancha con el traje y bancás desde afuera', ef:{lid:10, fanLove:12, moral:-6, rep:5}, r:'Ganan. En la foto del festejo estás en el medio, de traje, y es la mejor foto de tu carrera.'},
  {t:'Te quedás en el hotel', ef:{moral:-12, com:6, mgrRel:-8}, r:'Lo ves solo, en una habitación, y no bajás al festejo. Cada uno duele como puede.'},
  {t:'Le pedís explicaciones antes del partido', ef:{com:-3, mgrRel:-12, moral:5, lid:3}, r:'Te las da y no te convencen. Al menos se lo dijiste a la cara.'}
 ]},

{id:'w1', w:3, st:['ple','vet'], when:p=>conVitrina(p) && p.age>=25,
 t:'La segunda sabe distinta',
 d:p=>`Ganaron otra vez. La primera fue una explosión; ésta es un vestuario donde se descorcha, se sacan la foto y a los veinte minutos ya hay tres hablando del año que viene.`,
 c:[
  {t:'Forzás que se festeje como la primera', ef:{lid:7, moral:10, fanLove:8, fis:-3}, r:'Terminan a las seis de la mañana. Al año siguiente ganan otra: no era casualidad.'},
  {t:'Te sumás al que ya piensa en el año que viene', ef:{forma:7, com:6, moral:-4}, r:'Ganás tres seguidas. También te perdés tres festejos que no van a volver.'},
  {t:'Te vas temprano a tu casa', ef:{moral:4, com:5, lid:-4}, r:'Cenás con los tuyos. Es tu manera y a nadie tiene por qué gustarle.'}
 ]},

{id:'w2', w:2, st:['ple','vet'], when:p=>conVitrina(p),
 t:'«Ganaste porque te tocó el equipo bueno»',
 d:p=>`Lo dice un ex jugador en televisión y lo repite media red social durante tres días. La parte que más molesta es que no es del todo falso.`,
 c:[
  {t:'Contestás con la lista de lo que hiciste vos', ef:{hype:10, rep:3, moral:4, fanLove:-4}, r:'Ganás la discusión y perdés algo más difícil de nombrar.'},
  {t:'Te lo tomás en serio y te vas a un club más chico', ofr:{t:'chico',cuando:'ya'}, ef:{rep:8, fanLove:10, forma:-5, moral:6}, r:'Ahí no hay excusas. Lo que hagas a partir de ahora es tuyo entero.'},
  {t:'No decís nada', ef:{com:8, moral:-3, forma:5}, r:'A los cinco años, cuando la carrera está completa, esa frase ya no la dice nadie.'}
 ]},

{id:'w3', w:2, st:['vet','oca'], when:p=>(p.ligas||0)>=3,
 t:'El club te propone hacer una vitrina con lo tuyo',
 d:p=>`Quieren un rincón del museo con tus camisetas y tus medallas. Piden que lleves lo que tengas guardado, y te dan una lista.`,
 c:[
  {t:'Llevás todo', ef:{fanLove:14, moral:10, rep:5}, r:'Tu vieja lo baja del ropero en cajas. Llora ella y llorás vos, cada uno por su lado.'},
  {t:'Llevás todo menos una', ef:{moral:8, fanLove:8, com:4}, r:'Te quedás la del debut. Nadie pregunta cuál falta y todos lo entienden.'},
  {t:'Decís que todavía no: seguís jugando', ef:{forma:6, com:6, fanLove:-4}, r:'Los museos son para después. Todavía te queda algo que agregar a esa lista.'}
 ]},

{id:'w4', w:2, st:['ple','vet'], when:p=>conVitrina(p) && p.age>=26,
 t:'Un compañero que nunca ganó nada',
 d:p=>`Tiene treinta y cuatro, jugó en once clubes y no tiene una sola medalla. Este año pueden ganar la copa y él no lo dice, pero se le nota en cada entrenamiento.`,
 c:[
  {t:'Le das tu lugar en el once de la final si el técnico deja', ef:{lid:12, fanLove:10, moral:8, forma:-6}, r:'Entra veinte minutos y levanta la copa. La foto de él con la copa la tenés vos enmarcada.'},
  {t:'Jugás para que él gane', ef:{lid:7, forma:8, moral:8}, r:'Ganan. Te abraza y no puede hablar. No hace falta que le des tu lugar para dárselo.'},
  {t:'Jugás como siempre: es su carrera, no la tuya', ef:{forma:6, com:5, lid:-4}, r:'Ganan igual y él la levanta igual. También es una manera de ayudar.'}
 ]},

{id:'w5', w:2, st:['ple','vet'], when:p=>(p.contis||0)>=1 || (p.mundiales||0)>=1,
 t:'La resaca del año perfecto',
 d:p=>`Ganaron todo y el equipo empezó la temporada siguiente como si se le hubiera terminado el motivo. Tres derrotas en agosto y nadie sabe explicar por qué.`,
 c:[
  {t:'Proponés objetivos nuevos, chicos y concretos', ef:{lid:9, forma:7, moral:5}, r:'Funciona. Ganar de nuevo empieza por dejar de mirar lo que ya ganaste.'},
  {t:'Pedís al club que traiga hambre de afuera', ef:{lid:5, mgrRel:4, moral:-3}, r:'Llegan dos pibes que corren como si les fuera la vida. Contagia en un mes.'},
  {t:'Esperás a que pase solo', ef:{com:5, forma:-6, moral:-5}, r:'Pasa, pero en enero, y para entonces la liga está a doce puntos.'}
 ]},

{id:'w6', w:2, st:['vet','oca'], when:p=>conVitrina(p) && p.age>=31,
 t:'Un pibe te pregunta a qué sabe ganar',
 d:p=>`Tiene diecinueve, todavía no ganó nada y te lo pregunta en serio, en el micro, después de un entrenamiento cualquiera. Esperás para contestar más de lo que esperabas.`,
 c:[
  {t:'Le decís la verdad: dura poco', ef:{lid:8, com:6, moral:4}, r:'Se queda callado veinte minutos. A los treinta años él le va a decir lo mismo a otro.'},
  {t:'Le contás la noche entera, minuto a minuto', ef:{lid:6, moral:10, fanLove:4}, r:'Se le van los ojos. Le acabás de dar un motivo para los próximos diez años.'},
  {t:'Le decís que se concentre en jugar', ef:{com:6, forma:4, lid:-3}, r:'Tenés razón y él se queda con la pregunta. Algunas se contestan solas.'}
 ]},

{id:'z1', w:4, st:['asc','ple','vet'], when:p=>p.injuredWeeks>0,
 t:'El vestuario sigue funcionando sin vos',
 d:p=>`Llevás semanas afuera. Ganaron cuatro seguidos y el que juega en tu puesto anda bien. Entrás al vestuario el lunes y las conversaciones no te incluyen.`,
 c:[
  {t:'Te quedás igual, todos los días, aunque no puedas hacer nada', ef:{lid:8, mgrRel:8, moral:4, fis:2}, r:'Cuando volvés no tenés que reconquistar a nadie: no te fuiste nunca.'},
  {t:'Te concentrás en recuperarte lejos del club', ef:{fis:7, forma:4, moral:-6, lid:-4}, r:'Volvés antes y mejor. También volvés a un grupo que se acostumbró a no contar con vos.'},
  {t:'Se lo decís al técnico', ef:{com:5, mgrRel:6, moral:5}, r:'Te pone a ayudar con los videos. Es un puesto inventado y te salva la cabeza.'}
 ]},

{id:'z2', w:3, st:['ple','vet'], when:p=>p.injuredWeeks>0 && p.age>=25,
 t:'Tu médico no coincide con el del club',
 d:p=>`El del club dice seis semanas y conservador. El tuyo, que te opera desde hace años, dice que hay que entrar ya. Los dos tienen argumentos y los dos te miran esperando.`,
 c:[
  {t:'Vas con el del club', ef:{mgrRel:8, fis:4, moral:-3}, r:'Sale bien. Si hubiera salido mal, al menos no habrías estado solo.'},
  {t:'Vas con el tuyo', ef:{fis:6, forma:5, mgrRel:-10, com:4}, r:'Volvés dos semanas antes. El club lo anota en un informe que no vas a leer nunca.'},
  {t:'Pedís una tercera opinión y decidís vos', ef:{com:8, fis:5, moral:6, mgrRel:-3}, r:'Tardás cinco días más en decidir y decidís bien. Es tu cuerpo: la firma es tuya.'}
 ]},

{id:'z3', w:3, st:['asc','ple','vet'], when:p=>p.injuredWeeks>0,
 t:'El que te reemplazó está jugando mejor que vos',
 d:p=>`No es una impresión: los números lo dicen. Y encima es buen tipo, viene a preguntarte cómo va la rodilla y te pide consejos sobre el rival del domingo.`,
 c:[
  {t:'Le das los consejos, todos, sin guardarte nada', ef:{lid:10, moral:6, rep:5, mgrRel:6}, r:'Hace un partidazo con algo que le dijiste vos. Te busca al final y te lo dice delante de todos.'},
  {t:'Le contestás de a poco y te guardás lo mejor', ef:{com:5, moral:-4, lid:-4}, r:'Nadie lo nota. Vos sí, y no te gusta lo que ves.'},
  {t:'Adelantás la vuelta para pelearle el puesto', ef:{forma:7, fis:-8, moral:5, trait:'cristal'}, r:'Volvés al mes. Recaés en noviembre y perdés el doble de tiempo.'}
 ]},

{id:'z4', w:2, st:['vet','oca'], when:p=>p.injuredWeeks>0 && p.age>=29,
 t:'Esta vez tardás más',
 d:p=>`La misma lesión que a los veinticuatro te tuvo tres semanas ahora lleva siete. Nadie te lo dice, pero el kinesiólogo empezó a hablarte de «gestionar cargas».`,
 c:[
  {t:'Aceptás gestionar cargas y jugar menos partidos', ef:{fis:6, com:7, forma:-4, moral:-3}, r:'Jugás cuarenta partidos menos en tres años y te retirás dos años más tarde.'},
  {t:'Te negás: querés jugar todo mientras puedas', ef:{forma:8, moral:8, fis:-7}, r:'Dos temporadas espléndidas y una tercera que no existe.'},
  {t:'Cambiás de entrenamiento por completo', ef:{fis:5, def:2, pas:2, forma:-3, com:5}, r:'Corrés menos y llegás antes. Aprender eso a los treinta es casi un fichaje.'}
 ]},

{id:'z5', w:2, st:['asc','ple'], when:p=>p.injuredWeeks>0 && p.age<=25,
 t:'La cabeza después de la lesión',
 d:p=>`Estás recuperado y los estudios están perfectos. Pero en el primer entrenamiento fuerte no entraste a una división que antes entrabas sin pensar, y te diste cuenta en el momento.`,
 c:[
  {t:'Se lo contás al psicólogo del club', ef:{com:8, moral:8, forma:5}, r:'Tres sesiones y una explicación que te ordena la cabeza. Se te va en un mes.'},
  {t:'Te obligás a entrar a la próxima', ef:{com:5, fis:-4, forma:6, moral:4}, r:'Entrás, no pasa nada, y el miedo se rompe ahí mismo. Podría haber salido al revés.'},
  {t:'No se lo decís a nadie y jugás midiendo', ef:{fis:5, def:3, forma:-6, moral:-5}, r:'Catorce meses entrando medio segundo tarde a todo. Aprendés a ganar la pelota sin el cuerpo, que también es una manera de jugar.'}
 ]},

{id:'k1', w:5, st:['vet','oca'], when:p=>p.contract<=1,
 t:'Último año de contrato y nadie llama',
 d:p=>`Enero. Te queda medio año y el club no te ofreció nada. Podés firmar con quien quieras a partir de ahora y tu teléfono está en silencio.`,
 c:[
  {t:'Se lo preguntás al director deportivo de frente', ef:{com:6, mgrRel:4, moral:-4}, r:'Te dice la verdad: están esperando a ver si aparece otro. Es horrible y es útil saberlo.'},
  {t:'Jugás los mejores seis meses de tu vida', ef:{forma:10, fis:-4, moral:6, value:6}, r:'En marzo hay tres clubes llamando. El tuyo, cuarto.'},
  {t:'Firmás lo primero que aparezca', ef:{moral:-5, wage:-12, com:3, contrato:2}, r:'Te sacás la incertidumbre de encima. Te vas a arrepentir en junio, cuando aparezcan los otros.'}
 ]},

{id:'k2', w:2, st:['ple','vet'], when:p=>p.wage>=6,
 t:'Se filtró lo que ganás',
 d:p=>`Sale publicado con dos decimales. Sos el mejor pagado del plantel por bastante y ahora todos lo saben, incluidos los que se cambian al lado tuyo.`,
 c:[
  {t:'Lo hablás en el vestuario, sin esconderte', ef:{lid:8, rep:5, moral:4, com:4}, r:'Se corta la incomodidad en dos días. Lo que no se habla es lo que se pudre.'},
  {t:'Invitás a comer a todo el plantel', ef:{moral:6, fanLove:4, lid:4, capital:-0.05}, r:'Funciona esa noche. La aritmética sigue ahí el lunes.'},
  {t:'No decís nada: es tu contrato', ef:{com:7, lid:-5, moral:-4}, r:'Tenés toda la razón. El vestuario no funciona con razones.'}
 ]},

{id:'k3', w:2, st:['ple','vet'], when:p=>p.age>=28 && p.ovr <= p.peakOvr-3,
 t:'Tu valor se derrumbó y te enteraste por una página web',
 d:p=>`Un sitio que actualiza precios te bajó a la mitad de lo que valías hace dos años. No es oficial, no decide nada, y lo lee todo el mundo.`,
 c:[
  {t:'Lo usás de combustible', ef:{forma:9, fis:-3, moral:5, value:4}, r:'Cerrás la temporada con números que obligan a corregirlo. Es una victoria diminuta y sabe bien.'},
  {t:'Aceptás que es más o menos cierto', ef:{com:8, moral:-4, wage:-6, contrato:2}, r:'Renegociás a la baja y jugás dos años más tranquilo. Muy poca gente hace esto.'},
  {t:'Cambiás de representante', ef:{value:3, rep:-3, moral:3, hype:4}, r:'El nuevo mueve el mercado y consigue una oferta. También se lleva un porcentaje más alto.'}
 ]},

{id:'k4', w:2, st:['asc','ple'], when:p=>p.contract>=4 && p.age<=26,
 t:'Te ata un contrato muy largo',
 d:p=>`Firmaste seis años cuando eras una promesa. Ahora valés el triple y te quedan cuatro, con un sueldo de entonces y una cláusula que asusta a cualquiera.`,
 c:[
  {t:'Pedís renegociar', ef:{wage:20, mgrRel:-6, fanLove:-5, com:3}, r:'Te lo mejoran para que no se hable más del tema. Alguien en el club te lo va a recordar.'},
  {t:'Lo cumplís sin quejarte', ef:{fanLove:12, lid:6, mgrRel:8, wage:-2}, r:'Cuatro años cobrando menos de lo que valés. Te ganás algo que no se cobra.'},
  {t:'Pedís que le bajen la cláusula', ef:{com:6, value:-4, moral:5, mgrRel:-4}, r:'Aceptan, y con eso comprás la llave de tu propia puerta.'}
 ]}

];
EVENTS.push(...EVENTS8);

const EVENTS9 = [

{id:'ca1', w:2, st:['ple','vet'], when:p=>(p.capital||0)>=6 && p.age>=26,
 t:'Te ofrecen entrar en un negocio',
 d:p=>`Un excompañero monta una cadena de canchas de fútbol cinco y te ofrece la mitad. Los números cierran en el papel. Los papeles siempre cierran.`,
 c:[
  {t:'Ponés una parte y te quedás afuera de la gestión', ef:{capital:-3, com:4, moral:3},
   r:'Rinde despacio y no te ocupa la cabeza, que era exactamente lo que querías.'},
  {t:'Ponés fuerte y te metés a manejarlo', ef:{capital:-6, hype:5, fitness:-6, forma:-4},
   r:'Funciona. También descubrís que dirigir un negocio en temporada se paga con entrenamientos.'},
  {t:'No: tu trabajo es jugar', ef:{moral:4, rit:2},
   r:'Se lo decís sin vueltas. Dos años después el negocio cerró y vos seguías jugando.'}
 ]},

{id:'ca2', w:2, st:['asc','ple'], when:p=>(p.capital||0)>=2.5,
 t:'Tu familia todavía vive donde vos vivías',
 d:p=>`Tenés lo suficiente para sacarlos del barrio. Nadie te lo pidió: tu vieja dice que está bien ahí y que no gastes.`,
 c:[
  {t:'Les comprás la casa igual', ef:{capital:-2.5, moral:12, fanLove:6, lid:3},
   r:'Discuten una semana y se mudan. La primera noche te llama para decir que se escucha el silencio.'},
  {t:'Les arreglás la de siempre', ef:{capital:-0.8, moral:8, com:3},
   r:'Techo, calefacción y una cocina nueva. Se quedan donde son ellos, que era el punto.'},
  {t:'Guardás todo: la carrera es corta', ef:{com:6, moral:-4},
   r:'Tenés razón en el número y vas a pensar en esto más de una noche.'}
 ]},

{id:'ca3', w:1, st:['vet','oca'], when:p=>(p.capital||0)>=10 && p.age>=30,
 t:'Un asesor te promete el doble',
 d:p=>`Traje impecable, oficina impecable, rentabilidad impecable. Dos compañeros ya pusieron. Te muestra la carpeta y no te deja llevártela.`,
 c:[
  {t:'Ponés una parte de lo que tenés', ef:{capital:-4, com:7},
   r:'A los ocho meses la oficina no existe y el teléfono tampoco. Nunca más vas a firmar algo que no te dejen leer en tu casa.'},
  {t:'Se lo das a leer a un abogado tuyo', ef:{capital:-0.3, com:8, lid:3},
   r:'El abogado tarda una tarde en encontrarlo. Trescientos mil dólares de honorarios que valieron cuatro millones.'},
  {t:'No firmás nada que no te dejen llevar', ef:{com:6, moral:3},
   r:'Es la regla más simple del dinero y casi nadie la cumple. Vos sí.'}
 ]},

{id:'ca4', w:2, st:['vet','oca'], when:p=>(p.capital||0)>=4 && p.age>=31 && lejosDeCasa(p),
 t:'Podés elegir sin mirar el sueldo',
 d:p=>`Juntaste lo suficiente para que el dinero deje de decidir por vos. Es la primera vez en tu vida que eso pasa, y llega justo cuando quedan pocos años.`,
 c:[
  {t:'Volvés al club donde te hiciste, cobrando poco', ofr:{t:'casa',cuando:'ya'},
   ef:{capital:-1.5, fanLove:22, moral:14, hype:6, wage:-45},
   r:'La presentación llena el estadio un martes. Hay gente llorando que no te conoce.'},
  {t:'Vas donde más se juega, aunque paguen menos', ef:{capital:-0.8, rit:3, reg:2, moral:8}, ofr:{t:'chico', cuando:'ya'},
   r:'Dos temporadas jugando de verdad en lugar de cobrar por entrenar.'},
  {t:'Cobrás lo máximo mientras dure', ef:{capital:3, fanLove:-8, moral:-3},
   r:'Nadie te lo puede reprochar y varios te lo van a reprochar igual.'}
 ]}

];
EVENTS.push(...EVENTS9);


const EVENTS10 = [

{id:'t1', w:3, st:['ini'],
 t:'El Mundial, en el comedor de la pensión',
 d:p=>`Hay un solo televisor y treinta pibes. Juega tu país y el técnico del club dijo que mañana se entrena igual, a las siete.`,
 c:[
  {t:'Lo mirás entero y bancás el entrenamiento', ef:{moral:12, forma:-4, fis:-3, mgrRel:-4},
   r:'Dormís cuatro horas y al otro día no podés con las piernas. Te acordás del partido toda la vida.'},
  {t:'Te vas a dormir en el entretiempo', ef:{fis:3, mgrRel:6, moral:-6, trait:'profesional'},
   r:'Te enterás del resultado en el desayuno. El técnico se entera de que te fuiste a dormir, y eso también cuenta.'},
  {t:'Lo mirás anotando lo que hace el que juega en tu puesto', ef:{reg:2, pas:2, com:3, forma:-2},
   r:'Llenás dos hojas. Tres de esas anotaciones te las vas a robar para siempre.'}
 ]},

{id:'t2', w:2, st:['ini'],
 t:'Se retira el ídolo de tu infancia',
 d:p=>`El tipo de los pósters que tenías pegados anuncia que cuelga. Tenés ${p.age} y estás empezando lo que él termina.`,
 c:[
  {t:'Le escribís una carta y se la mandás al club', ef:{moral:10, lid:3, hype:4},
   r:'Nunca contesta. Dos años después, en una entrevista, la nombra sin decir tu nombre.'},
  {t:'Te ponés su número en la espalda', ef:{hype:8, moral:6, com:-3},
   r:'La comparación te va a perseguir en cada nota mala. También te va a abrir puertas.'},
  {t:'Nada: hay que hacerse el propio', ef:{com:6, forma:4, moral:-3},
   r:'No decís una palabra. Guardás el póster igual, en un cajón.'}
 ]},

{id:'t3', w:2, st:['ini'],
 t:'El traspaso más caro de la historia',
 d:p=>`Un club paga una cifra que nadie entiende por un jugador de veintidós. En el vestuario de reserva no se habla de otra cosa.`,
 c:[
  {t:'Te obsesionás con llegar a eso', ef:{hype:10, forma:6, moral:-5, com:-4},
   r:'Entrenás mirando un número. Vas a jugar mejor y a disfrutar menos.'},
  {t:'Le preguntás al utilero cuánto ganaba él a tu edad', ef:{com:7, lid:4, moral:4},
   r:'Te cuenta una historia de 1994 que te ordena la cabeza más que cualquier charla técnica.'},
  {t:'Te da igual: falta demasiado', ef:{forma:5, fis:3, hype:-5},
   r:'Seguís a lo tuyo. Nadie escribe notas sobre vos, que a los diecisiete es una ventaja.'}
 ]},

{id:'t4', w:1, st:['ini'],
 t:'Entrenás una mañana con el primer equipo',
 d:p=>`Falta gente por la fecha de selecciones y suben a tres de reserva. Uno sos vos. El capitán te da la mano y te dice tu nombre bien.`,
 c:[
  {t:'Jugás como si fuera una final', tira:'com', mas:-2, ef:{hype:8},
   bien:{ef:{moral:16, mgrRel:14, rep:6, reg:2, flag:'promesa'}, r:'Le ganás dos pelotas al que juega los domingos. El técnico pregunta tu nombre a la tarde.'},
   mal:{ef:{moral:-12, mgrRel:-8, forma:-6}, r:'Los nervios te comen. Tocás cuatro pelotas en dos horas y ninguna hacia adelante.'}},
  {t:'Jugás sencillo y no te equivocás', ef:{com:6, mgrRel:8, pas:2, hype:-4},
   r:'Nadie se acuerda de vos esa tarde. Tampoco nadie tiene nada malo que decir, que a esa edad es media victoria.'},
  {t:'Buscás la jugada de la semana', ef:{reg:3, hype:12, mgrRel:-10, moral:5},
   r:'Un caño en la mitad de la cancha. La cara del capitán te la vas a acordar más que el caño.'}
 ]},

{id:'t5', w:1, st:['ini'], req:'promesa',
 t:'Te sientan en el banco de primera',
 d:p=>`Domingo, estadio lleno, y tu nombre en la lista. No vas a entrar, pero estás. Tu viejo llora en la platea y vos lo ves desde el banco.`,
 c:[
  {t:'Calentás toda la segunda mitad por si acaso', ef:{fis:2, mgrRel:6, moral:10},
   r:'No entrás. El técnico te agradece igual: vio que estabas listo desde el minuto sesenta.'},
  {t:'Mirás el partido y aprendés dónde se para tu puesto', ef:{def:2, pas:2, com:5, moral:6},
   r:'Noventa minutos estudiando al que te tapa el camino. Volvés con dos cosas que nadie te enseñó.'},
  {t:'Te sacás fotos con el estadio de fondo', ef:{hype:10, moral:8, mgrRel:-6},
   r:'La foto la ven cuarenta mil personas. El cuerpo técnico la ve también.'}
 ]},

{id:'t6', w:3, st:['ini'],
 t:'El colectivo de las cinco de la mañana',
 d:p=>`Dos horas de viaje para entrenar y dos para volver. Un compañero del barrio te ofrece llevarte en moto: media hora, sin casco.`,
 c:[
  {t:'Seguís con el colectivo', ef:{fis:-3, com:6, moral:-4, trait:'profesional'},
   r:'Cuatro horas por día durante dos años. Nadie te lo va a reconocer nunca y a vos te ordenó la vida.'},
  {t:'Vas en moto y ganás tres horas de sueño', ef:{fis:4, forma:5, moral:6},
   r:'Dormís como no dormías hace meses. Una noche de lluvia pensás en lo que estás haciendo.'},
  {t:'Pedís al club que te consiga pensión', ef:{moral:-6, mgrRel:-5, fis:5, com:3},
   r:'Te dan una cama en una casa con otros seis. Extrañás mucho y entrenás mejor.'}
 ]},

{id:'t7', w:3, st:['ini'],
 t:'Tu primer sueldo de verdad',
 d:p=>`No es plata de futbolista todavía, pero es más de lo que gana tu viejo en el taller. Te lo depositan un jueves.`,
 c:[
  {t:'Se lo das entero a tu vieja', todo:true, ef:{capital:-0.05, moral:14, fanLove:4, lid:3},
   r:'Lo rechaza dos veces y lo acepta a la tercera. Esa noche cenan afuera por primera vez en años.'},
  {t:'Lo guardás sin tocarlo', ef:{capital:0.06, com:5, moral:-3},
   r:'Abrís una caja de ahorro y no la mirás en un año. Vas a agradecértelo a los treinta.'},
  {t:'Te comprás los botines que querías', todo:true, ef:{capital:-0.01, moral:10, forma:4, hype:3},
   r:'Los estrenás un martes de lluvia y hacés dos goles. No es casualidad y tampoco son los botines.'}
 ]},

{id:'t8', w:2, st:['ini'],
 t:'Un representante te espera afuera del entrenamiento',
 d:p=>`Tenés ${p.age}. Te dice que te vio, que le gustás, y que si firmás con él te lleva a ${enLigaEuropea(p) ? 'un club grande' : 'Europa'} en dos años. Tiene una tarjeta y un auto grande.`,
 c:[
  {t:'Firmás ahí mismo', ef:{hype:12, moral:8, com:-6, flag:'agente'},
   r:'No leés nada. En cuatro años te va a costar caro salir de ese papel.'},
  {t:'Le decís que hable con tus viejos', ef:{com:8, lid:4, moral:3, flag:'agente'},
   r:'Va a tu casa un sábado. Tu vieja le hace tres preguntas que lo dejan mudo y firmás igual, pero mejor.'},
  {t:'No firmás con nadie todavía', ef:{com:6, hype:-8, moral:-4},
   r:'Se va molesto. Aparecen otros dos y podés elegir, que era exactamente el punto.'}
 ]},

{id:'t9', w:2, st:['ini'],
 t:'Te dicen que sos petiso para tu puesto',
 d:p=>`El informe del club dice que te faltan siete centímetros y que probablemente no los tengas nunca. Tenés ${p.age} y lo leés de casualidad.`,
 c:[
  {t:'Trabajás lo que sí depende de vos', ef:{reg:3, pas:3, rit:2, moral:-4},
   r:'Empezás a jugar a un toque porque no te queda otra. Terminás jugando mejor que los altos.'},
  {t:'Te obsesionás con el gimnasio', ef:{fis:5, aer:3, reg:-2, forma:-3},
   r:'Ganás cuatro kilos de músculo. Perdés medio segundo en los primeros cinco metros.'},
  {t:'Se lo discutís al que hizo el informe', ef:{lid:5, com:-4, mgrRel:-8, moral:6},
   r:'No cambia nada del informe. Cambia que a partir de ahí te miran los partidos.'}
 ]},

{id:'t10', w:2, st:['ini'],
 t:'El compañero que juega mejor que vos',
 d:p=>`Hay uno en tu categoría que hace todo antes y mejor. Todos lo saben, incluido él. Van a subir a uno solo.`,
 c:[
  {t:'Te hacés amigo y le copiás todo', ef:{reg:3, pas:2, com:5, moral:6},
   r:'Aprendés más en seis meses que en tres años. Suben a él y a vos te suben al año siguiente.'},
  {t:'Entrenás a escondidas para pasarlo', ef:{fis:4, reg:2, forma:6, moral:-6},
   r:'Ganás terreno de verdad. También te ponés muy solo, que a los dieciséis pesa.'},
  {t:'Aceptás que él es mejor y jugás a lo tuyo', ef:{com:7, lid:4, moral:4, hype:-5},
   r:'Dejás de compararte. Diez años después él dejó y vos seguís.'}
 ]},

{id:'t11', w:2, st:['ini'],
 t:'La primera lesión que da miedo',
 d:p=>`Un tirón raro en el aductor y el médico del club dice tres semanas. Nunca estuviste tres semanas sin jugar desde que tenés memoria.`,
 c:[
  {t:'Respetás los plazos al día', ef:{fis:4, fitness:10, moral:-6, trait:'profesional'},
   r:'Volvés entero. Aprendés que el cuerpo avisa y que hay que escucharlo, lección que muchos no aprenden nunca.'},
  {t:'Volvés a los diez días para el partido importante', ef:{forma:8, moral:8, fitness:-14, trait:'cristal'},
   r:'Jugás y jugás bien. El aductor te va a acompañar quejándose durante años.'},
  {t:'Aprovechás para hacer gimnasio de todo lo demás', ef:{fis:5, aer:3, fitness:4, forma:-5},
   r:'Volvés más fuerte de lo que te fuiste, y una semana más tarde de lo previsto.'}
 ]},

{id:'t12', w:2, st:['ini'],
 t:'Te cambian de puesto sin preguntarte',
 d:p=>`El técnico de la categoría decide que jugás de otra cosa. Dice que es donde el club te necesita y que ya está hablado.`,
 c:[
  {t:'Lo aceptás y aprendés el puesto nuevo', ef:{special:'reposicion', def:3, pas:3, com:5, moral:-5},
   r:'Seis meses incómodos. Terminás entendiendo el juego desde un lugar que la mayoría no ve nunca.'},
  {t:'Pedís volver al tuyo, con argumentos', ef:{lid:5, com:4, mgrRel:-8, moral:6},
   r:'Te escuchan a medias: volvés después de tres meses. Te ganaste que te consulten la próxima.'},
  {t:'Te plantás: no jugás fuera de tu puesto', ef:{moral:6, mgrRel:-16, forma:-8, hype:-4, lid:5},
   r:'Te devuelven a tu puesto en seis semanas porque no les queda otra. También queda escrito en un informe que alguien va a leer en cuatro años.'}
 ]},

{id:'t13', w:3, st:['asc'],
 t:'La primera nota con tu nombre en el título',
 d:p=>`Un diario te pone en tapa de la sección deportes. Tu vieja compra cinco ejemplares. En el vestuario te lo dejan pegado en el locker, con un bigote dibujado.`,
 c:[
  {t:'Te lo tomás a risa y pagás el asado', ef:{lid:6, mgrRel:8, moral:8, capital:-0.08},
   r:'Se ríen con vos y no de vos, que es una diferencia que dura años.'},
  {t:'Lo guardás y no decís nada', ef:{com:6, moral:4, hype:-4},
   r:'Está en un cajón de tu casa. Lo vas a mirar una noche mala dentro de mucho tiempo.'},
  {t:'Empezás a hablar más con periodistas', ef:{hype:14, rep:4, mgrRel:-6, forma:-3},
   r:'Te vuelven a llamar. Empezás a construir una imagen antes de tener una carrera.'}
 ]},

{id:'t14', w:3, st:['asc'],
 t:'Un grande manda a alguien a verte',
 d:p=>`Hay un tipo con carpeta en la tribuna vacía de un martes. No viene por el equipo: viene por vos, y tu club lo sabe.`,
 c:[
  {t:'Jugás para la carpeta', tira:'com', mas:-3, ef:{hype:10},
   bien:{ef:{rep:8, value:14, moral:10, hype:6}, r:'Dos asistencias y un partido completo. La carpeta se llena.'},
   mal:{ef:{moral:-10, hype:-6, forma:-5}, r:'Querés hacer de más y hacés de menos. El tipo se va en el minuto setenta.'}},
  {t:'Jugás tu partido y listo', ef:{com:7, forma:5, rep:3},
   r:'Hacés lo de siempre, que es bastante. Vuelve tres veces más antes de decidir.'},
  {t:'Le preguntás al capitán cómo se maneja esto', ef:{lid:4, com:6, mgrRel:6, moral:4},
   r:'Te dice tres frases que valen un curso. La primera es que los ojeadores vuelven.'}
 ]},

{id:'t15', w:2, st:['asc'],
 t:'Te ofrecen tu primer contrato profesional',
 d:p=>`Cuatro años, sueldo de verdad y una cláusula que no entendés. El club dice que es lo estándar y que hay que firmar el lunes.`,
 c:[
  {t:'Firmás lo que te ponen', ef:{contrato:4, moral:8, wage:10, com:-4},
   r:'Es más plata de la que viste junta. La cláusula la vas a entender cuando te moleste.'},
  {t:'Lo llevás a un abogado antes del lunes', ef:{contrato:4, com:8, wage:4, mgrRel:-6, capital:-0.05},
   r:'Se firma el jueves con dos cambios. El club te mira distinto: no mal, distinto.'},
  {t:'Pedís que te bajen la cláusula en vez de subir el sueldo', ef:{contrato:4, com:6, value:-4, moral:5},
   r:'Aceptan sin pensarlo. Acabás de comprar la llave de tu propia puerta.'}
 ]},

{id:'t16', w:2, st:['asc'],
 t:'El técnico que te subió se va',
 d:p=>`El que te hizo debutar firma en otro club y se lleva a dos del plantel. A vos no te llama.`,
 c:[
  {t:'Le preguntás de frente por qué no', ef:{com:7, lid:5, moral:-6, mgrRel:4},
   r:'Te dice la verdad: le pediste demasiado poco al club para negociarte. Duele y sirve.'},
  {t:'Te concentrás en convencer al que viene', ef:{forma:8, mgrRel:10, fis:2, moral:-3},
   r:'Empezás de cero con el nuevo. A los dos meses sos titular otra vez.'},
  {t:'Lo tomás como una traición y lo decís', ef:{hype:8, moral:6, rep:-5, mgrRel:-10, trait:'polemico'},
   r:'Te dan la razón por dos días. Después el fútbol sigue y vos quedaste marcado.'}
 ]},

{id:'t17', w:2, st:['asc'],
 t:'Tu club vende a la figura y te ponen a vos',
 d:p=>`Se fue el que hacía la diferencia y el club decide no reemplazarlo: la camiseta es tuya. La hinchada no está convencida.`,
 c:[
  {t:'Aceptás la responsabilidad en público', ef:{lid:8, hype:10, moral:8, forma:-4, fanLove:8},
   r:'Lo decís en una entrevista y no hay marcha atrás. La primera fecha te silban y la quinta te cantan.'},
  {t:'Trabajás en silencio y que hablen los partidos', ef:{forma:9, com:6, fis:2, hype:-6},
   r:'Tardan tres meses en aceptarte. Cuando lo hacen, es para siempre.'},
  {t:'Pedís que traigan a alguien: no querés esa mochila', ef:{moral:6, mgrRel:-8, rep:-5, fanLove:-10},
   r:'Traen a un veterano y compartís el peso. También compartís los minutos.'}
 ]},

{id:'t18', w:2, st:['asc'],
 t:'La barra te espera en la puerta',
 d:p=>`Tres tipos que no conocés te felicitan por el partido y te piden entradas para todas las fechas. Lo dicen amable. No es una pregunta.`,
 c:[
  {t:'Se las das para que no haya problema', ef:{moral:-8, com:-4, fanLove:6, capital:-0.1},
   r:'Vuelven cada quince días y piden un poco más. Aprendiste cómo empieza.'},
  {t:'Les decís que no y avisás al club', ef:{com:8, lid:6, moral:-5, fanLove:-8},
   r:'El club manda seguridad a tu casa una semana. No vuelven a aparecer y vos no dormís bien un tiempo.'},
  {t:'Se lo contás al capitán antes que a nadie', ef:{lid:5, com:6, mgrRel:6, moral:4},
   r:'Lo resuelve en una charla de dos minutos con alguien. No preguntás cómo.'}
 ]},

{id:'t19', w:2, st:['asc'],
 t:'Te llaman de la selección juvenil',
 d:p=>`Un torneo de tres semanas del otro lado del mundo, justo cuando en el club te estabas ganando el puesto. El club prefiere que no vayas.`,
 c:[
  {t:'Vas igual: es tu país', ef:{rep:10, hype:8, mgrRel:-12, moral:12},
   r:'Volvés con una medalla y sin el puesto. Tardás dos meses en recuperarlo y no te arrepentís.'},
  {t:'Te quedás y consolidás el puesto', ef:{forma:8, mgrRel:12, moral:-8, rep:-5},
   r:'Jugás las seis fechas. En la selección entra otro y no vuelve a salir.'},
  {t:'Negociás ir sólo a la fase final', ef:{com:8, lid:4, rep:4, mgrRel:-4},
   r:'Nadie queda del todo contento y todos quedan un poco. Vas diez días.'}
 ]},

{id:'t20', w:2, st:['asc'],
 t:'Un club de afuera te quiere ya',
 d:p=>`Te llega una oferta de un club chico de una liga grande. Menos hinchada, menos ruido, mejor fútbol y un idioma que no hablás.`,
 c:[
  {t:'Vas: es el salto', ofr:{t:'europa',cuando:'ventana'}, ef:{hype:8, moral:6, com:4},
   r:'Se abre la puerta para el mercado. Vas a aterrizar solo en una ciudad con lluvia.'},
  {t:'Te quedás un año más a jugar todo', ef:{forma:8, fanLove:10, rep:4, hype:-6},
   r:'Jugás cincuenta partidos. Al año siguiente vale el doble y elegís mejor.'},
  {t:'Pedís que te dejen ir sólo si es titular', ef:{com:7, lid:4, moral:4, hype:-3},
   r:'La condición los enfría. Te ganaste el respeto de tu propio representante.'}
 ]},

{id:'t21', w:2, st:['asc'],
 t:'Un compañero te pide que lo cubras',
 d:p=>`Llegó tarde tres veces esta semana y el técnico pregunta si estaba en el gimnasio. Te mira a vos.`,
 c:[
  {t:'Lo cubrís', ef:{lid:4, com:-5, mgrRel:-6, moral:-4},
   r:'Se salva. Dos meses después hace lo mismo con otro y ese otro no lo cubre.'},
  {t:'No mentís, pero no lo entregás', ef:{com:8, lid:6, mgrRel:4, moral:3},
   r:'Decís que no sabés. Es cierto y alcanza. Él te lo agradece igual.'},
  {t:'Se lo decís a él, no al técnico', ef:{lid:8, com:6, moral:5, mgrRel:-3},
   r:'Lo encarás en el vestuario. Se pudre por dos días y después entrena como no entrenaba hace un año.'}
 ]},

{id:'t22', w:2, st:['asc'],
 t:'Tu viejo quiere manejarte la carrera',
 d:p=>`Dejó el trabajo y dice que te va a representar él, que nadie te va a cuidar como él. No sabe de contratos y lo sabe.`,
 c:[
  {t:'Le decís que sí', ef:{moral:10, fanLove:4, com:-6, capital:-0.15, flag:'padre'},
   r:'Firma cosas que no entiende con gente que sí. Te cuesta plata y no te cuesta el vínculo.'},
  {t:'Le decís que no, y le explicás por qué', ef:{com:8, lid:6, moral:-10},
   r:'La conversación más difícil de tu vida hasta ahora. Se lo banca. Tardan un año en volver a hablar de fútbol.'},
  {t:'Lo ponés a trabajar con un profesional', ef:{com:6, moral:6, capital:-0.15, lid:3},
   r:'Aprende de a poco y opina donde tiene que opinar. Es la solución cara y la que funciona.'}
 ]},

{id:'t23', w:2, st:['oca','vet'],
 t:'Ya no te reconocen en la calle',
 d:p=>`Pasás por donde te paraban veinte personas y no te para nadie. No es hostilidad: es que no te ven.`,
 c:[
  {t:'Te da alivio y lo decís', ef:{moral:10, com:6, hype:-8},
   r:'Descubrís que extrañabas caminar. Vas a volver a esa vereda muchas veces.'},
  {t:'Te duele más de lo que esperabas', ef:{moral:-10, forma:-4, lid:4},
   r:'Te sorprende cuánto pesa. Te obliga a preguntarte quién sos sin la camiseta, que es la pregunta.'},
  {t:'Buscás la manera de volver a estar', ef:{hype:14, forma:-5, moral:-4, com:-4},
   r:'Aceptás dos programas de televisión y una entrevista larga. Volvés a existir un mes.'}
 ]},

{id:'t24', w:2, st:['oca','vet'],
 t:'Te ofrecen un puesto en la comisión directiva',
 d:p=>`El club te ofrece un cargo para cuando termines. Reuniones, presupuestos y política. Nada que ver con jugar.`,
 c:[
  {t:'Aceptás para después del retiro', ef:{com:8, lid:8, moral:8, rep:5},
   r:'Sabés qué viene después y eso te saca un peso. Jugás el último tramo más liviano.'},
  {t:'Decís que no: querés seguir cerca de la cancha', ef:{lid:6, moral:6, rep:-3},
   r:'Preferís el campo al escritorio. Te vas a ofrecer de ayudante de campo en dos años.'},
  {t:'Pedís tiempo y no contestás', ef:{com:5, moral:-5, mgrRel:-4},
   r:'La oferta se enfría sola. En el club queda la sensación de que no te interesa el club.'}
 ]},

{id:'t25', w:2, st:['oca'],
 t:'El chico que ocupa tu lugar te pide consejo',
 d:p=>`Tiene diecinueve, juega en tu puesto y el técnico lo prefiere a él. Te espera en el estacionamiento para preguntarte algo.`,
 c:[
  {t:'Le contás todo lo que sabés', ef:{lid:10, mgrRel:8, moral:8, forma:-3, flag:'mentor'},
   r:'Le das en veinte minutos lo que a vos te costó diez años. Va a hablar de vos toda su carrera.'},
  {t:'Le decís dos cosas y te guardás el resto', ef:{com:6, lid:3, moral:2},
   r:'Le sirve igual. Vos te quedás con algo que no sabés bien para qué guardás.'},
  {t:'Le decís que se lo gane como te lo ganaste vos', ef:{moral:5, com:4, mgrRel:-8, lid:-5},
   r:'Se lo gana igual, sin vos. Es la respuesta que más se dice y la que menos se recuerda bien.'}
 ]},

{id:'t26', w:2, st:['oca'],
 t:'Tu último clásico',
 d:p=>`Sabés que es el último que jugás. No lo dijiste, pero lo sabés. La semana entera se siente distinta.`,
 c:[
  {t:'Lo jugás como si fuera el primero', tira:'fis', mas:-10, ef:{hype:10},
   bien:{ef:{moral:20, fanLove:24, rep:8, lid:6}, r:'Corrés como no corrías hace dos años y ganan. Te sacan en hombros de un partido que no era una final.'},
   mal:{ef:{moral:-14, fanLove:-8, forma:-8}, r:'Las piernas no acompañan la cabeza. Te sacan a los sesenta y aplauden igual, que es peor.'}},
  {t:'Lo jugás sin épica, ordenado', ef:{com:8, def:2, mgrRel:6, moral:4},
   r:'Cumplís. Nadie escribe sobre vos y el equipo no pierde por tu lado.'},
  {t:'Se lo contás al vestuario antes del partido', ef:{lid:10, moral:12, fanLove:10, forma:-4},
   r:'Salen a jugar por vos. Es la clase de cosa que un vestuario no olvida.'}
 ]},

{id:'t27', w:2, st:['oca','vet'],
 t:'Tu cuerpo tarda tres días en recuperarse',
 d:p=>`Antes jugabas miércoles y domingo sin pensarlo. Ahora el martes todavía te duele el domingo anterior.`,
 c:[
  {t:'Hablás con el club y armás un plan de cargas', ef:{fitness:12, fis:3, com:6, forma:-4},
   r:'Jugás treinta partidos en vez de cuarenta y llegás entero a todos.'},
  {t:'Te lo callás y jugás todo', ef:{forma:6, moral:6, fitness:-16, trait:'cristal'},
   r:'Nadie se entera hasta que el cuerpo lo anuncia solo, en el peor momento posible.'},
  {t:'Cambiás de manera de jugar', ef:{pas:3, com:7, lid:4, rit:-3},
   r:'Empezás a correr diez metros menos y a llegar dos segundos antes. Se llama oficio.'}
 ]},

{id:'t28', w:2, st:['vet','oca'],
 t:'Un club de tu país te quiere para la despedida',
 d:p=>`No es tu club: es uno chico que te quiere para llenar el estadio y para que los pibes te vean de cerca un año.`,
 c:[
  {t:'Vas', ofr:{t:'chico',cuando:'ya'}, ef:{fanLove:18, moral:12, wage:-50, rep:-4, capital:-0.4},
   r:'Un año de canchas chicas y pibes mirándote atar los botines. No te va a dar puntos y te va a dar otra cosa.'},
  {t:'Preferís terminar donde estás', ef:{com:6, moral:4, fanLove:6},
   r:'Terminás en un vestuario que conocés. Hay algo de eso que también es dignidad.'},
  {t:'Escuchás y usás la oferta para renovar', ef:{contrato:2, wage:12, moral:3, fanLove:-8},
   r:'Te mejoran para retenerte. Funcionó y dejó un gusto raro.'}
 ]},

{id:'t29', w:1, st:['oca'],
 t:'Te piden que juegues un partido más, por otro',
 d:p=>`Un excompañero está enfermo y organizan un partido a beneficio. Ya te habías despedido. Faltan dos meses y no entrenás.`,
 c:[
  {t:'Jugás, aunque no estés para eso', ef:{fanLove:20, moral:16, lid:8, fitness:-10, capital:-0.2},
   r:'Jugás cuarenta minutos y no podés casi. Se llena el estadio y se recauda lo que hacía falta.'},
  {t:'No jugás pero ponés la plata', ef:{capital:-1.2, moral:10, com:5, hype:-4},
   r:'Nadie se entera excepto él. Es probablemente la decisión más adulta de tu carrera.'},
  {t:'Organizás vos el partido sin jugarlo', ef:{lid:12, rep:6, moral:12, fanLove:14},
   r:'Conseguís a veinte que sí pueden jugar. Se recauda el triple de lo previsto.'}
 ]},

{id:'t30', w:2, st:['oca'],
 t:'El último día en el vestuario',
 d:p=>`Está todo guardado en un bolso. Quedan el utilero, vos y una hilera de perchas vacías.`,
 c:[
  {t:'Te quedás un rato largo, solo', ef:{moral:12, com:8, lid:4},
   r:'Cuarenta minutos sentado donde te sentaste mil veces. Nadie te apura. Es tuyo.'},
  {t:'Le dejás algo tuyo al utilero', ef:{fanLove:12, lid:6, moral:10},
   r:'La camiseta del primer partido, firmada. La cuelga detrás de la puerta y sigue ahí veinte años después.'},
  {t:'Te vas rápido, sin ceremonia', ef:{com:9, moral:-4, fanLove:-4},
   r:'Salís por la puerta de siempre, saludás con la mano y arrancás el auto. Cada uno se despide como puede.'}
 ]}

];
EVENTS.push(...EVENTS10);

const EVENTS11 = [

{id:'nw1', w:3, st:['ini'], when:p=>p.age<=18,
 t:'Botines negros por reglamento',
 d:p=>`El técnico de la cantera de ${C(p.club).n} prohíbe los botines de colores en juveniles. Llegás con unos amarillo flúor que te regaló tu viejo, y te los mira fijo.`,
 c:[
  {t:'Los pintás de negro con fibra en el vestuario', ef:{com:4, mgrRel:6, moral:-4}, r:'Quedan grises y manchados. Tu viejo te pregunta por los botines el sábado y le decís que están en el club.'},
  {t:'Jugás igual con los de color', ef:{hype:6, mgrRel:-10, forma:-5, trait:'polemico'}, r:'Te manda a trotar alrededor de la cancha los noventa minutos. Desde el alambrado, tu viejo mira los botines.'},
  {t:'Pedís unos prestados a un compañero', ef:{lid:3, mgrRel:4, fis:-2}, r:'Te quedan dos números chicos. Terminás con las dos ampollas reventadas y cumpliendo el reglamento.'} ]},

{id:'nw2', w:3, st:['ini'], when:p=>p.age<=19,
 t:'El alcanzapelotas del clásico',
 d:p=>`No estás convocado, pero te piden que seas alcanzapelotas en el clásico. Minuto 89, van empatando, y la pelota sale por tu banda.`,
 c:[
  {t:'Se la das rápido a tu delantero', ef:{fanLove:8, mgrRel:6, hype:5, moral:-2}, r:'De ese saque sale el gol. Nadie te nombra en ninguna crónica y vos sabés de dónde salió.'},
  {t:'Escondés la pelota para hacer tiempo', ef:{fanLove:10, moral:4, rep:-4, mgrRel:-4, trait:'polemico'}, r:'El banco rival te insulta por tu nombre, que alguien les pasó. Aprendés que te lo van a recordar.'},
  {t:'Se la alcanzás al rival sin problema', ef:{com:5, rep:3, fanLove:-6, mgrRel:-4}, r:'El rival mete el centro y casi les cuesta el partido. Tu técnico no te habla en dos semanas.'} ]},

{id:'nw3', w:2, st:['ini'], when:p=>p.age<=19,
 t:'El micro de las tres de la mañana',
 d:p=>`Diez horas de viaje para jugar en una cancha de barro. Se rompe la calefacción del micro y afuera hay tres grados bajo cero.`,
 c:[
  {t:'Le prestás tu campera a un chico lesionado', ef:{lid:6, moral:8, fis:-3, fitness:-4}, r:'Llegás tiritando y jugás mal los primeros veinte minutos. Él no se olvida y vos tampoco.'},
  {t:'Te dormís tapado con los bolsos', ef:{fis:2, forma:4, lid:-3}, r:'Bajás entero. También bajás siendo el único que durmió mientras el resto se cagaba de frío.'},
  {t:'Te quejás con el delegado', ef:{lid:2, mgrRel:-6, moral:-4, hype:-2}, r:'Anota tu apellido en una libreta. En inferiores las quejas se pagan tres meses después, sin aviso.'} ]},

{id:'nw4', w:2, st:['ini'], when:p=>p.age<=18,
 t:'La foto en el diario del barrio',
 d:p=>`Un diario local saca una foto tuya festejando en quinta y titula: «El pibe que vale millones». Tu viejo compra diez ejemplares.`,
 c:[
  {t:'Le firmás una para el canillita', ef:{fanLove:8, rep:2, hype:-3}, r:'La cuelga en el kiosco. Durante dos años, cada vez que pasás, te grita el resultado del domingo.'},
  {t:'La pegás en la heladera de tu casa', ef:{moral:8, com:2, hype:-4}, r:'La mirás todas las mañanas. En marzo, cuando no jugás un minuto, la das vuelta.'},
  {t:'Te la creés y la subís con un mensaje soberbio', ef:{hype:12, mgrRel:-8, moral:-3, trait:'polemico'}, r:'El capitán del primer equipo te la muestra impresa en la práctica. No se ríe: la deja en tu banco y se va.'} ]},

{id:'nw5', w:3, st:['ini','asc'], when:p=>p.age<=20,
 t:'Entrenamiento sobre nieve',
 d:p=>`Amanece el predio tapado. El preparador suspende la pelota y arma una sesión de fuerza en la colina.`,
 c:[
  {t:'Encabezás todas las pasadas', ef:{fis:4, rit:2, mgrRel:6, fitness:-6}, r:'Ganás todas y vomitás en la última. El martes no podés bajar la escalera del micro.'},
  {t:'Vas tranquilo para cuidar las rodillas', ef:{fitness:6, fis:1, mgrRel:-5, moral:-3}, r:'El preparador anota «intensidad» al lado de tu apellido. Esa palabra viaja hasta el cuerpo técnico de arriba.'},
  {t:'Armás una guerra de bolas de nieve', ef:{moral:10, fanLove:4, mgrRel:-6, fis:-2}, r:'Veinte minutos de risas y una hora extra de abdominales para los treinta. Dos te lo agradecen y el resto no.'} ]},

{id:'nw6', w:2, st:['ini'], when:p=>p.age<=19,
 t:'El primer auspiciante',
 d:p=>`Una marca local de suplementos te ofrece 500 dólares y productos gratis por tres fotos al mes. Tu representante te pide que no firmes todavía.`,
 c:[
  {t:'Firmás igual: necesitás la plata', ef:{capital:0.01, hype:6, rep:-2, mgrRel:-6}, r:'Comprás ropa para tu familia. El club te llama para explicarte qué es una marca no autorizada y quién decide eso.'},
  {t:'Le hacés caso a tu representante', ef:{com:4, rep:3, moral:-4}, r:'Seis meses sin cobrar un peso, mirando cómo dos compañeros estrenan zapatillas. En abril llama una marca internacional.'},
  {t:'Pedís que donen productos a la cantera', todo:true, ef:{fanLove:10, lid:6, capital:-0.01}, r:'La marca acepta y te baja el contrato a la mitad. Los de reserva se enteran de lo primero y nunca de lo segundo.'} ]},

{id:'nw7', w:2, st:['ini'], when:p=>p.age<=19,
 t:'El pelotazo al auto del presidente',
 d:p=>`Le pegás mal de zurda en una práctica de tiro. La pelota pasa el alambrado y rompe el parabrisas del auto del presidente.`,
 c:[
  {t:'Vas a su oficina a pedir disculpas', todo:true, ef:{com:6, mgrRel:8, capital:-0.01}, r:'Te escucha, te dice que no hace falta y te descuentan el parabrisas igual, en cuotas, de los viáticos.'},
  {t:'Culpás al delantero que pateó antes', ef:{moral:-6, mgrRel:-5, lid:-4, fanLove:-4}, r:'Lo desmiente el video de la cámara del portón. Te queda un apodo por dos temporadas.'},
  {t:'Te ofrecés a pagarlo con tus viáticos', todo:true, ef:{capital:-0.01, rep:4, fis:-2}, r:'Tres meses viajando en colectivo por un vidrio. La dirigencia se entera y no te lo dice nunca.'} ]},

{id:'nw8', w:2, st:['ini'], when:p=>p.age<=20,
 t:'El torneo nocturno de fútbol 5',
 d:p=>`Tus amigos del barrio te invitan a la final de un torneo nocturno. Hay 200 dólares en juego y el club lo tiene prohibido.`,
 c:[
  {t:'Jugás con capucha y gorra', ef:{moral:4}, tira:'reg', mas:-2,
   bien:{ef:{capital:0.2, reg:2, fitness:-4}, r:'Salen campeones y hacés tres. Volvés a las cuatro de la mañana y el martes corrés como si tuvieras cuarenta años.'},
   mal:{ef:{fitness:-12, mgrRel:-20, forma:-10}, r:'Te doblás el tobillo en una baldosa floja. El médico del club te lo ve el lunes y no te pregunta nada, que es peor.'},
   r:'Entrás a la cancha de cemento tapado hasta los ojos.'},
  {t:'Vas a mirar desde la tribuna', ef:{moral:6, fanLove:4, fis:-2}, r:'Volvés a la una de la mañana por acompañarlos. Nadie se entera y el martes te cuesta igual.'},
  {t:'Elegís no arriesgar la carrera y te quedás en casa', ef:{com:5, moral:-6, fanLove:-4, trait:'profesional'}, r:'Ganan sin vos y te mandan la foto a las dos de la mañana. Es la primera vez que el fútbol te saca algo.'} ]},

{id:'nw9', w:3, st:['ini','asc'], when:p=>p.age<=21,
 t:'El test de esfuerzo',
 d:p=>`Llega un cuerpo médico nuevo con aparatos modernos. Hacen el test de esfuerzo máximo y pegan los resultados en la puerta del vestuario.`,
 c:[
  {t:'Te exprimís hasta vomitar en la pista', ef:{fis:4, rit:2, mgrRel:8, fitness:-6}, r:'Primero en resistencia y dos días sin poder entrenar con pelota. Queda escrito lo primero.'},
  {t:'Hacés lo justo para quedar en la media', ef:{fitness:6, com:4, mgrRel:-5}, r:'Reservás para el domingo y jugás bien. Tu apellido queda pegado en la puerta, en el medio de la lista, donde no lo mira nadie.'},
  {t:'Cuestionás el método delante de los kinesiólogos', ef:{rep:3, mgrRel:-8, moral:-4, trait:'polemico'}, r:'Tenés parte de razón y elegiste el peor lugar para tenerla. Te miden todo el doble durante un año.'} ]},

{id:'nw10', w:2, st:['ini'], when:p=>p.age<=18,
 t:'La pensión sin agua caliente',
 d:p=>`Se rompe la caldera en pleno invierno. Llevan cuatro días bañándose con agua helada después de entrenar.`,
 c:[
  {t:'Organizás un reclamo con los chicos', ef:{lid:7, moral:6, mgrRel:-6}, r:'La arreglan al día siguiente. Quedás como el vocero de la pensión, que es un cargo que nadie quiere en la oficina de arriba.'},
  {t:'Te bañás en casa de un familiar', ef:{moral:4, com:2, lid:-4, fanLove:-2}, r:'Volvés seco y solo. Los otros cuatro se bañan con agua helada y aprenden a contarse cosas que a vos no te cuentan.'},
  {t:'Te la aguantás sin decir nada', ef:{fis:3, com:5, moral:-6, fitness:-4}, r:'Once días. Al octavo te agarrás una angina y jugás con fiebre el partido del sábado.'} ]},

{id:'nw11', w:3, st:['asc','ple'],
 t:'El asado de reconciliación',
 d:p=>`Después de dos derrotas duras y discusiones fuertes, el referente organiza un asado en su casa. El grupo está tenso.`,
 c:[
  {t:'Agarrás la guitarra y ponés música', ef:{moral:10, mgrRel:6, forma:-4}, r:'Terminan a las tres de la mañana. El jueves entrenan como en el barro y el sábado ganan igual.'},
  {t:'Te sentás a hablar de táctica con el capitán', ef:{pas:3, lid:5, mgrRel:5, moral:-4}, r:'Dos horas de servilletas con flechas. El resto los mira desde la parrilla y alguno dice que sos un plomo.'},
  {t:'Te despedís apenas terminás de comer', ef:{fitness:4, forma:4, moral:-4, lid:-4}, r:'Dormís nueve horas. El lunes el referente te saluda con la cabeza y no con la mano.'} ]},

{id:'nw12', w:2, st:['asc','ple','vet'],
 t:'El compañero con olor a alcohol',
 d:p=>`Un delantero titular llega a la práctica de la mañana con anteojos de sol y un olor que no deja dudas. El técnico todavía no salió.`,
 c:[
  {t:'Lo metés a la ducha fría y lo cubrís', ef:{lid:6, moral:4, mgrRel:-6, com:-3}, r:'Zafa por diez minutos. Te queda la sensación rara de haber tapado algo que va a volver a pasar.'},
  {t:'Le avisás al capitán', ef:{lid:5, mgrRel:4, moral:-3}, r:'Lo manda al gimnasio y habla con él a solas. Él sabe quién lo dijo y tarda un mes en volver a sentarse cerca tuyo.'},
  {t:'Dejás que el técnico lo descubra', ef:{mgrRel:6, moral:-8, fanLove:-4, lid:-5}, r:'Lo desafecta del partido y lo multa. El vestuario no dice nada y se acomoda distinto en el micro.'} ]},

{id:'nw13', w:3, st:['ple','vet'],
 t:'El robo en el vestuario',
 d:p=>`Desaparecen tres relojes caros durante la práctica. Seguridad quiere revisar los bolsos de los juveniles y los utileros.`,
 c:[
  {t:'Te negás a que los requisen', ef:{lid:9, fanLove:10, mgrRel:-8, rep:-3}, r:'Defendés a los que menos ganan y los relojes no aparecen. Dos compañeros creen que protegiste al que fue.'},
  {t:'Ofrecés pagar los relojes de tu bolsillo', ef:{capital:-0.09, rep:4, lid:-3}, r:'Se termina la discusión en cinco minutos. También queda claro que el que puede comprar el silencio sos vos.'},
  {t:'Dejás que seguridad haga su trabajo', ef:{com:4, moral:-6, fanLove:-6}, r:'Revisan los bolsos de los pibes delante de todos. Al culpable lo encuentran afuera del club, dos semanas después.'} ]},

{id:'nw14', w:2, st:['asc','ple','vet'],
 t:'La deuda del póker',
 d:p=>`En las concentraciones se juega fuerte. Un referente te debe 5.000 dólares hace dos semanas y no da señales.`,
 c:[
  {t:'Se los cobrás delante de todos en el micro', ef:{moral:-3}, tira:'lid', mas:2,
   bien:{ef:{capital:0.5, lid:6, mgrRel:-4}, r:'Te paga ahí mismo, avergonzado. Nadie vuelve a deberte nada y nadie vuelve a invitarte a jugar.'},
   mal:{ef:{moral:-8, mgrRel:-8, fanLove:-4, rep:-3}, r:'Se arma una discusión fea a mitad de la ruta. Quedás como el pesado de la plata y la deuda sigue impaga.'},
   r:'Lo decís en voz alta, con el micro en silencio.'},
  {t:'Le decís que la deuda se salda con una asistencia', ef:{pas:2, moral:6, mgrRel:5, capital:-0.01}, r:'Risas y la plata perdida. En el partido siguiente te busca en cada centro, que era más o menos el punto.'},
  {t:'Lo dejás pasar y no jugás más con él', ef:{com:5, capital:-0.01, lid:-3}, r:'Perdés cinco mil dólares y una manera de matar el tiempo en las concentraciones.'} ]},

{id:'nw15', w:3, st:['asc','ple'],
 t:'La cábala del utilero',
 d:p=>`El utilero sostiene que si no usás sus medias de la suerte en la final, pierden. Las medias tienen dos agujeros enormes.`,
 c:[
  {t:'Te las ponés con orgullo', ef:{fanLove:8, moral:8, fis:-3, fitness:-3}, r:'Terminás con el talón en carne viva y el utilero llorando en el vestuario. Las dos cosas son ciertas.'},
  {t:'Te ponés unas nuevas sin que se note', ef:{com:4, forma:4, moral:-4}, r:'Jugás cómodo y ganás. En el festejo lo ves buscándote con la mirada y te hacés el que no.'},
  {t:'Tirás las medias viejas a la basura', ef:{com:3, mgrRel:-6, fanLove:-6, moral:-4}, r:'Las saca del tacho él mismo, sin decir nada, y las guarda. No te vuelve a preparar el bolso.'} ]},

{id:'nw16', w:2, st:['ple','vet'],
 t:'El grupo de chat paralelo',
 d:p=>`Varios armaron un grupo sin el técnico ni los referentes para quejarse de los esquemas. Te agregan.`,
 c:[
  {t:'Te salís del grupo enseguida', ef:{com:6, mgrRel:8, lid:-4, moral:-3}, r:'Sin drama y sin aviso. Los seis del grupo entienden perfectamente qué significa que te hayas ido.'},
  {t:'Usás el grupo para calmar las aguas', ef:{lid:8, pas:2, forma:-4}, r:'Convertís tres semanas de quejas en dos propuestas concretas. Te lleva noches enteras y nadie lo va a contar.'},
  {t:'Opinás tan duro como el que más', ef:{moral:-6, mgrRel:-10, rep:-4, trait:'polemico'}, r:'Se filtra una captura a la prensa con tu nombre arriba de todo. El técnico la lee en voz alta.'} ]},

{id:'nw17', w:2, st:['asc','ple','vet'],
 t:'La música del vestuario',
 d:p=>`Te toca a vos poner los parlantes antes del partido. Lo que les gusta a los pibes enoja a los veteranos, y al revés.`,
 c:[
  {t:'Armás una lista mezclada', ef:{moral:8, lid:4, com:-2}, r:'Cantan tres temas de cada lado y ninguno queda del todo contento. Salen a la cancha hablándose, que es lo que hacía falta.'},
  {t:'Dejás que ponga música el capitán', ef:{com:4, mgrRel:4, lid:-4}, r:'Pasás desapercibido, que era el plan. En el vestuario nadie te asocia con nada.'},
  {t:'Ponés tu música rara favorita', ef:{moral:4, fanLove:2, mgrRel:-4, lid:-3}, r:'Te sacan el teléfono a los tres temas entre risas. No te vuelven a dar los parlantes en todo el año.'} ]},

{id:'nw18', w:3, st:['ple','vet'], when:p=>afuera(p),
 t:'La bienvenida al extranjero',
 d:p=>`Llega un refuerzo importante que no habla una palabra del idioma y se lo ve perdido en la ciudad.`,
 c:[
  {t:'Lo invitás a cenar con tu familia', ef:{lid:8, rep:5, pas:2, forma:-4}, r:'Cinco cenas y dos domingos ocupados. En la cancha se entienden de memoria y en tu casa ya es uno más, para bien y para mal.'},
  {t:'Le conseguís un profesor de idioma', ef:{mgrRel:6, com:4, capital:-0.1}, r:'Lo pagás vos y no se lo decís. Le acomodás la adaptación sin invadirlo, que es lo más difícil de las dos cosas.'},
  {t:'Dejás que se arregle con el traductor del club', ef:{com:3, mgrRel:-4, moral:-3}, r:'Tarda cuatro meses en rendir lo que vale. Cuando arranca, el que lo acompañó fue otro.'} ]},

{id:'nw19', w:2, st:['asc','ple'],
 t:'El apodo ridículo',
 d:p=>`Se te escapa una muletilla en una entrevista y la hinchada rival te arma un apodo burlón que se vuelve viral.`,
 c:[
  {t:'Te hacés una remera festejando el apodo', ef:{hype:14, fanLove:10, rep:-5, mgrRel:-4}, r:'Se vende bien y ya no te lo podés sacar. Vas a tener sesenta años y alguien te lo va a gritar en un aeropuerto.'},
  {t:'Metés tres el domingo y festejás pidiendo silencio', ef:{def:3, moral:12, hype:10, fanLove:-6, mgrRel:-4}, r:'El apodo muere en noventa minutos. Esa hinchada te espera con otra cosa durante seis años.'},
  {t:'Se te nota la molestia en conferencia', ef:{moral:-8, hype:8, rep:-3, trait:'polemico'}, r:'Bastan cuatro segundos de video. Te lo cantan en todas las canchas del país durante una temporada entera.'} ]},

{id:'nw20', w:2, st:['ple','vet'],
 t:'El aviso del árbitro',
 d:p=>`Un árbitro veterano te avisa por lo bajo en un córner: «Te quedan dos faltas antes de la amarilla. Usalas bien».`,
 c:[
  {t:'Usás las faltas para cortar contras', ef:{dfs:3, com:6, rep:-3, fanLove:-2}, r:'Dos faltas tácticas perfectas y una fama que empieza a construirse. El rival te la va a cobrar en la revancha.'},
  {t:'Le agradecés pero jugás limpio', ef:{rep:4, com:4, dfs:-2}, r:'Te cobra dos dudosas a favor en el segundo tiempo. Pasan tres contras que podrías haber cortado y una termina en gol.'},
  {t:'Hacés una falta violenta en la jugada siguiente', ef:{mgrRel:-14, moral:-10, forma:-8, rep:-4}, r:'Te expulsa sin mirarte. Le habías arruinado el favor y los dos lo sabían antes de que sonara el silbato.'} ]},

{id:'nw21', w:3, st:['asc','ple'],
 t:'El programa de la tarde',
 d:p=>`Aparecen fotos tuyas cenando con una modelo conocida. Un programa le dedica una hora a tu vida privada en la semana del partido más importante.`,
 c:[
  {t:'Aclarás en redes que estás enfocado en el club', ef:{mgrRel:6, hype:8, moral:-4, rep:-2}, r:'El comunicado dura un día y medio. Ella lo lee antes que vos y no vuelve a contestarte.'},
  {t:'Apagás el teléfono toda la semana', ef:{forma:8, com:6, hype:-8, fanLove:-3}, r:'Rendís al máximo el domingo. El programa llena la semana con lo que se le da la gana, sin nadie que lo desmienta.'},
  {t:'Vas al programa a dar una nota en vivo', ef:{hype:18, rep:-4, mgrRel:-10, forma:-6, trait:'polemico', mem:{polemicas:1}}, r:'Dos horas de aire y un titular que no dijiste. El técnico te deja en el banco y lo explica con una palabra.'} ]},

{id:'nw22', w:2, st:['ple','vet'],
 t:'La biografía no autorizada',
 d:p=>`Un periodista publica un libro sobre tu carrera sin permiso, con secretos de los vestuarios de tus primeros años.`,
 c:[
  {t:'Lo llevás a la justicia', ef:{rep:6, capital:-0.5, moral:-4, hype:-6}, r:'Ganás el juicio en dos años. En ese tiempo el libro se agota tres veces y la prensa aprende a llamarte poco.'},
  {t:'Escribís tu propia biografía con la verdad', ef:{capital:1.5, hype:12, fanLove:8, mgrRel:-8, forma:-4}, r:'Se agota en las librerías. Dos ex compañeros dejan de hablarte por tres párrafos de la página ciento diez.'},
  {t:'Te lo tomás con humor en una entrevista', ef:{com:8, fanLove:6, moral:-5}, r:'Quedás por encima del chisme y el libro vende el doble esa semana. Lo leés entero una noche y no te reís.'} ]},

{id:'nw23', w:3, st:['asc','ple','vet'],
 t:'El meme de la semana',
 d:p=>`Errás un gol insólito abajo del arco y sin arquero. La jugada se convierte en el meme del mes.`,
 c:[
  {t:'Te reís del meme en tus propias redes', ef:{fanLove:12, com:6, def:-2, mgrRel:-3}, r:'Amansás la ola en dos días. Durante un año, cada vez que errás una, alguien reflota tu propio chiste.'},
  {t:'Te encerrás a patear quinientas abajo del arco', ef:{def:4, peg:2, forma:6, fitness:-5, moral:-4}, r:'Tres semanas de tardes solo con el arquero suplente. En abril metés una igual y no la festejás.'},
  {t:'Insultás a un hincha que te lo recuerda en la calle', ef:{fanLove:-12, mgrRel:-8, capital:-0.1, trait:'polemico'}, r:'Lo filma alguien desde un auto. Multa del club y una imagen que no se borra más de internet.'} ]},

{id:'nw24', w:2, st:['ple','vet'],
 t:'La media del videojuego',
 d:p=>`Sale la edición nueva del videojuego más famoso. Te pusieron 74 cuando esperabas 82.`,
 c:[
  {t:'Publicás un video gracioso reclamándoles', ef:{hype:16, fanLove:10, rep:-4, mgrRel:-3}, r:'Se vuelve viral y te suben dos puntos en la actualización. También te instalan como el que se preocupa por eso.'},
  {t:'Demostrás en cancha que se equivocaron', ef:{forma:10, rit:2, def:2, moral:-4, fitness:-4}, r:'Una temporada entera empujada por un número de un videojuego. Funciona, y da un poco de vergüenza que funcione.'},
  {t:'No te importa: no jugás a los videojuegos', ef:{com:5, hype:-6, fanLove:-4}, r:'Tres pibes de la cantera lo comentan sin que los escuches. Para ellos ese número sos vos.'} ]},

{id:'nw25', w:3, st:['asc','ple'], when:p=>(p.capital||0)>=1,
 t:'La marca de ropa propia',
 d:p=>`Un diseñador te propone lanzar una línea de gorras y remeras con tu nombre.`,
 c:[
  {t:'La lanzás e invertís capital', ef:{capital:-1.0, hype:14, fanLove:6, forma:-4}, r:'Pega fuerte entre los pibes y te come los martes y los jueves. El diseñador se lleva la mitad y no aparece en ninguna foto.'},
  {t:'Lo dejás para cuando te retires', ef:{com:6, hype:-6, capital:-0.05, trait:'profesional'}, r:'Foco absoluto adentro de la cancha. Dos años después el mismo diseñador lo lanza con otro apellido.'},
  {t:'Regalás gorras a todo el plantel', ef:{moral:8, fanLove:8, capital:-0.5, com:-3}, r:'El vestuario entero usa tu ropa en los viajes. También descubrís que regalar el producto es la manera más rápida de no venderlo.'} ]},

{id:'nw26', w:2, st:['ple','vet'],
 t:'El periodista que busca pelea',
 d:p=>`Un cronista famoso por provocar te pregunta en conferencia si tu ciclo en el club está terminado, después de que errás un penal.`,
 c:[
  {t:'Le respondés con una ironía elegante', ef:{com:8, rep:6, hype:10, mgrRel:-4}, r:'Se ríe hasta la sala de prensa. Vuelve cada semana a buscar la respuesta, y una de esas te va a agarrar cansado.'},
  {t:'Le tirás el micrófono y cortás la conferencia', ef:{mgrRel:-10, fanLove:-6, capital:-0.15, rep:-6, trait:'polemico', mem:{polemicas:1}}, r:'Tapa de todos los diarios y multa de la liga. El video abre su programa durante un mes.'},
  {t:'Respondés con frases de manual', ef:{com:4, hype:-5, moral:-4}, r:'El tema se termina ahí y él escribe el domingo que ya ni siquiera contestás. Tiene razón.'} ]},

{id:'nw27', w:2, st:['asc','ple'],
 t:'El stream con el famoso',
 d:p=>`Un streamer con millones de espectadores te invita a jugar en vivo un domingo a la noche, después del partido.`,
 c:[
  {t:'Aceptás y hablás de fútbol relajado', ef:{hype:20, fanLove:12, rep:4, forma:-5, fitness:-4}, r:'Cuatro horas de stream que terminan a las tres. El martes hay partido y se nota en los primeros veinte minutos.'},
  {t:'Rechazás: preferís descansar para el martes', ef:{forma:6, fitness:4, hype:-8, trait:'profesional'}, r:'Duerme nueve horas y jugás bien. Va otro compañero y esa noche gana medio millón de seguidores.'},
  {t:'Vas y hablás sin filtro del técnico', ef:{hype:25, mgrRel:-16, moral:-8, rep:-5, trait:'polemico', mem:{polemicas:1}}, r:'Recortan el clip y llega al grupo del cuerpo técnico antes de que llegues a tu casa.'} ]},

{id:'nw28', w:3, st:['ple','vet'],
 t:'El busto en el predio',
 d:p=>`Un grupo de hinchas junta firmas y bronce para hacerte un busto en la entrada del predio.`,
 c:[
  {t:'Lo inaugurás con un discurso', ef:{fanLove:20, rep:8, forma:-4, moral:-3, trait:'idolo'}, r:'Lágrimas y aplausos un jueves a las once de la mañana, en plena semana de partido. El técnico va y no dice nada.'},
  {t:'Pedís que usen esa plata para pintar la pensión', ef:{fanLove:25, lid:10, hype:-6, moral:8}, r:'Los hinchas que juntaron el bronce tardan un año en perdonarte. Los pibes duermen en un lugar que no da vergüenza.'},
  {t:'Te da vergüenza y no vas al acto', ef:{com:4, fanLove:-8, rep:-3}, r:'Lo inauguran igual, con una silla vacía en la primera fila. La foto sale con la silla.'} ]},

{id:'nw29', w:2, st:['asc','ple'],
 t:'La publicidad ridícula',
 d:p=>`Te ofrecen un comercial de papas fritas donde tenés que bailar disfrazado de papa. Pagan muy bien.`,
 c:[
  {t:'Aceptás el ridículo por la plata', ef:{capital:1.2, hype:12, rep:-6, mgrRel:-3}, r:'Se ríen en todos los vestuarios del país durante seis meses. En el clásico te lo cantan disfrazado y todo.'},
  {t:'Exigís un guión más deportivo', ef:{capital:0.8, rep:3, hype:-4}, r:'Comercial normal, plata normal, cero recuerdo. La marca no te vuelve a llamar para la campaña grande.'},
  {t:'Rechazás para cuidar tu imagen', ef:{rep:4, com:4, capital:-0.05}, r:'Lo hace un compañero tuyo y le pagan el triple de lo que te ofrecieron a vos. Mantener el prestigio cuesta y se paga en efectivo.'} ]},

{id:'nw30', w:2, st:['ple','vet'],
 t:'El futbolista mejor vestido',
 d:p=>`Una revista de moda te elige el futbolista mejor vestido del año y te invitan a una gala en París.`,
 c:[
  {t:'Vas a París entre dos partidos', ef:{hype:14, rep:6, fitness:-6, forma:-5, mgrRel:-4}, r:'Fotos espectaculares y dos vuelos en cuarenta y ocho horas. El domingo te sacan a los sesenta y la prensa junta las dos cosas.'},
  {t:'Mandás un video de agradecimiento desde el predio', ef:{rep:4, hype:-6, trait:'profesional'}, r:'Cumplís sin romper la rutina. La revista te baja del puesto uno al cuatro por no ir.'},
  {t:'Subastás el traje para caridad', ef:{fanLove:12, moral:8, rep:6, capital:-0.2}, r:'Ponés vos la diferencia para que la cifra sea decente. Nadie pregunta cuánto puso el traje y cuánto pusiste vos.'} ]},

{id:'nw31', w:3, st:['asc','ple','vet'],
 t:'El tiro libre en la barrera',
 d:p=>`Tiro libre rival al borde del área en el minuto 90. La pelota sale a ciento diez y va derecho a tu cara.`,
 c:[
  {t:'Ponés la cara y cubrís el arco', ef:{dfs:3, fanLove:10, fitness:-6, forma:-4}, r:'Salvás el triunfo y salís mareado, sin saber en qué cancha estás. Tres días de dolor de cabeza que no contás.'},
  {t:'Te agachás por instinto', ef:{fitness:3, moral:-6, mgrRel:-8, fanLove:-6}, r:'La pelota pasa por donde estaba tu cabeza y entra. En el video se ve clarísimo y el técnico lo pasa dos veces.'},
  {t:'Saltás con los codos arriba', ef:{moral:-2}, tira:'dfs', mas:0,
   bien:{ef:{dfs:2, fitness:-3}, r:'La desviás al córner con el hombro. Te queda el brazo dormido veinte minutos.'},
   mal:{ef:{moral:-12, mgrRel:-12, fanLove:-8, forma:-6}, r:'Mano clarísima. Penal, expulsión y una noche que te van a repetir en cada previa contra ese equipo.'},
   r:'Salís del salto con los brazos donde no hay que tenerlos.'} ]},

{id:'nw32', w:2, st:['ple','vet'],
 t:'La cancha inundada',
 d:p=>`Lluvia sin parar. El agua tapa los tobillos y la pelota no rueda en el medio.`,
 c:[
  {t:'Pedís tapones de aluminio largos', ef:{fis:3, forma:6, fitness:-4}, r:'Te adaptás al barro mejor que nadie y terminás con los gemelos de piedra. Dos asistencias de puro empuje.'},
  {t:'Proponés jugar todo por arriba', ef:{aer:4, pas:2, mgrRel:6, reg:-2}, r:'Le cambiás el partido al equipo en el entretiempo. También te pasás noventa minutos jugando a algo que no es lo tuyo.'},
  {t:'Evitás tirarte a barrer', ef:{com:4, fitness:4, forma:-5, fanLove:-4}, r:'Salís limpio de un partido donde todos salieron negros. Se nota en la foto del vestuario y alguien la comenta.'} ]},

{id:'nw33', w:3, st:['asc','ple','vet'],
 t:'El corte en la ceja',
 d:p=>`Choque de cabezas tremendo a los veinte minutos. Sangrás pero podés seguir. El médico te quiere cambiar.`,
 c:[
  {t:'Exigís que te venden y seguir', ef:{fanLove:16, fis:2, fitness:-8, com:-3, trait:'caudillo'}, r:'Jugás cuarenta minutos con la cabeza vendada y la vista nublada. Siete puntos y una semana de mareos que le ocultás al médico.'},
  {t:'Aceptás el cambio por precaución', ef:{fitness:6, moral:-6, fanLove:-5, mgrRel:2}, r:'Salís caminando y te aplauden a medias. Entra un pibe, mete un gol y el técnico lo repite el domingo siguiente.'},
  {t:'Infiltración rápida en el vestuario', ef:{forma:4, moral:4, fitness:-6, mem:{infiltraciones:1}}, r:'Volvés sin dolor y con la ceja abierta cerrada con grapas. Te queda la cicatriz y la costumbre.'} ]},

{id:'nw34', w:2, st:['asc','ple'],
 t:'El arquero expulsado',
 d:p=>`Roja al arquero a los 85 y ya no quedan cambios. Alguien de campo tiene que ponerse los guantes.`,
 c:[
  {t:'Te los ponés vos', ef:{moral:4}, tira:'com', mas:4,
   bien:{ef:{fanLove:20, rep:8, fitness:-4, trait:'clutch'}, r:'Atajás un tiro libre en el descuento y salís con la mano hinchada. Nadie se acuerda de la mano.'},
   mal:{ef:{moral:-10, fanLove:-6, mgrRel:-4}, r:'Te meten un gol fácil de treinta metros y pierden por eso. Todos te agradecen el gesto, que es lo que se dice cuando no hay otra cosa.'},
   r:'Te calzás los guantes que te quedan grandes.'},
  {t:'Se los das al central más alto', ef:{lid:6, pas:2, fis:-3}, r:'Armás una línea de cinco y corrés por dos durante cinco minutos eternos. Aguantan.'},
  {t:'Te hacés el distraído', ef:{com:2, moral:-6, lid:-5, mgrRel:-4}, r:'Va otro, y va mirando el piso. En el vestuario nadie lo menciona y todos saben quién no levantó la mano.'} ]},

{id:'nw35', w:3, st:['ple','vet'],
 t:'El que te pisa en los córners',
 d:p=>`Un delantero rival te pisa el pie en cada pelota parada, siempre cuando el árbitro mira para otro lado.`,
 c:[
  {t:'Le devolvés un codazo sutil', ef:{moral:-2}, tira:'dfs', mas:0,
   bien:{ef:{dfs:3, fis:2, rep:-2}, r:'Se le van las ganas por el resto del partido. También queda anotado en el informe del árbitro.'},
   mal:{ef:{moral:-12, mgrRel:-14, forma:-8, rep:-4}, r:'El línea lo ve de frente. Roja directa, dos fechas y un rival que va a contar la versión que le convenga.'},
   r:'Esperás la pelota parada siguiente y lo buscás.'},
  {t:'Exagerás la caída para que lo amonesten', ef:{com:6, rep:-4, fanLove:-3}, r:'Conseguís la amarilla y el teatro queda filmado desde tres ángulos. Te lo van a mostrar toda la semana.'},
  {t:'Se lo decís al árbitro con calma en el entretiempo', ef:{com:6, rep:4, dfs:-2}, r:'Lo advierte y se termina el juego sucio. También te deja de cobrar los contactos a favor: cree que ya tuviste el tuyo.'} ]},

{id:'nw36', w:2, st:['asc','ple','vet'],
 t:'Cuarenta grados a las dos de la tarde',
 d:p=>`El césped quema y a los treinta minutos varios ya piden agua con desesperación.`,
 c:[
  {t:'Dosificás y jugás a un toque', ef:{pas:4, com:6, fitness:4, fanLove:-5}, r:'Manejo de ritmo perfecto y ni una carrera hacia atrás. Desde la tribuna se ve otra cosa y te lo hacen saber.'},
  {t:'Presionás como si hicieran quince grados', ef:{fis:3, fanLove:8, fitness:-12, forma:-4}, r:'Das el ejemplo y terminás con suero en el vestuario. El sábado siguiente no llegás a la mitad del partido.'},
  {t:'Pedís la pausa de hidratación', ef:{lid:5, mgrRel:4, forma:-4}, r:'Le das aire a todo el equipo y le cortás la inercia al partido justo cuando estaban mejor. El técnico no opina.'} ]},

{id:'nw37', w:2, st:['ple','vet'],
 t:'El entretiempo a oscuras',
 d:p=>`Se corta la luz del estadio visitante justo en el descanso. Van perdiendo y el técnico no puede usar la pizarra.`,
 c:[
  {t:'Das vos la charla con la linterna del teléfono', ef:{lid:10, moral:8, mgrRel:-5, trait:'lider'}, r:'Lo dan vuelta en el segundo tiempo. El técnico te felicita delante de todos y no vuelve a pedirte una charla nunca más.'},
  {t:'Aprovechás para descansar los ojos', ef:{fitness:4, com:4, lid:-4, moral:-3}, r:'Recuperás algo de cabeza. Al volver, el vestuario ya se ordenó solo y vos no estuviste en eso.'},
  {t:'Protestás con los delegados', ef:{mgrRel:-5, rep:2, forma:-4}, r:'La luz no vuelve más rápido y salés al segundo tiempo caliente por lo que no era. Te amonestan a los seis minutos.'} ]},

{id:'nw38', w:3, st:['asc','ple'],
 t:'El travesaño del minuto 94',
 d:p=>`Última jugada. Sacás un derechazo desde treinta metros que explota en el travesaño y pica en la línea. El árbitro no lo cobra y no hay VAR.`,
 c:[
  {t:'Aceptás el fallo y saludás al arquero', ef:{rep:8, com:8, moral:-6, fanLove:-4}, r:'La prensa lo resalta el lunes. En la popular, esa tarde, alguien grita que sos demasiado educado para este club.'},
  {t:'Vas a protestarle al línea con todo', ef:{mgrRel:-6, rep:-4, moral:-4, trait:'polemico'}, r:'Te amonestan por protestar una jugada que ya terminó. Esa amarilla te deja afuera del clásico.'},
  {t:'Te tirás al piso a llorar de bronca', ef:{fanLove:8, moral:-8, com:-4, hype:6}, r:'La imagen abre todos los resúmenes. También la usan seis meses después para decir que sos inestable.'} ]},

{id:'nw39', w:2, st:['ple','vet'],
 t:'La marca personal',
 d:p=>`El técnico rival puso a un volante joven a seguirte hasta cuando vas a tomar agua al banco. No tocás una pelota limpia.`,
 c:[
  {t:'Lo sacás de su zona llevándotelo a la banda', ef:{pas:3, com:6, forma:6, def:-2}, r:'Desarmás el esquema rival arrastrando tu marca. Terminás el partido sin patear una sola vez al arco.'},
  {t:'Usás el cuerpo en cada jugada', ef:{fis:4, moral:6, rep:-3, fitness:-4}, r:'Le hacés sentir el rigor y terminás amonestado a los treinta. Los últimos veinte los jugás sin poder tocarlo.'},
  {t:'Le pedís el cambio al técnico de pura bronca', ef:{fitness:5, moral:-8, mgrRel:-8, fanLove:-6}, r:'Salís caliente y el pibe que te marcaba sale aplaudido. Ganó la táctica rival y lo dice todo el mundo.'} ]},

{id:'nw40', w:2, st:['asc','ple','vet'],
 t:'El césped alto y seco',
 d:p=>`El local dejó el pasto largo y sin regar para frenar el juego rápido de tu equipo.`,
 c:[
  {t:'Pateás de media distancia aprovechando los piques raros', ef:{peg:4, def:2, pas:-2, moral:4}, r:'Sorprendés al arquero con un remate que pica mal. También tirás otras seis que terminan en la tribuna.'},
  {t:'Pedís centros picados', ef:{aer:3, pas:3, reg:-2}, r:'Le escapás al pasto jugando por el aire. Es feo, funciona, y el técnico te lo va a pedir en las diez canchas que vienen.'},
  {t:'Te quejás del pique todo el partido', ef:{moral:-6, forma:-5, com:-3, mgrRel:-4}, r:'Perdés dos pelotas mirando el césped en vez de la jugada. El local hizo exactamente lo que quería hacer.'} ]},

{id:'nw41', w:3, st:['ple','vet'],
 t:'La cláusula contra los rivales',
 d:p=>`Al renovar, el club quiere prohibirte por contrato jugar en cualquier equipo del país durante tres años si te vas.`,
 c:[
  {t:'La rechazás: nadie te dice dónde trabajar', ef:{com:6, mgrRel:-6, fanLove:-4, contrato:2}, r:'La dirigencia cede y te firma el mismo sueldo que tenías. Alguien filtra que pusiste condiciones y en la popular lo escuchan.'},
  {t:'La aceptás si duplican las primas por título', ef:{wage:8, capital:1.0, moral:-3, flag:'clausulaPais', contrato:2}, r:'Te asegurás un contrato importante. La firma de abajo te encierra en un solo país y todavía no sabés cuánto pesa eso.'},
  {t:'Firmás sin darle importancia: pensás retirarte acá', ef:{fanLove:10, com:-4, flag:'clausulaPais', trait:'idolo', contrato:3}, r:'Lealtad sin leer. La letra chica queda igual de escrita que si la hubieras leído.'} ]},

{id:'nw42', w:2, st:['asc','ple'],
 t:'Oferta a veinte minutos del cierre',
 d:p=>`Faltan veinte minutos para que cierre el libro de pases en Europa. Llega una oferta que paga tu cláusula.`,
 c:[
  {t:'Armás el bolso y firmás en el auto', ofr:{t:'europa',cuando:'ya'}, ef:{hype:20, moral:10, fanLove:-16, forma:-6}, r:'Traspaso relámpago sin despedirte de nadie. Aterrizás a las cuatro de la mañana en una ciudad donde no conocés a una sola persona.'},
  {t:'La rechazás: querés terminar el torneo acá', ef:{fanLove:18, moral:8, rep:6, hype:-8}, r:'La hinchada te ovaciona el sábado. Ese club ficha a otro y no vuelve a llamar en tres años.'},
  {t:'Pedís dos horas para pensarlo', ef:{com:3, moral:-8, hype:-6, rep:-3}, r:'A los cincuenta minutos te avisan que cerraron por otro. Te quedaste sin el pan y sin la torta, y con la sensación de que la duda fue la respuesta.'} ]},

{id:'nw43', w:2, st:['ple','vet'], when:p=>(p.capital||0)>=2,
 t:'El porcentaje de tu propio pase',
 d:p=>`Sos dueño del quince por ciento de tu propio pase. El club te pide que renuncies para cerrar los números con el comprador.`,
 c:[
  {t:'Renunciás para que se haga el pase de tu vida', ef:{capital:-2.0, moral:8, rep:6, com:-3}, ofr:{t:'gigante', cuando:'ya'}, r:'Llegás al club grande y firmás la renuncia sin abogado. La plata no se recupera con el sueldo nuevo tan rápido como te dijeron.'},
  {t:'Exigís hasta el último centavo', ef:{capital:2.5, mgrRel:-8, hype:-4, rep:-3}, ofr:{t:'gigante', cuando:'ventana'}, r:'Cobrás lo tuyo y la transferencia se atrasa tres semanas. Llegás con la pretemporada empezada y una etiqueta puesta.'},
  {t:'Negociás cobrar la mitad en departamentos', ef:{capital:1.2, com:5, moral:-4, forma:-3}, r:'Dos meses de escrituras y visitas a inmobiliarias en plena temporada. Uno de los tres departamentos no se termina nunca.'} ]},

{id:'nw44', w:3, st:['asc','ple'],
 t:'El club que no paga las cuotas',
 d:p=>`Te vendieron hace un año y el club comprador quebró sin pagar. Tu club anterior amenaza con ir a la FIFA.`,
 c:[
  {t:'Te mantenés al margen y jugás', ef:{com:6, forma:5, lid:-4, rep:-2}, r:'Que se ocupen los abogados. Tu club anterior, donde te hiciste, pasa un año sin cobrar un peso de tu pase.'},
  {t:'Hablás con el presidente para acercar a las partes', ef:{lid:6, rep:4, mgrRel:4, forma:-4}, r:'Cuatro reuniones y dos viajes en tus días libres. Se destraba en marzo y nadie te nombra en el comunicado.'},
  {t:'Declarás en la prensa que estás incómodo', ef:{hype:10, mgrRel:-6, rep:-4, fanLove:-5, trait:'polemico'}, r:'Ruido de dos días que no le sirve a nadie. Los dos clubes quedan enojados con vos y siguen enojados entre ellos.'} ]},

{id:'nw45', w:2, st:['ple','vet'],
 t:'El sueldo en criptomonedas',
 d:p=>`Un auspiciante nuevo propone pagar el treinta por ciento de los sueldos en una moneda digital.`,
 c:[
  {t:'Aceptás el riesgo', tira:'com', mas:-6, ef:{hype:4},
   bien:{ef:{capital:2.0, moral:6}, r:'Sube seis meses seguidos y salís a tiempo. Nunca vas a saber si fue cabeza o suerte.'},
   mal:{ef:{capital:-1.2, moral:-10, hype:-4}, r:'Se derrumba un martes cualquiera. Trabajaste cuatro meses gratis y no se lo contás a nadie.'},
   r:'Firmás la parte en moneda digital.'},
  {t:'Exigís cobrar todo en moneda normal', ef:{com:6, mgrRel:-4, hype:-4, trait:'profesional'}, r:'Te lo dan sin discutir y el auspiciante se enfría. Dos compañeros que aceptaron cobran el doble ese semestre y te lo recuerdan.'},
  {t:'Pedís que esa parte sean bonos del club', ef:{fanLove:10, moral:6, capital:-0.3}, r:'Los socios lo toman muy bien. Los bonos valen la mitad el día que querés venderlos.'} ]},

{id:'nw46', w:2, st:['asc','ple'],
 t:'Los dueños nuevos',
 d:p=>`Un grupo inversor compra el club y anuncia diez refuerzos de nivel mundial.`,
 c:[
  {t:'Trabajás el doble en pretemporada', ef:{forma:10, fis:3, fitness:-6, moral:-3}, r:'El técnico nuevo te mantiene de titular al ver el compromiso. Llegás a octubre con el tanque en la mitad.'},
  {t:'Pedís aumento acorde al presupuesto nuevo', ef:{wage:12, capital:1.0, mgrRel:-6, fanLove:-5}, r:'Aprovechás la billetera gorda y te lo dan en dos días. Quedás anotado como el primero que pidió, y eso también se archiva.'},
  {t:'Buscás club: no te gusta el proyecto', ofr:{t:'menor',cuando:'ventana'}, ef:{rep:6, fanLove:-8, wage:-10, hype:-4}, r:'Te vas a un club de fútbol de verdad, a cobrar bastante menos. Los diez refuerzos llegan y el equipo sale campeón sin vos.'} ]},

{id:'nw47', w:3, st:['ple','vet'],
 t:'Contrato por partido jugado',
 d:p=>`El club te ofrece renovar un año con un fijo muy bajo y cincuenta mil dólares por partido jugado.`,
 c:[
  {t:'Aceptás: confiás en tu cuerpo', tira:'fis', mas:-2, ef:{moral:6, forma:6, contrato:1},
   bien:{ef:{capital:1.5, moral:6}, r:'Treinta y cinco partidos. Terminás cobrando más que antes y con la razón de tu lado.'},
   mal:{ef:{capital:0.15, moral:-12, wage:-10}, r:'Once partidos y dos lesiones. Cobrás la mitad de lo que cobrabas antes de firmar.'},
   r:'Firmás el fijo bajo.'},
  {t:'Exigís un fijo más alto', ef:{wage:4, com:4, mgrRel:-5, hype:-3, contrato:1}, r:'Contrato tradicional, sin sorpresas y sin techo. El club te ofrece un año en vez de dos.'},
  {t:'Lo rechazás por falta de respeto', ef:{mgrRel:-10, moral:-6, wage:-6, flag:'quiereIrse', mem:{plantes:1}}, r:'Se rompe la relación con la dirigencia en una reunión de once minutos. En junio firmás por menos de lo que rechazaste.'} ]},

{id:'nw48', w:2, st:['asc','ple'], when:p=>!p.loanFrom,
 t:'La compra obligatoria',
 d:p=>`Un club te quiere a préstamo un año. Tu club pide que si jugás quince partidos, la compra sea obligatoria.`,
 c:[
  {t:'Presionás para que se firme', ofr:{t:'europa',cuando:'ya',prestamo:true}, ef:{hype:12, moral:6, fanLove:-6, mgrRel:-4}, r:'Te vas a probar suerte a la liga grande con una cláusula que te obliga a jugar quince. Vas a contarlos todas las semanas.'},
  {t:'Preferís venta definitiva ahora o nada', ef:{com:5, mgrRel:4, hype:-6, moral:-4}, r:'Exigís certezas y no las hay. La operación se cae en cuarenta y ocho horas y te quedás donde estabas.'},
  {t:'Te quedás a pelearla acá', ef:{fanLove:8, moral:4, rep:-4, hype:-6}, r:'Rechazás la salida corta. Jugás dieciocho partidos, ninguno de los que se miran desde afuera.'} ]},

{id:'nw49', w:2, st:['ple','vet'], when:p=>p.nt.caps>0,
 t:'El llamado del técnico de la Selección',
 d:p=>`Te llama por lo bajo: «Si te vas al Golfo, desde allá el lugar te lo vas a tener que ganar el doble. Y yo miro los partidos que puedo mirar».`,
 c:[
  {t:'Rechazás los millones y te quedás', ef:{rep:8, moral:10, fanLove:8, wage:-15}, r:'Elegís la camiseta por encima del contrato. Tu representante tarda un mes en volver a llamarte.'},
  {t:'Te vas igual, confiando en tu nivel', ofr:{t:'golfo',cuando:'ya'}, ef:{wage:30, capital:4.0, rep:-6, forma:-6, trait:'mercenario'}, r:'Dejás a tu familia asegurada. Desde allá, cada convocatoria es cuesta arriba.'},
  {t:'Le pedís garantías de titularidad', ef:{moral:4, mgrRel:-4, rep:-4}, r:'Te dice que nadie tiene el puesto asegurado y corta antes de lo que corta siempre. No te llama en las dos fechas que siguen.'} ]},

{id:'nw50', w:2, st:['asc','ple'], when:p=>(p.capital||0)>=0.5,
 t:'La comisión de tu papá',
 d:p=>`Tu papá, que te representa, pide medio millón de comisión y el club comprador se niega a pagarlo.`,
 c:[
  {t:'La pagás de tu bolsillo para destrabar el pase', ef:{capital:-0.5, moral:6, rep:4, com:-3}, ofr:{t:'europa', cuando:'ya'}, r:'Se firma en dos días. Tu papá cobra sin saber de dónde salió y vos empezás en el club nuevo medio millón más pobre.'},
  {t:'Hablás con él para que baje sus pretensiones', ef:{com:6, lid:4, moral:-8}, r:'Charla familiar de dos horas en la cocina. Baja la cifra y no te habla del tema nunca más, que es distinto de que se le pase.'},
  {t:'Lo dejás manejar todo, aunque se caiga el pase', ef:{moral:-6, hype:-6, rep:-4, forma:-4}, r:'Se cae la venta por codicia. Seis meses más donde estabas, sabiendo exactamente por qué.'} ]}

];

EVENTS11.push(

{id:'nw51', w:3, st:['asc','ple'], when:p=>p.age>=21 && (p.capital||0)>=2,
 t:'La primera casa',
 d:p=>`Juntaste tus primeros ahorros de verdad. Alcanza para una casa con pileta para vos, o para un departamento para tus viejos.`,
 c:[
  {t:'Les comprás el departamento a tus viejos', ef:{capital:-1.5, moral:16, fanLove:10, trait:'lider'}, r:'Tu mamá llora con las llaves en la mano y tarda cuatro meses en mudarse. Vos seguís alquilando cerca del predio.'},
  {t:'Te comprás la casa con pileta', ef:{capital:-2.0, moral:10, hype:6, fanLove:-6}, r:'Tu primer gran gusto, con foto aérea en un diario. En tu casa nadie te dice nada y se nota que nadie te dice nada.'},
  {t:'Invertís la plata a largo plazo', ef:{capital:0.5, com:8, moral:-6, trait:'profesional'}, r:'Cabeza de inversor a los veintidós. Tus viejos siguen donde están y vos elegiste que sigan ahí.'} ]},

{id:'nw52', w:2, st:['ple','vet'],
 t:'El divorcio',
 d:p=>`Separación complicada en plena temporada. Abogados, división de bienes y tapas de revista.`,
 c:[
  {t:'Arreglás rápido cediendo plata', ef:{capital:-1.5, moral:8, forma:6}, r:'Firmás todo en una tarde y perdés la mitad de lo que juntaste. El domingo jugás bien por primera vez en dos meses.'},
  {t:'Peleás cada centavo', ef:{capital:1.0, moral:-12, forma:-10, hype:-4}, r:'Catorce meses de audiencias y de abogados que te llaman los viernes. Ganás la mitad de lo que peleabas y perdés una temporada entera.'},
  {t:'Te mudás al predio un mes', ef:{forma:8, mgrRel:6, moral:-6, fanLove:-3}, r:'El fútbol como refugio, en una habitación de concentración con la luz del pasillo. Rendís, y a las tres de la mañana estás despierto.'} ]},

{id:'nw53', w:2, st:['ini','asc'], when:p=>p.age<=20,
 t:'Tu hermano en inferiores',
 d:p=>`Tu hermano menor entra a las divisiones inferiores del club. Lo comparan con vos en cada práctica.`,
 c:[
  {t:'Vas a todos sus partidos y lo aconsejás', ef:{moral:10, lid:6, forma:-5, fitness:-3}, r:'Se siente respaldado. Vos jugás doce sábados con las piernas de un domingo por la mañana en cancha de tierra.'},
  {t:'Pedís en el club que no lo presionen con tu apellido', ef:{mgrRel:-5, com:4, moral:4}, r:'Le cuidás el desarrollo y lo bajan a la categoría de abajo «para que respire». Él cree que fue por su nivel.'},
  {t:'Te mantenés lejos para que haga su camino', ef:{com:4, moral:-8, lid:-4}, r:'Él lo siente como desinterés y no te lo dice. Se entera por otros de que preguntabas por él todas las semanas.'} ]},

{id:'nw54', w:2, st:['ple','vet'],
 t:'La parrilla con tu nombre',
 d:p=>`Un socio te propone abrir una parrilla con tu nombre en la zona más cara de la ciudad.`,
 c:[
  {t:'La abrís y vas a comer una vez por semana', tira:'com', mas:-4, ef:{hype:8},
   bien:{ef:{capital:0.9, fanLove:8}, r:'Se vuelve lugar de peregrinación. Hay cola los domingos y no sos vos el que la hace.'},
   mal:{ef:{capital:-1.0, moral:-8, hype:-4}, r:'Dos años de excusas del socio y un local cerrado con tu apellido todavía en el cartel.'},
   r:'Ponés la plata y la cara.'},
  {t:'Ponés la cara pero no la plata', ef:{hype:10, capital:0.3, rep:-4}, r:'Negocio de imagen sin riesgo. Cuando cierra mal, el apellido en el cartel sigue siendo el tuyo.'},
  {t:'Decís que no: la gastronomía es riesgosa', ef:{com:6, hype:-5, moral:-3, trait:'profesional'}, r:'Tenés razón y el socio abre igual con otro jugador. Le va bien tres años y te lo cuentan cada vez que te lo cruzan.'} ]},

{id:'nw55', w:3, st:['asc','ple'], when:p=>p.age>=22,
 t:'El amigo que pide trabajo',
 d:p=>`Tu mejor amigo de la infancia está sin trabajo y te pide si podés meterlo de asistente o chofer en el club.`,
 c:[
  {t:'Le pagás vos como asistente personal', ef:{capital:-0.15, moral:10, lid:4, com:-4}, r:'Lo sumás a tu equipo y a tu vida entera. A los ocho meses no sabés cómo decirle que llega tarde.'},
  {t:'Le conseguís una entrevista en la utilería', ef:{mgrRel:4, moral:6, fanLove:-3}, r:'Entra por la puerta que corresponde y cobra un sueldo de utilero. Te agradece con una incomodidad que no se va nunca del todo.'},
  {t:'Le explicás que preferís no mezclar', ef:{moral:-8, com:6, fanLove:-4}, r:'Lo entiende en el momento y deja de contestarte a los tres meses. Tenías razón y te salió cara.'} ]},

{id:'nw56', w:2, st:['ple','vet'],
 t:'El robo en tu casa',
 d:p=>`Entran a robar mientras jugás un partido de copa de noche. Se llevan medallas, camisetas y joyas.`,
 c:[
  {t:'Ofrecés recompensa por las medallas', ef:{capital:-0.5, fanLove:10, hype:12, com:-3}, r:'Recuperás la del debut en la puerta de tu casa, sin ver a nadie. La ciudad se moviliza y vos dormís peor que antes.'},
  {t:'Contratás seguridad para tu familia', ef:{capital:-0.8, moral:8, com:4, fanLove:-3}, r:'Dos autos y un tipo en la puerta todo el día. Tus hijos crecen con eso y ya no saben vivir de otra manera.'},
  {t:'Pensás seriamente en irte del país', ef:{moral:-10, forma:-6, flag:'quiereIrse'}, r:'La sensación de inseguridad te pega en el rendimiento antes que en las decisiones. Empezás a mirar cada oferta de afuera distinto.'} ]},

{id:'nw57', w:2, st:['asc','ple','vet'],
 t:'Las noches de consola',
 d:p=>`Te enganchás con un juego en línea y te quedás hasta las cuatro de la mañana todas las noches.`,
 c:[
  {t:'Lo desinstalás de golpe', ef:{forma:8, fitness:6, moral:-6, trait:'profesional'}, r:'Recuperás el físico en tres semanas y las noches se te hacen larguísimas. Descubrís que lo usabas para algo.'},
  {t:'Jugás sólo los domingos después del partido', ef:{moral:6, com:4, fitness:-3}, r:'Equilibrio razonable que aguanta cuatro meses. En febrero volvés a los martes, y de los martes a todo.'},
  {t:'Seguís de noche a escondidas', ef:{moral:6, fitness:-10, forma:-8, mgrRel:-6}, r:'El técnico te ve las ojeras en cada charla y no dice nada durante dos meses. Cuando lo dice, ya estás en el banco.'} ]},

{id:'nw58', w:2, st:['ple','vet'], when:p=>(p.capital||0)>=0.6,
 t:'El auto de carrera',
 d:p=>`Te comprás un deportivo de gran cilindrada con tus primeros ahorros grandes.`,
 c:[
  {t:'Lo disfrutás con prudencia en tus días libres', ef:{moral:8, capital:-0.6, com:-3, mgrRel:-3}, r:'Desconexión necesaria y una multa por exceso de velocidad que el club se entera igual. Nadie te dice nada y todos lo saben.'},
  {t:'El contrato te prohíbe actividades de riesgo', ef:{mgrRel:6, com:4, capital:-0.15, moral:-5}, r:'Lo vendés sin protestar y perdés plata en la reventa. Cada vez que ves uno igual en la calle, girás la cabeza.'},
  {t:'Te filmás a 220 y lo subís', ef:{mgrRel:-12, fanLove:-8, capital:-0.2, rep:-5, trait:'polemico'}, r:'Sanción del club, multa de tránsito y una semana entera de programas discutiendo si sos un irresponsable.'} ]},

{id:'nw59', w:3, st:['asc','ple'], when:p=>p.age>=20,
 t:'El primer técnico que tuviste',
 d:p=>`Aparece en el entrenamiento el señor de ochenta años que te vio por primera vez a los siete, en una cancha de tierra. Tiene la campera gastada.`,
 c:[
  {t:'Lo hacés pasar al vestuario y le firmás tu camiseta', ef:{fanLove:16, moral:14, mgrRel:-5, forma:-3}, r:'El plantel entero lo aplaude en pleno horario de entrenamiento. Al preparador físico no le causa gracia y lo dice.'},
  {t:'Le comprás el carnet de socio vitalicio', ef:{capital:-0.2, fanLove:12, moral:10}, r:'No se lo olvida nunca más y no lo usa: vive a cuatrocientos kilómetros. Se lo presta a un nieto que sí viene.'},
  {t:'Lo saludás en la puerta, sin bajar del auto', ef:{moral:-8, fanLove:-6, com:3}, r:'Se vuelve en el colectivo de las cinco. En tu pueblo lo cuentan de una manera y no van a contarlo de otra.'} ]},

{id:'nw60', w:2, st:['ple','vet'],
 t:'El perro del predio',
 d:p=>`Un perro callejero se instala en el predio y se vuelve la mascota del plantel.`,
 c:[
  {t:'Te lo llevás a vivir a tu casa', ef:{moral:10, fanLove:12, fitness:-3, com:-2}, r:'Se vuelve tu compañero y te despierta a las cinco todos los días. Las fotos son un éxito y el plantel pierde su mascota.'},
  {t:'Le pagan el veterinario entre todos y le arman una casilla', ef:{moral:8, lid:4, capital:-0.05}, r:'La mística del grupo se fortalece por donde menos se espera. El perro elige dormir en el auto del utilero.'},
  {t:'Pedís que se lo lleven por higiene', ef:{fanLove:-14, moral:-6, lid:-5, trait:'polemico'}, r:'Alguien lo cuenta afuera con tu nombre y una foto del perro. Dos días después hay una bandera en la popular con el hocico dibujado.'} ]},

{id:'nw61', w:3, st:['asc','ple','vet'], when:p=>p.nt.caps>0,
 t:'La noche antes de la final',
 d:p=>`Mañana jugás la final con la Selección. Hay quinientos hinchas con bengalas afuera del hotel a las doce de la noche.`,
 c:[
  {t:'Salís al balcón a cantar con la gente', ef:{fanLove:18, moral:12, hype:10, fitness:-6, forma:-4}, r:'Cuarenta minutos de comunión y cuatro horas de sueño. Mañana lo vas a sentir en los primeros veinte minutos y no se lo vas a decir a nadie.'},
  {t:'Tapones de oído y ocho horas de sueño', ef:{com:8, forma:6, fanLove:-6, trait:'profesional'}, r:'Cabeza fría y piernas enteras. Dos compañeros salieron al balcón y en la foto del diario no estás.'},
  {t:'Mandás al capitán a pedir silencio', ef:{lid:-4, moral:2, fanLove:-10, mgrRel:3}, r:'Se van refunfuñando a las dos de la mañana. Alguien filma el momento desde abajo y se entiende perfecto quién lo mandó.'} ]},

{id:'nw62', w:2, st:['ple','vet'], when:p=>p.nt.caps>=8,
 t:'El recambio',
 d:p=>`El técnico nuevo de la Selección deja afuera a tres históricos y te señala a vos como el líder del grupo joven.`,
 c:[
  {t:'Asumís y unificás al grupo', ef:{lid:12, rep:8, forma:-5, moral:-4, trait:'capitan', flag:'capitan'}, r:'Empieza una era con tu nombre y con tu teléfono sonando a cualquier hora. Los tres históricos no te contestan más.'},
  {t:'Declarás que se extraña a los históricos', ef:{rep:4, mgrRel:-8, moral:4, hype:6}, r:'Lealtad con los que se fueron, dicha en el peor momento. El técnico te da la cinta a otro esa misma semana.'},
  {t:'Te pesa la responsabilidad', ef:{com:3, moral:-8, forma:-6, lid:-4}, r:'La presión de todo un país es otra cosa y se te nota en tres partidos seguidos. Te dejan afuera de la lista de octubre.'} ]},

{id:'nw63', w:3, st:['ple','vet'], when:p=>p.nt.caps>0,
 t:'Dieciocho horas de vuelo por un amistoso',
 d:p=>`Viaje a Asia con la Selección por un amistoso. Tu club te pide que te hagas el lesionado para no ir.`,
 c:[
  {t:'Vas igual', ef:{rep:8, fanLove:12, fitness:-8, mgrRel:-8, forma:-4}, r:'La camiseta por encima de todo y treinta y seis horas de avión en cinco días. Volvés el viernes y jugás el sábado peor que nunca.'},
  {t:'Le hacés caso al club y te quedás', ef:{mgrRel:8, fitness:6, rep:-8, fanLove:-6}, r:'Priorizás a quien te paga y te inventás una molestia que no tenés. En tu país lo publica un diario con la palabra «falso» en el título.'},
  {t:'Vas y acordás jugar sólo un tiempo', ef:{com:6, pas:2, mgrRel:-4, rep:-3, fitness:-4}, r:'Solución diplomática que deja a los dos a medias. Jugás cuarenta y cinco minutos malos y viajás igual las dieciocho horas.'} ]},

{id:'nw64', w:2, st:['asc','ple'], when:p=>p.nt.caps>0,
 t:'El gol con la mano',
 d:p=>`Metés un gol con la mano en el minuto 90 que le da el triunfo a tu Selección. El árbitro no lo ve y lo convalida.`,
 c:[
  {t:'Festejás y no decís nada', ef:{moral:10, fanLove:14, rep:-6, trait:'polemico'}, r:'Triunfo clave y una foto de la mano que va a existir para siempre. Te aman adentro y te odian afuera, y las dos cosas duran décadas.'},
  {t:'Le confesás al árbitro que fue mano', ef:{rep:16, fanLove:-12, moral:-6, mgrRel:-8}, r:'Anula el gol y empatan. En tu país te destrozan durante un mes y tus compañeros tardan más que la prensa en perdonarte.'},
  {t:'Decís en la nota que fue la mano de Dios', ef:{hype:16, rep:2, fanLove:-4, com:-4}, r:'Frase para los diarios del lunes y para tres libros. Te define más que cualquier cosa que hayas hecho con los pies.'} ]},

{id:'nw65', w:2, st:['ple','vet'],
 t:'Tres mil seiscientos metros',
 d:p=>`Eliminatorias en la altura. A los quince minutos falta el aire y el mareo es difícil de explicar.`,
 c:[
  {t:'Tubo de oxígeno en cada parate y dosificás', ef:{com:8, pas:4, fis:-3, fanLove:-4}, r:'Cabeza fría para jugar sin pulmones y cero recorrido. Los de acá te silban cada vez que caminás.'},
  {t:'Pateás de afuera: la pelota no dobla', ef:{peg:5, def:3, pas:-3}, r:'Metés un golazo de treinta y cinco metros y tirás otras cinco a la tribuna. Empatan y alcanza.'},
  {t:'Pedís el cambio a los cuarenta, fundido', ef:{fitness:6, moral:-6, rep:-4, mgrRel:-5}, r:'La altura te ganó delante de todo el continente. El técnico no te lleva a la fecha siguiente, que también es en altura.'} ]},

{id:'nw66', w:3, st:['ple','vet'],
 t:'La tanda de penales del Mundial',
 d:p=>`Cuartos de final. Penales. El técnico busca con la mirada al que patea el quinto.`,
 c:[
  {t:'Te ofrecés para el quinto', ef:{rep:4}, tira:'com', mas:2,
   bien:{ef:{rep:12, moral:16, fanLove:20, trait:'hielo'}, r:'Cruzado, abajo. Clasificación histórica. Tu nombre no se olvida más.'},
   mal:{ef:{moral:-20, fanLove:-16, forma:-12}, r:'Palo y afuera. Un país entero en silencio y tu cara en la repetición durante cuatro años.'},
   r:'Levantás la mano antes de que te miren a vos.'},
  {t:'Pedís patear el primero', ef:{com:6, rep:4, moral:-3}, r:'Lo metés limpio y le das tranquilidad al resto. El quinto lo erra un pibe de veintiuno y lo abrazás sabiendo que podías haber sido vos.'},
  {t:'Preferís que patee un especialista', ef:{com:2, moral:-8, lid:-5, fanLove:-5}, r:'Le dejás el lugar a otro y se nota en el banco quién lo pidió y quién no. Nadie lo dice y todos lo vieron.'} ]},

{id:'nw67', w:2, st:['asc','ple'],
 t:'El himno a capela',
 d:p=>`Falla el sonido del estadio y el himno se corta a los cinco segundos. Cuarenta mil personas lo siguen cantando solas.`,
 c:[
  {t:'Lo gritás abrazado a tus compañeros', ef:{moral:14, fanLove:16, com:-4, forma:-3}, r:'Piel de gallina y salen a comérselos crudos. A los diez minutos ya están amonestados tres y el partido se les va de las manos.'},
  {t:'Mantenés la concentración táctica', ef:{com:6, forma:4, fanLove:-6, moral:-3}, r:'Cabeza fría en ambiente caliente. En la foto de las cuarenta mil gargantas, vos estás mirando al lateral rival.'},
  {t:'Mirás la tribuna hasta que se te caen las lágrimas', ef:{fanLove:12, moral:8, forma:-5, com:-4}, r:'Foto de portada en todos lados. Arrancás el partido dos marchas atrás y te sacan a los sesenta.'} ]},

{id:'nw68', w:2, st:['ple','vet'],
 t:'La camiseta de la leyenda',
 d:p=>`Termina el partido contra una potencia y la figura rival te busca a vos para cambiar camisetas.`,
 c:[
  {t:'Se la das y te ponés la de él ahí mismo', ef:{rep:8, hype:10, fanLove:-8}, r:'Reconocimiento de igual a igual delante de las cámaras. En tu país se discute tres días por qué te ponés esa camiseta.'},
  {t:'Se la das pero guardás la de él sin ponértela', ef:{rep:4, fanLove:4, hype:-4}, r:'Respeto por tu propia camiseta. Él lo nota y no te vuelve a buscar en los tres partidos que se cruzan.'},
  {t:'Le decís que la vas a subastar para un hospital', ef:{fanLove:16, rep:10, capital:-0.2, moral:6}, r:'El gesto se cuenta en todo el mundo. La subasta la organizás vos, la pagás vos y da menos de lo que esperabas.'} ]},

{id:'nw69', w:2, st:['asc','ple','vet'],
 t:'Los premios que no llegaron',
 d:p=>`La Federación no pagó los premios por clasificar al Mundial. El plantel evalúa no salir a entrenar.`,
 c:[
  {t:'Firmás el comunicado y encabezás el reclamo', ef:{lid:10, rep:6, fanLove:10, mgrRel:-8, hype:8}, r:'Consiguen que les paguen también a los utileros y a los juveniles. La Federación te deja afuera de la próxima gira comercial.'},
  {t:'Proponés jugar igual y reclamar después', ef:{rep:8, fanLove:12, lid:-4, moral:-4}, r:'La gente primero y el reclamo nunca. Ocho meses más tarde los utileros siguen sin cobrar y ya nadie firma nada.'},
  {t:'Te mantenés neutral', ef:{mgrRel:5, moral:-6, lid:-6, rep:-4}, r:'Quedás mal con el plantel sin quedar bien con nadie. En la próxima votación no te preguntan.'} ]},

{id:'nw70', w:2, st:['ple','vet'],
 t:'Deportista del año',
 d:p=>`Te dan el premio al mejor deportista del año, en una cena con atletas de todas las disciplinas.`,
 c:[
  {t:'Se lo dedicás a tus viejos y a tu club de barrio', ef:{fanLove:18, moral:12, rep:8, hype:-4}, r:'Aplauden de pie en un salón lleno de gente que no juega al fútbol. Tu club actual manda un tuit tarde y sin foto.'},
  {t:'Se lo dedicás al plantel de la Selección', ef:{lid:8, rep:6, fanLove:-5}, r:'Liderazgo colectivo y una frase que no recuerda nadie. En tu ciudad esperaban que los nombraras.'},
  {t:'Agradecés rápido y volvés al hotel', ef:{rep:2, forma:4, fanLove:-8, hype:-8}, r:'Perfil bajo y ocho horas de sueño. Al otro día el titular es que te fuiste antes de la cena.'} ]},

{id:'nw71', w:3, st:['oca'], when:p=>p.age>=33,
 t:'El cuerpo pide cuarenta y ocho horas más',
 d:p=>`Jugaste noventa minutos el domingo. El martes te levantás y bajar la escalera duele.`,
 c:[
  {t:'Pileta y kinesiología, sin pisar la cancha', ef:{fitness:8, com:6, forma:-4, mgrRel:-4}, r:'Inteligencia de veterano. Los martes entrenás solo en la pileta mientras el resto juega el picado que era lo único que te gustaba.'},
  {t:'Infiltración y a la par de los de veinte', ef:{forma:8, moral:4, fitness:-12, trait:'cristal', mem:{infiltraciones:1}}, r:'Orgullo puro y una rodilla que se hincha cada jueves. El cuerpo te lo va a cobrar en tres meses, con intereses.'},
  {t:'Pedís no viajar a los partidos más lejanos', ef:{fitness:10, mgrRel:6, fanLove:-6, lid:-4}, r:'Administración inteligente de los minutos. En dos canchas de visitante te empiezan a cantar que no fuiste.'} ]},

{id:'nw72', w:2, st:['oca'], when:p=>p.age>=34,
 t:'El pibe que te hace un caño',
 d:p=>`Un juvenil de diecisiete entra al picado, te tira un caño y sale festejando. Hace quince años vos eras ese pibe.`,
 c:[
  {t:'Lo felicitás y le enseñás a cubrir la pelota', ef:{lid:10, rep:6, forma:-4, moral:-3, trait:'lider'}, r:'Pase de posta en un picado de martes. En abril te gana el puesto con la jugada que le enseñaste.'},
  {t:'En la jugada siguiente lo atendés con un cuerpo a cuerpo limpio', ef:{fis:3, moral:6, mgrRel:-4, lid:-3}, r:'Queda en el piso sin protestar y aprende algo. Tres compañeros de veinte años lo levantan y ninguno te mira.'},
  {t:'Pedís que lo saquen del entrenamiento', ef:{moral:-8, mgrRel:-8, lid:-6, fanLove:-4, trait:'polemico'}, r:'Lo sacan. El vestuario entero entiende exactamente qué acaba de pasar y nadie hace un chiste en toda la tarde.'} ]},

{id:'nw73', w:3, st:['oca'], when:p=>p.age>=35,
 t:'La decisión',
 d:p=>`Fin de temporada. El teléfono no suena con nada interesante y el cuerpo tiene su propia opinión.`,
 c:[
  {t:'Anunciás el retiro en conferencia', ef:{moral:14, fanLove:20, rep:10, retiro:1}, r:'Despedida de rey y una sala llena. Esa misma tarde, tres clubes que no habían llamado dicen en privado que te habrían llamado en agosto.'},
  {t:'Seis meses más en el club de tu infancia, gratis', ofr:{t:'chico',cuando:'ya'}, ef:{fanLove:25, moral:16, wage:-50, capital:-0.3, rep:-5, trait:'idolo'}, r:'Último baile donde empezó todo, en canchas sin tribuna visitante. Pagás vos el micro de la última fecha.'},
  {t:'Te retirás con un comunicado escrito', ef:{moral:8, com:8, fanLove:-10, hype:-8, retiro:1}, r:'Sin show ni lágrimas públicas. Nadie te aplaude nunca y tu vieja te pregunta durante años por qué no la dejaste ir a una despedida.'} ]},

{id:'nw74', w:2, st:['vet','oca'], when:p=>p.age>=32 && (p.capital||0)>=0.5,
 t:'El partido a beneficio',
 d:p=>`Organizás un partido de amigos y retirados para juntar fondos para el hospital de niños de tu ciudad.`,
 c:[
  {t:'Traés a las figuras con las que jugaste', ef:{rep:10, capital:-0.5, fanLove:18, forma:-5}, r:'Lo televisan a todo el país y recaudan un récord. Te comés cuarenta llamadas y dos semanas de organización en plena temporada.'},
  {t:'Lo hacés sólo con la gente de tu primer club', ef:{fanLove:14, moral:10, capital:-0.2, hype:-4}, r:'Noche familiar en una cancha para tres mil personas. Se junta un cuarto de lo que se hubiera juntado y alcanza para dos aparatos.'},
  {t:'Donás el doble de lo recaudado', ef:{capital:-1.5, fanLove:20, moral:12}, r:'El hospital compra lo que necesitaba. Tu contador te llama al día siguiente y te lee en voz alta cuánto era el doble.'} ]},

{id:'nw75', w:2, st:['oca'], when:p=>p.age>=34,
 t:'El llamado del lunes',
 d:p=>`No pasaron cuarenta y ocho horas de tu último partido y el presidente te ofrece dirigir al primer equipo.`,
 c:[
  {t:'Aceptás sin escalas', ef:{rep:8, moral:10, hype:12, com:-5, retiro:1}, r:'Del vestuario al banco de un salto, con los mismos que ayer eran tus compañeros. A los cuatro meses tenés que dejar afuera al que te prestaba la campera.'},
  {t:'Pedís un año para estudiar y prepararte', ef:{com:8, rep:-4, hype:-8, trait:'profesional'}, r:'Decisión sabia: dirigir se aprende. Contratan a otro y cuando estás listo, el puesto tiene dueño.'},
  {t:'Rechazás: querés estar con tu familia', ef:{moral:10, fanLove:4, rep:-6, hype:-10}, r:'Paz bien ganada después de veinte años. En marzo, mirando un partido cualquiera por televisión, te agarra algo raro en el pecho.'} ]},

{id:'nw76', w:2, st:['oca'], when:p=>p.age>=33,
 t:'Las primeras canas',
 d:p=>`Te mirás al espejo antes del partido y ahí están, en la barba. En la tele ya te dicen «el abuelo».`,
 c:[
  {t:'Te teñís de platinado con los pibes', ef:{hype:12, moral:6, fanLove:6, rep:-5}, r:'Te sacás cinco años de encima en la foto y ninguno en la cancha. Dos programas hacen una hora con eso.'},
  {t:'Las lucís con orgullo', ef:{rep:6, lid:6, com:6, hype:-6}, r:'Estampa de tipo que ya vio todo. La palabra «abuelo» pasa de ser una broma a ser una descripción y aparece en las previas.'},
  {t:'Te rapás a cero', ef:{fis:2, moral:4, fanLove:-3}, r:'Cara nueva para el tramo final. Tu hijo tarda tres días en acostumbrarse y te lo dice.'} ]},

{id:'nw77', w:2, st:['oca'], when:p=>p.age>=34,
 t:'El cuarto de las camisetas',
 d:p=>`Tu pareja arma una habitación con todas las camisetas que intercambiaste, enmarcadas.`,
 c:[
  {t:'Te quedás dos horas mirándolas', ef:{moral:14, com:8, forma:-4}, r:'Veinte años en las paredes de una sola habitación. Bajás a cenar callado y no podés explicar por qué.'},
  {t:'Donás las más valiosas para una subasta', ef:{fanLove:16, rep:8, capital:-0.2, moral:-6}, r:'Tu generosidad vuelve a ser noticia. La de tu debut se va con las otras por error y no la recuperás nunca.'},
  {t:'Te sacás una foto ahí y la subís', ef:{hype:14, fanLove:10, com:-4}, r:'Te contestan colegas de todo el mundo. Tu pareja, que armó la habitación, se entera de que existe por Instagram.'} ]},

{id:'nw78', w:2, st:['oca'], when:p=>p.age>=33,
 t:'El último córner',
 d:p=>`Minuto 93 de tu último partido. Córner a favor. Lo vas a patear vos y el estadio entero está de pie.`,
 c:[
  {t:'Buscás la cabeza del central', ef:{moral:2}, tira:'peg', mas:2,
   bien:{ef:{moral:16, fanLove:20, pas:2, trait:'clutch'}, r:'Asistencia de gol en el último minuto de tu carrera. Final de película, y encima ganan.'},
   mal:{ef:{moral:-8, fanLove:2, forma:-4}, r:'Se va larguísima y muere en la tribuna de arriba. Te aplauden igual, que es exactamente lo que no querías.'},
   r:'Levantás el brazo y tomás carrera.'},
  {t:'Le pegás directo al arco', ef:{hype:14, fanLove:10, moral:-4}, r:'Casi entra: la saca el arquero con los dedos. Despedida a pura audacia y una jugada que vas a rever mil veces.'},
  {t:'Se la tocás corta al lateral', ef:{com:6, forma:4, fanLove:-8, hype:-6}, r:'Cabeza fría hasta el último segundo. Sesenta mil personas de pie esperando un final y les diste un pase de tres metros.'} ]},

{id:'nw79', w:2, st:['oca'], when:p=>p.age>=34,
 t:'La cabina de televisión',
 d:p=>`Una cadena internacional te ofrece tres años como comentarista estrella cuando cuelgues los botines.`,
 c:[
  {t:'Firmás el contrato', ef:{capital:1.5, rep:6, hype:10, forma:-5}, r:'Tu trabajo después del fútbol, resuelto en abril. Los últimos tres meses de jugador los pasás pensando en cámaras.'},
  {t:'Preferís el panel de debate', ef:{hype:16, capital:1.0, rep:-8, trait:'polemico'}, r:'Show asegurado todas las noches. En dos años ya no sos un ex jugador: sos el que opina.'},
  {t:'Rechazás: no te gusta hablar de colegas', ef:{rep:8, com:6, capital:-0.1, hype:-10}, r:'Perfil bajo e intachable, y un año entero sin saber de qué vas a vivir. El puesto se lo dan a uno con la mitad de tus partidos.'} ]},

{id:'nw80', w:3, st:['oca'], when:p=>p.age>=35,
 t:'El aplauso del rival',
 d:p=>`Te sacan a los ochenta en la cancha del clásico rival, en tu última visita. El estadio entero se pone de pie.`,
 c:[
  {t:'Levantás las manos y agradecés', ef:{rep:18, fanLove:-6, moral:14, trait:'idolo'}, r:'Trascendiste los colores. En tu propia hinchada hay un sector que no te lo perdona y saca una bandera el domingo siguiente que se lee desde la platea.'},
  {t:'Salís mirando el piso', ef:{com:6, moral:4, rep:-6, fanLove:-4}, r:'Respeto en silencio que nadie lee como respeto. En los dos vestuarios interpretan otra cosa.'},
  {t:'Te tocás el escudo de tu club al salir', ef:{fanLove:12, rep:-6, hype:6, trait:'polemico'}, r:'Los aplausos se transforman en silbidos en tres segundos. Tu hinchada te canta el nombre durante una semana y la otra te lo va a cobrar para siempre.'} ]},

{id:'nw81', w:2, st:['asc','ple'],
 t:'El perro en la cancha',
 d:p=>`Un perro entra a la cancha en pleno partido y corre hacia vos moviendo la cola. El juego se detiene tres minutos.`,
 c:[
  {t:'Lo alzás y lo sacás con cuidado', ef:{fanLove:14, hype:8, forma:-4}, r:'La foto recorre el mundo. Te comés tres minutos parado en el momento en que el equipo estaba mejor, y el partido se enfría.'},
  {t:'Le jugás con la pelota un rato', ef:{moral:10, fanLove:10, mgrRel:-6, forma:-4}, r:'Momento simpático que le saca presión a todos, incluido al rival, que estaba ahogado. El técnico te lo dice en el entretiempo.'},
  {t:'Pedís que lo saquen rápido', ef:{forma:4, com:4, fanLove:-8, moral:-3}, r:'Lo sacan a los empujones y se ve. En redes queda el clip de vos señalando al perro y no vas a poder explicarlo nunca.'} ]},

{id:'nw82', w:2, st:['ple','vet'],
 t:'Treinta y ocho y medio de fiebre',
 d:p=>`Te levantás el domingo con fiebre y anginas. El médico sugiere no jugar. Es el partido del año.`,
 c:[
  {t:'Jugás infiltrado y metés dos', ef:{fanLove:16, moral:14, fitness:-12, forma:-6, trait:'clutch', mem:{infiltraciones:1}}, r:'Hazaña. Caés rendido en el vestuario y perdés cuatro kilos en una tarde. Estás dos semanas sin poder entrenar.'},
  {t:'Arrancás en el banco por si hacés falta', ef:{com:6, fitness:-4, fanLove:-4, mgrRel:2}, r:'Entrás veinte minutos con cuarenta de fiebre y no cambiás nada. Uso inteligente de lo poco que tenías, que igual era poco.'},
  {t:'Te quedás en la cama', ef:{fitness:6, moral:-6, fanLove:-8, mgrRel:-5}, r:'La salud primero. Pierden, y el resumen del lunes titula con tu ausencia en vez de con el partido.'} ]},

{id:'nw83', w:2, st:['asc','ple'],
 t:'El hincha que saltó al campo',
 d:p=>`En pleno festejo de un gol, un hincha esquiva a seguridad, salta a la cancha y te tacklea de un abrazo.`,
 c:[
  {t:'Lo abrazás y le das tu camiseta antes de que se lo lleven', ef:{fanLove:18, moral:10, hype:10, rep:-4, capital:-0.05}, r:'Se va detenido y feliz. La multa del club por la camiseta la pagás vos y la sanción por invasión la paga el club.'},
  {t:'Pedís que no le peguen', ef:{lid:6, fanLove:12, rep:4, forma:-3}, r:'Liderazgo en diez segundos y una discusión con el jefe de seguridad que se estira hasta el entretiempo.'},
  {t:'Te asustás y lo empujás', ef:{fanLove:-8, moral:-4, hype:4, com:-3}, r:'Comprensible, y en la repetición a velocidad lenta queda feo. Lo pasan una semana entera en todos los programas.'} ]},

{id:'nw84', w:2, st:['ple','vet'],
 t:'El botín roto',
 d:p=>`Se te despega la suela del botín derecho a los diez minutos y no tenés otro par igual en el banco.`,
 c:[
  {t:'Jugás con unos prestados de otro color', ef:{com:6, forma:4, fis:-3, hype:-3}, r:'Te adaptás sin drama y con el pie derecho apretado. Terminás el partido rengueando de una ampolla, no de un golpe.'},
  {t:'Lo atás con cinta aisladora', ef:{moral:6, fanLove:8, forma:-5}, r:'Remedio de potrero que aguanta doce minutos. Después la suela se abre del todo y jugás media hora resbalando.'},
  {t:'Mandás a buscar un par a tu casa', ef:{hype:4, forma:-6, mgrRel:-5}, r:'Quince minutos jugando con lo que había. El técnico gasta un cambio pensando que estabas lesionado.'} ]},

{id:'nw85', w:2, st:['asc','ple'],
 t:'El reloj de oro',
 d:p=>`Después de un amistoso en Asia, el presidente del club rival te regala un reloj de ochenta mil dólares en el vestuario.`,
 c:[
  {t:'Lo aceptás y le das tu camiseta enmarcada', ef:{capital:0.08, rep:6, hype:8, mgrRel:-4}, r:'Relaciones excelentes y una foto que da la vuelta al continente. Tu club tiene que explicar por qué un jugador suyo acepta regalos del rival.'},
  {t:'Donás lo que vale a un hospital de tu ciudad', ef:{fanLove:20, moral:14, rep:10, capital:-0.08}, r:'Noticia internacional. El reloj no se podía vender tan rápido, así que la plata la ponés vos y esperás cuatro meses.'},
  {t:'Lo rechazás por política del club', ef:{com:4, mgrRel:4, rep:-3, hype:-4}, r:'Ajustado a las normas y a nadie le gusta. El presidente que te lo regaló no vuelve a mandar una invitación.'} ]},

{id:'nw86', w:2, st:['ple','vet'],
 t:'El grito en el túnel',
 d:p=>`Camino al segundo tiempo, el técnico rival te insulta buscando que reacciones y te echen.`,
 c:[
  {t:'Sonreís, lo mirás y no decís nada', ef:{com:10, rep:6, moral:-3}, r:'Mente de acero. Le metés dos en el segundo tiempo y él termina el partido gritándole a su propio banco.'},
  {t:'Le respondés con altura delante de las cámaras', ef:{hype:8, lid:4, mgrRel:-5, forma:-4}, r:'Firmeza de capitán y quince minutos de cabeza en otra cosa. Arrancás el segundo tiempo dos marchas atrás.'},
  {t:'Se la vas a cobrar ahí mismo', ef:{moral:-2}, tira:'com', mas:-4,
   bien:{ef:{moral:4, rep:-2}, r:'Los separan a tiempo. Queda un empujón en tres cámaras y una advertencia del delegado.'},
   mal:{ef:{moral:-12, mgrRel:-14, forma:-8, rep:-4}, r:'Te expulsan en el túnel, antes de que arranque el segundo tiempo. Tres fechas por una frase que él dijo a propósito.'},
   r:'Vas hasta donde está y le hablás a diez centímetros.'} ]},

{id:'nw87', w:2, st:['asc','ple'],
 t:'El apagón',
 d:p=>`Se cortan los reflectores a los ochenta minutos y tardan una hora en volver. Treinta mil personas esperan a oscuras.`,
 c:[
  {t:'Hacés jueguitos con la luz de los celulares', ef:{fanLove:14, hype:12, fitness:-5, forma:-4}, r:'Show inolvidable que transmiten en vivo. Volvés al partido frío después de una hora y te rompés el gemelo a los tres minutos de reanudar.'},
  {t:'Te ponés a estirar para no enfriarte', ef:{fitness:4, com:4, forma:4, fanLove:-6}, r:'Profesionalismo puro en la oscuridad. Treinta mil personas esperando algo y el único que se movió lo hizo mirando al piso.'},
  {t:'Armás una caminata del equipo a saludar a la gente', ef:{fanLove:16, lid:6, fitness:-4, mgrRel:-4}, r:'Agradecimiento por la paciencia y cuarenta minutos de pie sobre el césped frío. El preparador no quería a nadie caminando.'} ]},

{id:'nw88', w:2, st:['ple','vet'],
 t:'La camiseta embarrada',
 d:p=>`Un refuerzo nuevo sale al segundo tiempo con la camiseta del primero, toda embarrada.`,
 c:[
  {t:'Le avisás en el túnel y le conseguís una limpia', ef:{lid:6, moral:4, mgrRel:4, forma:-3}, r:'Le salvás el papelón y entrás vos treinta segundos tarde al segundo tiempo. El técnico te grita sin saber por qué fue.'},
  {t:'Te reís con el resto del banco', ef:{moral:6, lid:-4, mgrRel:-2}, r:'Chiste de vestuario para tres semanas. Él lo escucha desde el campo y se da vuelta a mirar quién se ríe.'},
  {t:'Dejás que entre así', ef:{com:-2, lid:-4, mgrRel:-4}, r:'El árbitro lo hace salir a cambiarse y juegan cuatro minutos con uno menos. Les hacen el gol del empate en esos cuatro minutos.'} ]},

{id:'nw89', w:2, st:['asc','ple'],
 t:'El comercial en tu potrero',
 d:p=>`Grabás un comercial internacional y pedís que lo filmen en la canchita donde empezaste.`,
 c:[
  {t:'Contratás a tus vecinos como extras', ef:{fanLove:18, moral:12, capital:-0.3, forma:-4}, r:'El barrio entero de fiesta durante dos días de filmación. La productora te descuenta a los extras del caché y no lo discutís.'},
  {t:'Donás lo que cobrás para iluminar la canchita', ef:{fanLove:22, moral:14, rep:8, capital:-0.25}, r:'Ahora se juega de noche donde vos aprendiste. La obra sale el doble de lo que cobraste y la diferencia la ponés vos.'},
  {t:'Filmás rápido y salís en helicóptero', ef:{hype:10, capital:0.4, fanLove:-10, moral:-5}, r:'Doce horas en total, contando el vuelo. En el barrio se quedan con la imagen del helicóptero y no con la del comercial.'} ]},

{id:'nw90', w:2, st:['ple','vet'],
 t:'El taco sobre la línea',
 d:p=>`La pelota va entrando despacio. Podés empujarla de taco o dejar que entre sola y que el gol sea de tu compañero.`,
 c:[
  {t:'La empujás para que el gol sea tuyo', ef:{def:2, moral:4, fanLove:-4, mgrRel:-4, lid:-5}, r:'El gol es tuyo en la planilla y en la tabla de goleadores. En el vestuario alguien lo anota también, en otra tabla.'},
  {t:'La dejás entrar y lo abrazás a él', ef:{moral:8, lid:6, mgrRel:6, pas:2, def:-2}, r:'Un gesto que el vestuario no olvida. A fin de año terminás a dos goles del premio al goleador.'},
  {t:'La asegurás de cabeza', ef:{moral:6, aer:2, lid:-3}, r:'Sin lujos y sin riesgo. Se discute media hora en la mesa de los sábados a quién correspondía el gol, y no queda claro.'} ]},

{id:'nw91', w:2, st:['asc','ple'],
 t:'El analista obsesivo',
 d:p=>`Un integrante nuevo del cuerpo técnico te manda cuarenta y cinco minutos de video a las once de la noche, sobre los movimientos del lateral rival.`,
 c:[
  {t:'Lo mirás entero y tomás notas', ef:{pas:3, def:3, mgrRel:8, fitness:-4, moral:-3}, r:'El domingo le ganás la espalda cuatro veces seguidas. Te acostaste a las dos y a partir de esa noche te manda video todas las semanas.'},
  {t:'Le pedís un resumen de tres minutos', ef:{com:4, mgrRel:-3, pas:1}, r:'Te lo hace y le sale peor: el detalle que servía estaba en el minuto treinta y uno. Igual le ganás dos veces.'},
  {t:'Lo dejás en visto y te dormís', ef:{fitness:4, mgrRel:-6, forma:-4}, r:'Elegís el sueño. El lateral te come la espalda dos veces y en el video del lunes se ve que estaba todo avisado.'} ]},

{id:'nw92', w:2, st:['ple','vet'],
 t:'La promesa en la radio',
 d:p=>`En la previa de la final prometés en la radio que si salen campeones te rapás en el medio de la cancha.`,
 c:[
  {t:'Salen campeones y te rapás ahí mismo', ef:{fanLove:16, moral:12, hype:10, com:-4}, r:'Cumplís en vivo para todo el país, con una máquina prestada y en pleno festejo. Tres meses después todavía te lo piden en cada nota.'},
  {t:'Te hacés un corte cómico y nada más', ef:{fanLove:8, moral:6, rep:-3}, r:'Cumplís a medias y se nota que es a medias. La radio lo repite con la promesa original de fondo.'},
  {t:'No te rapás: era un chiste', ef:{fanLove:-8, rep:-4, com:4, hype:-4}, r:'Te tratan de arrugador durante semanas. Es un tema menor y aparece en la previa de los tres partidos siguientes.'} ]},

{id:'nw93', w:2, st:['asc','ple'],
 t:'El auto del auspiciante',
 d:p=>`Una marca de autos le regala un cero kilómetro a cada jugador del plantel.`,
 c:[
  {t:'Se lo regalás a tus viejos', ef:{moral:14, fanLove:8, capital:-0.1}, r:'Alegría familiar de las grandes. Tenés que pagar la transferencia y el seguro, y seguís yendo a entrenar en el de siempre.'},
  {t:'Lo vendés al día siguiente e invertís', ef:{capital:0.4, com:6, fanLove:-6, mgrRel:-4}, r:'Cabeza práctica. La marca se entera en una semana y no renueva el acuerdo con el plantel el año siguiente.'},
  {t:'Lo usás para ir a entrenar', ef:{hype:6, moral:4, capital:-0.05}, r:'Auto nuevo, impecable, igual al de los otros veinticuatro. En el estacionamiento del predio no se distingue el tuyo.'} ]},

{id:'nw94', w:2, st:['ple','vet'],
 t:'El penal en el clásico',
 d:p=>`Penal decisivo contra el eterno rival. Ese arquero es famoso por tirarse temprano.`,
 c:[
  {t:'La picás suave al medio', ef:{hype:6}, tira:'com', mas:4,
   bien:{ef:{moral:18, fanLove:20, rep:10, trait:'hielo'}, r:'Golazo descomunal. Se recuerda durante años y lo van a pasar cada vez que se juegue este clásico.'},
   mal:{ef:{moral:-18, fanLove:-14, mgrRel:-12, forma:-8}, r:'El arquero no se mueve y la agarra sin saltar. Papelón histórico, y elegido por vos.'},
   r:'Tomás carrera corta y decidís a mitad de camino.'},
  {t:'Le pegás fuerte abajo al palo', ef:{com:6, def:2, moral:6, hype:-4}, r:'Gol seguro y sin una historia que contar. En el resumen no lo pasan ni una vez.'},
  {t:'Frenás en la carrera para engañarlo', ef:{com:4, moral:4, rep:-3}, r:'Ejecución de manual y el arquero adivina el palo. Entra pegada al poste y te queda temblando la pierna hasta el final.'} ]},

{id:'nw95', w:2, st:['asc','ple'],
 t:'El árbitro en el supermercado',
 d:p=>`Te cruzás con el árbitro que te expulsó el domingo, haciendo las compras en tu barrio.`,
 c:[
  {t:'Lo saludás y se toman un café', ef:{rep:8, com:6, hype:-4}, r:'Se limpia el rencor entre las góndolas. Alguien los filma y al día siguiente hay que explicar por qué tomabas café con el árbitro que te expulsó.'},
  {t:'Le tirás una ironía entre las góndolas', ef:{rep:-4, moral:4, com:-3, trait:'polemico'}, r:'Se la come callado y la anota. En el próximo partido que te dirige, ninguna dudosa cae para tu lado.'},
  {t:'Te cambiás de pasillo', ef:{com:4, moral:-3}, r:'Perfil bajo y compra rápida. Te lo cruzás en la caja igual y ninguno de los dos sabe dónde mirar.'} ]},

{id:'nw96', w:2, st:['ple','vet'],
 t:'La canción con tu nombre',
 d:p=>`La hinchada le pone letra propia a una canción conocida, y la cantan cuarenta mil personas.`,
 c:[
  {t:'Agradecés a los cuatro costados', ef:{fanLove:18, moral:12, forma:-4, trait:'idolo'}, r:'Afecto que ya no se rompe. También una vara: cada partido flojo a partir de ahora se mide contra esa tarde.'},
  {t:'Te ponés la mano en el pecho en el centro de la cancha', ef:{fanLove:15, moral:10, com:-3}, r:'Gesto noble, con el partido parado por un córner y el técnico gritándote que te muevas.'},
  {t:'Te da vergüenza y te metés al vestuario', ef:{com:6, moral:4, fanLove:-10}, r:'Cuarenta mil personas cantando tu nombre y el túnel vacío. La canción se deja de cantar en tres semanas.'} ]},

{id:'nw97', w:2, st:['asc','ple'],
 t:'El póster de tu habitación',
 d:p=>`Jugás contra el tipo que tenías colgado en la pared a los diez años.`,
 c:[
  {t:'Lo esperás en la puerta del vestuario para pedirle la camiseta', ef:{moral:10, rep:4, com:-4, hype:-3}, r:'Te la da con un abrazo y te felicita por tu nivel. Después ves la foto y ves la cara que tenías: la de un pibe de diez años.'},
  {t:'Se la pedís en el entretiempo', ef:{moral:4, mgrRel:-5, forma:-4}, r:'Un poco ansioso. El técnico te pide concentración delante de todos y jugás el segundo tiempo pensando en eso.'},
  {t:'Esperás a que te la pida él', ef:{com:6, rep:6, moral:-5}, r:'Orgullo bien puesto. No te la pide, se va por el otro lado del túnel y no volvés a jugar contra él nunca.'} ]},

{id:'nw98', w:2, st:['ple','vet'],
 t:'La copa en la cama',
 d:p=>`Después de ganar el título más importante, te llevás el trofeo a la habitación del hotel y te sacás una foto durmiendo abrazado a él.`,
 c:[
  {t:'Subís la foto', ef:{hype:20, fanLove:16, rep:-5, com:-3}, r:'Un millón de reacciones en tres horas. Dos ex compañeros que perdieron la final la usan de meme y no lo dicen en broma.'},
  {t:'La dejás en el grupo familiar', ef:{moral:10, com:6, hype:-8}, r:'Para adentro. Alguien de la familia la filtra en seis horas y sale igual, pero recortada y con otra historia.'},
  {t:'Se la prestás al utilero para que se saque una igual', ef:{fanLove:14, lid:8, hype:-4, moral:6}, r:'Humildad de campeón. Se la saca solo, a las cuatro de la mañana, y la tiene de fondo de pantalla hasta que se jubila.'} ]},

{id:'nw99', w:2, st:['asc','ple','vet'],
 t:'El partido en el penal',
 d:p=>`El club organiza una visita y un partido de exhibición en la cárcel de la ciudad, como programa de reinserción.`,
 c:[
  {t:'Vas, jugás y te quedás una hora charlando', ef:{rep:10, fanLove:12, moral:-6, forma:-4}, r:'Volvés distinto de lo que fuiste y no dormís esa noche. Dos internos te cuentan cosas que te acompañan durante años.'},
  {t:'Donás pelotas y camisetas, pero no vas', ef:{rep:4, capital:-0.1, fanLove:-4}, r:'Aporte material que llega y sirve. En la foto del programa hay un cartel con tu nombre y una silla vacía.'},
  {t:'Pedís no ir por seguridad', ef:{com:4, moral:-6, fanLove:-6, mgrRel:-3}, r:'Comprensible y distante. Van seis compañeros y ninguno te pregunta por qué no fuiste.'} ]},

{id:'nw100', w:3, st:['oca'], when:p=>p.age>=35 && !!p.flags.padre,
 t:'De la mano',
 d:p=>`Último partido de tu carrera, en tu estadio. Salís del túnel llevando a tu hijo de la mano, con la camiseta del club.`,
 c:[
  {t:'Le decís al oído: «mirá todo esto»', ef:{moral:20, fanLove:25, rep:12, trait:'idolo', retiro:1}, r:'Sesenta mil personas de pie. Tiene seis años y dentro de veinte no va a acordarse de nada: te lo va a contar él, con las palabras que le pusiste vos.'},
  {t:'Le das la pelota para que haga un gol antes del pitazo', ef:{fanLove:22, moral:16, hype:14, rep:-4, retiro:1}, r:'El estadio entero le grita el gol a tu hijo. En dos programas discuten si estuvo bien, y él tiene edad para escucharlos.'},
  {t:'Caminás en silencio disfrutando el césped', ef:{com:10, moral:14, hype:-10, fanLove:-4, retiro:1}, r:'No decís una palabra en todo el recorrido. No hay foto, no hay frase y no hay nadie que pueda contarlo por vos.'} ]}

);
EVENTS.push(...EVENTS11);


const EVENTS12 = [

{id:'rc1', w:3, st:['ple','vet','oca'], when:p=>(p.mem&&p.mem.plantes||0)>=2,
 t:'La fama que te precede',
 d:p=>`Tu representante te lo dice sin vueltas: hay dos clubes que te quieren y los dos preguntaron primero por qué te fuiste de los últimos. No preguntaron por tus goles.`,
 c:[
  {t:'Lo asumís y lo explicás uno por uno', ofr:{t:'menor',cuando:'ventana'}, ef:{com:8, rep:4, moral:-6, hype:-5}, r:'Dos llamadas largas y honestas. Uno te ofrece contrato para el mercado, con un año menos del que te iba a ofrecer.'},
  {t:'Cambiás de representante para cambiar el relato', ef:{hype:6, wage:-8, com:-4, rep:-3}, r:'El nuevo mueve el mercado y cuenta otra historia. La anterior te la van a preguntar en la primera conferencia igual.'},
  {t:'Te quedás donde estás y lo aguantás dos años', ef:{fanLove:10, mgrRel:10, moral:-8, contrato:2}, r:'Firmás por dos años en un lugar que no elegiste. Es la primera vez que la reputación te elige el club a vos.'}
 ]},

{id:'rc2', w:3, st:['vet','oca'], when:p=>(p.mem&&p.mem.infiltraciones||0)>=2,
 t:'La cuenta de las infiltraciones',
 d:p=>`El médico nuevo pide la historia clínica entera y se queda callado leyéndola. Después te pregunta, sin levantar la vista, cuántas veces jugaste sabiendo que no tenías que jugar.`,
 c:[
  {t:'Se lo contás todo y le entregás el cuerpo', ef:{fitness:14, com:8, forma:-8, mgrRel:-6}, r:'Te arma un plan de cuatro meses que incluye no jugar seis partidos. Se lo tiene que explicar él al técnico porque vos no podés.'},
  {t:'Le decís que no llevás la cuenta', ef:{mgrRel:6, forma:6, fitness:-10, moral:-8}, r:'Te deja jugar todo y es mentira: la llevás. Sabés el número exacto y sabés en qué partido fue cada una.'},
  {t:'Pedís una infiltración más, la última', ef:{forma:8, fanLove:8, fitness:-14, trait:'cristal'}, r:'La última es siempre la última. Jugás el partido y en abril no podés apoyar el pie para bajar del auto.'}
 ]},

{id:'rc3', w:3, st:['ple','vet'], when:p=>(p.mem&&p.mem.polemicas||0)>=2,
 t:'Ya no te llaman para hablar de fútbol',
 d:p=>`Repasás las últimas seis notas que diste y en ninguna te preguntaron por un partido. Un programa te ofrece una nota fija todas las semanas: buena plata, cero fútbol.`,
 c:[
  {t:'Firmás la nota semanal', ef:{capital:0.6, hype:16, rep:-8, mgrRel:-8}, r:'Cobrás por opinar todos los martes. En dos años vas a ser un panelista que además juega, y va a ser difícil volver.'},
  {t:'Cortás con la prensa seis meses', ef:{forma:8, com:8, hype:-14, fanLove:-6}, r:'Seis meses de silencio absoluto. Escriben lo que quieren sin vos y la mitad de las veces les sale peor de lo que hubieras dicho.'},
  {t:'Pedís hablar sólo con quien te pregunte por el juego', ef:{rep:8, com:6, hype:-8, moral:-4}, r:'Quedan tres periodistas de treinta. Con esos tres hablás bien durante el resto de tu carrera.'}
 ]}

];
EVENTS.push(...EVENTS12);


const EVENTS13 = [

{id:'sx1', w:2, st:['ini'], when:p=>p.age<=19,
 t:'La charla en tu escuela vieja',
 d:p=>`La directora de tu escuela primaria te invita a hablarles a los chicos de sexto grado. Es el jueves a la mañana, el mismo día de la doble sesión, y ya les dijo a todos que vas.`,
 c:[
  {t:'Pedís permiso y vas', ef:{fanLove:8, lid:4, mgrRel:-5, forma:-3}, r:'Te preguntan cuánto ganás, si conocés a alguien famoso y si sabés hacer jueguitos. Hacés cuarenta en el patio donde aprendiste a hacer cinco.'},
  {t:'Mandás un video grabado en el vestuario', ef:{hype:4, com:2}, r:'Lo pasan en el televisor del aula y se corta dos veces. Un chico pregunta por qué no vino en persona y la maestra no sabe qué contestarle.'},
  {t:'Le decís que no vas', ef:{forma:4, mgrRel:3, moral:-5}, r:'La directora te dice que lo entiende, con la voz de cuando no entregabas la tarea. Entrenás bien, y a la tarde pasás por la puerta de la escuela sin mirar.'} ]},

{id:'sx2', w:2, st:['ini'], when:p=>p.age>=17 && p.age<=19,
 t:'El viaje de egresados',
 d:p=>`Tu curso se va diez días de viaje de fin de estudios y el torneo juvenil más importante del año cae justo en el medio. Tus compañeros de colegio juntan plata para ese viaje desde hace tres años.`,
 c:[
  {t:'Te vas con tu curso', ef:{moral:12, fanLove:-4, mgrRel:-12, forma:-6}, r:'Diez días sin botines. Volvés con una foto que vas a tener toda la vida, y en la foto del torneo hay otro pibe con tu camiseta.'},
  {t:'Te quedás a jugar el torneo', ef:{forma:6, mgrRel:8, com:3, moral:-8}, r:'Llegan a semifinales. Las fotos del viaje te las mandan de noche y en todas hay alguien parado donde tendrías que estar vos.'},
  {t:'Jugás el torneo y viajás solo para los dos últimos días', ef:{capital:-0.01, moral:5, fitness:-5}, r:'Pagás el pasaje con lo poco que tenés. Llegás cuando ya se contaron todas las historias y te las cuentan a vos, de apuro, la última noche.'} ]},

{id:'sx12', w:2, st:['ini','asc'], when:p=>p.age<=21,
 t:'La canchita que van a lotear',
 d:p=>`El potrero donde aprendiste a jugar, a tres cuadras de tu casa, lo compró una constructora. Los vecinos juntan firmas y quieren poner en el volante tu foto con la camiseta de ${C(p.club).n}.`,
 c:[
  {t:'Prestás la foto y vas a la marcha', ef:{fanLove:10, hype:5, mgrRel:-6}, r:'Salís en el noticiero local con un cartel hecho a mano. El club te llama para explicarte quién decide qué se hace con su camiseta. El edificio se construye igual, un año después.'},
  {t:'Ponés plata para el abogado de los vecinos', todo:true, ef:{capital:-0.01, fanLove:6, moral:4}, r:'Es poca plata y la reciben como si fuera mucha. El abogado pierde en primera instancia y te manda un mensaje larguísimo de agradecimiento.'},
  {t:'Decís que no te metés', ef:{mgrRel:3, com:2, fanLove:-8, moral:-4}, r:'Los vecinos lo entienden y te lo hacen saber. Cuando pasás por la cuadra, la reja nueva ya tiene el cartel de «Próximamente».'} ]},

{id:'sx13', w:2, st:['ini'], when:p=>p.age<=19,
 t:'La cuenta de fans que te inventa',
 d:p=>`Alguien abrió una cuenta dedicada a vos y ya tiene tres mil seguidores. Sube tus jugadas de juveniles con música épica y, cada tanto, publica una frase tuya que nunca dijiste.`,
 c:[
  {t:'Le escribís para agradecerle', ef:{hype:8, moral:4, com:-2}, r:'Resulta ser un chico de trece años de otra ciudad. A la semana publica «Palabras de él para ustedes», con otra frase que tampoco dijiste.'},
  {t:'Pedís que la cierren', ef:{com:3, hype:-6, fanLove:-4}, r:'La cierran en dos días. Abren otra, con menos seguidores y más enojada, que te dice traidor cada vez que perdés.'},
  {t:'No la mirás más', ef:{com:5, forma:2}, r:'La voluntad te dura nueve días. La décima noche la revisás entera en la cama, y la frase inventada de ese día es mejor que cualquiera que se te hubiera ocurrido.'} ]},

{id:'sx14', w:2, st:['ini'], when:p=>p.age<=19,
 t:'El acto de tu hermana',
 d:p=>`Tu hermana menor tiene el acto de fin de año en la escuela y le toca decir un poema. Es el sábado a las cuatro; vos jugás a las tres y media, a una hora de ahí.`,
 c:[
  {t:'Pedís salir en el entretiempo', ef:{moral:6, mgrRel:-8, forma:-3}, r:'El técnico te deja ir con una cara que vas a volver a ver. Llegás cuando ella está bajando del escenario y te pregunta si la escuchaste. Le decís que sí.'},
  {t:'Jugás y le pedís a tu viejo que lo grabe', ef:{forma:4, mgrRel:3, moral:-6}, r:'El video tiembla y se escucha más a tu tía que a ella. Lo mirás tres veces en el micro de vuelta, con el volumen al máximo.'},
  {t:'Faltás al partido', ef:{moral:10, mgrRel:-14, hype:-3}, r:'Te sentás en la primera fila y ella se equivoca en la segunda estrofa por mirarte. El lunes, en la práctica, te toca hacer de cono.'} ]},

{id:'sx15', w:2, st:['ini'], when:p=>p.age<=19,
 t:'Tu viejo contra el alambrado',
 d:p=>`Tu viejo se pasa los partidos colgado del alambrado discutiendo cada cambio del técnico de la categoría. El domingo le gritó el nombre completo, con apellido, y ahora el técnico te saluda sólo con la cabeza.`,
 c:[
  {t:'Le pedís que deje de venir un tiempo', ef:{mgrRel:8, com:3, moral:-10}, r:'No discute. Deja de venir y empieza a preguntarte por teléfono cómo te fue, siempre las mismas preguntas en el mismo orden, como si leyera una lista.'},
  {t:'Lo defendés delante del técnico', ef:{moral:6, lid:3, mgrRel:-12}, r:'El técnico escucha, asiente y el sábado te pone de suplente. Tu viejo, desde el alambrado, no grita nada en todo el partido.'},
  {t:'Le pedís disculpas vos al técnico', ef:{mgrRel:5, com:4}, r:'Te dice que no es tu culpa y que lo entiende, con la voz de alguien que no lo va a entender nunca. Tu viejo no se entera de que fuiste.'} ]},

{id:'sx20', w:2, st:['ini'], when:p=>p.age<=19,
 t:'Tu abuelo quiere ver una práctica',
 d:p=>`Tu abuelo, el que te llevó por primera vez a un club, te pide ver una práctica de ${C(p.club).n}. Las prácticas son a puertas cerradas y el técnico tiene fama de echar hasta a los periodistas.`,
 c:[
  {t:'Le pedís permiso al técnico', ef:{moral:8, mgrRel:-4}, r:'Te dice que sí con un gesto que no es del todo un sí. Tu abuelo mira la práctica entera parado, con las manos atrás, y a la salida te dice que corrés torcido.'},
  {t:'Lo metés por el portón de atrás', ef:{moral:10, mgrRel:-10, forma:-3}, r:'El utilero lo ve y se hace el distraído. El técnico también lo ve y no se hace nada: te hace correr hasta que tu abuelo se va.'},
  {t:'Le decís que venga a un partido mejor', ef:{mgrRel:2, moral:-6}, r:'Dice que claro, que no pasa nada. Al partido viene con una silla plegable y se sienta en la tribuna de enfrente, al sol, para no molestar.'} ]},

{id:'sx4', w:3, st:['ini'], when:p=>p.age<=19,
 t:'Cumpleaños en la pensión',
 d:p=>`Cumplís ${enLetras(p.age)} un martes, lejos de tu casa. En la pensión de ${C(p.club).n} hay una torta de supermercado con una sola vela y doce pibes que cantan mal a propósito.`,
 c:[
  {t:'Te pasás la noche en videollamada con tu casa', ef:{moral:8, lid:-3}, r:'Tu vieja pone el teléfono en el medio de la mesa para que veas la cena que hicieron igual. En la pensión se comen la torta sin vos.'},
  {t:'Te quedás con los pibes hasta tarde', ef:{moral:6, lid:4, forma:-4}, r:'Juegan a las cartas hasta las dos y el encargado apaga la luz desde el pasillo. A tu casa llamás al día siguiente y te atienden un poco más secos.'},
  {t:'Te acostás temprano: mañana hay partido', ef:{forma:5, com:3, moral:-6}, r:'Te dormís escuchando cómo terminan la torta en la cocina. A la mañana te guardaron una porción, con tu nombre escrito en una servilleta.'} ]},

{id:'sx19', w:3, st:['ini'], when:p=>p.age<=19,
 t:'La heladera de la pensión',
 d:p=>`En la pensión alguien viene sacando comida de la heladera compartida. Una noche lo ves: es el pibe que llegó desde más lejos, el que no recibe visitas y nunca tiene plata para la cantina.`,
 c:[
  {t:'No decís nada', ef:{com:3, moral:-5}, r:'Siguen faltando cosas y el encargado pone un candado. El pibe baja dos kilos en un mes y nadie hace la cuenta.'},
  {t:'Le avisás al encargado, sin dar el nombre', ef:{mgrRel:4, com:2, moral:-8}, r:'Ponen una cámara en la cocina. A la semana lo agarran a él, que en la pantalla se ve más chico de lo que es.'},
  {t:'Le empezás a dejar comida tuya', todo:true, ef:{capital:-0.01, lid:6, moral:4}, r:'Un táper con un papelito, todas las semanas. Nunca lo hablan. En la despedida de fin de año te regala una pulsera hecha con cordones de botín.'} ]},

{id:'sx3', w:2, st:['ini'], when:p=>p.age<=19,
 t:'El que te pisa en cada práctica',
 d:p=>`Hay un pibe en tu categoría que te pisa en cada práctica. No en los partidos: los martes, cuando no mira nadie. Ya tenés el tobillo del color de una berenjena.`,
 c:[
  {t:'Se la devolvés en la próxima dividida', ef:{fis:3, moral:4, mgrRel:-6, fitness:-4}, r:'Terminan los dos en el piso y el técnico los manda juntos a las duchas. En la ducha no se hablan; el martes siguiente, tampoco se pisan.'},
  {t:'Se lo decís al técnico', ef:{mgrRel:4, com:2, lid:-4, moral:-3}, r:'Lo sienta una semana. El resto de la categoría te trata con una amabilidad nueva, la que se usa con los que avisan.'},
  {t:'Le pedís que te marque él en los ejercicios', ef:{reg:4, com:3, fitness:-6}, r:'Un mes entero de patadas. Al final aprendés a soltar la pelota medio segundo antes, y él aprende a llegar medio segundo tarde.'} ]},

{id:'sx11', w:2, st:['ini'], when:p=>p.age<=19,
 t:'El cuaderno del técnico',
 d:p=>`Tu técnico de inferiores te da un cuaderno y te pide que anotes, después de cada práctica, una cosa que hiciste mal. Nada más. Dice que lo va a leer a fin de año.`,
 c:[
  {t:'Lo llenás todos los días', ef:{com:6, pas:3, moral:-3}, r:'A los tres meses te cuesta encontrar errores nuevos, y ahí está el truco. En diciembre lo hojea en dos minutos y te lo devuelve con una sola palabra escrita al final.'},
  {t:'Lo llenás todo la noche antes de dárselo', ef:{moral:3, mgrRel:-6}, r:'Veinte errores inventados con la misma birome y la misma letra apurada. Te lo devuelve sin abrirlo, que es como te enterás de que se dio cuenta.'},
  {t:'Le decís que preferís que te lo diga él', ef:{lid:4, rep:2, mgrRel:-3}, r:'Te mira un rato largo. Desde ese día te marca un error por práctica, en voz alta y delante de todos, y nunca repite el mismo.'} ]},

{id:'sx6', w:2, st:['ini'], when:p=>p.age<=19 && (p.capital||0)>=0.02,
 t:'La cena la pagás vos',
 d:p=>`Ya cobrás algo y en tu categoría hay una costumbre: el primero que cobra paga la cena de todos. Son veintidós y eligen el lugar más caro que conocen, que tampoco es tan caro.`,
 c:[
  {t:'Pagás todo, postre incluido', ef:{capital:-0.02, lid:6, moral:6}, r:'Veintidós milanesas y un mozo que te trata de señor. Se te va medio mes, y el grupo habla de vos un tiempo en tercera persona y bien.'},
  {t:'Proponés pizza en la pensión', ef:{capital:-0.01, moral:3, lid:-2}, r:'Cumplís a medias. Alguien dice «cena de rata» y el nombre queda, aunque te comés cuatro porciones igual que todos.'},
  {t:'Decís que esa costumbre es una estupidez', ef:{com:4, lid:-5, moral:-4}, r:'Tenés razón y lo sabe la mitad. La otra mitad se acuerda en el partido siguiente, cuando nadie te la da corta.'} ]},

{id:'sx18', w:2, st:['ini','asc'], when:p=>p.age<=21,
 t:'El pacto de los tres',
 d:p=>`Con dos compañeros de la categoría se prometieron, cuando eran chicos, que iban a debutar juntos el mismo día. El técnico de la primera de ${C(p.club).n} te sube a vos solo para el fin de semana.`,
 c:[
  {t:'Vas y no les decís nada todavía', ef:{forma:4, moral:-4, lid:-3}, r:'Se enteran por la lista pegada en la puerta. Uno te abraza, y el otro también, pero más corto.'},
  {t:'Se lo contás a ellos antes que a nadie', ef:{lid:4, moral:5}, r:'Te felicitan en la esquina de siempre con una gaseosa. A uno se le quiebra la voz a mitad de frase y lo disimula tosiendo.'},
  {t:'Le pedís al técnico que suba a uno de ellos', ef:{lid:6, moral:3, mgrRel:-10}, r:'Te mira como si le hubieras pedido las llaves del auto. Subís solo igual, y ahora el técnico sabe que sos de los que piden.'} ]},

{id:'sx7', w:2, st:['ini','asc'], when:p=>p.age<=21,
 t:'La charla técnica que no entendés',
 d:p=>`Te suben una semana a entrenar con la primera de ${C(p.club).n} y te meten en la charla técnica. El técnico habla veinte minutos de flechas, números y palabras que nunca escuchaste, y al final te señala: «Vos hacés lo que te dije».`,
 c:[
  {t:'Levantás la mano y preguntás', ef:{pas:3, mgrRel:5, moral:-5}, r:'Dos titulares se ríen por la nariz. El técnico te lo vuelve a explicar más despacio, con la misma cara que pone para anunciar el horario del micro.'},
  {t:'Le preguntás al capitán en el pasillo', ef:{pas:2, com:3}, r:'Te lo explica en diez segundos con un vaso de plástico y dos botellas. Era sencillo. Nunca vas a saber si era eso lo que había dicho el técnico.'},
  {t:'Asentís y hacés lo que te sale', ef:{reg:2, moral:4, mgrRel:-8}, r:'Jugás el ensayo como jugás en juveniles: bien y en cualquier lado. El técnico no te dice nada y el viernes estás de vuelta abajo.'} ]},

{id:'sx16', w:2, st:['ini'], when:p=>p.age>=16 && p.age<=19 && p.seasons.length<=1 && !p.loanFrom,
 t:'Hincha de toda la vida',
 d:p=>`Firmás tu primer contrato con ${C(p.club).n} y para la foto oficial te piden que digas que sos hincha de toda la vida. De chico tenías en tu pieza el póster del rival, y en tu barrio lo sabe todo el mundo.`,
 c:[
  {t:'Decís la frase como te la pasaron', ef:{contrato:3, fanLove:8, moral:-4}, r:'Sale en la web del club con tu foto sonriente. Esa noche un amigo del barrio te manda una foto del póster, que su hermana todavía tiene.'},
  {t:'Decís que desde hoy sos hincha', ef:{contrato:3, rep:4, com:3}, r:'Queda honesto y un poco frío. Algún hincha lo celebra y otro guarda la captura para el día que te vayas.'},
  {t:'Contás lo del póster con una sonrisa', ef:{contrato:3, hype:8, moral:4, fanLove:-8, mgrRel:-3}, r:'Se hace viral por el lado malo. En el club la mitad se ríe, y la otra mitad te lo va a recordar en tu primer error.'} ]},

{id:'sx8', w:2, st:['ini'], when:p=>p.age<=19 && p.rep>=10,
 t:'Compartís pieza con el enemigo',
 d:p=>`Te convocan a una concentración de la selección juvenil y te toca pieza con el capitán de la categoría del clásico rival. La última vez que se cruzaron le tiraste un caño y él te escupió cerca del botín.`,
 c:[
  {t:'Le proponés una tregua el primer día', ef:{lid:5, com:3}, r:'Te da la mano sin mirarte. La tercera noche te presta el cargador y ya no hay vuelta: van a ser amigos, y en el clásico se van a pegar igual.'},
  {t:'Pedís que te cambien de pieza', ef:{moral:3, mgrRel:-5, rep:-2}, r:'El utilero de la selección te mira como a un chico de jardín y te cambia. En la lista del torneo quedan los dos; en la foto del grupo, en puntas opuestas.'},
  {t:'No le hablás y dormís con un ojo abierto', ef:{com:4, forma:-4, fitness:-3}, r:'Cinco noches de silencio con el ventilador de fondo. Rinden peor los dos en los ensayos, y el cuerpo técnico anota sus nombres en el mismo renglón.'} ]},

{id:'sx10', w:3, st:['ini'], when:p=>p.age<=19,
 t:'El ojeador vino por otro',
 d:p=>`Todos saben que el hombre de campera gris en la tribuna vino a ver a tu compañero de ataque. Él también lo sabe, y está tan nervioso que en el calentamiento no le entra un pase.`,
 c:[
  {t:'Le das todas las pelotas', ef:{pas:3, lid:5, hype:-4}, r:'Juega el mejor partido de su vida con tus asistencias. Al mes se va, y en la despedida te agradece delante de todos, lo que no cambia quién se fue.'},
  {t:'Jugás para vos, que también te mira', ef:{reg:3, hype:6, moral:-4, lid:-4}, r:'Hacés dos y él ninguno. El de la campera gris anota algo que nunca vas a saber qué es, y tu compañero no te saluda en el vestuario.'},
  {t:'Lo calmás antes de salir y jugás normal', ef:{com:4, moral:3}, r:'Le decís una pavada que lo hace reír. Juega bien, vos jugás bien, y el ojeador se va en el entretiempo porque le llovía encima.'} ]},

{id:'sx9', w:2, st:['ini'], when:p=>p.age<=19 && !p.injuredWeeks,
 t:'El dolor que no contás',
 d:p=>`Hace dos semanas que te duele la rodilla cada vez que frenás. El sábado viene un ojeador de un club grande a verte a vos, y el kinesiólogo de la categoría para a cualquiera que renguee un poco.`,
 c:[
  {t:'Se lo decís al kinesiólogo', ef:{fitness:4, forma:-6, moral:-8, hype:-4}, r:'Te para tres semanas. El ojeador ve el partido desde la tribuna, anota otro nombre y se va antes del final.'},
  {t:'Jugás vendado y con la boca cerrada', ef:{fitness:-4}, tira:'fis', mas:0,
   bien:{ef:{hype:10, moral:8, rep:3}, r:'Hacés tu mejor partido del año con la rodilla caliente. El ojeador pregunta tu nombre, y el lunes no te podés levantar de la cama, pero eso ya no lo ve nadie.'},
   mal:{ef:{fitness:-18, moral:-10, mgrRel:-8}, r:'Al minuto veinte la rodilla dice que no. Salís en camilla, y el kinesiólogo, sin decirte nada, llena un formulario con tu nombre.'},
   r:'Te vendás en el baño, lejos de todos.'},
  {t:'Pedís arrancar en el banco', ef:{fitness:4, com:3}, r:'Entrás los últimos quince minutos, cuidándote en cada pelota. El ojeador ya estaba en el estacionamiento.'} ]},

{id:'sx17', w:2, st:['ini'], when:p=>p.age<=18,
 t:'La prueba de la selección regional',
 d:p=>`Doscientos pibes, pecheras numeradas y quince minutos por cabeza en una cancha auxiliar. Te toca el cuarenta y siete, y los que anotan están sentados lejos, abajo de un paraguas.`,
 c:[
  {t:'Jugás simple, sin perder una pelota', ef:{com:4, pas:2, hype:-3}, r:'Quince minutos sin un error. Al final del día leen los números que siguen y el tuyo no está; el de al lado, que perdió seis pelotas y metió un golazo, sí.'},
  {t:'Intentás la jugada que te van a anotar', ef:{moral:3}, tira:'reg', mas:0,
   bien:{ef:{hype:10, rep:5, moral:8}, r:'Tirás una rabona que entra por el segundo palo. Abajo del paraguas alguien se para, y tu número queda escrito dos veces.'},
   mal:{ef:{moral:-12, hype:-6, forma:-4}, r:'La perdés en la mitad de la cancha y es gol de ellos. En los doce minutos que quedan no te la pasan ni los de tu misma pechera.'},
   r:'Esperás la pelota con una sola idea en la cabeza.'},
  {t:'Te ofrecés para el puesto que les falta', ef:{dfs:3, lid:3, moral:-3}, r:'Faltaban laterales y vos nunca fuiste lateral. Quedás, y durante dos años te llaman para jugar donde no jugás.'} ]},

{id:'sx5', w:2, st:['ini'], when:p=>p.age<=19,
 t:'Los botines que no pediste',
 d:p=>`Te llega al club una caja con los botines más caros del catálogo, de tu número exacto. Adentro hay una tarjeta de un representante con una sola frase: «Cuando quieras, hablamos».`,
 c:[
  {t:'Los estrenás y lo llamás', ef:{hype:6, moral:4, mgrRel:-4, flag:'agente'}, r:'Te atiende al primer timbre, como si estuviera con el teléfono en la mano. Firmás un papel de dos hojas que leés en diagonal.'},
  {t:'Los devolvés con una nota', ef:{com:5, rep:3, moral:-3}, r:'Los mandás de vuelta en la misma caja. En el vestuario te dicen que sos el único pibe del país que devuelve botines, y no es un elogio.'},
  {t:'Se los das a un compañero que juega con unos rotos', ef:{lid:5, moral:4}, r:'Le quedan medio número grandes y los usa igual. Al mes, el representante lo llama a él.'} ]},

{id:'sx21', w:2, st:['asc'], when:p=>p.age>=20,
 t:'El nombre borrado de la pizarra',
 d:p=>`El viernes el técnico escribe el once en la pizarra del vestuario y tu apellido está ahí, en fibra azul. El sábado a la mañana alguien lo borró con el dedo y encima, más prolijo, está el del cinco veterano. Nadie dice nada.`,
 c:[
  {t:'Le preguntás al técnico en su oficina', ef:{com:4, mgrRel:3, moral:-4}, r:'Te dice que es táctico y que el domingo lo vas a entender. El domingo juega el veterano, hace un partido correcto, y lo entendés perfectamente.'},
  {t:'Entrenás el doble sin decir una palabra', ef:{fis:3, forma:4, fitness:-6, moral:-3}, r:'Te quedás después de hora corriendo con el preparador. A los quince días tu apellido vuelve a la pizarra, en fibra negra, que es la que no se borra.'},
  {t:'Le preguntás al veterano si fue él', ef:{lid:4, moral:-6, mgrRel:-4}, r:'Se ríe y te dice que él no toca la pizarra, que no le hace falta. Tiene razón, y es lo peor que te dijeron en el año.'} ]},

{id:'sx22', w:2, st:['asc','ple'],
 t:'Dormís al lado de tu competencia',
 d:p=>`En las concentraciones te toca pieza con el otro pibe que pelea tu puesto. Mañana juega uno solo de los dos y nadie sabe cuál. Son las dos de la mañana, él tiene la luz prendida y te pregunta si podés mirar con él los videos de sus errores.`,
 c:[
  {t:'Los mirás y le decís la verdad', ef:{lid:5, moral:4}, r:'Le marcás tres cosas que hace mal y que vos harías mejor. Al otro día juega él, y las corrige las tres.'},
  {t:'Apagás la luz y le decís que duerma', ef:{forma:5, com:3, lid:-3}, r:'Dormís siete horas. Él no, y se le nota en el calentamiento. Jugás vos, y no terminás de saber por qué.'},
  {t:'Le pedís al utilero que te cambie de pieza', ef:{forma:3, mgrRel:-3, moral:-4}, r:'Te mudás con un arquero suplente que ronca. La próxima lista de piezas la arma el técnico en persona, y los vuelve a poner juntos.'} ]},

{id:'sx23', w:2, st:['asc'], when:p=>!p.loanFrom && C(p.club).tier<=3,
 t:'El técnico que te llama al celular',
 d:p=>`Un número que no tenés agendado. Es el técnico de un club más chico que ${C(p.club).n}: consiguió tu teléfono no sabés cómo, te vio jugar en la reserva y te quiere a préstamo. «Conmigo jugás todos los partidos», dice. «No te lo prometo: te lo aviso.»`,
 c:[
  {t:'Le decís que sí antes de colgar', ofr:{t:'chico', cuando:'ya', prestamo:true}, ef:{moral:8, forma:4, mgrRel:-6}, r:'En el club se enteran por él, no por vos. Te arman los papeles igual, sin ceremonia y sin nadie que te pida que te quedes.'},
  {t:'Le pedís que hable con tu club', ef:{com:4, mgrRel:3, moral:-4}, r:'El director deportivo le dice que no salís ni vendido ni prestado. Te enterás un mes después, por un mensaje del técnico que termina con «suerte, pibe».'},
  {t:'Le decís que te vas a ganar el lugar acá', ef:{moral:4, fanLove:4, forma:-4}, r:'Te desea suerte con la voz de alguien que ya escuchó esa frase. Colgás sintiéndote grande, y el sábado de nuevo no estás en la lista.'} ]},

{id:'sx24', w:3, st:['asc','ple'], when:p=>p.rep>=30 && C(p.club).tier>=2,
 t:'Dos almuerzos el mismo día',
 d:p=>`Tu representante te manda fotos del estadio de un club grande de ${enLigaEuropea(p) ? 'otra liga' : 'Europa'} que pregunta por vos. Media hora después, el presidente de ${C(p.club).n} invita a tus viejos a almorzar el mismo día, a la misma hora. Tu vieja ya eligió qué ponerse.`,
 c:[
  {t:'Vas al almuerzo con el presidente', ef:{contrato:4, wage:15, fanLove:8}, r:'Tu vieja le cuenta cómo eras de chico y él toma nota como si importara. Firmás cuatro años con aumento, y el grande pregunta por otro.'},
  {t:'Le decís a tu representante que avance', ofr:{t:'gigante', cuando:'ventana'}, ef:{hype:10, fanLove:-12, mgrRel:-6, flag:'tentado'}, r:'Tus viejos van solos al almuerzo. El presidente es amable con ellos todo el tiempo, y eso es lo que más le duele a tu viejo.'},
  {t:'Usás el interés del grande para pedir aumento', ef:{wage:25, rep:-4, fanLove:-6, mgrRel:-4, trait:'mercenario'}, r:'Te lo dan en una tarde, sin una sonrisa. El presidente no vuelve a invitar a tus viejos a nada.'} ]},

{id:'sx25', w:2, st:['asc'], when:p=>p.age<=22,
 t:'El primer sueldo que se nota',
 d:p=>`Entra el primer sueldo con un número que no parece tuyo. Lo mirás tres veces en el teléfono, sentado en el vestuario, antes de ducharte. Tenés ${enLetras(p.age)} años y nadie en tu familia ganó eso en un año entero.`,
 c:[
  {t:'Les pagás un año de alquiler a tus viejos', ef:{capital:-0.03, moral:8, fanLove:3}, r:'Tu vieja llora y después se enoja porque no le avisaste. Tu viejo no dice nada, y esa noche lava el auto a mano.'},
  {t:'Te comprás el auto que querías desde los doce', ef:{capital:-0.06, hype:6, moral:6, mgrRel:-4}, r:'Lo estacionás al lado del auto del capitán, que es más viejo. Al otro día alguien te escribe «nene» con el dedo en el polvo del capó.'},
  {t:'No tocás nada y seguís yendo en colectivo', ef:{com:4, moral:-4}, r:'Llegás a entrenar en colectivo, con los auriculares puestos, como antes. A fin de año la plata sigue ahí, y vos no sabés muy bien para qué.'} ]},

{id:'sx35', w:2, st:['asc'], when:p=>p.age>=20 && p.rep>=20, veta:['agente','pleitoAgente'],
 t:'La agencia grande te quiere',
 d:p=>`Una agencia con oficinas en cuatro países te quiere firmar. Tu representante es el mismo desde que eras chico, el tío de un compañero de la cantera, que nunca tuvo otro jugador que valiera lo que vos. Te lo cuenta él, porque ya se enteró.`,
 c:[
  {t:'Firmás con la agencia', ef:{hype:6, rep:4, value:10, moral:-6, flag:'agente'}, r:'Te mandan un contrato de treinta páginas y un auto a buscarte al entrenamiento. Él te desea suerte por mensaje, y para tu cumpleaños ya no escribe.'},
  {t:'Te quedás con el de siempre', ef:{moral:6, com:3, flag:'agenteFiel'}, r:'Te invita a comer para festejar y paga él, con una tarjeta que tarda en pasar. Sabés exactamente lo que dejaste arriba de la mesa.'},
  {t:'Te manejás solo, con un abogado', ef:{capital:-0.02, com:4, rep:2}, r:'El abogado cobra por hora y vos aprendés qué es una cláusula de rescisión un jueves a las once de la noche. Los dos representantes se enteran por la prensa.'} ]},

{id:'sx40', w:2, st:['asc'], when:p=>p.age>=20,
 t:'La cena de los nuevos',
 d:p=>`En el plantel de ${C(p.club).n} hay una tradición: el último que subió paga la cena de todo el grupo, en un restaurante que elige el capitán. Este año sos vos. El capitán ya reservó, y el lugar tiene carta de vinos.`,
 c:[
  {t:'Pagás todo sin mirar', ef:{capital:-0.015, lid:4, moral:4}, r:'Treinta y dos cubiertos y un vino que alguien pidió para probar. Te palmean la nuca toda la noche, y la cuenta la guardás doblada en cuatro, de recuerdo.'},
  {t:'Pedís cambiar a una parrilla de barrio', ef:{capital:-0.004, lid:2, moral:-3}, r:'Los más grandes protestan diez minutos y comen dos horas. Uno dice que es la mejor cena de los nuevos en años y otro que sos un rata. Los dos piensan un poco las dos cosas.'},
  {t:'Te negás: la tradición es un abuso', ef:{com:4, lid:-4, moral:-6}, r:'Tenés razón y lo decís bien. Cenan igual, sin vos, y el año que viene la paga otro pibe que se acuerda perfectamente de que vos no pagaste.'} ]},

{id:'sx30', w:2, st:['asc'], when:p=>p.age>=20,
 t:'El técnico no sabe tu nombre',
 d:p=>`El técnico nuevo lleva tres semanas llamándote con el apellido de otro. No de cualquiera: el de un jugador que se fue del club hace dos años, por la puerta de atrás. Los más grandes ya se ríen cada vez que pasa.`,
 c:[
  {t:'Lo corregís delante de todos', tira:'lid', mas:0,
   bien:{ef:{mgrRel:6, moral:8, rep:3}, r:'Se ríe, lo repite dos veces y le pide disculpas al grupo. Desde ese día te llama por el nombre de pila, cosa que no hace con nadie.'},
   mal:{ef:{mgrRel:-12, moral:-6}, r:'Te mira un segundo largo y sigue con la charla. Esa semana no te nombra ni con el apellido del otro.'},
   ef:{}, r:'Levantás la mano en la charla y decís tu apellido, despacio.'},
  {t:'Contestás al apellido equivocado', ef:{com:4, mgrRel:4, moral:-6}, r:'Te llama así hasta diciembre. En la planilla del partido, por suerte, lo escribe otro.'},
  {t:'Le pedís al capitán que se lo diga', ef:{mgrRel:2, moral:3, lid:-3}, r:'Se lo dice en un pasillo. El técnico lo aprende en el acto, y también aprende que para hablar con vos hay que pasar por otro.'} ]},

{id:'sx31', w:2, st:['asc','ple'], when:p=>p.age>=20 && p.mgrRel>=55,
 t:'«Si lo sacan a él, sáquenme a mí»',
 d:p=>`Llevás cuatro partidos malos y la hinchada ya te silba en el calentamiento. En la conferencia, el técnico dice que si te sacan a vos, que lo saquen a él también. La frase abre todos los programas deportivos del día.`,
 c:[
  {t:'Le agradecés en público', ef:{mgrRel:8, moral:6}, r:'Queda como un pacto. Desde ahí cada error tuyo es también de él, y lo sabés cada vez que la pelota te llega.'},
  {t:'Le pedís en privado que no te defienda más', ef:{com:6, lid:4, mgrRel:-4}, r:'Te escucha, asiente, y el domingo te deja en el banco sin explicarte si es por eso. Entrás a los setenta y jugás tu mejor media hora del año.'},
  {t:'Te quedás callado y dejás que hable él', ef:{forma:4, hype:-4, moral:-3}, r:'Ganan dos partidos y la frase se olvida. A vos no, sobre todo cuando lo echan en marzo y nadie dice nada parecido por él.'} ]},

{id:'sx26', w:2, st:['asc','ple'],
 t:'La cuenta anónima que te sigue',
 d:p=>`Hace meses una cuenta sin foto comenta cada error tuyo, a los dos minutos del final, con detalles que sólo sabe alguien que te conoce. Un amigo en común te lo confirma: es un pibe con el que jugabas en la cantera, al que dejaron libre el mismo año que a vos te subieron.`,
 c:[
  {t:'Le escribís en privado', ef:{com:5, lid:3, moral:-4}, r:'Tarda dos días en contestar. Te pide perdón en cuatro líneas y en la quinta te pregunta si sabés de algún club que busque gente. No sabés.'},
  {t:'Lo bloqueás y seguís', ef:{forma:4, com:3}, r:'Durante un mes revisás si abrió otra cuenta. No abrió ninguna, y eso tampoco te deja tranquilo.'},
  {t:'Lo exponés con nombre y apellido', ef:{hype:12, moral:4, rep:-6, fanLove:-4, trait:'polemico'}, r:'Tus seguidores le hacen en una tarde lo que él te hacía en un año. El pibe cierra la cuenta, la otra, y la del negocio de su familia.'} ]},

{id:'sx27', w:2, st:['asc','ple'],
 t:'La boda en día de partido',
 d:p=>`Tu novia te presentó a toda su familia hace tres meses, y es lo más serio que tuviste nunca. Su hermana se casa un sábado a la tarde, el mismo sábado que ${C(p.club).n} juega de local. Probablemente vas al banco. Probablemente.`,
 c:[
  {t:'Le pedís permiso al técnico para faltar', ef:{moral:10, mgrRel:-10}, r:'Te lo da con una cara que vas a recordar. Bailás hasta las cuatro. El lunes entrenás con los suplentes de los suplentes.'},
  {t:'Jugás y llegás al postre en jogging', ef:{mgrRel:4, com:2}, r:'Entrás los últimos cinco minutos. Llegás al salón con el pelo mojado, cuando ya cortaron la torta, y la abuela te pregunta si ganaron. Ganaron. Nadie más pregunta.'},
  {t:'Le decís que no vas', ef:{forma:4, mgrRel:4, moral:-10}, r:'Te quedás los noventa minutos en el banco sin calentar. A la noche ves las fotos: hay un lugar vacío en la mesa que alguien tapó con una cartera.'} ]},

{id:'sx32', w:2, st:['asc'], when:p=>p.age>=20,
 t:'Un colchón en el piso',
 d:p=>`Hace cinco meses que vivís solo y el departamento sigue igual que el día de la mudanza: un colchón en el piso, la tele arriba de una caja y dos platos. Tu vieja avisa que llega el viernes a visitarte. Faltan tres días.`,
 c:[
  {t:'Amueblás todo en una tarde', ef:{capital:-0.02, moral:6, forma:-3}, r:'Tres negocios, una tarde y un sillón que no entra por la puerta. Tu vieja llega, mira todo, y te pregunta por qué los platos siguen siendo dos.'},
  {t:'La recibís así, como está', ef:{moral:4, com:3}, r:'Se queda cuatro días y no dice nada del colchón. Cuando se va, la heladera tiene comida para dos semanas y hay cortinas que no sabés de dónde sacó.'},
  {t:'Le pedís que no venga, que tenés partidos', ef:{forma:4, moral:-8}, r:'Te dice que claro, que entiende. Esa noche comés sentado en el colchón, mirando la tele arriba de la caja, y pensás en llamarla y no la llamás.'} ]},

{id:'sx33', w:2, st:['asc','ple'], when:p=>afuera(p),
 t:'Asentís sin entender nada',
 d:p=>`El técnico explica una jugada preparada nueva en el idioma de acá, rápido, con la pizarra tapada por tres compañeros. Todos asienten y vos también. Mañana se juega, y en esa jugada el primero que tiene que moverse sos vos.`,
 c:[
  {t:'Copiás lo que haga el de al lado', ef:{com:2, mgrRel:-6, moral:-4}, r:'El de al lado estaba pensando en otra jugada. Corrés al primer palo mientras el córner va al segundo, y en el video del lunes frenan la imagen dos veces.'},
  {t:'Levantás la mano y pedís que la repita', ef:{mgrRel:4, com:4, moral:-4}, r:'La repite más lento, con el traductor, mientras dos compañeros se miran. El domingo sale perfecta, y en el vestuario te imitan el acento una semana entera.'},
  {t:'Le pedís al analista que te la dibuje después', ef:{pas:2, com:3}, r:'Una hora con el analista y el traductor del teléfono. Te la dibuja en una servilleta que guardás en la media, y en el córner la mirás.'} ]},

{id:'sx28', w:2, st:['asc','ple'], when:p=>p.nt && p.nt.caps===0 && p.rep>=30,
 t:'La citación y la lesión inventada',
 d:p=>`Llega tu primera citación a la selección mayor, para dos amistosos. Esa misma semana ${C(p.club).n} juega el partido del año, y el presidente te llama a su oficina: el médico puede firmar una sobrecarga, si vos querés. Nadie te obliga, te aclara dos veces.`,
 c:[
  {t:'Viajás con la selección', ef:{moral:12, rep:6, hype:6, mgrRel:-8, fanLove:-4}, r:'Entrenás cuatro días con gente que mirabas por la tele y no jugás un minuto. El club pierde el partido del año, y en la radio cuentan quién faltó.'},
  {t:'Aceptás la sobrecarga', ef:{mgrRel:10, fanLove:6, rep:-8, moral:-6}, r:'Jugás el partido del año y lo ganan. El técnico de la selección no llama para quejarse; simplemente no vuelve a llamar por un tiempo.'},
  {t:'Llamás vos al seleccionador y le contás todo', ef:{com:5, rep:3, mgrRel:4, moral:-6}, r:'Te agradece la honestidad y te libera. Jugás para tu club, ganan, y en la lista siguiente no estás. Nadie te explica si una cosa tiene que ver con la otra.'} ]},

{id:'sx29', w:2, st:['asc'], when:p=>p.age>=21 && p.nt && p.nt.caps===0 && p.rep>=25,
 t:'La lista se lee en voz alta',
 d:p=>`Un periodista te aseguró que ibas a estar. Mirás el anuncio en un bar con tus amigos de siempre, y alguien ya pidió una botella para el brindis. El seleccionador lee los apellidos en orden alfabético, y el tuyo tendría que haber sonado entre dos que conocés de memoria.`,
 c:[
  {t:'Brindás igual, por los que están', ef:{com:6, fanLove:4, moral:-6}, r:'Levantás la copa y decís dos apellidos en voz alta. Tus amigos te aplauden un poco de más, y eso es lo que más te cuesta del día.'},
  {t:'Te vas a correr al predio vacío', ef:{fis:3, forma:4, moral:-8}, r:'Una hora de pasadas con las luces de emergencia. La botella la pagan ellos, y te guardan el corcho sin decírtelo.'},
  {t:'Subís una indirecta a las redes', ef:{hype:12, moral:4, rep:-6, flag:'enLaMira'}, r:'«Algunos trabajan, otros tienen amigos.» Cinco palabras. La prensa ya tiene qué preguntarte cada domingo, y el seleccionador ya tiene por qué no llamarte.'} ]},

{id:'sx34', w:3, st:['asc','ple'], when:p=>p.age>=20,
 t:'El pase atrás en la semifinal',
 d:p=>`Semifinal, minuto 86, uno a uno. Tocás atrás sin mirar y la pelota le queda al nueve de ellos, que no perdona. Quedan eliminados. En la zona mixta hay doce micrófonos, y hay una salida por el estacionamiento.`,
 c:[
  {t:'Te parás frente a los micrófonos', ef:{com:6, rep:5, moral:-8}, r:'Decís que fue tuyo, sin vueltas, cuatro veces, porque te lo preguntan cuatro veces. Al otro día el título es la frase y no el error.'},
  {t:'Salís por el estacionamiento', ef:{forma:3, fanLove:-8, hype:-4}, r:'Nadie te ve y todos lo notan. El capitán habla por vos, con palabras que vos no habrías elegido.'},
  {t:'Vas hasta la tribuna a pedir perdón', ef:{fanLove:10, moral:-10, mgrRel:-4}, r:'Caminás hasta la popular con la cabeza gacha. La mitad aplaude, la otra mitad te tira lo que tiene a mano, y el técnico te espera en el túnel para decirte que eso no se hace.'} ]},

{id:'sx39', w:3, st:['asc'], when:p=>p.age>=20,
 t:'Titular desde el calentamiento',
 d:p=>`Faltan doce minutos para el partido más grande de tu carrera hasta ahora, y el titular se toca el isquiotibial en el calentamiento. El técnico te busca con la mirada y te hace una seña: vos. No tuviste tiempo de ponerte nervioso. Lo vas a tener en cuanto te sientes.`,
 c:[
  {t:'Pedís todas las pelotas', tira:'com', mas:0,
   bien:{ef:{moral:12, hype:10, mgrRel:8, fanLove:6}, r:'Hacés el mejor partido de tu vida en un partido que no ibas a jugar. El titular lo mira desde el palco, con hielo en la pierna, y es el primero que te aplaude.'},
   mal:{ef:{moral:-10, forma:-8, mgrRel:-6}, r:'Perdés las tres primeras y dejás de pedirla. A los sesenta te saca, y el cambio lo aplauden.'},
   ef:{hype:4}, r:'Salís a la cancha pidiéndola desde el primer toque.'},
  {t:'Jugás simple, a no equivocarte', ef:{com:4, mgrRel:4, hype:-4}, r:'Noventa minutos sin un error y sin una jugada que alguien vaya a recordar. El técnico te dice «bien» en el vestuario, que es exactamente lo que jugaste.'},
  {t:'Le pedís un minuto al titular', ef:{lid:4, moral:4, forma:-4}, r:'Rengueando, te agarra la cara y te dice tres cosas del nueve de ellos. Dos son ciertas. Salís tarde a la cancha y el cuarto árbitro te lo anota.'} ]},

{id:'sx36', w:2, st:['asc','ple'], when:p=>p.rep>=25,
 t:'El periodista que te descubrió',
 d:p=>`Cuando nadie te conocía, un periodista de un diario chico escribió una página entera sobre vos y la tituló con tu apellido. Ahora se habla de tu transferencia y te pide la exclusiva. En ${C(p.club).n} está prohibido hablar del tema, y él lo sabe.`,
 c:[
  {t:'Le das la exclusiva', ef:{rep:3, hype:8, mgrRel:-10}, r:'Sale en tapa un domingo y la leen hasta en la oficina del presidente. Te multan con una sonrisa, y él te manda una foto de la tapa enmarcada.'},
  {t:'Le pedís que espere', ef:{mgrRel:4, com:3, moral:-6}, r:'Te contesta «lo entiendo», y lo entiende. Su nota siguiente sobre vos es correcta, profesional, y no tiene ni un adjetivo.'},
  {t:'Le das algo en off', ef:{hype:4, com:2, mgrRel:-5}, r:'Publica una línea con «fuentes cercanas al jugador». Todo el club sabe quién es la fuente cercana al jugador.'} ]},

{id:'sx37', w:2, st:['asc'], when:p=>p.age>=20,
 t:'Quince entradas para el domingo',
 d:p=>`El grupo de tus amigos de siempre tiene un mensaje fijado: la lista de quién va el domingo. Esta semana son quince nombres. El club te da dos entradas por partido, y el resto las pagás vos o no hay.`,
 c:[
  {t:'Pagás las trece que faltan', ef:{capital:-0.002, fanLove:4, moral:6}, r:'Quince tipos en la tribuna con tu apellido en carteles de cartón. Al domingo siguiente son diecinueve, y a uno no lo conocés.'},
  {t:'Sorteás las dos que tenés', ef:{lid:3, com:2, moral:-4}, r:'Hacen el sorteo por videollamada y gana el que menos te habla. Los otros catorce lo miran por la tele en el bar de siempre, que es donde lo miraban antes.'},
  {t:'Los invitás a un entrenamiento', ef:{moral:4, mgrRel:-4, forma:-2}, r:'Llegan treinta, no quince, y el técnico corta la práctica diez minutos antes. Tu amigo más viejo le saca una foto a tu botín y la pone de perfil.'} ]},

{id:'sx38', w:2, st:['asc','ple'],
 t:'Tus camisetas, a la venta',
 d:p=>`En una página de ventas encontrás una camiseta tuya firmada, con dedicatoria: «Para Nacho, mi hermano de toda la vida». Nacho es Nacho. Hay otras tres publicadas, todas con su nombre.`,
 c:[
  {t:'Le preguntás qué le pasa', ef:{lid:4, moral:-6}, r:'Perdió el trabajo en marzo y no te lo quería decir. Prefirió vender tus camisetas antes que pedirte nada, y no sabés cuál de las dos cosas te duele más.'},
  {t:'Las comprás vos, las cuatro, sin decirle', ef:{capital:-0.004, com:4}, r:'Te llegan en un sobre con su letra en el remitente. Las guardás en un cajón, y cada tanto pensás qué va a hacer cuando se le terminen.'},
  {t:'Le firmás diez más', ef:{moral:4, lid:2}, r:'Se las das en una bolsa sin decir nada, y él la agarra sin decir nada. Nunca fueron tan amigos como esa tarde, y nunca volvieron a serlo.'} ]},

{id:'sx41', w:2, st:['ple'], when:p=>p.attrs.def>=72 && p.rep>=55,
 t:'El récord es de un taxista',
 d:p=>`El récord de goles en una temporada de ${C(p.club).n} es de un señor que hoy maneja un taxi. Te faltan dos para pasarlo. Consigue tu número por un utilero y te pide una sola cosa: que no sea un martes, que los martes trabaja de noche.`,
 c:[
  {t:'Le conseguís una platea para todos los partidos', ef:{fanLove:8, moral:6}, r:'Viene a los cuatro partidos siguientes con la misma gorra del club. El que faltaba llega en el cuarto y él aplaude de pie, que es lo más difícil que hace en toda la noche.'},
  {t:'Le decís que los goles no se eligen', ef:{com:4, forma:4, fanLove:-4}, r:'Es verdad y suena peor de lo que querías. Lo pasás un martes contra el último. Él lo escucha por la radio del taxi, con un pasajero que no sabe quién es.'},
  {t:'Le cedés los penales a un compañero hasta el sábado', ef:{lid:3, moral:4, mgrRel:-6}, r:'Regalás dos penales y el técnico no entiende nada. El sábado hacés los dos que faltaban, uno de cabeza, con el señor en la platea, y el técnico sigue sin entender.'} ]},

{id:'sx42', w:2, st:['ple','vet'], when:p=>!!p.flags.padre && p.hype>=30,
 t:'La muestra del jardín',
 d:p=>`Tu hijo tiene la muestra de fin de año del jardín el jueves a las diez. La directora llama a tu casa: el año pasado, cuando fuiste, los padres te filmaron a vos y no a los chicos. Te pide, con mucha educación, que lo pienses.`,
 c:[
  {t:'Vas igual y te quedás parado al fondo', ef:{moral:8, fanLove:4, forma:-2}, r:'Te reconocen igual, de espaldas. Tu hijo te busca entre las sillas durante toda la canción y te encuentra en la última estrofa.'},
  {t:'No vas y te lo mandan por video', ef:{com:4, rep:3, moral:-10}, r:'Treinta segundos filmados de lejos por otra madre. Lo mirás once veces en el micro. Él no te reclama nada. Todavía.'},
  {t:'Vas, y al terminar firmás todo lo que haya', ef:{fanLove:10, moral:4, mgrRel:-4, fitness:-3}, r:'Una hora y media de fotos en el patio. Llegás tarde a la práctica, y tu hijo pasa la mañana mirando cómo firmás, con el disfraz de árbol todavía puesto.'} ]},

{id:'sx43', w:2, st:['ple','vet'], when:p=>!!p.flags.capitan,
 t:'El reparto del premio',
 d:p=>`Clasificaron y la dirigencia paga un premio al plantel en un solo sobre. Como capitán, el reparto lo decidís vos. Hay titulares con treinta partidos, pibes con dos minutos y un utilero que lleva veinte años sin cobrar un premio.`,
 c:[
  {t:'Partes iguales para todos, utilería incluida', ef:{lid:7, fanLove:4, capital:0.02, moral:-4}, r:'Los pibes no lo pueden creer, y dos titulares tampoco, por otras razones. El utilero se compra una heladera y te trae la foto al vestuario.'},
  {t:'Por minutos jugados, planilla en mano', ef:{capital:0.06, com:4, lid:-4}, r:'Es justo y es una planilla de cálculo. Nadie protesta. Los pibes cobran lo que jugaron y lo gastan en silencio.'},
  {t:'Por minutos, y tu parte para el utilero', ef:{lid:4, rep:5}, r:'No se lo decís a nadie y se sabe igual, en tres días, por el utilero. Te lo agradece una sola vez y después te prepara el bolso como si cada partido fuera una final.'} ]},

{id:'sx44', w:2, st:['ple'], when:p=>p.rep>=35,
 t:'La final cae el día de la boda',
 d:p=>`${C(p.club).n} llega a la final de la copa, y la final cae el mismo sábado que se casa tu hermana, con el salón pagado desde hace un año. Ella te llama para decirte que no pasa nada, con la voz de cuando sí pasa.`,
 c:[
  {t:'Le pagás mover todo al domingo', ef:{capital:-0.06, moral:6, fitness:-4}, r:'El salón cobra el doble por el cambio y el cura no puede, así que los casa uno amigo del novio. En las fotos tenés cara de no haber dormido.'},
  {t:'Jugás la final y llegás al postre', ef:{moral:6, fitness:-8, mgrRel:-4}, r:'Salís del estadio sin ducharte y llegás cuando están cortando la torta. Bailás el vals con ella en el jogging del club y ella se ríe por primera vez en el día.'},
  {t:'Le pedís que no cambie nada y te guarde un video', ef:{forma:6, com:3, moral:-8}, r:'Jugás concentrado como pocas veces. El video dura cuarenta minutos y en ninguno te nombran, salvo el tío que brinda por los que no están.'} ]},

{id:'sx45', w:2, st:['ple'], when:p=>p.rep>=60 && C(p.club).lg!=='SAU',
 t:'Los médicos de la habitación 614',
 d:p=>`Concentración antes de un partido de visitante. A las once de la noche golpean la puerta de tu habitación: dos médicos de un club del Golfo, con un maletín y una oferta que multiplica por cuatro tu sueldo. Tu representante sabía que venían.`,
 c:[
  {t:'Los dejás pasar', ofr:{t:'golfo', cuando:'ventana'}, ef:{hype:8, forma:-6, mgrRel:-8}, r:'Te sacan sangre sentado en la cama, con la tele prendida para tapar el ruido. Al día siguiente jugás como alguien que no durmió en esa habitación.'},
  {t:'No abrís', ef:{com:5, mgrRel:4, moral:-3}, r:'Golpean dos veces más y se van. A la mañana, tu representante desayuna en otra mesa.'},
  {t:'Los escuchás y el lunes se lo contás a tu club', ef:{wage:15, contrato:3, fanLove:-6, rep:-3}, r:'El lunes te mejoran el contrato en una reunión de veinte minutos. El presidente te da la mano y no te la suelta hasta que termina de decir la palabra «lealtad».'} ]},

{id:'sx46', w:2, st:['ple'], when:p=>p.fanLove>=55 && p.rep>=60 && C(p.club).tier<=4,
 t:'El escudo que besaste el domingo',
 d:p=>`El domingo hiciste el gol del triunfo y te besaste el escudo delante de la popular. El lunes a la mañana llama ${enLigaEuropea(p) ? 'uno de los clubes más grandes del mundo' : 'un grande de Europa'}. La foto del beso sigue fijada arriba de todo en la cuenta de ${C(p.club).n}.`,
 c:[
  {t:'Decís que sí', ofr:{t:'gigante', cuando:'ventana'}, ef:{hype:10, moral:4, fanLove:-22}, r:'Se sabe el miércoles. La foto del beso la vuelven a subir, ahora los hinchas, con otro texto abajo.'},
  {t:'Decís que no, por ahora', ef:{fanLove:6, com:3}, r:'Nadie se entera de que dijiste que no, así que nadie te lo agradece. El beso, en cambio, sigue arriba de todo.'},
  {t:'Usás la llamada para renovar', ef:{wage:25, contrato:4, fanLove:-10, mgrRel:-4}, r:'El club iguala casi todo. Un dirigente habla de más y la popular hace la cuenta: el beso fue el domingo y la llamada, el lunes.'} ]},

{id:'sx47', w:2, st:['ple','vet'], when:p=>p.clubYears>=2,
 t:'Tu renovación o la de él',
 d:p=>`El director deportivo te ofrece cuatro años más con aumento. Antes de que firmes te lo dice sin vueltas: para pagarte a vos no le van a renovar a tu mejor amigo del plantel, que termina en junio y todavía no sabe nada.`,
 c:[
  {t:'Firmás y no decís nada', ef:{contrato:4, wage:20, moral:-8}, r:'Él se entera en mayo por un correo del club. Te abraza en la despedida, y en el abrazo no hay reproche, que es lo que te queda.'},
  {t:'Pedís menos para que alcance para los dos', ef:{contrato:4, wage:5, lid:6, moral:4}, r:'Firmás por bastante menos y a él le ofrecen un año, no dos. Lo acepta sin saber por qué, y vos no se lo decís nunca.'},
  {t:'Se lo contás a él antes de firmar', ef:{contrato:4, wage:20, lid:4, mgrRel:-8, moral:-3}, r:'Te agradece y esa misma semana arregla con otro club. El director deportivo te para en el pasillo para preguntarte para qué le contás las cosas a la gente.'} ]},

{id:'sx48', w:2, st:['ple'], when:p=>afuera(p),
 t:'Tu vieja cuenta los días',
 d:p=>`Tu vieja se vino a vivir con vos hace seis meses. No entiende el idioma, no le gusta el pan, y en la cocina tiene un almanaque donde tacha los días que faltan para las fiestas.`,
 c:[
  {t:'Le pagás tres meses a su hermana para que venga', ef:{capital:-0.02, moral:6, forma:-2}, r:'Llega con dos valijas llenas de cosas que acá se consiguen. Las escuchás reírse en la cocina a la una de la mañana, y el almanaque desaparece de la pared.'},
  {t:'La mandás de vuelta a casa', ef:{forma:4, com:3, moral:-6}, r:'La llevás al aeropuerto y los dos dicen que es por ella. La casa queda en silencio, y te acostumbrás más rápido de lo que te gustaría.'},
  {t:'La anotás en un curso de idioma', ef:{capital:-0.01, moral:5}, r:'Va dos semanas. A la tercera se hace amiga de la profesora y dejan de ir las dos: ahora toman café los martes y la profesora ya cocina las recetas de tu vieja.'} ]},

{id:'sx49', w:2, st:['ple'], when:p=>p.hype>=35,
 t:'Una revista quiere tu boda',
 d:p=>`Te casás en tres meses. Una revista ofrece una cifra con muchos ceros por la exclusiva: fotos, vestido, lista de invitados, y un fotógrafo propio que no te deja ver las fotos antes.`,
 c:[
  {t:'Vendés la exclusiva', ef:{capital:0.8, hype:10, moral:-6}, r:'Tu suegra sale de espaldas en todas las fotos porque no firmó la autorización. La tapa vende muy bien y tu primo no puede subir ni una foto.'},
  {t:'Boda chica, con los teléfonos en la puerta', ef:{moral:8}, r:'Cuarenta invitados y una canasta con los celulares en la entrada. Igual aparece una foto borrosa al día siguiente, y sabés exactamente de qué mesa salió.'},
  {t:'Vendés la exclusiva y donás todo', ef:{fanLove:8, rep:4, hype:6, moral:-4}, r:'La revista también pone eso en la tapa, que era parte del trato. Tu pareja se entera de adónde fue la plata por la entrevista, igual que los lectores.'} ]},

{id:'sx50', w:2, st:['ple'], when:p=>(p.capital||0)>=2,
 t:'El socio que dejó de contestar',
 d:p=>`Hace dos años pusiste plata en la cadena de gimnasios de tu amigo de la infancia. Hoy te llama el contador, no tu amigo: tres locales cerrados, deudas con proveedores, y tu amigo hace dos semanas que no atiende el teléfono.`,
 c:[
  {t:'Ponés más para salvarlo', ef:{capital:-1.5, moral:4, forma:-4}, r:'Sobreviven dos locales de tres. Tu amigo vuelve a contestar, siempre de noche, siempre pidiendo perdón primero.'},
  {t:'Das la plata por perdida y no lo llamás más', ef:{com:5, moral:-8}, r:'Te cuesta lo que pusiste y un nombre en el teléfono que no borrás.'},
  {t:'Lo mandás a los abogados', ef:{capital:0.4, moral:-6, fanLove:-4, rep:-2}, r:'Recuperás una parte en un año y medio. Su madre le cuenta a medio barrio que lo demandaste, y medio barrio le cree.'} ]},

{id:'sx51', w:2, st:['ple'], when:p=>p.rep>=70 && p.hype>=40,
 t:'La maldición de la portada',
 d:p=>`Te ofrecen la portada del videojuego de fútbol más vendido del año. Paga muy bien. En el vestuario te recuerdan que los últimos tres de la portada se rompieron algo esa misma temporada, y el kinesiólogo no se ríe.`,
 c:[
  {t:'Aceptás', ef:{capital:1.2, hype:14, moral:-4, fitness:-4}, r:'Aparecés en tiendas de países que no sabías ubicar en el mapa. Durante un año, cada vez que te caés, el estadio entero contiene la respiración.'},
  {t:'No aceptás', ef:{com:4}, r:'La portada la hace otro. En octubre se rompe los ligamentos y un compañero te mira en la práctica como si hubieras hecho trampa.'},
  {t:'Aceptás si ponen también a un compañero', ef:{capital:0.6, hype:8, lid:4, moral:-6}, r:'Salen los dos en la tapa, él un poco más atrás. En noviembre se lesiona él, y el que no duerme sos vos.'} ]},

{id:'sx52', w:3, st:['ple','vet'], when:p=>p.clubYears>=3,
 t:'El asiento del fondo del micro',
 d:p=>`Se retiró el que llevaba once años en ${C(p.club).n}, y su asiento en el fondo del micro quedó vacío. Nadie dijo nada, pero en el primer viaje de la temporada el plantel entero sube despacio para ver quién se sienta ahí.`,
 c:[
  {t:'Te sentás vos', ef:{lid:7, moral:-3}, r:'Un defensor con más años que vos se sienta adelante y no te habla hasta el primer peaje. Para el tercer viaje ya es tu asiento y nadie se acuerda de cómo fue.'},
  {t:'Lo dejás vacío toda la temporada', ef:{moral:6, lid:-3}, r:'Nadie se sienta ahí en todo el año. Él se entera por un utilero y te manda un audio de tres minutos que escuchás con auriculares, mirando por la ventanilla.'},
  {t:'Le hacés señas al pibe más nuevo', ef:{mgrRel:4, moral:4, lid:-2}, r:'El pibe se sienta como si el asiento quemara. Los grandes lo toman como una broma tuya, y durante un mes le hacen pagar el café en cada parada.'} ]},

{id:'sx53', w:2, st:['ple'], when:p=>p.age>=25,
 t:'El técnico nuevo fue tu compañero',
 d:p=>`Echan al técnico y ponen a uno que hace cinco años jugaba con vos. Compartían pieza en las concentraciones y sabés cosas de él que el presidente no sabe. En la primera charla te llama por el apellido.`,
 c:[
  {t:'Le decís «míster» como todos', ef:{mgrRel:10, moral:-4, lid:-2}, r:'Funciona. En dos meses los dos se olvidaron de que alguna vez se prestaron las ojotas, y los dos lo extrañan un poco.'},
  {t:'Le decís el apodo delante del plantel', ef:{lid:3, moral:4, mgrRel:-12}, r:'Se ríen todos menos él. El sábado te enterás de la formación por la pantalla del estadio.'},
  {t:'Le pedís un café a solas', ef:{mgrRel:6, lid:3}, r:'Hablan una hora de todo menos de fútbol. Al final te pide que lo ayudes con el vestuario, y vos ya sabés que eso tiene un precio en algún lado.'} ]},

{id:'sx54', w:2, st:['ple'], when:p=>p.nt && p.nt.caps>=3,
 t:'El que le rompió la pierna a tu amigo',
 d:p=>`En la concentración de la selección para el torneo te toca pieza con el defensor que, hace un año, le rompió la pierna a tu mejor amigo. Él llega primero, elige la cama de la ventana y te pregunta si te molesta la luz.`,
 c:[
  {t:'Pedís que te cambien de pieza', ef:{moral:4, hype:6, rep:-4}, r:'Te cambian esa misma noche y la prensa lo sabe a la mañana siguiente. Durante todo el torneo, cada vez que se cruzan, hay una cámara.'},
  {t:'Le decís que no te molesta la luz', ef:{com:6, lid:4, moral:-6}, r:'Veinte días de convivencia correcta. La última noche te cuenta que él tampoco durmió aquella vez. No sabés qué hacer con eso y no hacés nada.'},
  {t:'Le hablás de tu amigo la primera noche', ef:{lid:5, rep:3, forma:-4}, r:'Hablan hasta las tres. Al día siguiente entrenás mal y el preparador lo anota, pero tu amigo recibe un mensaje de un número que no conoce.'} ]},

{id:'sx55', w:2, st:['ple'], when:p=>p.rep>=75,
 t:'Hacer campaña para el premio',
 d:p=>`Estás en la terna del premio al mejor jugador del año. Tu representante tiene un plan: dos entrevistas por semana, un video con tus mejores jugadas y cenas con periodistas que votan. «Los premios no se ganan en la cancha», te dice, y se nota que lo cree.`,
 c:[
  {t:'Hacés la campaña entera', ef:{hype:14, rep:6, forma:-6, mgrRel:-6}, r:'Salís en todos lados menos en la práctica de los jueves. Quedás segundo por dos votos, y uno de los periodistas de las cenas votó al que ganó.'},
  {t:'Decís que eso lo deciden los que votan', ef:{com:5, forma:4}, r:'Suena digno y no mueve nada. Gana otro, que hizo la campaña entera, y vos lo aplaudís desde la tercera fila.'},
  {t:'Usás las entrevistas para hablar de un compañero', ef:{lid:6, fanLove:6, rep:-3}, r:'Hablás de un volante al que nadie mira y le cambiás el año: lo llaman de la selección. A vos no te vota nadie, ni tu representante, que no vota, pero se nota que no lo haría.'} ]},

{id:'sx56', w:2, st:['ple'], when:p=>p.injuredWeeks===0,
 t:'Operarte ahora o en junio',
 d:p=>`El menisco hace ruido desde hace un mes. El médico te da dos caminos: operarte ahora y perderte la pretemporada y el arranque, o infiltrarte cada semana hasta junio y operarte después, «si todavía queda algo que operar».`,
 c:[
  {t:'Te operás ya', ef:{fitness:-18, forma:-14, moral:-8, fanLove:-4, fis:2}, r:'Mirás los primeros partidos desde el palco, con muletas. Volvés con la rodilla limpia y sin nadie que hable de vos.'},
  {t:'Te infiltrás y jugás hasta junio', tira:'fis', mas:0,
   bien:{ef:{forma:8, fanLove:12, hype:8, fitness:-10}, r:'Llegás a junio caminando raro y jugando bien. Te operan el primer día de vacaciones y el cirujano te muestra en una foto lo que quedaba.'},
   mal:{ef:{fitness:-25, forma:-12, moral:-10}, r:'En abril la rodilla dice basta en una jugada sin nadie cerca. Ahora es la operación igual, seis meses en vez de tres, con la infiltración de la semana anterior en la cuenta.'},
   ef:{moral:4, mem:{infiltraciones:1}}, r:'Pinchazo el viernes, partido el domingo.'},
  {t:'Pedís dos semanas de reposo y ves', ef:{fitness:6, forma:-6, mgrRel:-6}, r:'Dos semanas de hielo y bicicleta fija. La rodilla mejora un poco y el técnico te pone de nuevo como si hubiera mejorado mucho.'} ]},

{id:'sx57', w:3, st:['ple','vet'], when:p=>p.hype>=35,
 t:'Alguien pide plata en tu nombre',
 d:p=>`Una cuenta con tus fotos y tu nombre les escribe a hinchas pidiendo plata para una fundación que no existe. Una jubilada mandó sus ahorros y ahora sale llorando en el noticiero de la noche, con tu camiseta puesta.`,
 c:[
  {t:'Le devolvés la plata vos', ef:{capital:-0.03, fanLove:10, rep:4}, r:'Vas a su casa con la plata en un sobre y un fotógrafo que no llamaste. Al día siguiente te escriben cuarenta personas más que dicen que también las estafaron.'},
  {t:'Denunciás y avisás en todas tus redes', ef:{rep:3, moral:-5, fanLove:-3}, r:'Tres semanas de abogados y formularios. La cuenta cae, aparece otra con una letra cambiada, y la jubilada sigue esperando.'},
  {t:'Dejás que lo resuelva el club', ef:{forma:4, mgrRel:3, fanLove:-8}, r:'El club saca un comunicado correcto a las once de la noche. En el noticiero de las doce sigue saliendo la jubilada.'} ]},

{id:'sx58', w:2, st:['ple'],
 t:'Tu potrero está en venta',
 d:p=>`El municipio de tu ciudad natal va a vender la canchita de tierra donde aprendiste a patear. Van a hacer un estacionamiento. Los vecinos juntan firmas, y alguien te pregunta en un mensaje, con mucho cuidado, si vos no podrías.`,
 c:[
  {t:'La comprás con lo que tengas', todo:true, ef:{capital:-1.5, fanLove:12, moral:8}, r:'Firmás ante un escribano que te pide una foto antes que el documento. Le ponen redes a los arcos y un cartel con tu nombre que no pediste y que no te animás a sacar.'},
  {t:'Ponés la cara en la campaña, no la plata', ef:{fanLove:6, hype:6}, r:'Vas a una marcha un lunes y salís en todos los canales. El municipio posterga la venta un año, que con los municipios es lo más parecido a ganar.'},
  {t:'Le decís que no, con cariño', ef:{com:3, moral:-6, fanLove:-6}, r:'Hacen el estacionamiento. La próxima vez que volvés, dejás el auto justo donde estaba el arco de la izquierda y te quedás un rato sentado adentro.'} ]},

{id:'sx59', w:3, st:['ple'], when:p=>p.hype>=50,
 t:'El súper a la una de la mañana',
 d:p=>`Hace meses que hacés las compras a la una de la mañana, en un supermercado de las afueras, porque es la única hora en que nadie te pide una foto. Esta noche la cajera te mira, te cobra y te dice que su hijo te tiene en la pared de la pieza.`,
 c:[
  {t:'Le firmás el ticket para el hijo', ef:{fanLove:5, moral:4}, r:'Ella lo dobla y lo guarda en el delantal. A la semana siguiente hay tres personas esperándote en el estacionamiento a la una y diez.'},
  {t:'Le pagás a alguien para que te haga las compras', ef:{capital:-0.02, forma:3, moral:-5}, r:'Las bolsas llegan a tu puerta con todo lo que pediste y nada de lo que habrías elegido. Sin darte cuenta, dejás de salir de tu casa los martes.'},
  {t:'Le pedís, bajito, que no le cuente a nadie', ef:{com:4, moral:-3, fanLove:-2}, r:'Te dice que sí y cumple. Seguís yendo a la una, ahora a su caja, y ella no vuelve a nombrar al hijo, cosa que extrañás más de lo que pensabas.'} ]},

{id:'sx60', w:2, st:['ple','vet'], when:p=>!!p.flags.capitan,
 t:'La charla te toca a vos',
 d:p=>`Es la final y el técnico, en el vestuario, se corre a un costado: la última charla la da el capitán. Treinta caras te miran y en la cabeza, nada. Afuera ya se escucha el estadio.`,
 c:[
  {t:'Leés lo que escribiste anoche en el celular', ef:{lid:3, com:4, moral:-3}, r:'Se nota que estás leyendo, y a mitad de la segunda frase se te apaga la pantalla. Se ríen. Salen a la cancha riéndose, que tampoco estaba tan mal.'},
  {t:'Improvisás', tira:'lid', mas:0,
   bien:{ef:{moral:12, forma:8, fanLove:6}, r:'Te sale algo sobre tu vieja, tu calle y la primera vez que alguien te dio una camiseta. Vos no te acordás de nada después; ellos sí, y tres te lo repiten años más tarde, palabra por palabra.'},
   mal:{ef:{moral:-12, forma:-6, mgrRel:-4}, r:'Arrancás tres veces la misma frase. El arquero suplente mira el piso por vos. Salen a la cancha en silencio, que no es lo mismo que concentrados.'},
   ef:{hype:4}, r:'Te parás en el medio del vestuario sin saber cómo termina la primera frase.'},
  {t:'Le das la palabra al más viejo del plantel', ef:{moral:4, mgrRel:4, lid:-3}, r:'Habla cuatro minutos, dice dos malas palabras por frase y nadie se acuerda del resto. Vos lo mirás desde la puerta con la cinta puesta, que de repente te queda grande.'} ]},

{id:'sx61', w:2, st:['vet'], when:p=>p.clubYears>=2,
 t:'El dorsal para el refuerzo',
 d:p=>`${C(p.club).n} cierra al refuerzo del año y el departamento de marketing te llama antes que el técnico. Él quiere tu número, lo usa desde chico, y ya tienen camisetas impresas en una caja «por las dudas».`,
 c:[
  {t:'Se lo das', ef:{mgrRel:6, lid:3, moral:-8, fanLove:-4}, r:'Te toca uno de los números altos que sobraban. La primera vez que te ves de espaldas en una foto no te reconocés.'},
  {t:'Le decís que no', ef:{moral:6, fanLove:6, mgrRel:-6, hype:-3}, r:'Marketing reimprime cuatro mil camisetas. El refuerzo te saluda con cortesía todo el año, que es la forma más larga de no saludar.'},
  {t:'Se lo cambiás por camperas nuevas para los utileros', ef:{lid:5, fanLove:3}, r:'Acepta sin pestañear y paga todo en una tarde. Los utileros estrenan abrigo y vos te quedás con la sensación de haber vendido algo que no era del todo tuyo.'} ]},

{id:'sx62', w:3, st:['vet'],
 t:'El GPS dice que perdiste un paso',
 d:p=>`El preparador físico te muestra la planilla sin decir nada: tu velocidad máxima bajó dos kilómetros por hora desde la temporada pasada. No es mucho. Es exactamente lo que separa llegar de no llegar.`,
 c:[
  {t:'Hacés trabajo de pista extra por las tardes', tira:'rit', mas:0,
   bien:{ef:{rit:3, moral:8, forma:4}, r:'En seis semanas recuperás uno de los dos kilómetros. El otro no vuelve, pero el que recuperaste lo usás en cada cierre.'},
   mal:{ef:{fitness:-12, moral:-8, forma:-6}, r:'A la tercera semana se te carga el isquiotibial. El preparador anota la fecha en la misma planilla, abajo de la velocidad.'},
   ef:{fitness:-4}, r:'Tres tardes por semana, vos, el preparador y un cronómetro.'},
  {t:'Cambiás la forma de jugar: salís antes, no más rápido', ef:{com:5, pas:2, moral:-4}, r:'Empezás a moverte medio segundo antes de que salga el pase. Nadie lo nota desde la tribuna. Vos lo notás cada vez que tenés que hacerlo.'},
  {t:'Le pedís que no se la muestre al técnico', ef:{moral:4, mgrRel:-8}, r:'Dobla la hoja y te dice que lo va a pensar. El técnico no dice nada durante dos semanas; después empieza a cambiarte a los setenta minutos.'} ]},

{id:'sx63', w:2, st:['vet'],
 t:'La bañera de hielo en el garaje',
 d:p=>`A los ${enLetras(p.age)}, tu cuerpo tarda un día más que el año pasado en volver después de cada partido. Un proveedor te ofrece armar en tu casa lo mismo que tiene el club: bañera de hielo, botas de presoterapia y una cámara de frío que ocupa medio garaje.`,
 c:[
  {t:'Comprás todo', ef:{capital:-0.3, fitness:12, fis:2}, r:'Lo instalan en un día. Tu auto duerme en la calle desde entonces y vos te metés a tres grados bajo cero todas las noches, solo, escuchando la radio.'},
  {t:'Te quedás después de entrenar a usar lo del club', ef:{fitness:6, mgrRel:4, moral:-6}, r:'Una hora y media más en el predio cada día. Llegás a tu casa cuando ya comieron todos.'},
  {t:'Dormís más y listo', ef:{moral:4, forma:3, fitness:-4}, r:'Diez horas por noche y siesta. Funciona para el domingo; los miércoles, cuando hay copa, ya no.'} ]},

{id:'sx64', w:2, st:['vet'], when:p=>p.age>=30,
 t:'El técnico jugó con vos',
 d:p=>`El nuevo técnico de ${C(p.club).n} fue compañero tuyo hace diez años, en otro vestuario. Se retiró temprano por la rodilla, hizo los cursos mientras vos seguías jugando, y hoy te llama por el apellido delante del plantel. Hasta el mes pasado te decía por el apodo.`,
 c:[
  {t:'Le decís «profe», como todos', ef:{mgrRel:10, com:3, moral:-4}, r:'Le cuesta más a él que a vos. A la semana te llama a su oficina y habla veinte minutos sin mencionar nada de antes.'},
  {t:'Seguís diciéndole por el apodo', ef:{moral:6, lid:3, mgrRel:-10}, r:'El plantel se ríe la primera vez y la segunda ya no. Te deja afuera del once del sábado y te lo explica, eso sí, usando el apodo.'},
  {t:'Le pedís un café a solas antes de la primera práctica', ef:{mgrRel:6, lid:4}, r:'Le decís que va a tener tu respeto en público y tu opinión en privado. Lo primero lo acepta enseguida. Lo segundo lo va a ir midiendo.'} ]},

{id:'sx65', w:2, st:['vet'], when:p=>p.rep>=45 && !p.flags.golfo && C(p.club).lg!=='SAU',
 t:'La videollamada desde el desierto',
 d:p=>`Un director deportivo del Golfo te muestra el estadio por videollamada: césped perfecto, butacas vacías, un martes a la tarde. Después dice una cifra con más ceros de los que tu representante acostumbra decir en voz alta. En tu casa alguien busca en el teléfono cuánto calor hace allá en agosto.`,
 c:[
  {t:'Le decís que en la ventana hablan en serio', ofr:{t:'golfo', cuando:'ventana'}, ef:{moral:4, hype:6, fanLove:-10, rep:-4}, r:'Esa misma noche alguien filtra una captura de la llamada: vos con camisa arriba y en bermudas abajo. La hinchada la usa de bandera hasta que te vas.'},
  {t:'La usás para renovar mejor acá', ef:{wage:15, contrato:2, mgrRel:-6, fanLove:-4}, r:'Tu representante lleva la cifra a la oficina del presidente. Te suben el sueldo y te lo cobran en miradas cada vez que pasás por la secretaría.'},
  {t:'Cortás con amabilidad', ef:{fanLove:6, moral:-4, flag:'golfo'}, r:'Les agradecés el recorrido por el estadio vacío. Te dicen que no hay apuro, con el tono de alguien que ya vio a mucha gente cambiar de idea.'} ]},

{id:'sx66', w:2, st:['vet'], when:p=>p.rep>=40,
 t:'Una liga que te quiere en el afiche',
 d:p=>`Llama un club de una liga más joven y con menos historia: estadios nuevos, viajes de cinco horas en avión y un contrato que incluye tu cara en los afiches de toda la temporada. No te buscan por lo que jugás hoy sino por lo que tu nombre todavía dice.`,
 c:[
  {t:'Escuchás la oferta', ofr:{t:'menor', cuando:'ventana'}, ef:{hype:8, moral:4}, r:'Te mandan el afiche de prueba antes que el contrato. Salís más joven que en el espejo, y te gusta más de lo que admitirías.'},
  {t:'Pedís que te quieran por jugar, no por la foto', ef:{rep:3, com:3, moral:-5, hype:-4}, r:'Te dicen que claro, que obvio, y no vuelven a llamar. Tu representante se entera por otro jugador de que el afiche ya tiene otra cara.'} ]},

{id:'sx67', w:2, st:['vet'],
 t:'Noventa minutos en otro puesto',
 d:p=>`Se lesiona un titular en el calentamiento y el técnico te manda a un puesto donde no jugaste nunca, para salir del paso. Terminás el partido con más pelotas tocadas que en todo el mes. El analista te espera en el pasillo con una tablet y una idea.`,
 c:[
  {t:'Le pedís al técnico quedarte ahí', ef:{special:'reposicion', mgrRel:8, moral:4, hype:-4, forma:-4}, r:'Aprendés de nuevo dónde pararte, a quién mirar y cuándo callarte. A tu edad lo difícil no es aprender: es aceptar que tenés que hacerlo.'},
  {t:'Volvés a tu puesto apenas se cura el titular', ef:{moral:4, com:2}, r:'Le devolvés el lugar sin discutir y recuperás el tuyo. El analista guarda la tablet y la idea, que no es lo mismo que tirarla.'},
  {t:'Te ofrecés de comodín para lo que haga falta', ef:{lid:4, pas:2, mgrRel:4, forma:-6, moral:-3}, r:'Jugás donde falte alguien cada semana. Sos útil en cinco puestos y titular en ninguno.'} ]},

{id:'sx68', w:2, st:['vet'],
 t:'El reloj del primer sueldo',
 d:p=>`Un pibe de la cantera que juega en tu puesto cobra su primer sueldo de verdad y aparece en la práctica con un reloj que vale exactamente eso. Te lo muestra a vos antes que a nadie, esperando algo.`,
 c:[
  {t:'Le decís lo que pensás, sin vueltas', ef:{lid:6, flag:'mentor'}, r:'Se le borra la sonrisa y se va a cambiar sin hablar. Al mes te pide el teléfono de tu contador, y el reloj no lo vuelve a traer.'},
  {t:'Le decís que está buenísimo', ef:{moral:4, fanLove:2, lid:-4}, r:'Se va contento. A los dos años no tiene ni el reloj ni la plata, y vos te acordás perfectamente de lo que le dijiste.'},
  {t:'Le mostrás el tuyo, el mismo de hace diez años', ef:{lid:3, com:2}, r:'Lo mira como se mira algo de museo. Entiende algo, o no; a esa edad es difícil saber cuál de las dos.'} ]},

{id:'sx69', w:3, st:['vet'], when:p=>minutesShare(p)>=0.5 && p.clubYears>=2,
 t:'La pechera del otro color',
 d:p=>`El jueves el técnico arma el equipo del sábado con pecheras. Te tira la naranja, la de los suplentes, y le da la verde al pibe que llegó en el último mercado. Hacía años que no te tocaba ese color.`,
 c:[
  {t:'Entrenás como si fuera una final', ef:{forma:8, mgrRel:6, fitness:-6, moral:-4}, r:'Ganás cada pelota dividida y le pegás a todo lo que se mueve. El sábado arrancás en el banco igual, con la pechera naranja todavía en el bolso.'},
  {t:'Le preguntás al técnico en la cara', ef:{com:4, lid:2, moral:-6}, r:'Te dice lo que ya sabías y te lo dice bien, que es peor. Por lo menos no te enterás por la pizarra.'},
  {t:'Le marcás dos cosas al pibe de la verde', ef:{lid:7, fanLove:3}, r:'Dos cosas que el técnico no vio. El sábado las hace bien. No te lo agradece en voz alta, pero en el festejo te busca a vos.'} ]},

{id:'sx70', w:2, st:['vet','oca'], when:p=>p.contract<=1,
 t:'Te ofrecen renovar por un año',
 d:p=>`Te queda poco contrato y la oferta de ${C(p.club).n} llega en un sobre, no en una reunión: un año más, con recorte de sueldo y una cláusula por partidos jugados. Vos querías dos.`,
 c:[
  {t:'Firmás el año y no discutís', ef:{contrato:2, wage:-15, mgrRel:6, fanLove:4, moral:-6}, r:'Firmás en la oficina con una lapicera del club que no escribe bien. El año se empieza a contar esa misma tarde.'},
  {t:'Pedís dos años aunque cobres menos', ef:{contrato:3, wage:-25, moral:4}, r:'Te los dan casi sin discutir, que es lo que te preocupa. Cobrás menos que un lateral de veintidós años y dormís mejor que él.'},
  {t:'Pedís más plata por cada partido jugado', ef:{contrato:2, wage:8, fitness:-8, mgrRel:-4}, r:'Aceptan el premio por partido. Desde ese día jugás con dolores que antes hubieras declarado.'} ]},

{id:'sx71', w:2, st:['vet'],
 t:'Te guardan para los partidos de local',
 d:p=>`El área de ciencia del deporte presenta un plan para cuidarte: no viajás a los partidos lejos, no jugás en césped sintético y no hacés dos partidos en la misma semana. Lo explican con gráficos de colores y como si fuera un favor.`,
 c:[
  {t:'Aceptás el plan', ef:{fitness:12, forma:-4, moral:-6, trait:'profesional'}, r:'Los domingos de visitante los mirás por televisión, en tu casa, con hielo en la rodilla por costumbre. Rendís mejor que el año pasado y te sentís peor.'},
  {t:'Pedís jugar todo mientras aguantes', ef:{fanLove:6, lid:4, fitness:-10, mgrRel:-4}, r:'Viajás, jugás, y en febrero el cuerpo te pasa la cuenta toda junta. El preparador no dice «te avisé» porque no hace falta.'},
  {t:'Negociás: los viajes sí, el sintético no', ef:{fitness:5, mgrRel:4, com:2}, r:'Te aceptan la mitad del plan. Ahora te toca explicar en cada vestuario por qué hoy sí y el miércoles no.'} ]},

{id:'sx72', w:2, st:['vet'],
 t:'La semifinal con el gemelo',
 d:p=>`Semifinal de copa el miércoles y el lunes sentís el pinchazo en el gemelo. El ecógrafo dice «un poquito». El médico dice que puede infiltrarte, que es tu decisión y que va a dejar por escrito que te lo explicó.`,
 c:[
  {t:'Jugás infiltrado', tira:'fis', mas:0,
   bien:{ef:{fanLove:12, moral:10, hype:8}, r:'Noventa minutos sin sentir el pie y un pase al gol en el segundo tiempo. El jueves no podés bajar de la cama y no te importa nada.'},
   mal:{ef:{fitness:-24, moral:-12, forma:-8}, r:'A los veinte minutos el gemelo termina de romperse. Salís caminando, porque eso hacen los veteranos, y por dentro gritás.'},
   ef:{fitness:-4, mem:{infiltraciones:1}}, r:'Entrás con la pierna dormida de la rodilla para abajo.'},
  {t:'Jugás sin infiltrar, lo que dure', ef:{fanLove:6, fitness:-8, forma:-4}, r:'Aguantás sesenta minutos pisando raro. Te cambian a tiempo y la pierna llega entera al domingo. Del resultado preferís no hablar.'},
  {t:'Le decís al técnico que no estás', ef:{fitness:6, com:4, fanLove:-8, moral:-6}, r:'Lo mirás desde el banco con una bolsa de hielo. Pierden por un gol y un periodista cuenta en voz alta tus minutos de la temporada.'} ]},

{id:'sx73', w:2, st:['vet'], req:'padre', when:p=>new Set(p.seasons.map(s=>s.clubId)).size>=3 && p.clubYears<=1,
 t:'Que sea la última mudanza',
 d:p=>`Tu hijo cambia otra vez de escuela y esta vez vuelve callado del primer día. En casa hacen la cuenta en voz alta: conoce más aeropuertos que compañeros de grado. Te piden que la próxima mudanza, si la hay, sea la última.`,
 c:[
  {t:'Prometés que no se mudan más', ef:{moral:10, com:3, hype:-6}, r:'Esa misma noche se lo decís a tu representante. Tu hijo arma su cuarto en una ciudad que va a poder decir que es suya.'},
  {t:'Si sale algo afuera, te vas solo', ef:{forma:4, hype:3, moral:-8}, r:'Lo decís fácil, en la cocina, con la mesa puesta. Viajar los lunes y volver los viernes se dice mucho más rápido de lo que se hace.'},
  {t:'No prometés lo que no sabés si podés cumplir', ef:{com:5, moral:-4}, r:'Decís «vamos a ver» y la frase queda flotando toda la cena. Es la respuesta honesta y nadie te la agradece.'} ]},

{id:'sx74', w:2, st:['vet','oca'], when:p=>p.clubYears>=2 && p.fanLove>=60,
 t:'Que te retires acá',
 d:p=>`La agrupación de hinchas más vieja te hace un homenaje en su sede: placa, asado y un micrófono que nadie te avisó que iba a haber. Antes de darte la placa, el presidente de la agrupación te pide que prometas, ahí mismo, que te retirás en ${C(p.club).n}.`,
 c:[
  {t:'Lo prometés', ef:{fanLove:18, moral:6, wage:-10, contrato:2}, r:'Aplauden de pie y alguien llora. A la semana, en la oficina, te ofrecen la renovación con un número más bajo: ya saben que no te vas.'},
  {t:'Decís que el futuro no lo decide uno', ef:{com:4, rep:2, fanLove:-8}, r:'Es verdad y suena a despedida. La placa te la dan igual, un poco más rápido.'},
  {t:'Hacés un chiste y cambiás de tema', ef:{fanLove:4, com:2, moral:-3}, r:'Se ríen y siguen comiendo. A la salida el presidente te agarra del brazo y te dice que no contestaste. Ya lo sabías.'} ]},

{id:'sx75', w:2, st:['vet','oca'], when:p=>p.age>=29,
 t:'El gimnasio de tu preparador',
 d:p=>`Tu preparador personal, el que te arma las pretemporadas en vacaciones hace años, quiere abrir un gimnasio y te ofrece ser socio. Él pone el trabajo; vos ponés medio millón y el apellido en el cartel de la entrada.`,
 c:[
  {t:'Entrás como socio', ef:{capital:-0.5, fis:2, rep:3, fitness:4}, r:'Pasás los lunes libres eligiendo máquinas y discutiendo el precio de la cuota. Por primera vez pensás qué vas a hacer a las nueve de la mañana cuando no haya práctica.'},
  {t:'Ponés el apellido, no la plata', ef:{capital:0.05, hype:4, rep:-4}, r:'Te pagan un porcentaje por la foto en la puerta. A los seis meses cambian las máquinas por otras más baratas y la foto sigue ahí.'},
  {t:'Le decís que no mezclás amistad y plata', ef:{com:4, fitness:-4, moral:-3}, r:'Lo entiende y lo abre con otro socio. En las vacaciones siguientes está ocupado y hacés la pretemporada solo, con una aplicación.'} ]},

{id:'sx76', w:3, st:['ple','vet'], when:p=>{ const u = p.seasons[p.seasons.length-1]; return p.nt.caps>=6 && !!u && (u.ntCaps||0)<=1; },
 t:'El grupo de la selección',
 d:p=>`Sale la lista de la próxima fecha y no estás. El grupo de mensajes de la selección sigue en tu teléfono: esa noche se llena de fotos del hotel, chistes internos y un «¿quién trae el parlante?» que ya no es para vos.`,
 c:[
  {t:'Te salís del grupo', ef:{com:5, forma:4, moral:-6}, r:'Un toque en la pantalla y listo. Durante semanas agarrás el teléfono a la hora de la cena, por costumbre, y no hay nada.'},
  {t:'Mandás un mensaje deseando suerte', ef:{lid:5, rep:4}, r:'Veinte pulgares arriba en un minuto. Después el grupo sigue con lo del parlante.'},
  {t:'Leés todo sin escribir nada', ef:{forma:8, moral:-8}, r:'Cada noche, todo, en silencio. Entrenás como hacía años no entrenabas y no sabés si es para volver o por otra cosa.'} ]},

{id:'sx77', w:2, st:['vet'], when:p=>minutesShare(p)>=0.4,
 t:'Siempre salís a los sesenta',
 d:p=>`Cuatro partidos seguidos y el mismo minuto: a los sesenta levantan el cartel con tu número, estés como estés. El domingo pasado estabas jugando tu mejor partido del año.`,
 c:[
  {t:'Le pedís explicaciones al técnico', ef:{fitness:4, moral:3, mgrRel:-6}, r:'Te dice que es para que llegues entero al final de la temporada. Tiene razón y no te gusta, y los dos se van del despacho sabiéndolo.'},
  {t:'Salís aplaudiendo, sin mirar al banco', ef:{fanLove:8, com:4, moral:-6}, r:'La gente se pone de pie cada vez que se levanta el cartel. Empieza a parecerse a una despedida en cuotas.'} ]},

{id:'sx78', w:3, st:['vet'],
 t:'El video de tus errores',
 d:p=>`El analista nuevo arma un video para la charla técnica: seis goles en contra de la temporada, y en los seis aparecés vos llegando un paso tarde. Lo pasan en la pantalla grande, con el plantel entero mirando.`,
 c:[
  {t:'Te hacés cargo en voz alta', ef:{lid:7, mgrRel:6, moral:-8}, r:'Pedís que lo pasen de nuevo y explicás cada jugada. Nadie más habla en toda la charla. Los pibes te miran distinto a la salida, y no sabés si mejor.'},
  {t:'Discutís el video: en tres había otro culpable', ef:{moral:5, mgrRel:-6, lid:-3}, r:'Tenés razón en dos. Para la charla siguiente el analista corrige el video y te saca de los seis, cosa que también se nota.'},
  {t:'Le pedís el video para mirarlo en tu casa', ef:{dfs:3, com:3, moral:-5}, r:'Lo mirás once veces en la cama. En la sexta empezás a verte correr como se corre a esta edad.'} ]},

{id:'sx79', w:2, st:['vet'], when:p=>p.rep>=50,
 t:'Un grande te quiere de suplente',
 d:p=>`Un club grande que pelea todo te quiere para lo que queda de la temporada. No de titular: de alguien que entra los últimos veinte minutos, que sabe cerrar partidos y no se queja en el banco. Es la chance más clara que te queda de levantar algo grande.`,
 c:[
  {t:'Aceptás el banco con chance de título', ofr:{t:'gigante', cuando:'ventana'}, ef:{hype:6, moral:4, fanLove:-10}, r:'Le decís a tu representante que avance. En tu club se enteran por la radio antes que por vos.'},
  {t:'Preferís ser titular donde estás', ef:{fanLove:8, lid:4, rep:-3}, r:'Te quedás a jugar noventa minutos en un equipo que no va a ganar nada. El día de la final de ellos la mirás entera, sin cambiar de canal.'},
  {t:'Usás el interés para pedir refuerzos', ef:{lid:3, fanLove:4}, r:'Le decís al presidente que te quedás si traen dos jugadores. Traen uno, y te lo recuerda cada vez que pierden.'} ]},

{id:'sx80', w:3, st:['vet','oca'], when:p=>p.age>=29,
 t:'Dejan de fabricar tus botines',
 d:p=>`La marca discontinúa el modelo que usás desde que debutaste. El utilero te trae el nuevo: más liviano, más brillante, con una suela que según el folleto «reinventa el contacto con la pelota». Te aprieta en un lugar donde el otro no apretaba nunca.`,
 c:[
  {t:'Comprás los últimos pares que queden en internet', todo:true, ef:{capital:-0.02, com:3, moral:4}, r:'Conseguís once pares en tres países. Los guardás en el placard y hacés la cuenta de cuántas temporadas son. Te da corta.'},
  {t:'Te adaptás a los nuevos', ef:{rit:1, hype:3, forma:-6}, r:'Tres semanas de ampollas. Después ya no te acordás de cómo eran los otros, que era justo lo que te daba miedo.'},
  {t:'Mandás a hacer unos a mano', ef:{capital:-0.1, moral:8, rep:-3}, r:'Un zapatero viejo te toma el molde del pie con yeso y papel de diario. Son los mejores botines que tuviste, y la marca te manda una carta de su departamento legal.'} ]},

{id:'sx81', w:2, st:['oca'], when:p=>p.age>=33,
 t:'El kinesiólogo que sabe demasiado',
 d:p=>`El kinesiólogo de ${C(p.club).n} te conoce el cuerpo mejor que vos. Mientras te trabaja el gemelo te dice, sin levantar la vista, que el isquio izquierdo no está para noventa minutos. El técnico le pregunta a él antes de armar el equipo.`,
 c:[
  {t:'Le pedís que no diga nada', ef:{forma:5, moral:4, fitness:-10}, r:'Te mira un rato largo y asiente. El domingo jugás los noventa y el lunes bajás del auto con las dos manos.'},
  {t:'Le decís que hable con el técnico', ef:{fitness:8, mgrRel:6, forma:-6, moral:-5}, r:'Te sacan del equipo «por precaución», que es la palabra que usan con los que después no vuelven a entrar del todo. El isquio te lo agradece.'},
  {t:'Le pagás sesiones aparte, en tu casa', ef:{fitness:10, fis:1, capital:-0.03, moral:-2}, r:'Viene martes y jueves a las diez de la noche con una camilla plegable. Cobra en efectivo y habla poco, que es justamente lo que le pagás.'} ]},

{id:'sx82', w:3, st:['oca'], when:p=>p.age>=33,
 t:'La escalera del micro, de costado',
 d:p=>`Una cámara te agarra bajando la escalera del micro de costado, escalón por escalón, agarrado del pasamanos. El video dura nueve segundos y ya lo vio medio país. Abajo, en la vereda, te esperaba un nene con tu camiseta.`,
 c:[
  {t:'Subís un video bajando la escalera de espaldas', ef:{hype:10, fanLove:8}, r:'Te reís de vos antes que nadie y funciona: el video nuevo tiene el triple de vistas que el otro. El preparador físico lo mira tres veces seguidas y no se ríe en ninguna.'},
  {t:'Te encerrás a hacer movilidad todas las mañanas', ef:{fitness:6, fis:2, moral:-4, forma:-3}, r:'Cuarenta minutos antes que todos, sobre una colchoneta, solo. A las tres semanas bajás de frente. Eso no lo filma nadie.'},
  {t:'No decís nada', ef:{com:3, hype:-6, moral:-3}, r:'El video se olvida en una semana. El nene de la vereda no: sale en la foto de otro diario, con la camiseta, mirándote bajar.'} ]},

{id:'sx83', w:3, st:['oca'], when:p=>p.age>=33,
 t:'Veinte minutos, pero los últimos',
 d:p=>`El técnico te cita en su oficina y te lo dice sin rodeos: de acá en adelante entrás en los últimos veinte minutos, cuando el partido se rompe. Lo dice como un elogio. Vos hacés la cuenta de cuántos años hace que no calentás al costado de la línea.`,
 c:[
  {t:'Aceptás y aprendés a entrar en frío', ef:{com:4, mgrRel:8, moral:-6}, r:'Aprendés a calentar tres veces por partido y a leer el cansancio del rival desde el banco. Te sale bien. Eso es lo peor.'},
  {t:'En la primera que entrás, corrés como si fueran noventa', tira:'fis', mas:0,
   bien:{ef:{forma:10, moral:10, fanLove:8}, r:'Recuperás dos pelotas, das una asistencia y el domingo siguiente estás en el once. Dura tres partidos, pero dura.'},
   mal:{ef:{fitness:-14, moral:-8, mgrRel:-4}, r:'A los doce minutos de entrar sentís el pinchazo en el gemelo. Salís caminando por el mismo lugar por donde entraste.'},
   ef:{hype:3}, r:'Te sacás el pechero antes de que el cuarto árbitro levante el cartel.'},
  {t:'Le decís que así no', ef:{moral:4, lid:2, mgrRel:-14}, r:'Te escucha, te agradece la sinceridad y no cambia nada. Ahora él sabe lo que pensás y vos sabés que no alcanza.'} ]},

{id:'sx84', w:2, st:['oca'], when:p=>p.age>=34,
 t:'Nació el año que debutaste',
 d:p=>`En el desayuno del predio, un pibe recién subido hace la cuenta en voz alta: nació el año de tu debut. Vos tenés ${enLetras(p.age)} y todos se ríen, vos también. Al día siguiente alguien pega en tu casillero una foto tuya de ese año, con el pelo que tenías.`,
 c:[
  {t:'Pegás al lado una foto de él en pañales', ef:{moral:8, lid:4, mgrRel:-3}, r:'Se la consigue la mamá del pibe por un mensaje. Queda un mes en el vestuario, y el técnico pide que la saquen el día que viene el presidente.'},
  {t:'La dejás ahí y no decís nada', ef:{com:5, moral:-5}, r:'Nadie la saca. Te cambiás todos los días al lado de vos mismo con diecinueve años, que te mira como si supiera algo que vos te olvidaste.'},
  {t:'La sacás y pedís respeto', ef:{lid:4, mgrRel:3, moral:-6}, r:'La sacás en silencio y lo decís una sola vez, sin gritar. Funciona. Desde ese día en el vestuario te hablan un poco más bajo, y no es exactamente respeto.'} ]},

{id:'sx85', w:2, st:['oca'], when:p=>p.age>=33,
 t:'Te toca dormir con el pibe',
 d:p=>`En la concentración te ponen de compañero de habitación a un juvenil de diecisiete años que viaja por primera vez con el plantel. A las once todavía está hablando por teléfono con su mamá, en voz baja, para no molestarte. Mañana juegan los dos.`,
 c:[
  {t:'Le contás cómo fue tu primera concentración', ef:{lid:6, moral:6, fitness:-4}, r:'Hablan hasta la una. Te acordás de cosas que no sabías que te acordabas. A la mañana estás hecho un trapo y él durmió como un tronco.'},
  {t:'Apagás la luz y le decís que duerma', ef:{fitness:4, forma:2, lid:-3}, r:'Se duerme en diez minutos, aliviado de que alguien le diga qué hacer. En el desayuno se sienta en otra mesa, con los de su edad.'},
  {t:'Pedís una habitación para vos solo', ef:{fitness:6, forma:4, mgrRel:-4, lid:-4}, r:'Te la dan: a tu edad ya te la ganaste, dice el delegado. El pibe termina con el utilero, que ronca, y no vuelve a llamar a nadie de noche.'} ]},

{id:'sx86', w:2, st:['oca'], when:p=>p.age>=34,
 t:'La lista de invitados del homenaje',
 d:p=>`${C(p.club).n} te organiza un partido homenaje por tu carrera, con amigos y ex compañeros, y te pide la lista de invitados. Falta un nombre: el técnico que te tuvo un año entero afuera del plantel y con el que no hablás desde entonces.`,
 c:[
  {t:'Lo invitás', ef:{rep:6, com:4, moral:-6}, r:'Viene, se sienta en la primera fila y aplaude cada vez que tocás la pelota. En el vestuario te da la mano y no te dice nada. Esperabas algo más y no sabés qué.'},
  {t:'No lo invitás', ef:{moral:6, rep:-4}, r:'Una radio lo nota y lo llama. Él dice que no le sorprende. La frase se repite más que cualquier gol de esa noche.'},
  {t:'Le pasás la lista al club y que decida', ef:{com:3, moral:-3}, r:'El club lo invita, para quedar bien. Él no viene. Te enterás por el utilero, que te lo cuenta como si fuera una buena noticia.'} ]},

{id:'sx87', w:2, st:['oca'], when:p=>p.age>=33 && p.clubYears>=3,
 t:'La última noche del estadio viejo',
 d:p=>`${C(p.club).n} se muda a un estadio nuevo y el domingo es el último partido en la cancha de siempre. Sos de los que más partidos jugaron ahí de todo el plantel. El lunes entran las máquinas.`,
 c:[
  {t:'Te llevás el punto del penal en un balde', ef:{moral:8, fanLove:4}, r:'Lo sacás con una pala que te presta el canchero a la una de la mañana. Lo plantás en el patio de tu casa y no prende nunca.'},
  {t:'Pedís ser el último en salir de la cancha', ef:{fanLove:12, hype:6, mgrRel:-4}, r:'Te dejan. Diez minutos solo en el círculo central, con la tribuna vaciándose y las luces apagándose de a una. El técnico te espera en el micro con el motor en marcha y cara de haber esperado.'},
  {t:'Jugás el partido como otro cualquiera', ef:{forma:6, com:4, moral:-6, fanLove:-3}, r:'Hacés tu partido, te bañás y te vas. A la semana ves en una foto que la tribuna tenía una bandera con tu nombre. No la viste.'} ]},

{id:'sx88', w:2, st:['oca'], when:p=>p.age>=33,
 t:'Los lunes, a la escuela de técnicos',
 d:p=>`Te anotás en el curso de entrenador, que se cursa los lunes, tu único día libre. En el aula hay un defensor retirado que te marcó durante años y un profesor más joven que vos. El primer examen es en tres semanas.`,
 c:[
  {t:'Lo hacés en serio: carpeta, apuntes y examen', ef:{lid:5, com:3, fitness:-6, forma:-4}, r:'Sacás un nueve y el martes entrenás con la cabeza en la pizarra. El defensor retirado te pide los apuntes y te dice que en la cancha eras insoportable.'},
  {t:'Vas para cumplir y aprobás raspando', ef:{lid:2, rep:-3, moral:-2}, r:'Te sentás atrás y copiás lo justo. El profesor más joven que vos te pregunta algo delante de todos y no sabés contestar. Te lo vuelve a preguntar, más despacio.'},
  {t:'Lo dejás para cuando te retires', ef:{fitness:5, forma:2, moral:-4}, r:'Recuperás los lunes y el sillón. El defensor retirado termina el curso ese año, y a los dos años dirige en primera.'} ]},

{id:'sx89', w:2, st:['oca'], when:p=>p.age>=33,
 t:'El técnico te pregunta el equipo',
 d:p=>`Hace un tiempo que el técnico te llama los viernes para «charlar». Esta vez te muestra dos formaciones dibujadas en una servilleta y te pregunta cuál. En una jugás vos; en la otra, el pibe que te está sacando el puesto.`,
 c:[
  {t:'Elegís la del pibe', ef:{lid:6, mgrRel:10, moral:-8, forma:-4}, r:'Juega el pibe y ganan. El técnico te sigue llamando los viernes. Ya no te pregunta: te cuenta.'},
  {t:'Elegís la tuya', ef:{forma:6, moral:4, mgrRel:-4, lid:-3}, r:'Jugás, y jugás bien. El técnico no vuelve a sacar una servilleta delante tuyo.'},
  {t:'Le decís que eso lo decide él', ef:{com:5, moral:-4}, r:'Dobla la servilleta y se la guarda en el bolsillo. El domingo juega el pibe. No sabés si ya lo tenía decidido o si lo decidiste vos sin abrir la boca.'} ]},

{id:'sx90', w:2, st:['oca'], when:p=>p.age>=33,
 t:'Un canal de streaming te quiere',
 d:p=>`Un canal de streaming te ofrece un programa semanal mientras todavía jugás. La plata es buena y la condición es una sola: que hables. De la liga, de tus rivales y, si se da, de tu propio vestuario.`,
 c:[
  {t:'Aceptás y hablás de todo', ef:{capital:0.15, hype:14, mgrRel:-12, lid:-3}, r:'El tercer programa lo recortan en treinta videos. En uno opinás de un compañero sin nombrarlo, y en el vestuario no hace falta nombrarlo.'},
  {t:'Aceptás, pero de tu club no hablás', ef:{capital:0.06, hype:4, rep:-3}, r:'Hablás de los demás con prudencia de diplomático. Los números bajan cada semana y en la décima te avisan que el programa se toma un descanso.'},
  {t:'Decís que no', ef:{mgrRel:4, com:3, hype:-4}, r:'Ponen a un ex jugador que no pisa una cancha hace diez años y habla de tu equipo todos los lunes. Una vez, de vos.'} ]},

{id:'sx91', w:2, st:['oca'], when:p=>p.age>=33 && lejosDeCasa(p),
 t:'Un audio de tu primer club',
 d:p=>`El utilero del club donde empezaste te manda un audio de cuatro minutos. Que el equipo anda mal, que los pibes no tienen a quién mirar, que el presidente no se anima a llamarte. Al final se queda callado unos segundos y corta sin despedirse.`,
 c:[
  {t:'Le decís que sí, para la próxima temporada', ofr:{t:'casa', cuando:'ventana'}, ef:{moral:10, hype:4, fanLove:-8}, r:'El presidente te llama esa misma noche, ahora sí. En tu club actual se enteran por la radio antes que por vos.'},
  {t:'Le mandás camisetas y botines para los pibes', ef:{capital:-0.02, lid:3, moral:-3}, r:'Llegan en una caja y el utilero te manda una foto de los pibes con las camisetas puestas, grandes como camisones. No te pregunta nada más, y eso también es una respuesta.'},
  {t:'No contestás', ef:{com:2, moral:-8}, r:'El audio queda ahí, escuchado. Cada tanto lo volvés a poner entero, los cuatro minutos, incluido el silencio del final.'} ]},

{id:'sx92', w:2, st:['oca'], when:p=>p.age>=33,
 t:'Un club chico con vista al mar',
 d:p=>`Un club chico de una ciudad costera te ofrece un año de contrato para la próxima temporada. Estadio de cuatro mil personas, entrenamiento a las nueve y la tarde libre. Tu familia vio las fotos de la playa y ya no pregunta otra cosa.`,
 c:[
  {t:'Vas', ofr:{t:'chico', cuando:'ventana'}, ef:{moral:12, fitness:6, rep:-6, hype:-8}, r:'Firmás en el mercado. La primera semana te reconocen en la panadería; la segunda ya no te lo mencionan. No sabés cuál de las dos te gusta más.'},
  {t:'Te quedás a pelear el puesto', ef:{forma:4, lid:2, moral:-6}, r:'Les decís que todavía no. Tu familia guarda las fotos en una carpeta del teléfono que se llama «después».'},
  {t:'Usás la oferta para renegociar', ef:{wage:10, mgrRel:-6, fanLove:-4}, r:'El club te mejora un diez por ciento y te lo hace sentir cada vez que el tesorero te cruza en el pasillo.'} ]},

{id:'sx93', w:2, st:['oca'], when:p=>p.age>=33,
 t:'La planilla del contador',
 d:p=>`Tu contador te pide una reunión y aparece con una planilla impresa. Con lo que tenés y lo que gastás hoy, te dice cuántos años podés vivir sin jugar. Da vuelta la hoja antes de que termines de leer el número.`,
 c:[
  {t:'Vendés el auto y la casa grande', ef:{capital:0.6, moral:-8, hype:-4}, r:'Te mudás a algo más chico y con menos cochera. El auto lo compra un compañero, que lo estaciona todos los días en el predio, dos lugares más allá del tuyo, que es gris y cualquiera.'},
  {t:'Le pedís que te arme un plan de inversiones', ef:{capital:-0.05, com:4, moral:4}, r:'Te cobra la planilla, el plan y la reunión. Por primera vez en quince años sabés cuánto tenés, que no es lo mismo que estar tranquilo.'},
  {t:'Le decís que todavía te quedan años de fútbol', ef:{moral:6, forma:3}, r:'Guarda la planilla en una carpeta con tu nombre. Dice que la va a actualizar el año que viene, y los dos saben con qué número.'} ]},

{id:'sx94', w:2, st:['oca'], when:p=>p.age>=33 && p.rep>=40,
 t:'Escuelitas de fútbol con tu nombre',
 d:p=>`Una empresa quiere abrir escuelitas de fútbol con tu nombre en cinco ciudades. Te ofrecen un porcentaje por prestar la cara y te juran que no tenés que hacer nada. Es exactamente lo que te preocupa.`,
 c:[
  {t:'Firmás y prestás el nombre', ef:{capital:0.25, hype:6, rep:-8}, r:'A los seis meses sale una nota: en una de las sedes cobran la cuota y no hay pelotas. En la foto del diario, arriba del portón, estás vos sonriendo.'},
  {t:'Firmás, con la condición de ir una vez por mes', ef:{capital:0.1, fanLove:8, lid:3, fitness:-6}, r:'Un sábado por mes, en otra ciudad, doscientos chicos y una foto con cada uno. Llegás a los partidos con la sonrisa todavía puesta y las piernas en otro lado.'},
  {t:'Decís que no', ef:{rep:3}, r:'A los tres meses abren igual, con el nombre de un ex compañero tuyo. En la inauguración hay un inflable con su cara.'} ]},

{id:'sx95', w:2, st:['oca'], req:'padre', when:p=>p.age>=33,
 t:'«Mi compañero dice que estás viejo»',
 d:p=>`Tu hijo vuelve del colegio serio. Un compañero le dijo que su papá ya está viejo para jugar. Te lo pregunta en el auto, sin mirarte, como se preguntan las cosas importantes.`,
 c:[
  {t:'Le prometés un gol para el domingo', tira:'def', mas:0,
   bien:{ef:{moral:14, fanLove:6, forma:6}, r:'Minuto setenta, un rebote en el área, adentro. Festejás señalando una platea donde no sabés si está. Estaba.'},
   mal:{ef:{moral:-12, forma:-6}, r:'No la tocás en todo el partido. En el auto de vuelta él habla de otra cosa, con mucho cuidado, como hacés vos con él cuando pierde.'},
   ef:{moral:4}, r:'Le decís que el domingo mire bien.'},
  {t:'Le decís la verdad: que sí, que estás viejo', ef:{com:4, moral:5}, r:'Lo piensa un semáforo entero. «Pero jugás», dice al final, y lo dice como quien gana una discusión.'},
  {t:'Lo llevás al entrenamiento el lunes', ef:{moral:8, lid:3, mgrRel:-4}, r:'Los compañeros le firman una pelota y el arquero se deja hacer tres goles. El técnico no dice nada, pero la práctica empieza veinte minutos tarde.'} ]},

{id:'sx96', w:2, st:['oca'], when:p=>p.age>=33,
 t:'El seguro ya no te cubre',
 d:p=>`La aseguradora del club manda una carta: desde esta temporada tu póliza no cubre lesiones de rodilla ni de tobillo. Si te rompés, el sueldo sale de tu bolsillo. En ${C(p.club).n} dicen que no pueden hacer nada.`,
 c:[
  {t:'Pagás un seguro privado de tu bolsillo', todo:true, ef:{capital:-0.05, moral:6, fitness:4}, r:'Cuesta lo que un auto por año. Dormís tranquilo y firmás el cheque sin mirar la cifra, que es la única forma de firmarlo.'},
  {t:'Jugás igual, sin cobertura', ef:{forma:4, moral:-8, fitness:-4}, r:'Cada pelota dividida la pensás medio segundo más. Tu representante dice que no se nota. Se nota.'},
  {t:'Pedís que el club lo ponga en el contrato', ef:{rep:4, mgrRel:-6, wage:-10}, r:'Aceptan a cambio de un diez por ciento menos de sueldo. Por primera vez en la carrera pagás por la posibilidad de romperte.'} ]},

{id:'sx97', w:2, st:['oca'], when:p=>p.age>=33 && p.clubYears>=5,
 t:'Te faltan seis para el récord',
 d:p=>`La prensa hace la cuenta: te faltan seis partidos para ser el que más veces vistió la camiseta de ${C(p.club).n}. Quedan diez fechas, y el técnico no suele regalar nada.`,
 c:[
  {t:'Le pedís al técnico los minutos', ef:{fanLove:8, rep:3, mgrRel:-10}, r:'Te los da de a cinco y de a diez, en partidos resueltos. Llegás al récord entrando en el minuto noventa y uno de un cuatro a cero. La tribuna lo festeja igual.'},
  {t:'Decís en público que el récord no te importa', ef:{com:5, mgrRel:6, moral:-6}, r:'Queda muy bien en la entrevista. Después, en tu casa, abrís la página de estadísticas del club tres veces por noche.'},
  {t:'Dejás que pase lo que tenga que pasar', ef:{com:3, fanLove:-3, moral:-2}, r:'Llegás a cuatro. Te faltan dos y se termina la temporada. El año que viene alguien más va a hacer la cuenta.'} ]},

{id:'sx98', w:2, st:['oca'], when:p=>p.age>=34 && p.fanLove>=55,
 t:'La bandera necesita una fecha',
 d:p=>`Un grupo de hinchas de ${C(p.club).n} lleva meses cosiendo una bandera de cuarenta metros con tu cara. Mandan a uno a preguntarte, con mucho respeto, cuándo es tu último partido. La quieren estrenar ese día y no antes.`,
 c:[
  {t:'Le decís que a fin de esta temporada', ef:{retiro:1, fanLove:16, moral:6}, r:'Lo decís en voz alta por primera vez, y a un desconocido. El último domingo la bandera cubre media tribuna. Tu cara cosida a mano tiene una arruga que vos todavía no tenés.'},
  {t:'Le decís que no sabés', ef:{fanLove:-6, moral:-4, com:3}, r:'Asiente y se va. La bandera queda doblada en un garaje, esperando una fecha que no depende de ellos, y cada tanto alguien te para en la calle para preguntarte si ya sabés.'},
  {t:'Les pedís que la estrenen el domingo', ef:{fanLove:10, hype:8, forma:-6}, r:'La estrenan. Toda la tarde ves tu cara gigante en la tribuna y jugás como si fuera tu velorio. Perdés la pelota en el gol de ellos.'} ]},

{id:'sx99', w:2, st:['oca'], when:p=>p.age>=33,
 t:'El pibe y el auto importado',
 d:p=>`Un compañero de diecinueve años te muestra en el teléfono el auto que se va a comprar con su primer contrato grande. Cuesta más de lo que ganaste en tus primeras cinco temporadas. Te pregunta qué te parece, y no te lo pregunta por el color.`,
 c:[
  {t:'Le contás en qué gastaste vos la primera plata', ef:{lid:6, com:2, moral:-6}, r:'Le contás todo, hasta lo que no le contaste a nadie. Te escucha con respeto, te da las gracias, y el sábado llega al predio con el auto. Un poco más chico, eso sí.'},
  {t:'Le decís que se lo compre, que se lo ganó', ef:{moral:6}, r:'Se lo compra y te lleva a dar una vuelta. Maneja rápido y se ríe de todo. Por un rato largo te acordás de cómo era.'},
  {t:'Le presentás a tu contador', ef:{lid:4, mgrRel:4, forma:-3}, r:'Va a una reunión y sale con una planilla y cara de velorio. No se compra el auto. Durante un mes no te pasa la pelota en los rondos.'} ]},

{id:'sx100', w:3, st:['oca'], when:p=>p.age>=34,
 t:'La votación en la sobremesa',
 d:p=>`Un domingo, en la sobremesa, alguien de tu familia propone votar si seguís un año más o no. Se ríen, pero después levantan la mano en serio. Sale empatado y todos te miran a vos.`,
 c:[
  {t:'Desempatás: esta temporada es la última', ef:{retiro:1, moral:10}, r:'Nadie aplaude. Alguien levanta los platos, alguien pone a calentar agua. Recién en el auto, de vuelta, te das cuenta de que lo dijiste.'},
  {t:'Desempatás: un año más', ef:{contrato:2, forma:3, moral:-5}, r:'El lunes el club te da un año más de contrato sin discutir, y eso te preocupa un poco. En tu casa, los que votaron que no te siguen preparando el bolso los viernes, sin comentar nada, que es peor.'},
  {t:'Anulás la votación', ef:{lid:2, moral:-6}, r:'Decís que eso no se vota y que lo decidís vos. Tenés razón. La sobremesa termina temprano.'} ]}

];
EVENTS.push(...EVENTS13);


const EVENTS14 = [

{id:'oc1', w:2, st:['asc','ple'], when:p=>has(p,'gambeta') && p.age>=20,
 t:'El caño en el amistoso',
 d:p=>`En un amistoso de pretemporada le tirás un caño a un central veterano del rival, y la tribuna lo festeja como un gol. En el túnel te dice, sin levantar la voz, que en el partido de verdad te va a romper.`,
 c:[
  {t:'Le pedís disculpas ahí mismo', ef:{com:2, moral:-4, fanLove:-3}, r:'Te mira como se mira a un pibe. En el partido de verdad te marca limpio y no te deja tocar una. Nadie se acuerda del caño.'},
  {t:'Se lo volvés a hacer en el partido', tira:'reg', ef:{hype:4},
   bien:{ef:{fanLove:14, hype:8, moral:6}, r:'Minuto doce, misma pierna, mismo hueco. El estadio se cae. Él te da la mano al final, y no dice nada.'},
   mal:{ef:{fitness:-14, moral:-8}, r:'Lo intentás en el minuto doce. En el trece estás en el piso con el tobillo para un costado y él mirando al árbitro con cara de nada.'},
  r:'Esperás la primera pelota.'},
  {t:'Jugás simple todo el partido', ef:{mgrRel:6, fanLove:-5, moral:-3}, r:'Dos toques, siempre. El técnico te felicita y la tribuna te silba un poco. El veterano te busca toda la tarde y no te encuentra.'} ]},

{id:'oc2', w:2, st:['ple','vet'], when:p=>has(p,'gambeta'),
 t:'El más pateado de la liga',
 d:p=>`Sos el jugador que más faltas recibe de la liga y un árbitro dice en la radio que te tirás. Esa semana te pegan el doble.`,
 c:[
  {t:'Pedís protección en la conferencia', ef:{hype:6, moral:4, mgrRel:-4}, r:'La frase sale en todos lados. Los árbitros te cobran más faltas y te amonestan por protestar cada una.'},
  {t:'Soltás la pelota medio segundo antes', ef:{pas:3, fanLove:-6, hype:-4}, r:'Te pegan menos y la tribuna te reconoce menos. Das más asistencias y te gritan que jugás para el costado.'},
  {t:'Seguís encarando y aguantás', ef:{fitness:-10, fanLove:8, moral:3}, r:'Terminás la temporada con los gemelos de otro color. Cada vez que te levantás del piso, el estadio aplaude un poco más.'} ]},

{id:'oc3', w:2, st:['asc','ple'], when:p=>has(p,'espectaculo') && p.age>=20,
 t:'El técnico prohíbe las rabonas',
 d:p=>`El técnico nuevo de ${C(p.club).n} escribe en el pizarrón, con tu nombre al lado: «Nada de rabonas, nada de tacos, nada de sombreritos». Todo el vestuario se da vuelta para mirarte.`,
 c:[
  {t:'Obedecés', ef:{mgrRel:10, fanLove:-8, hype:-6}, r:'Jugás tres meses con el freno de mano puesto. Los resultados mejoran y a vos nadie te pide una foto.'},
  {t:'Lo ignorás en el primer partido', tira:'fil', ef:{},
   bien:{ef:{fanLove:12, hype:10, mgrRel:-4}, r:'Rabona al segundo palo, gol. El técnico no festeja, pero el lunes borra la palabra «rabonas» del pizarrón.'},
   mal:{ef:{mgrRel:-18, moral:-8}, r:'El taco sale para atrás, directo al nueve rival. Gol de ellos. Te cambian en el entretiempo y el pizarrón sigue ahí.'},
  r:'Esperás la primera que se pueda.'},
  {t:'Te los guardás para el clásico', ef:{mgrRel:2, moral:-3, fanLove:4}, r:'Un solo sombrerito, en el clásico, con el partido ganado. El técnico hace como que no lo vio. La tribuna lo vio dos veces.'} ]},

{id:'oc4', w:2, st:['ple','vet'], when:p=>has(p,'espectaculo') && p.hype>=35,
 t:'Tu propio programa',
 d:p=>`Una plataforma te ofrece un programa semanal: vos, una cancha y una cámara, haciendo jugadas que nadie más se anima a hacer. Graban los lunes, el día de descanso.`,
 c:[
  {t:'Aceptás todo', ef:{capital:0.2, hype:12, mgrRel:-6, forma:-4}, r:'El programa es un éxito y los lunes dejan de existir. En el tercer mes el técnico pone un recorte del programa en el video del análisis.'},
  {t:'Sólo en la pretemporada', ef:{capital:0.05, hype:5}, r:'Ocho capítulos y se termina. Te pagan menos y te piden más, y la plataforma contrata a otro para la temporada.'},
  {t:'Lo rechazás', ef:{forma:3, moral:-2, hype:-4}, r:'Los lunes dormís. A los dos meses el programa sale igual, con un jugador de otro club haciendo tus jugadas peor.'} ]},

{id:'oc5', w:2, st:['ple','vet'], when:p=>has(p,'muro'),
 t:'El nueve que estudió tus partidos',
 d:p=>`El delantero del próximo rival dice en una entrevista que vio cuarenta partidos tuyos y que siempre salís a cortar por la izquierda. Lo dice tranquilo, como quien da el pronóstico del tiempo.`,
 c:[
  {t:'Cambiás tu salida para ese partido', ef:{com:3, forma:-3}, r:'Lo esperás del otro lado toda la tarde. No te gana ninguna, y vos tampoco estás cómodo con ninguna.'},
  {t:'Le contestás en la prensa', ef:{hype:8, mgrRel:-4, moral:4}, r:'Le decís que mire cuarenta más. El partido se vende como un duelo y la cámara los sigue a los dos toda la noche.'},
  {t:'Le pedís al técnico que lo marque otro', ef:{mgrRel:-6, moral:-6, fitness:4}, r:'El técnico te lo concede con una cara que vas a ver durante semanas. El nueve hace un gol y en la conferencia dice tu nombre.'} ]},

{id:'oc6', w:2, st:['vet','oca'], when:p=>has(p,'muro') && p.age>=29,
 t:'Tres años sin perderte un partido',
 d:p=>`Hace tres temporadas que no te perdés un partido. El médico de ${C(p.club).n} te muestra una resonancia de la rodilla y te dice que una cosa es aguantar y otra es estar sano.`,
 c:[
  {t:'Parás tres semanas', ef:{fitness:20, fanLove:-4, mgrRel:-4, moral:-4}, r:'Mirás tres partidos desde el palco. El equipo pierde dos, y en los dos la tribuna canta tu nombre.'},
  {t:'Seguís jugando', tira:'fis', ef:{},
   bien:{ef:{fanLove:8, rep:4}, r:'Llegás al final de la temporada con hielo después de cada práctica y sin faltar a ninguna. El médico archiva la resonancia sin decir nada.'},
   mal:{ef:{fitness:-30, moral:-10}, r:'En febrero la rodilla dice basta en un cambio de ritmo cualquiera. Tres años de racha se cortan en un partido que nadie va a recordar.'},
  r:'Le devolvés la resonancia.'},
  {t:'Pedís jugar sólo los de local', ef:{fitness:8, mgrRel:-6, hype:-4}, r:'Te ahorrás los viajes y la racha se termina igual, por otro camino. En la tabla de presencias aparece un asterisco al lado de tu nombre.'} ]},

{id:'oc7', w:2, st:['asc','ple','vet'], when:p=>has(p,'sangrefria') && p.age>=20,
 t:'El que patea los penales',
 d:p=>`El que patea los penales en ${C(p.club).n} erró los últimos dos. El técnico dice que va a seguir pateándolos él. En el vestuario, más de uno te mira a vos.`,
 c:[
  {t:'Le pedís la pelota en el próximo', tira:'com', ef:{hype:4},
   bien:{ef:{rep:6, moral:10, mgrRel:-2}, r:'Arriba, a la izquierda, el arquero ni se mueve. El que pateaba te abraza primero. Desde ese día, los patea vos.'},
   mal:{ef:{moral:-14, mgrRel:-10, fanLove:-6}, r:'El arquero te lo ataja con el pie. Pasás al lado del que pateaba y ninguno de los dos dice nada en toda la semana.'},
  r:'Esperás que cobren uno.'},
  {t:'Lo bancás en público', ef:{lid:3, mgrRel:6, hype:-3}, r:'Decís que es el mejor pateador del plantel. Erra el siguiente igual, pero te lo agradece con un asado que paga él.'},
  {t:'Hablás con el técnico a solas', ef:{mgrRel:3, moral:-3}, r:'Te escucha, asiente, y no cambia nada. Te enterás después que la misma charla ya la habían tenido otros dos.'} ]},

{id:'oc8', w:2, st:['asc','ple'], when:p=>has(p,'turbo') && p.age>=20,
 t:'El GPS dice 36,4',
 d:p=>`Registran el pique más rápido de la temporada de toda la liga y es tuyo. Una marca de bebidas te ofrece correr una carrera de cien metros contra un velocista olímpico, en vivo, en el entretiempo de un partido.`,
 c:[
  {t:'Corrés la carrera', tira:'rit', ef:{fitness:-4},
   bien:{ef:{hype:14, fanLove:6}, r:'Te gana por medio metro y el video da la vuelta al mundo igual. Dice que nunca vio a nadie salir tan rápido con botines.'},
   mal:{ef:{hype:6, moral:-10, fanLove:-4}, r:'Te saca seis metros. El estadio se ríe y vos también, pero el meme dura toda la temporada.'},
  r:'Te ponés las clavas por primera vez.'},
  {t:'Hacés el comercial pero no la carrera', ef:{capital:0.15, hype:4, fanLove:-3}, r:'Corrés solo, en cámara lenta, con una lata en la mano. Pagan bien. En la tribuna rival te gritan el nombre de la bebida.'},
  {t:'Decís que no', ef:{mgrRel:4, moral:-2}, r:'El club te lo agradece. El velocista corre contra otro jugador, que pierde por poco y sale en todos los noticieros.'} ]},

{id:'oc9', w:2, st:['vet','oca'], when:p=>has(p,'turbo') && p.age>=30,
 t:'Ya no alcanza con correr',
 d:p=>`Un lateral de diecinueve años te alcanzó dos veces en el mismo partido. El analista te muestra los números: tu velocidad máxima es la de siempre; lo que se fue es la arrancada.`,
 c:[
  {t:'Cambiás la forma de jugar', ef:{pas:3, com:2, hype:-4, moral:-4}, r:'Empezás a jugar a un toque, de cara. Rendís igual. La gente dice que ya no sos el de antes, y tiene razón.'},
  {t:'Doble turno de velocidad', ef:{rit:2, fitness:-12, forma:4}, r:'Recuperás medio paso y lo pagás con los isquiotibiales. El preparador te mira las piernas como quien mira un auto con muchos kilómetros.'},
  {t:'Pedís menos minutos y más intensos', ef:{fitness:10, mgrRel:2, rep:-4}, r:'Entrás a los sesenta, con el rival cansado. Volvés a ganarle a todos en los primeros tres pasos. Durante media hora.'} ]},

{id:'oc10', w:2, st:['asc','ple','vet'], when:p=>has(p,'metronomo') && p.age>=20,
 t:'Noventa y cuatro por ciento',
 d:p=>`Terminás la ronda como el jugador con más pases acertados de la liga. Un comentarista dice en televisión que es fácil acertar todos si los das para el costado.`,
 c:[
  {t:'Arriesgás más pases', tira:'pas', ef:{},
   bien:{ef:{rep:6, fanLove:6}, r:'Tres pases entre líneas en el primer tiempo, dos goles. El porcentaje baja a ochenta y siete y nadie lo menciona nunca más.'},
   mal:{ef:{mgrRel:-10, fanLove:-6}, r:'Dos pelotas perdidas en el medio, dos contras, un gol en contra. El comentarista no dice nada: le alcanza con mostrar la jugada.'},
  r:'Empezás a buscar el pase difícil.'},
  {t:'Le contestás con datos', ef:{hype:5, fanLove:-4}, r:'Publicás tus pases hacia adelante. Tenés razón, y los hinchas igual se quedan con la frase de él.'},
  {t:'No contestás nada', ef:{com:2, moral:-4}, r:'Seguís igual. A fin de mes el comentarista dice lo mismo de otro, y te das cuenta de que no era personal.'} ]},

{id:'oc11', w:2, st:['asc','ple'], when:p=>has(p,'incansable') && p.age>=20,
 t:'Jugaste todos los minutos',
 d:p=>`La temporada pasada jugaste cada minuto de cada partido de ${C(p.club).n}. El preparador físico te muestra una planilla con tu nombre en rojo y te dice que el cuerpo cobra en cuotas.`,
 c:[
  {t:'Pedís descanso en algunos partidos', ef:{fitness:16, mgrRel:-3, fanLove:-3}, r:'Te sientan en dos partidos de copa. En los dos te levantás del banco cada vez que el equipo ataca.'},
  {t:'Seguís jugando todo', ef:{fanLove:6, rep:3, fitness:-14}, r:'Otra temporada sin salir. La planilla sigue en rojo y a nadie le importa hasta que importa.'},
  {t:'Descansás en los amistosos nomás', ef:{fitness:6, mgrRel:2, moral:-2}, r:'Un acuerdo a medias que deja contentos a todos un poco. El preparador sigue usando la birome roja.'} ]},

{id:'oc12', w:2, st:['asc','ple'], when:p=>has(p,'ambidiestro') && p.age>=20,
 t:'El comodín',
 d:p=>`En lo que va de la temporada jugaste en cinco puestos distintos. El técnico te llama su comodín, con cariño. Vos querés un puesto.`,
 c:[
  {t:'Pedís un puesto fijo', ef:{mgrRel:-8, moral:6, forma:3}, r:'Te lo da, a regañadientes. A la tercera fecha se lesiona el lateral y te pregunta si podés, sólo por esta vez.'},
  {t:'Aceptás ser el comodín', ef:{mgrRel:10, rep:-4, moral:-4}, r:'Jugás todos los partidos y en ninguno sos el mejor de tu puesto. El técnico te pone primero en la lista y último en las entrevistas.'},
  {t:'Pedís que te paguen como titular', ef:{wage:10, mgrRel:-6, fanLove:-3}, r:'El club te lo paga. Desde entonces, cada vez que te mandan a otro puesto, alguien hace el chiste de que te pagan por eso.'} ]},

{id:'oc13', w:2, st:['asc','ple','vet'], when:p=>has(p,'torre') && p.age>=20,
 t:'Al arco',
 d:p=>`Expulsan al arquero en el minuto setenta y no quedan cambios. Todo el equipo se da vuelta y te mira, porque sos el más alto.`,
 c:[
  {t:'Te ponés los guantes', tira:'aer', ef:{},
   bien:{ef:{fanLove:16, hype:12, moral:8}, r:'Un centro, dos centros, un cabezazo en la línea que sacás con las dos manos. Terminan uno a cero y te llevan en andas un arquero de prestado.'},
   mal:{ef:{moral:-10, hype:6, fanLove:-4}, r:'Al primer centro salís mal y queda solo el nueve. Al segundo, también. El video de tus salidas lo pasan en un programa de humor.'},
  r:'El arquero expulsado te tira los guantes desde la línea.'},
  {t:'Decís que vaya otro', ef:{mgrRel:-6, fanLove:-4, fitness:4}, r:'Va el lateral, que mide uno setenta. Ataja todo lo que puede y lo que no, entra. Nadie te dice nada, que es peor.'} ]},

{id:'oc14', w:2, st:['ple','vet'], when:p=>has(p,'hielo'),
 t:'La tanda que nadie quiere patear',
 d:p=>`Final, penales. El técnico pide cinco voluntarios y levantan la mano dos. El quinto es el que define, y todos lo saben.`,
 c:[
  {t:'Pedís el quinto', tira:'com', ef:{hype:6},
   bien:{ef:{fanLove:14, rep:8, moral:10}, r:'Caminás despacio, la acomodás dos veces, la pegás al medio. El arquero ya estaba en el piso. Esa foto la vas a ver el resto de tu vida.'},
   mal:{ef:{moral:-16, fanLove:-8}, r:'La pelota da en el palo y sale. Sentís el silencio de tu tribuna como un golpe en el pecho, y la celebración del otro lado como un ruido lejano.'},
  r:'Levantás la mano.'},
  {t:'Pedís el primero', ef:{com:2, moral:4, hype:3}, r:'Lo metés y te volvés a la mitad de la cancha. El quinto lo patea otro. Mirás para abajo, como todos.'},
  {t:'Le dejás tu lugar al pibe que lo pide', ef:{lid:4, mgrRel:3, moral:-4}, r:'El pibe lo pide con la voz quebrada y vos le das el lugar. Lo mete. Te busca a vos antes que a nadie para abrazarte.'} ]},

{id:'oc15', w:2, st:['asc','ple','vet'], when:p=>has(p,'pegada') && p.age>=20,
 t:'El tiro libre del capitán',
 d:p=>`El capitán de ${C(p.club).n} patea todos los tiros libres desde hace años. Vos metiste los últimos tres en la práctica desde el mismo lugar, y él estaba mirando.`,
 c:[
  {t:'Le pedís el próximo', tira:'peg', ef:{},
   bien:{ef:{hype:10, fanLove:8, moral:6}, r:'Por arriba de la barrera, al ángulo. El capitán es el primero en llegar a abrazarte, y en el vestuario anuncia que desde ahora se reparten.'},
   mal:{ef:{moral:-8, mgrRel:-6}, r:'A la barrera. El rebote termina en un contragolpe y el capitán te mira mientras corre para atrás.'},
  r:'Te parás al lado de la pelota antes que él.'},
  {t:'Le proponés repartirlos por lado', ef:{lid:2, moral:3}, r:'Los de la derecha para él, los de la izquierda para vos. Funciona tres meses, hasta que cobran uno justo en el medio.'},
  {t:'Esperás tu turno', ef:{com:2, moral:-4}, r:'Seguís metiéndolos en la práctica. Él sigue pateándolos en los partidos. Los dos lo saben.'} ]},

{id:'oc16', w:2, st:['ple','vet','oca'], when:p=>has(p,'caudillo'),
 t:'El partido lo dirigís vos',
 d:p=>`Al técnico lo expulsaron en la semana y el ayudante está paralizado. En el entretiempo van perdiendo dos a cero y el vestuario entero te mira a vos.`,
 c:[
  {t:'Cambiás el esquema vos', tira:'lid', ef:{hype:4},
   bien:{ef:{fanLove:12, mgrRel:6, rep:5}, r:'Tres atrás, los dos rápidos arriba. Empatan a los ochenta. El técnico, desde la tribuna, te aplaude con las dos manos.'},
   mal:{ef:{mgrRel:-12, moral:-8}, r:'Cuatro a cero. El lunes el técnico vuelve y pregunta, delante de todos, quién decidió jugar con tres atrás.'},
  r:'Agarrás el fibrón.'},
  {t:'Le das la palabra al ayudante', ef:{mgrRel:6, moral:-4}, r:'Habla bajito y nadie lo escucha. Pierden dos a cero. El técnico, el lunes, te agradece que no le hayas pasado por encima.'},
  {t:'Hablás de ganas, no de táctica', ef:{fanLove:4, moral:4, mgrRel:-3}, r:'Gritás, golpeás una puerta, salen como fieras. Descuentan y pierden igual. La tribuna aplaude la derrota.'} ]},

{id:'oc17', w:2, st:['asc','ple','vet'], when:p=>has(p,'cristal') && p.age>=20,
 t:'Te quieren racionar',
 d:p=>`El cuerpo médico de ${C(p.club).n} propone que juegues sesenta minutos por partido, nunca más, durante toda la temporada. Lo dicen con una carpeta llena de tus lesiones.`,
 c:[
  {t:'Aceptás los sesenta minutos', ef:{fitness:14, hype:-6, rep:-3}, r:'Salís siempre en el mismo minuto, con el partido abierto o cerrado. Terminás la temporada entero por primera vez en años.'},
  {t:'Pagás un fisio personal', todo:true, ef:{capital:-0.04, fitness:8, mgrRel:-4}, r:'Viene a tu casa todas las noches. Al cuerpo médico del club no le gusta que alguien de afuera toque lo que ellos cuidan.'},
  {t:'Jugás todo y que sea lo que sea', ef:{fanLove:5, fitness:-14, moral:4}, r:'Jugás noventa cada vez que te dejan. Es la mejor racha de tu carrera, y la carpeta engorda en marzo.'} ]},

{id:'oc18', w:2, st:['ple','vet'], when:p=>has(p,'mercenario'),
 t:'La frase que te persigue',
 d:p=>`Alguien desentierra un video de tu presentación en otro club: «De acá no me voy nunca». Lo publican el mismo día que se sabe que tu representante está negociando con otros.`,
 c:[
  {t:'Pedís disculpas en un video', ef:{fanLove:6, rep:-2, moral:-4}, r:'Un minuto y medio, mirando a cámara. La mitad te cree. La otra mitad pone tu video nuevo al lado del viejo.'},
  {t:'Decís que el fútbol es un trabajo', ef:{fanLove:-10, hype:6, moral:3}, r:'Lo decís sin pestañear. Te silban en cada pelota durante un mes, y en el mercado aparecen dos ofertas más.'},
  {t:'No decís nada', ef:{com:2, fanLove:-4}, r:'El video tiene un millón de vistas y a la semana nadie se acuerda. Hasta la próxima vez que te vayas.'} ]},

{id:'oc19', w:2, st:['vet','oca'], when:p=>has(p,'idolo'),
 t:'La estatua en vida',
 d:p=>`La comisión directiva de ${C(p.club).n} quiere hacerte una estatua en la puerta del estadio. Todavía jugás ahí todos los domingos.`,
 c:[
  {t:'Aceptás', ef:{fanLove:12, hype:6, moral:-4}, r:'Cada domingo pasás al lado de tu cara de bronce. El día que jugás mal, alguien le pone una bufanda del rival.'},
  {t:'Pedís que esperen a que te retires', ef:{fanLove:4, com:2}, r:'Te dicen que sí. El escultor ya tenía la maqueta y te la regala. La ponés en el living, mirando para la pared.'},
  {t:'Pedís que pongan a alguien de las inferiores', ef:{lid:4, fanLove:6, rep:-3}, r:'Proponés al utilero que trabaja en el club hace cuarenta años. La estatua es de él, y en la inauguración llora más que vos en tu debut.'} ]},

{id:'oc20', w:2, st:['ple','vet','oca'], when:p=>has(p,'capitan'),
 t:'La cinta y el pibe',
 d:p=>`La dirigencia de ${C(p.club).n} te pide que le cedas la cinta de capitán a la joya de las inferiores. Dicen que es la única manera de que no se vaya en el próximo mercado.`,
 c:[
  {t:'Se la das', ef:{lid:3, mgrRel:8, moral:-8, fanLove:4}, r:'Se la ponés vos en el brazo antes del partido. Se queda un año más y después se va igual. La cinta vuelve a vos sin que nadie diga nada.'},
  {t:'Te negás', ef:{moral:4, mgrRel:-12, fanLove:3}, r:'Decís que la cinta no se negocia. La hinchada te banca. El pibe se va en enero y en la despedida no te nombra.'},
  {t:'Proponés compartirla', ef:{mgrRel:2, moral:-2, lid:2}, r:'Él en las copas, vos en la liga. Es raro, nadie entiende bien cómo funciona, y durante una temporada funciona.'} ]},

{id:'oc21', w:2, st:['asc','ple','vet'], when:p=>p.pos==='DC' && p.age>=20,
 t:'La sequía y la planilla',
 d:p=>`Nueve partidos sin hacer un gol. El analista de ${C(p.club).n} te muestra una planilla: llegás más que nunca, definís peor que nunca, y según los números es mala suerte.`,
 c:[
  {t:'Le creés a los números y seguís igual', ef:{com:3, moral:-3, fanLove:-4}, r:'Seguís llegando y errando. En el partido once entra una de rebote, con la rodilla. Después entran cuatro más en tres semanas.'},
  {t:'Te quedás a patear después de cada práctica', ef:{def:3, fitness:-8, forma:2}, r:'Doscientos remates por día contra un arco vacío. El utilero te espera para cerrar con la llave en la mano y cara de paciencia.'},
  {t:'Jugás de espaldas, para el equipo', ef:{pas:2, mgrRel:6, hype:-6}, r:'Bajás a buscar, aguantás, descargás. El equipo gana más partidos y vos no salís en ningún resumen.'} ]},

{id:'oc22', w:3, st:['ple','vet','oca'], when:p=>p.pos==='DC',
 t:'El central que te habla',
 d:p=>`El central del rival te habla todo el partido al oído. De tu juego, de tu familia, de tu pareja. El árbitro está a dos metros y no escucha nada.`,
 c:[
  {t:'Le aguantás todo', tira:'com', ef:{},
   bien:{ef:{moral:6, rep:4, mgrRel:4}, r:'Noventa minutos de veneno y no lo mirás ni una vez. En el final le das la mano. Él no sabe qué hacer con ella.'},
   mal:{ef:{mgrRel:-10, fanLove:-6, moral:-6}, r:'Minuto setenta, una frase de más, un empujón. La roja es para vos. Él se toca la cara como si le hubieras pegado.'},
  r:'Mirás para adelante.'},
  {t:'Le contestás desde el primer minuto', ef:{hype:6, moral:3, mgrRel:-6}, r:'Se pasan el partido discutiendo. Ninguno de los dos toca una pelota limpia. El técnico te saca a los sesenta.'},
  {t:'Lo contás en la conferencia', ef:{hype:8, rep:-2, mgrRel:-3}, r:'Repetís lo que te dijo. Él dice que es fútbol. La mitad del país te da la razón y la otra mitad te dice que no llores.'} ]},

{id:'oc23', w:2, st:['asc','ple'], when:p=>p.pos==='EXT' && p.age>=20,
 t:'Cambio de banda',
 d:p=>`El técnico te quiere en la otra banda, para que entres hacia adentro con tu pierna mala. Dice que así sos impredecible. Vos sentís que así sos peor.`,
 c:[
  {t:'Aceptás y entrenás la pierna mala', ef:{pmm:4, forma:-4, moral:-3}, r:'Dos meses horribles. Al tercero metés uno de afuera con la que nunca usabas, y el técnico lo festeja como si fuera suyo.'},
  {t:'Pedís quedarte en tu banda', ef:{mgrRel:-8, moral:4}, r:'Te deja. Pero cada vez que el partido se traba, mira para el banco, donde está el pibe que sí quiere cambiar.'},
  {t:'Pedís probar media temporada', ef:{pmm:2, mgrRel:3, hype:-3}, r:'Medio año de prueba. Ni muy bien ni muy mal. Al final, los dos dicen que tenían razón.'} ]},

{id:'oc24', w:2, st:['vet','oca'], when:p=>p.pos==='EXT' && p.age>=29,
 t:'El lateral de diecinueve',
 d:p=>`Un lateral de diecinueve años te dejó tres veces en el piso en el mismo partido, y el video está en todas las redes con una música de circo.`,
 c:[
  {t:'Pedís jugar más adentro', ef:{pas:2, rep:-3, fitness:6}, r:'Te mueven al medio. Corrés menos, tocás más, y el pibe de diecinueve se queda sin con quién bailar.'},
  {t:'Le pedís el video y lo estudiás', ef:{com:2, forma:3, moral:-4}, r:'Lo mirás veinte veces, con la música de circo puesta porque no encontrás otra versión. En la revancha no te pasa ni una.'},
  {t:'Te burlás en la conferencia', ef:{hype:8, fanLove:-4, moral:2}, r:'Decís que a su edad vos hacías lo mismo, con peores botines. Queda simpático. Al otro día el pibe publica tu frase con otro video.'} ]},

{id:'oc25', w:2, st:['asc','ple','vet'], when:p=>p.pos==='MCO' && p.age>=20,
 t:'De nueve falso',
 d:p=>`El técnico de ${C(p.club).n} no tiene delantero sano y te quiere de nueve falso: arriba de todo, pero bajando a armar. Nunca jugaste ahí.`,
 c:[
  {t:'Aceptás', ef:{def:3, moral:-3, hype:4}, r:'Los centrales no saben a quién marcar. Hacés tres goles en un mes y la prensa inventa un nombre para tu puesto.'},
  {t:'Pedís seguir de enganche', ef:{mgrRel:-8, moral:3}, r:'Juega de nueve un pibe de la Reserva. No llega nunca la pelota, porque la pelota la tenés vos y no sabés a quién dársela.'},
  {t:'Aceptás pero con libertad para bajar', ef:{pas:2, mgrRel:-2, forma:2}, r:'Arrancás de nueve y terminás de diez cada vez. El técnico grita, después se resigna, después lo dibuja en el pizarrón como si fuera idea suya.'} ]},

{id:'oc26', w:2, st:['ple','vet'], when:p=>p.pos==='MCO',
 t:'El enganche ya no se usa',
 d:p=>`Un comentarista dice que tu puesto está extinguido. Esa misma semana el técnico de ${C(p.club).n} presenta su esquema nuevo, y no hay ningún lugar que se parezca al tuyo.`,
 c:[
  {t:'Te reinventás de interior', ef:{dfs:3, fis:2, moral:-6, hype:-4}, r:'Aprendés a correr para atrás. Te sale. Extrañás la pelota en los pies como se extraña una casa.'},
  {t:'Buscás un club que juegue con diez', ofr:{t:'menor',cuando:'ventana'}, ef:{mgrRel:-10, hype:6}, r:'Tu representante encuentra uno. Es más chico, juega peor, y te dan la diez sin que la pidas.'},
  {t:'Peleás el puesto desde el banco', ef:{mgrRel:4, moral:-6, forma:3}, r:'Entrás diez minutos por partido. En uno de esos diez metés un pase que nadie más ve, y el técnico lo anota en su cuaderno.'} ]},

{id:'oc27', w:2, st:['asc','ple'], when:p=>p.pos==='MC' && p.age>=20,
 t:'La pausa que la tribuna no entiende',
 d:p=>`Cada vez que frenás la pelota para pensar, la tribuna de ${C(p.club).n} te silba. Quieren todo para adelante, ya. El técnico quiere que la frenes.`,
 c:[
  {t:'Acelerás todo', ef:{hype:4, fanLove:6, com:-2}, r:'La tribuna aplaude cada pase largo. Perdés más pelotas que nunca y el técnico te muestra cuántas en un video de doce minutos.'},
  {t:'Seguís con tu ritmo', ef:{com:3, fanLove:-8, mgrRel:4}, r:'Silbidos todos los domingos. El equipo es el que menos goles recibe de la liga y nadie te lo atribuye a vos.'},
  {t:'Le pedís al técnico que lo explique', ef:{mgrRel:2, hype:-2, moral:2}, r:'Lo explica en una conferencia con una pizarra. Los hinchas no la ven. Un periodista sí, y escribe una columna entera sobre tus pausas.'} ]},

{id:'oc28', w:2, st:['vet','oca'], when:p=>p.pos==='MC' && p.age>=29, veta:'capitan',
 t:'Te quieren de cinco',
 d:p=>`El técnico te propone jugar de cinco, delante de los centrales. Dice que con tu lectura podés durar ahí tres años más. Lo dice como un favor.`,
 c:[
  {t:'Aceptás', ef:{dfs:4, rep:-2, fitness:8}, r:'Corrés la mitad y llegás a todas. Te volvés el que ordena desde atrás y el que nadie mira en la televisión.'},
  {t:'Te negás', ef:{moral:4, mgrRel:-8}, r:'Seguís de ocho. Llegás un paso tarde dos veces por partido, y las dos veces te das cuenta antes que nadie.'},
  {t:'Aceptás si te dan la cinta', ef:{trait:'capitan', flag:'capitan', dfs:2, mgrRel:-4}, r:'El técnico se sorprende y dice que sí. Jugás de cinco con la cinta, y desde ahí atrás se ve todo el equipo.'} ]},

{id:'oc29', w:2, st:['asc','ple','vet'], when:p=>p.pos==='MCD' && p.age>=20,
 t:'La falta táctica',
 d:p=>`El técnico es claro: cuando el rival sale de contra, la cortás con falta y te comés la amarilla. Para eso estás.`,
 c:[
  {t:'Cumplís la orden', ef:{mgrRel:8, fanLove:-3, moral:-4, forma:-3}, r:'Doce amarillas en media temporada, tres partidos de suspensión. El técnico te defiende en todas las conferencias.'},
  {t:'Jugás limpio', ef:{mgrRel:-8, com:2, moral:3}, r:'Corrés hacia atrás en vez de cortar. Te hacen dos goles de contra y el técnico te los muestra en cámara lenta.'},
  {t:'Lo hacés sólo cuando no queda otra', ef:{dfs:2, mgrRel:2}, r:'Elegís cuáles. Algunas veces acertás, otras no. El técnico dice que así está bien, con cara de que no está tan bien.'} ]},

{id:'oc30', w:2, st:['ple','vet'], when:p=>p.pos==='MCD',
 t:'Nadie habla de vos',
 d:p=>`Es época de premios y nadie te nombra. Un dato que circula entre analistas dice que sos el que más pelotas recupera de la liga. Nadie lo publica.`,
 c:[
  {t:'Lo decís vos en una entrevista', ef:{hype:8, rep:3, mgrRel:-3}, r:'Sale el titular con tu número. Lo comparten mucho y se ríen un poco: el que nunca habla, hablando de él.'},
  {t:'Te da igual', ef:{com:2, moral:-3}, r:'Seguís recuperando pelotas para que otros salgan en la tapa. Te convencés de que no te importa casi del todo.'},
  {t:'Le pedís al club que lo difunda', ef:{hype:5, fanLove:3, mgrRel:-2}, r:'El club hace un video con tus quites y música épica. Lo ves una vez y te da vergüenza. Tu vieja lo ve todos los días.'} ]},

{id:'oc31', w:2, st:['asc','ple'], when:p=>p.pos==='LAT' && p.age>=20,
 t:'Subir o quedarse',
 d:p=>`El técnico quiere que pases al ataque en cada jugada. El central de tu lado lo odia, porque cada vez que subís, el que se queda solo es él.`,
 c:[
  {t:'Subís siempre', ef:{hype:4, fitness:-8, mgrRel:6}, r:'Tres asistencias en un mes y dos goles en contra por tu espalda. El central te deja de hablar en los entrenamientos.'},
  {t:'Te quedás atrás', ef:{dfs:2, mgrRel:-8}, r:'El central te invita a comer. El técnico te pone en el banco la fecha siguiente, con otro lateral que sube siempre.'},
  {t:'Arreglás con el central', ef:{lid:3, mgrRel:2, forma:-2}, r:'Un código entre los dos: si él levanta la mano, te quedás. Funciona casi siempre, y cuando no funciona, la culpa es compartida.'} ]},

{id:'oc32', w:2, st:['vet','oca'], when:p=>p.pos==='LAT' && p.age>=29,
 t:'Lateral por adentro',
 d:p=>`El técnico nuevo quiere que, cuando el equipo tiene la pelota, dejes la banda y te metas en el medio. Hace quince años que jugás pegado a la raya.`,
 c:[
  {t:'Aceptás', ef:{pas:4, moral:-3, forma:-3}, r:'Las primeras semanas no sabés dónde pararte. Después descubrís que en el medio se corre menos y se ve más.'},
  {t:'Pedís quedarte en la raya', ef:{mgrRel:-6, moral:3}, r:'Te deja, por ahora. En la pretemporada siguiente el club compra un lateral de veinte años que juega por adentro.'},
  {t:'Le pedís al pibe del medio que te enseñe', ef:{com:2, pas:2, moral:-2}, r:'Tiene veinte años y te explica los perfiles con una paciencia que no esperabas. Te reís los dos de la situación, y aprendés.'} ]},

{id:'oc33', w:2, st:['asc','ple','vet'], when:p=>p.pos==='DFC' && p.age>=20,
 t:'Salir jugando',
 d:p=>`El técnico exige salir jugando desde el arquero, siempre. Ya te comiste dos goles por intentarlo bajo presión. La tribuna grita «¡revoleala!».`,
 c:[
  {t:'Seguís saliendo jugando', ef:{pas:3, fanLove:-6, moral:-4}, r:'Un error más en noviembre. Después ninguno. En marzo la tribuna aplaude un pase entre dos delanteros que hace un año te hubiera insultado.'},
  {t:'La revoleás cuando te aprietan', ef:{mgrRel:-8, fanLove:4}, r:'La tribuna te ama. El técnico te muestra en una reunión cada pelotazo como una pelota regalada.'},
  {t:'Pedís sesiones extra con el arquero', ef:{pas:2, forma:-3, mgrRel:4}, r:'Una hora más por día, los dos solos con un preparador que les presiona. Al mes se entienden sin mirarse.'} ]},

{id:'oc34', w:2, st:['ple','vet','oca'], when:p=>p.pos==='DFC',
 t:'El delantero que te provoca',
 d:p=>`El nueve rival te pisa los talones cuando el árbitro no mira y se tira cuando mira. Ya le sacaron una roja a tu compañero por lo mismo.`,
 c:[
  {t:'Lo marcás sin tocarlo', tira:'com', ef:{},
   bien:{ef:{rep:4, mgrRel:4, moral:6}, r:'Noventa minutos a medio metro, sin una mano. Se tira dos veces y el árbitro no le cobra ninguna.'},
   mal:{ef:{mgrRel:-12, fanLove:-6, moral:-8}, r:'Un roce mínimo en el área, él vuela, penal y roja. Lo ves después en la repetición y casi no lo tocaste.'},
  r:'Te ponés las manos atrás.'},
  {t:'Le marcás territorio desde el primer minuto', ef:{hype:6, moral:3, mgrRel:-6}, r:'Una patada fuerte y legal en el minuto dos. Se queda lejos el resto del partido. Te ganás una amarilla y un apodo.'},
  {t:'Le avisás al árbitro antes del partido', ef:{mgrRel:2, moral:-2, hype:-2}, r:'Te escucha con educación. Al primer pisotón mira para otro lado, como siempre.'} ]},

{id:'oc35', w:2, st:['asc','ple','vet','oca'], when:p=>C(p.club).lg==='ENG' && p.age>=20,
 t:'Boxing Day',
 d:p=>`En Inglaterra no se para en Navidad: tres partidos en ocho días, uno el 26 a la tarde. Tu familia viajó para pasar las fiestas con vos y alquiló una casa a dos horas del estadio.`,
 c:[
  {t:'Jugás los tres', ef:{fanLove:8, fitness:-14, moral:-4}, r:'Ves a tu familia en el desayuno del 25 y en la tribuna del 26. Tu sobrino aprende a cantar la canción del club antes que vos.'},
  {t:'Pedís descanso en uno', ef:{fitness:8, mgrRel:-6, fanLove:-3}, r:'Te dan el del 29. Lo mirás por televisión con tu familia, en un sillón que no es tuyo, y el equipo pierde.'},
  {t:'Los llevás a todos al hotel de concentración', ef:{moral:6, forma:-3}, r:'Navidad en el comedor de un hotel de ruta, con el plantel y sus familias. Es la Navidad más rara de tu vida y una de las mejores.'} ]},

{id:'oc36', w:2, st:['asc','ple','vet','oca'], when:p=>C(p.club).lg==='ESP' && p.age>=20,
 t:'La tertulia de medianoche',
 d:p=>`En España hay programas de radio que discuten fútbol hasta las dos de la mañana. Uno te eligió de tema fijo: todas las noches, cuatro señores debaten si valés lo que costaste.`,
 c:[
  {t:'Llamás en vivo', ef:{hype:10, mgrRel:-4, fitness:-3}, r:'A la una y cuarto, desde tu cocina. Los cuatro se quedan mudos y después te tratan de usted. El club te pide que no lo vuelvas a hacer.'},
  {t:'Dejás de escuchar radio', ef:{com:2, moral:3}, r:'Escuchás música en el auto. Te enterás de lo que dicen por tu familia, que sigue escuchando y te lo cuenta con lujo de detalles.'},
  {t:'Le contestás jugando', ef:{forma:3, moral:-3}, r:'Hacés tu mejor mes en España. El programa dedica una noche entera a decir que siempre lo supieron.'} ]},

{id:'oc37', w:2, st:['asc','ple','vet','oca'], when:p=>C(p.club).lg==='ITA' && p.age>=20,
 t:'La charla de tres horas',
 d:p=>`En Italia el video de análisis dura lo que haga falta. Hoy van tres horas y el técnico de ${C(p.club).n} todavía no llegó al segundo tiempo del partido pasado.`,
 c:[
  {t:'Tomás nota de todo', ef:{dfs:2, com:2, moral:-4}, r:'Llenás un cuaderno. En el partido siguiente sabés dónde va a estar cada rival antes de que llegue, y estás agotado de saberlo.'},
  {t:'Te dormís', ef:{mgrRel:-10, moral:2, fitness:4}, r:'Te despierta la luz cuando prenden. El técnico no dice nada. El sábado jugás en el banco.'},
  {t:'Preguntás todo lo que no entendés', ef:{mgrRel:4, pas:2, forma:-2}, r:'La charla dura cuatro horas. Tus compañeros te odian un rato, y el técnico te pone de ejemplo en la siguiente.'} ]},

{id:'oc38', w:2, st:['asc','ple','vet','oca'], when:p=>C(p.club).lg==='GER' && p.age>=20,
 t:'La tribuna de pie',
 d:p=>`En Alemania la tribuna de pie de ${C(p.club).n} tiene veinte mil personas. Después de una victoria, los socios te invitan a tomar algo con ellos en el bar del estadio.`,
 c:[
  {t:'Vas', ef:{fanLove:12, fitness:-6, mgrRel:-4}, r:'Te quedás tres horas. Aprendés dos canciones y una palabra en alemán que no podés repetir en ninguna entrevista.'},
  {t:'Mandás camisetas firmadas', ef:{fanLove:4}, r:'Las cuelgan en el bar, al lado de las de otros que tampoco fueron.'},
  {t:'Vas una hora, sin alcohol', ef:{fanLove:8, moral:3, forma:-2}, r:'Una hora con un vaso de agua con gas en la mano. Nadie te lo reprocha. Uno te dice que así hacían los de antes.'} ]},

{id:'oc39', w:2, st:['asc','ple','vet'], when:p=>C(p.club).lg==='FRA' && p.age>=20,
 t:'Todo está en venta',
 d:p=>`El director deportivo de ${C(p.club).n} lo dice sin vueltas en una reunión: el club vive de vender, y cada jugador del plantel tiene un precio. Vos también. Te pregunta qué preferís.`,
 c:[
  {t:'Pedís que te pongan en la vidriera', ef:{hype:8, value:6, mgrRel:-4}, r:'El club te hace jugar todos los partidos que miran los ojeadores. Te sentís un auto en una concesionaria, y uno caro.'},
  {t:'Renovás para que no te vendan barato', ef:{contrato:4, wage:8, hype:-4}, r:'Cuatro años y una cláusula alta. El director sonríe: le acabás de subir el precio.'},
  {t:'Te hacés el distraído', ef:{com:2, moral:-2}, r:'Decís que sólo pensás en el próximo partido. Él toma nota de que no dijiste que no.'} ]},

{id:'oc40', w:2, st:['asc','ple','vet','oca'], when:p=>C(p.club).lg==='ARG' && p.age>=20,
 t:'Las elecciones del club',
 d:p=>`Hay elecciones en ${C(p.club).n}. Un candidato promete venderte para pagar las deudas; el otro promete que de acá no te vas. Los dos quieren sacarse una foto con vos esta semana.`,
 c:[
  {t:'Te sacás la foto con el que te quiere retener', ef:{fanLove:6, mgrRel:-4, hype:4}, r:'Gana por veinte votos. El primer mercado después de asumir, te pone en venta igual: dice que la situación cambió.'},
  {t:'Te sacás la foto con los dos', ef:{hype:6, fanLove:-6}, r:'Las dos fotos salen el mismo día. Los socios de los dos lados te reprochan lo mismo desde la tribuna.'},
  {t:'No te metés', ef:{com:2, moral:-2}, r:'Decís que votan los socios, no los jugadores. Gana uno, cambia todo, y nadie te pide cuentas.'} ]},

{id:'oc41', w:2, st:['asc','ple','vet','oca'], when:p=>C(p.club).lg==='BRA' && p.age>=20,
 t:'Cuatro horas de vuelo para el domingo',
 d:p=>`El partido del domingo es en la otra punta de Brasil: cuatro horas de avión, otro clima, y el miércoles hay copa en casa. El técnico de ${C(p.club).n} te pregunta cómo estás.`,
 c:[
  {t:'Viajás con el grupo', ef:{fitness:-6, lid:2, moral:2}, r:'Jugás con calor de treinta y cinco grados y volvés a las cuatro de la mañana. El miércoles las piernas pesan, pero estás.'},
  {t:'Pedís quedarte para la copa', ef:{fitness:10, mgrRel:-6, fanLove:-4}, r:'Te quedás entrenando con los suplentes. El equipo pierde lejos y en el aeropuerto algunos hinchas preguntan por vos.'},
  {t:'Viajás un día antes, pagándolo vos', todo:true, ef:{capital:-0.01, fitness:6, mgrRel:-2}, r:'Llegás descansado. Al club no le hace gracia que alguien se pague su propio hotel, porque ahora todos lo quieren.'} ]},

{id:'oc42', w:2, st:['ple','vet','oca'], when:p=>C(p.club).lg==='SAU',
 t:'Las apariciones del contrato',
 d:p=>`Tu contrato con ${C(p.club).n} incluye veinte apariciones para patrocinadores por temporada. Te mandan el calendario: inauguraciones, cenas, un centro comercial a medianoche.`,
 c:[
  {t:'Hacés las veinte', ef:{capital:0.1, fitness:-6, hype:6, moral:-4}, r:'Cortás cintas, sonreís, firmás. En la vigésima ya no sabés en qué ciudad estás, pero sí cuánto te pagaron.'},
  {t:'Negociás hacer la mitad', ef:{mgrRel:-6, moral:2}, r:'Lo conseguís después de tres reuniones. El club te recuerda, cada vez que puede, que firmaste otra cosa.'},
  {t:'Las hacés todas en un mes', ef:{fitness:-10, forma:-4, hype:4}, r:'Un mes sin dormir y once meses libres. Ese mes jugás tus peores partidos en años.'} ]},

{id:'oc43', w:2, st:['asc','ple','vet','oca'], when:p=>C(p.club).lg==='USA' && p.age>=20,
 t:'El césped sintético',
 d:p=>`El partido de visitante es en una cancha de césped sintético, a cinco horas de avión. Tu rodilla odia el sintético y el técnico de ${C(p.club).n} lo sabe.`,
 c:[
  {t:'Jugás igual', ef:{fitness:-10, mgrRel:4, fanLove:3}, r:'La pelota pica rara y la rodilla te avisa en cada frenada. Ganan, y vos te pasás el vuelo de vuelta con hielo.'},
  {t:'Pedís no viajar', ef:{fitness:6, mgrRel:-8}, r:'Te quedás. El técnico lo explica en la conferencia sin nombrarte, y todos saben de quién habla.'},
  {t:'Jugás un tiempo', ef:{fitness:-4, mgrRel:3}, r:'Cuarenta y cinco minutos con cuidado. No servís mucho y no te lastimás, que en el sintético ya es bastante.'} ]},

{id:'oc44', w:2, st:['asc','ple','vet','oca'], when:p=>C(p.club).lg==='MEX' && p.age>=20,
 t:'La gira por Estados Unidos',
 d:p=>`En pleno receso, ${C(p.club).n} se va de gira a jugar amistosos en estadios de Estados Unidos llenos de hinchas mexicanos. Es plata para el club y cansancio para el plantel.`,
 c:[
  {t:'Vas a la gira', ef:{capital:0.05, fitness:-8, fanLove:6}, r:'Cinco ciudades en doce días. En todas hay alguien con tu camiseta que viajó horas para verte, y eso hace que valga la pena casi todo.'},
  {t:'Pedís quedarte a entrenar', ef:{fitness:8, mgrRel:-4, fanLove:-4}, r:'Hacés la pretemporada solo con el preparador. Llegás al torneo en tu mejor estado, y los afiches de la gira tenían tu cara.'},
  {t:'Vas y das todas las entrevistas', ef:{hype:8, moral:-3, forma:-2}, r:'En inglés, en castellano, en el idioma que te pidan. Volvés con la voz gastada y doscientos mil seguidores más.'} ]},

{id:'oc45', w:2, st:['asc','ple','vet','oca'], when:p=>enSegunda(C(p.club)) && p.age>=20,
 t:'La segunda con vos adentro',
 d:p=>`${C(p.club).n} juega esta temporada en la segunda división. Micros de nueve horas, canchas chicas, y en cada partido un rival que juega el partido de su vida contra vos.`,
 c:[
  {t:'Te quedás a pelear el ascenso', ef:{fanLove:12, rep:-4, moral:-2}, r:'Decís que no te vas hasta subir. La hinchada imprime la frase en una bandera, y desde ese día cada derrota también es tuya.'},
  {t:'Pedís irte a un club de primera', ofr:{t:'menor',cuando:'ventana'}, ef:{fanLove:-12, hype:4}, r:'Tu representante empieza a llamar. En la cancha siguiente, un cartel con tu número tachado.'},
  {t:'Pedís la cinta para el ascenso', ef:{lid:4, mgrRel:4, moral:-3}, r:'Te la dan sin discutir. Cada lunes das una charla en un vestuario sin agua caliente, y te escuchan.'} ]},

{id:'oc46', w:2, st:['asc','ple','vet','oca'], when:p=>enSegunda(C(p.club)) && p.age>=20,
 t:'Dos metros de tribuna',
 d:p=>`En la cancha del rival de esta semana, la tribuna está a dos metros de la línea. Desde el calentamiento, un señor con un nene en brazos te insulta por tu apellido.`,
 c:[
  {t:'Le contestás', ef:{hype:6, mgrRel:-6, moral:3}, r:'Una frase, nada más. El video sale con tu cara y sin la de él, y el lunes tenés que dar explicaciones.'},
  {t:'Le aplaudís al final', ef:{fanLove:6, com:2}, r:'Ganan, y al salir le aplaudís a él, sólo a él. El nene te aplaude también. El señor no sabe dónde meterse.'},
  {t:'Te ponés del otro lado de la cancha', ef:{com:2, mgrRel:-3, moral:-2}, r:'Le pedís al técnico cambiar de banda. Te escucha, te cambia, y en el segundo tiempo el señor también se cambió de lugar.'} ]},

{id:'oc47', w:2, st:['asc','ple'], when:p=>p.age>=20 && p.age<=26,
 t:'El pibe de tu barrio',
 d:p=>`Un nene de catorce años de tu barrio acaba de entrar a las inferiores. Su mamá te para en la calle y te pide, casi sin mirarte, que lo cuides.`,
 c:[
  {t:'Lo tomás bajo tu ala', ef:{flag:'ahijado', lid:3, moral:4, forma:-2}, r:'Le pasás tu número, lo llamás después de cada partido suyo, le regalás tus botines viejos. Te dice «capitán» aunque no lo seas.'},
  {t:'Le pasás tu número y nada más', ef:{moral:-2, forma:2}, r:'Te escribe dos veces. Le contestás una. Después deja de escribir, y vos te olvidás de que te había escrito.'},
  {t:'Le decís a la madre que no le prometa nada', ef:{com:2, fanLove:-3}, r:'Le explicás que de cada cien llegan dos. Ella te agradece la sinceridad con una cara que no agradece nada.'} ]},

{id:'oc48', w:3, req:'ahijado', st:['ple','vet'], when:p=>p.age>=27,
 t:'El pibe ya no es pibe',
 d:p=>`El chico de tu barrio tiene veintiún años, juega en tu puesto y ${C(p.club).n} lo quiere comprar. Antes de firmar te llama a vos: quiere saber si te molesta que venga a pelearte el lugar.`,
 c:[
  {t:'Le decís que venga', ef:{lid:4, mgrRel:4, moral:-4}, r:'Viene. Entrena con vos todos los días y en marzo juega un partido que era tuyo. Después te pide perdón, y no hace falta.'},
  {t:'Le decís que se vaya a otro lado, a jugar', ef:{moral:3, lid:2}, r:'Te hace caso. Juega todos los partidos en un club más chico y cada tanto te manda un video de un gol suyo, sin texto.'},
  {t:'No le contestás', ef:{moral:-6, com:2, unflag:'ahijado'}, r:'Firma igual. En el primer entrenamiento te saluda con la mano, de lejos, como a cualquier otro.'} ]},

{id:'oc49', w:3, req:'ahijado', st:['vet','oca'], when:p=>p.age>=31,
 t:'Su primer gol con la camiseta de su país',
 d:p=>`El chico de tu barrio hace su primer gol con la camiseta de su país. En la entrevista de después, con la camiseta todavía mojada, dice que se lo dedica a vos.`,
 c:[
  {t:'Lo llamás esa misma noche', ef:{moral:10}, r:'Atiende a la una de la mañana, desde el micro. No hablan de fútbol. Hablan de la esquina donde jugaban los dos, en años distintos.'},
  {t:'Le escribís una carta', ef:{moral:6, lid:2}, r:'A mano, dos carillas. Te enterás años después de que la tiene en la billetera, doblada en cuatro.'},
  {t:'Vas a verlo jugar en lugar de entrenar', ef:{moral:8, mgrRel:-6, fanLove:3}, r:'Te escapás a verlo en el próximo partido. Las cámaras te encuentran en la tribuna. Tu técnico también.'} ]},

{id:'oc50', w:2, st:['ini'], when:p=>p.age<=19,
 t:'La primera entrevista',
 d:p=>`Una periodista joven de un diario chico te hace tu primera entrevista larga. Pregunta cosas que nadie te preguntó nunca: de qué tenés miedo, qué vas a hacer si no llegás.`,
 c:[
  {t:'Le contestás todo, de verdad', ef:{flag:'periodista', hype:4, moral:3}, r:'Sale una nota hermosa que lee muy poca gente. Ella te manda un mensaje: «Me acuerdo de los que contestan».'},
  {t:'Contestás lo que te enseñó el club', ef:{mgrRel:4, hype:1}, r:'Respuestas correctas, ninguna mentira, nada adentro. Ella cierra el cuaderno con educación.'},
  {t:'Le pedís que no la publique', ef:{com:2, hype:-2}, r:'Te mira raro, pero cumple. La nota nunca sale. Ella tampoco vuelve.'} ]},

{id:'oc51', w:3, req:'periodista', st:['ple','vet'], when:p=>p.age>=24,
 t:'Te pide una primicia',
 d:p=>`La periodista que te hizo tu primera entrevista trabaja ahora en el medio más grande del país. Te llama: sabe que un compañero tuyo se va del club y necesita que alguien se lo confirme.`,
 c:[
  {t:'Se lo confirmás, sin nombre', ef:{hype:4, mgrRel:-10, moral:-4}, r:'La primicia es de ella. En el vestuario buscan quién habló durante dos semanas. No te encuentran, pero vos sí te encontrás.'},
  {t:'Le decís que no', ef:{mgrRel:4, moral:-2}, r:'Te dice que lo entiende y que te iba a preguntar igual. No se enoja. Te queda la sensación de que te estaba probando.'},
  {t:'Le das otra historia: la tuya', ef:{hype:8, rep:2, moral:-3}, r:'Le contás algo tuyo que nunca contaste. Sale en tapa. Es más de lo que querías dar, y lo cuenta mejor de lo que pensabas.'} ]},

{id:'oc52', w:3, req:'periodista', st:['oca'], when:p=>p.age>=33,
 t:'El libro',
 d:p=>`La periodista que te descubrió quiere escribir tu biografía. Te pide acceso a todo: tu familia, tus técnicos, los años malos.`,
 c:[
  {t:'Le das todo', ef:{hype:10, fanLove:6, moral:-6}, r:'El libro se vende muchísimo. Hay un capítulo que tu vieja no quiere leer y que vos leíste tres veces.'},
  {t:'Sólo lo deportivo', ef:{hype:4, com:2}, r:'Sale un buen libro sobre un buen jugador. Ella te dice, en la presentación, que le quedó la mitad afuera.'},
  {t:'Le pedís que espere a que te retires', ef:{moral:3, hype:-2}, r:'Te dice que sí, que esperó quince años y puede esperar uno más. Te queda la sensación de tener una deuda con fecha.'} ]},

{id:'oc53', w:2, st:['asc','ple'], when:p=>p.age>=20 && p.capital>=0.2,
 t:'Un amigo con una idea',
 d:p=>`Tu amigo de toda la vida quiere abrir un complejo de canchas de fútbol cinco. Tiene el terreno, el plan y ganas. Le falta la plata, y te la pide a vos.`,
 c:[
  {t:'Ponés la plata', ef:{capital:-0.15, flag:'socio', moral:4}, r:'Firman en la mesa de la cocina de su casa. Te dice que le pongan tu nombre a la cancha uno. Le decís que no, y la cancha uno tiene tu nombre.'},
  {t:'Ponés el nombre, no la plata', ef:{hype:3, flag:'socioNombre'}, r:'Consigue otro inversor con tu foto en la presentación. El complejo abre con tu cara en el cartel de la entrada.'},
  {t:'Le decís que no', ef:{moral:-4, com:2}, r:'Lo entiende, o dice que lo entiende. En el cumpleaños de su hijo te sientan en la otra punta de la mesa.'} ]},

{id:'oc54', w:3, req:'socio', st:['vet','oca'], when:p=>p.age>=28,
 t:'El complejo pierde plata',
 d:p=>`El complejo de canchas que abriste con tu amigo pierde plata desde hace un año. Te llama a las once de la noche: necesita otra inyección o cierra en un mes.`,
 c:[
  {t:'Ponés lo que haga falta', todo:true, ef:{capital:-0.1, moral:3}, r:'Aguanta otra temporada. Tu amigo trabaja catorce horas por día y te manda fotos de las canchas llenas los jueves.'},
  {t:'Cerrás', ef:{capital:0.03, moral:-8, unflag:'socio'}, r:'Venden los arcos y las redes. Lo que recuperan no alcanza para nada. La amistad sigue, un poco más callada.'},
  {t:'Lo ponés a cargo a él y te corrés', ef:{com:2, moral:2}, r:'Le decís que haga lo que crea, sin tu plata. Lo achica a la mitad, alquila la otra mitad a una escuela, y no cierra.'} ]},

{id:'oc55', w:3, req:'socioNombre', st:['ple','vet','oca'], when:p=>p.age>=25,
 t:'Tu cara en la puerta',
 d:p=>`El complejo que lleva tu foto en la entrada tuvo un problema: un chico se lastimó en una cancha con el arco mal amurado. Los diarios usan tu nombre en el título.`,
 c:[
  {t:'Salís a dar la cara', ef:{fanLove:4, moral:-4, hype:-2}, r:'Vas a visitar al chico. Está bien, y te pide una foto. Salís en los diarios otra vez, de otra forma.'},
  {t:'Pedís que saquen tu foto', ef:{hype:-4, com:2, unflag:'socioNombre'}, r:'La sacan esa misma semana. Tu amigo no te lo reprocha. El cartel nuevo dice sólo el nombre del lugar.'},
  {t:'Decís que vos sólo prestaste la cara', ef:{fanLove:-6, com:2}, r:'Es verdad, y queda horrible. Tu amigo se entera por la televisión de que no era tu socio.'} ]},

{id:'oc56', w:2, st:['ini'], when:p=>p.age<=18,
 t:'La promesa al club del barrio',
 d:p=>`Te vas del club de barrio donde jugaste desde los cinco años. El técnico de siempre, que ya tiene setenta, te despide en la puerta y te pide una sola cosa: que algún día vuelvas.`,
 c:[
  {t:'Le prometés volver', ef:{flag:'promesaBarrio', moral:4, fanLove:3}, r:'Le das la mano. Te la aprieta fuerte, como cuando te enseñó a pegarle con el empeine.'},
  {t:'Le prometés mandar camisetas', ef:{moral:2}, r:'Se ríe y te dice que con eso alcanza. En la vitrina del club ya hay lugar reservado.'},
  {t:'No prometés nada', ef:{com:2, moral:-3}, r:'Le decís que no sabés dónde vas a estar. Te dice que tenés razón y se queda mirándote ir.'} ]},

{id:'oc57', w:3, req:'promesaBarrio', st:['ple','vet'], when:p=>p.age>=24,
 t:'El club del barrio se queda sin luz',
 d:p=>`Al club de barrio donde empezaste le cortaron la luz por una deuda. Los chicos entrenan con las luces de los autos. El técnico de siempre no te pidió nada; te enteraste por otro.`,
 c:[
  {t:'Pagás la deuda', todo:true, ef:{capital:-0.03, fanLove:6, moral:6}, r:'Lo hacés sin avisar. Al otro día te llega un audio del técnico de siempre, que habla dos minutos y no dice nada entendible.'},
  {t:'Organizás un partido a beneficio', ef:{hype:6, fitness:-4, mgrRel:-3, fanLove:4}, r:'Juntás a medio plantel un lunes de descanso. Se llena la canchita y alcanza para la luz y para pintar los vestuarios.'},
  {t:'Lo dejás para más adelante', ef:{moral:-6, fitness:3}, r:'Le mandás un mensaje diciendo que más adelante. El técnico de siempre te contesta con un pulgar para arriba.'} ]},

{id:'oc58', w:3, req:'promesaBarrio', st:['oca'], when:p=>p.age>=33,
 t:'Cumplir la promesa',
 d:p=>`El técnico de tu club de barrio cumple ochenta años. Le van a hacer un partido de homenaje con los veteranos del club, un domingo a la mañana. Te mandan la invitación sin esperar respuesta.`,
 c:[
  {t:'Vas a jugar', ef:{moral:12, fitness:-6, mgrRel:-4}, r:'Jugás un tiempo con los que eran grandes cuando vos eras chico. El técnico de siempre te grita igual que hace treinta años, y te corrige el perfil.'},
  {t:'Le decís que vas cuando te retires', ef:{moral:2}, r:'Te contesta que a su edad los planes se hacen de a una semana. Lo dice riéndose.'},
  {t:'Le mandás una camiseta firmada', ef:{moral:-6, com:2}, r:'La cuelga en la vitrina del club, al lado de la otra que le mandaste hace años. Es el único que no menciona la promesa.'} ]},

{id:'oc59', w:2, st:['ini'], when:p=>p.age<=19,
 t:'La beca',
 d:p=>`Una universidad de Estados Unidos te ofrece una beca completa para estudiar y jugar al fútbol allá. Es la única carta de tu vida que tu vieja abrió antes que vos.`,
 c:[
  {t:'Le decís que no: el club es tu camino', ef:{forma:3, mgrRel:4, moral:-4}, r:'Tu vieja guarda la carta en el cajón de los papeles importantes, al lado de tu partida de nacimiento. No la tira nunca.'},
  {t:'Pedís estudiar a distancia mientras jugás', ef:{com:2, fitness:-4, moral:3}, r:'No es la misma universidad ni la misma beca: es una materia por cuatrimestre, de noche. Aprobás la primera con un siete, en la pensión.'},
  {t:'Le contás al club que la tenés', ef:{mgrRel:-4, wage:10, hype:2}, r:'En una semana te ofrecen tu primer contrato con un sueldo de verdad. La carta, sin que vos lo planearas, negoció por vos.'} ]},

{id:'oc60', w:2, st:['ini'], when:p=>p.age<=19,
 t:'Tu hermano, el que no llegó',
 d:p=>`Tu hermano mayor también jugaba, y lo dejaron libre a los diecisiete. Desde que vos empezaste a sonar, dejó de ir a verte. Esta semana debutás, y no sabés si va a ir.`,
 c:[
  {t:'Lo invitás vos, directamente', ef:{moral:6, forma:-2}, r:'Te dice que va a ver si puede. En el segundo tiempo lo ves, en la última fila, solo, con la campera que usaba para ir a entrenar.'},
  {t:'Le pedís a tu vieja que lo convenza', ef:{moral:2}, r:'Tu vieja lo convence y él va. Se sienta lejos de la familia y se va antes del final.'},
  {t:'No le decís nada', ef:{com:2, moral:-5}, r:'No va. A la noche te manda un mensaje: «Te vi por la tele. Buen primer toque». Lo leés diez veces.'} ]},

{id:'oc61', w:2, st:['ini'], when:p=>p.age<=19,
 t:'El primer avión',
 d:p=>`La juvenil de ${C(p.club).n} viaja a un torneo y es la primera vez que te subís a un avión. En el aeropuerto te transpiran las manos y los demás ya se dieron cuenta.`,
 c:[
  {t:'Lo decís en voz alta', ef:{lid:2, moral:3, hype:-1}, r:'Decís que nunca volaste. Se ríen, y después dos más confiesan lo mismo. Viajan los tres juntos en la fila del medio.'},
  {t:'Hacés como si nada', ef:{com:2, forma:-3}, r:'Pasás el vuelo agarrado del apoyabrazos con cara de aburrido. Llegás con la espalda dura y jugás el primer partido como si siguieras sentado.'},
  {t:'Le pedís la ventanilla al capitán', ef:{moral:5, mgrRel:-2}, r:'Te la da. Pegás la cara al vidrio durante tres horas. Tu ciudad desde arriba es más chica de lo que pensabas.'} ]},

{id:'oc62', w:2, st:['ini'], when:p=>p.age>=17 && p.age<=19,
 t:'El video del vestuario',
 d:p=>`Un compañero de la Reserva filma a otro mientras los más grandes lo bautizan en la ducha. El video circula en el grupo del plantel, y en el fondo se te ve a vos.`,
 c:[
  {t:'Se lo contás al coordinador', ef:{lid:3, mgrRel:4, moral:-6}, r:'Se termina el bautismo para siempre en esa categoría. A vos te cambian de mesa en el comedor, y te quedás ahí.'},
  {t:'Pedís que lo borren', ef:{com:2, moral:-2}, r:'Lo borran del grupo. No de todos los teléfonos. El chico del video te saluda distinto desde entonces.'},
  {t:'Te hablás con el chico del video', ef:{moral:3, lid:2, forma:-2}, r:'Le preguntás si quiere que hagas algo. Te dice que no, que lo deje así. Al mes es tu mejor amigo en la pensión.'} ]},

{id:'oc63', w:2, st:['ini'], when:p=>p.age<=19,
 t:'La rifa de la escuela',
 d:p=>`La escuela de tu hermana menor hace una rifa para el viaje de fin de año. Le pidieron que consiguiera algo tuyo para el premio mayor, y ella ya dijo que sí.`,
 c:[
  {t:'Donás tu camiseta del debut', ef:{fanLove:4, moral:-3}, r:'Se vende el doble de números que el año pasado. La gana un señor que no conocés. Tu hermana te mira como si fueras otro.'},
  {t:'Ofrecés una tarde de entrenamiento con vos', ef:{fanLove:6, fitness:-3, lid:2}, r:'La gana un nene de nueve años que llega con botines de otro número. Terminás jugando dos horas con él y con su papá.'},
  {t:'Le decís a tu hermana que no', ef:{moral:-5, com:2}, r:'Le explicás que si das una, te van a pedir cien. Es verdad, y tu hermana no te habla en toda la semana.'} ]},

{id:'oc64', w:2, st:['oca'], when:p=>p.age>=33,
 t:'El curso de comentarista',
 d:p=>`Un canal te ofrece entrenarte como comentarista: una vez por semana, en el estudio, para que estés listo cuando te retires. El horario choca con la recuperación del lunes.`,
 c:[
  {t:'Aceptás', ef:{hype:6, com:2, fitness:-6, mgrRel:-3}, r:'Aprendés a mirar a la cámara correcta y a hablar en treinta segundos. Una tarde te hacen analizar un partido tuyo, y sos muy duro.'},
  {t:'Pedís empezar cuando te retires', ef:{moral:2, hype:-2}, r:'Te dicen que sí, con menos entusiasmo. Te mandan un correo cada seis meses para ver si seguís jugando.'},
  {t:'Decís que no vas a ser comentarista', ef:{com:2, moral:3, hype:-4}, r:'Lo decís con convicción. Más tarde te descubrís mirando cómo lo hace otro y pensando qué hubieras dicho vos.'} ]},

{id:'oc65', w:2, st:['oca'], when:p=>p.age>=33,
 t:'Las rodillas de los cincuenta',
 d:p=>`El traumatólogo de ${C(p.club).n} te lo dice sin dramatismo: cada temporada que jugás ahora es una que vas a sentir cuando quieras jugar con tus nietos.`,
 c:[
  {t:'Bajás la carga y aceptás jugar menos', ef:{fitness:10, rep:-4, hype:-4}, r:'Jugás la mitad de los partidos. Los jugás bien. Aprendés a mirar los otros desde el banco sin que te pique el cuerpo.'},
  {t:'Seguís igual', ef:{fanLove:4, fitness:-10, moral:3}, r:'Le decís que los nietos te van a ver jugar en video. Se ríe. No dice nada más.'},
  {t:'Decidís que esta es la última', ef:{retiro:1, moral:6}, r:'Salís del consultorio con la decisión tomada y llamás a una sola persona. El resto se entera por el club, semanas después.'} ]},

{id:'oc66', w:2, st:['oca'], when:p=>p.age>=33,
 t:'El contrato con fecha de despedida',
 d:p=>`${C(p.club).n} te ofrece renovar un año, con una condición escrita: al final, retiro y partido despedida en el estadio. Lo traen impreso, con la fecha del partido ya puesta.`,
 c:[
  {t:'Firmás', ef:{retiro:1, contrato:1, fanLove:10, moral:4}, r:'Firmás con la birome que te prestan. Esa temporada cada estadio rival te aplaude un poco, como si ya te estuvieran despidiendo ellos también.'},
  {t:'Pedís dos años sin cláusula', ef:{mgrRel:-8, moral:3}, r:'Te dicen que lo van a pensar. Lo piensan tres meses, y mientras tanto jugás sin saber si es el último año o no.'},
  {t:'Le pedís a tu familia que lo lea', ef:{moral:-2, com:2}, r:'Lo leen en la mesa del comedor. Nadie dice que firmes. Nadie dice que no. Alguien pregunta si en el partido despedida pueden entrar los chicos a la cancha.'} ]},

{id:'oc67', w:2, st:['oca'], when:p=>p.age>=34,
 t:'El equipo de veteranos',
 d:p=>`Un club amateur de tu ciudad natal te ofrece jugar en su equipo de veteranos cuando te retires. Juegan los sábados a la mañana y después hay asado.`,
 c:[
  {t:'Les decís que sí', ef:{moral:8}, r:'Te mandan la camiseta con tu número de siempre. La colgás en el placard al lado de las profesionales, y es la que más mirás.'},
  {t:'Les decís que todavía no pensás en eso', ef:{forma:2, moral:-2}, r:'Te dicen que no hay apuro. Te agregan igual al grupo del equipo, que manda doscientos mensajes por día sobre el asado.'},
  {t:'Les ofrecés entrenarlos', ef:{lid:3, moral:4, fitness:-2}, r:'Los visitás un sábado. Querés poner un sistema con tres atrás. El arquero tiene sesenta y dos años y te pregunta si eso es con o sin asado.'} ]},

{id:'oc68', w:2, st:['oca'], when:p=>p.age>=33,
 t:'El último vestuario',
 d:p=>`El plantel de ${C(p.club).n} tiene un promedio de edad de veintitrés años. En el grupo hablan de cosas que no entendés y en el micro ponen música que no conocés. Te miran como a un tío.`,
 c:[
  {t:'Te metés en todo', ef:{moral:4, lid:2, com:-2}, r:'Aprendés tres bailes y te equivocás en los tres. Te filman, lo suben, y es lo más visto del club en el año.'},
  {t:'Hacés de tío, con gusto', ef:{lid:4, mgrRel:3, hype:-2}, r:'Te vienen a consultar por contratos, por parejas, por el auto. Nadie te pregunta por fútbol, y te das cuenta de que eso ya lo saben.'},
  {t:'Te ponés los auriculares', ef:{com:2, moral:-4}, r:'Escuchás tu música en el micro. Llegás a los partidos tranquilo y te vas solo. Te respetan mucho y te invitan poco.'} ]},

{id:'oc69', w:3, st:['ple','vet','oca'], when:p=>p.seasons.reduce((a,s)=>a+(s.goals||0),0)>=100 && p.seasons.reduce((a,s)=>a+(s.goals||0),0)<=130,
 t:'Cien goles',
 d:p=>`Pasaste los cien goles en tu carrera. ${C(p.club).n} quiere hacerte un homenaje antes del próximo partido, en la cancha, con una camiseta enmarcada y tu familia en el círculo central.`,
 c:[
  {t:'Aceptás el homenaje', ef:{fanLove:8, hype:6, forma:-3}, r:'Diez minutos con el estadio de pie y tu vieja llorando en el círculo central. Después hay que jugar, y te cuesta entrar en el partido.'},
  {t:'Pedís que lo hagan al final de la temporada', ef:{com:2, mgrRel:3}, r:'Lo pasan para el último partido. Para entonces ya son más de cien, y el cuadro lo tienen que volver a imprimir.'},
  {t:'Pedís que el homenaje sea para el utilero', ef:{lid:3, fanLove:4, moral:3}, r:'Decís que cien goles necesitaron cien camisetas limpias. El utilero sale al círculo central con tu familia y no sabe qué hacer con las manos.'} ]},

{id:'oc70', w:3, st:['vet','oca'], when:p=>p.seasons.reduce((a,s)=>a+(s.apps||0),0)>=500 && p.seasons.reduce((a,s)=>a+(s.apps||0),0)<=560,
 t:'Quinientos partidos',
 d:p=>`Llegaste a los quinientos partidos profesionales. Un estadístico calcula que corriste la distancia de ida y vuelta hasta el país vecino, y te lo cuenta como si fuera una buena noticia.`,
 c:[
  {t:'Lo festejás con el plantel', ef:{moral:6, fitness:-4, lid:2}, r:'Pagás la cena para todos. El pibe más chico del plantel hace un brindis y se equivoca en el número: dice cincuenta. Nadie lo corrige.'},
  {t:'Te sentás a hacer la cuenta de los que te faltan', ef:{com:2, moral:-4}, r:'Con suerte, cuarenta más. Escribís el número en un papel y lo guardás en la billetera. No se lo mostrás a nadie.'},
  {t:'Le regalás la camiseta del 500 a tu primer técnico', ef:{moral:5, fanLove:3}, r:'Se la mandás por correo con una nota corta. Te contesta con una foto: la camiseta puesta en un maniquí, en el living de su casa.'} ]},

];
EVENTS.push(...EVENTS14);


const EVENTS15 = [

{id:'dn1', w:3, req:'heredero', st:['ini'], when:p=>p.age<=18,
 t:'El apellido en la planilla',
 d:p=>`En tu primer partido de inferiores el locutor dice tu apellido y la tribuna aplaude. No te aplauden a vos: aplauden a tu viejo, que está sentado en la tercera fila.`,
 c:[
  {t:'Pedís que te nombren por tu nombre', ef:{com:2, hype:-4, moral:3}, r:'El locutor te hace caso desde el partido siguiente. Medio estadio no sabe quién sos, y eso por un rato es un alivio.'},
  {t:'Lo disfrutás', ef:{hype:6, moral:3, forma:-3}, r:'Saludás a la tribuna como si fuera tuya. Jugás nervioso, apurado por estar a la altura de un aplauso que no era para vos.'},
  {t:'Le pedís a tu viejo que no venga más', ef:{moral:-4, forma:4, com:2}, r:'Te dice que entiende. Al otro partido no está en la tercera fila. Lo ves en el auto, en el estacionamiento, con la radio prendida.'} ]},

{id:'dn2', w:3, req:'heredero', st:['ini','asc'], when:p=>!!p.flags.apellidoPesado,
 t:'Pantalla partida',
 d:p=>`Un programa pone en pantalla partida un gol tuyo y uno de tu viejo a la misma edad. Al lado de cada uno, un número. El tuyo es más chico.`,
 c:[
  {t:'Decís que sos otro jugador', ef:{com:3, hype:-3}, r:'Lo decís bien, sin enojo. El programa usa la frase como título del bloque siguiente, con la pantalla partida de fondo.'},
  {t:'Prometés superarlo', ef:{hype:10, moral:-4, mgrRel:-2}, r:'Titular en todos lados. Tu viejo te manda un mensaje con un solo emoji, y no sabés si es orgullo o susto.'},
  {t:'Lo mirás con tu viejo', ef:{moral:6, forma:-2}, r:'Él se ríe del suyo: dice que el arquero era malísimo. Del tuyo no dice nada; lo rebobina dos veces.'} ]},

{id:'dn3', w:3, req:'heredero', st:['asc','ple'], when:p=>p.dinastia && p.club===p.dinastia.club,
 t:'La canción de tu viejo',
 d:p=>`En ${C(p.club).n}, la tribuna todavía canta la canción que le hacían a tu viejo. Ahora te la cantan a vos, con tu apellido, cada vez que tocás la pelota.`,
 c:[
  {t:'La aplaudís después de cada gol', ef:{fanLove:10, moral:4, com:-2}, r:'La tribuna se vuelve loca. Ya no sabés si te quieren a vos o a lo que te recuerdan.'},
  {t:'Le pedís a la barra una canción tuya', ef:{fanLove:-4, hype:6, lid:2}, r:'Tardan dos meses. La canción nueva es peor y más corta, y es tuya.'},
  {t:'No decís nada', ef:{com:2, moral:-2}, r:'La canción sigue. Un día, sin que nadie lo decida, le cambian una palabra y queda tu nombre.'} ]},

{id:'dn4', w:2, req:'heredero', st:['asc','ple','vet'], when:p=>p.dinastia && p.club!==p.dinastia.club,
 t:'Contra el club de tu viejo',
 d:p=>`Te toca jugar contra el club donde tu viejo es ídolo. En la previa, la hinchada rival cuelga una bandera con su cara y la palabra «traidor» chiquita, abajo.`,
 c:[
  {t:'Jugás como cualquier otro partido', ef:{com:3, forma:2, hype:-2}, r:'Noventa minutos sin mirar la bandera. Al final, el capitán rival te da la mano y te dice que tu viejo hubiera hecho lo mismo.'},
  {t:'Si hacés un gol, no lo festejás', ef:{fanLove:-6, moral:4, lid:2}, r:'Avisás en la conferencia. Tu hinchada no lo entiende; la de ellos te aplaude cuando salís reemplazado.'},
  {t:'Le pedís a tu viejo que se siente con tu hinchada', ef:{hype:8, fanLove:6, moral:-4}, r:'Lo hace. La foto de él con tu camiseta en la tribuna equivocada es la imagen de la fecha, y en su viejo club no se la perdonan.'} ]},

{id:'dn5', w:2, req:'heredero', st:['ple','vet'],
 t:'Tu viejo opina en televisión',
 d:p=>`Tu viejo ahora es comentarista. Anoche, en vivo, dijo que en tu puesto le falta personalidad al equipo. No dijo tu nombre; no hacía falta.`,
 c:[
  {t:'Lo llamás esa noche', ef:{moral:-3, lid:2, forma:2}, r:'Discuten una hora. Al final te dice que tiene razón y que por eso lo dijo. También tiene razón en eso.'},
  {t:'Le contestás en la conferencia', ef:{hype:8, moral:3, mgrRel:-4}, r:'Una frase corta y filosa. Es la pelea padre e hijo más vista del año. En el asado del domingo nadie la menciona.'},
  {t:'Te lo tomás como un consejo', ef:{lid:3, com:2, moral:-3}, r:'Empezás a hablar más en la cancha. Él lo nota en el partido siguiente y en la tele dice que el equipo mejoró, sin decir por qué.'} ]},

{id:'dn6', w:2, req:'heredero', st:['ple','vet'], when:p=>!!p.flags.apellidoPesado,
 t:'Padre e hijo en el comercial',
 d:p=>`Una marca quiere filmar un comercial con vos y tu viejo, pateando en el patio de la casa donde creciste. Pagan muy bien y el guion termina con él diciendo «es mejor que yo».`,
 c:[
  {t:'Aceptás tal cual', ef:{capital:0.15, hype:10, moral:-4}, r:'Él dice la frase en la primera toma, sin pestañear. Te queda la duda de si la dijo porque estaba en el guion.'},
  {t:'Pedís cambiar el final', ef:{capital:0.08, hype:5, com:2}, r:'El final nuevo es los dos tirados en el pasto, sin decir nada. Pagan menos. Es el que tu vieja pone cuando hay visitas.'},
  {t:'Decís que no', ef:{moral:2, hype:-4}, r:'La marca filma con otra familia de futbolistas. Tu viejo te dice que hiciste bien, y después ve el comercial de los otros tres veces.'} ]},

{id:'dn7', w:2, req:'heredero', st:['vet','oca'], when:p=>p.age>=29,
 t:'Ya no te dicen «el hijo de»',
 d:p=>`Te das cuenta leyendo el diario: hace un año que nadie escribe «el hijo de» antes de tu nombre. En el último titular, el que aparece entre paréntesis es tu viejo.`,
 c:[
  {t:'Le mandás el recorte', ef:{moral:6, lid:2}, r:'Te contesta con una foto: el recorte pegado en la heladera, al lado de los suyos de hace treinta años.'},
  {t:'Lo guardás para vos', ef:{com:3, moral:4, hype:-2}, r:'No se lo decís a nadie. Esa noche dormís como no dormías desde las inferiores.'},
  {t:'Le pedís al diario que lo vuelvan a nombrar', ef:{fanLove:4, hype:3, moral:-2}, r:'El periodista se ríe y te dice que eso no se pide. Al domingo siguiente, en una nota sobre vos, aparece una foto de los dos.'} ]},

{id:'dn8', w:3, req:'heredero', st:['oca'], when:p=>p.age>=33,
 t:'El nieto',
 d:p=>`Tu viejo te llama un martes: tu sobrino de nueve años la rompe en el baby fútbol del barrio. Te pide que lo vayas a ver el sábado, que juega a la misma hora que vos.`,
 c:[
  {t:'Le pedís al técnico faltar a un partido', ef:{moral:10, mgrRel:-8}, r:'Vas. El nene hace dos goles y festeja mirando a la tribuna, donde están sentados tu viejo y vos, uno al lado del otro.'},
  {t:'Le pedís a tu viejo que lo filme', ef:{moral:4, forma:2}, r:'El video está movido y se escucha más a tu viejo gritando que el partido. Lo mirás en el micro de vuelta, cuatro veces.'},
  {t:'Le decís que todavía es muy chico', ef:{com:2, moral:-4}, r:'Tu viejo se queda callado un rato largo. Después te dice que eso mismo le dijeron a él de vos.'} ]},

];
EVENTS.push(...EVENTS15);


function stageOf(p){
  return p.age<=19?'ini' : p.age<=23?'asc' : p.age<=28?'ple' : p.age<=32?'vet' : 'oca';
}
const CATS = {per:'Vida personal', car:'Carrera', clu:'Club', mun:'Mundo', leg:'Legendario'};
const EV_CAT = {
  t1:'mun', t2:'mun', t3:'mun', t4:'leg', t5:'leg',
  t6:'per', t7:'per', t8:'car', t9:'car', t10:'per', t11:'per', t12:'clu',
  t13:'mun', t14:'car', t15:'car', t16:'clu', t17:'clu', t18:'per',
  t19:'mun', t20:'car', t21:'clu', t22:'per',
  t23:'per', t24:'car', t25:'leg', t26:'leg', t27:'per', t28:'car', t29:'leg', t30:'leg',
  ca1:'car', ca2:'per', ca3:'per', ca4:'car',
  i1:'per', i2:'per', i8:'per', i9:'per', a5:'per', p3:'per', v9:'per', v5:'per',
  e24:'per', e16:'per', e45:'per', e43:'per', x4:'per', o4:'per', v3:'per',
  e2:'per', p9:'per', e32:'per', g2:'per', e12:'per', g16:'per', o3:'per',

  e1:'car', e3:'car', e4:'car', e5:'car', e6:'car', e13:'car', e18:'car', e23:'car',
  e25:'car', e30:'car', e33:'car', e44:'car', e11:'car', e15:'car', e19:'car',
  e31:'car', e40:'car', e20:'car', e26:'car', e36:'car', e41:'car',
  i3:'car', i5:'car', i6:'car', i7:'car', i10:'car', i11:'car', i13:'car', i14:'car',
  a1:'car', a4:'car', a6:'car', a8:'car', a9:'car', a10:'car', a12:'car',
  p5:'car', p8:'car', v1:'car', v4:'car', v7:'car', v10:'car', v2:'car',
  o1:'car', o5:'car', o8:'car', o7:'car', x3:'car', x5:'car',
  g1:'car', g3:'car', g4:'car', g5:'car', g6:'car', g7:'car', g9:'car', g10:'car',
  g13:'car', g14:'car', g15:'car', g17:'car', g18:'car', g19:'car', g23:'car',
  g24:'car', g25:'car', g26:'car', g27:'car', g28:'car',

  e7:'clu', e8:'clu', e10:'clu', e14:'clu', e17:'clu', e22:'clu', e27:'clu',
  e28:'clu', e29:'clu', e34:'clu', e37:'clu', i4:'clu', i12:'clu',
  a2:'clu', a3:'clu', a7:'clu', p4:'clu', p10:'clu', p11:'clu', v8:'clu', o6:'clu',
  x1:'clu', x6:'clu', g8:'clu', g11:'clu', g12:'clu', g20:'clu', g21:'clu',
  g22:'clu', g29:'clu', g30:'clu', g31:'clu',

  e9:'mun', e38:'mun', e39:'mun', p6:'mun', x2:'mun',

  p1:'leg', p2:'leg', p7:'leg', p12:'leg', a11:'leg', e21:'leg', e35:'leg',
  e42:'leg', o2:'leg', v6:'leg',

  n5:'car', n9:'car', n10:'car', n22:'car', n23:'car', n24:'car',
  n6:'per', n7:'per', n8:'per', n15:'per', n16:'per', n17:'per', n18:'per', n21:'per',
  n19:'clu', n20:'clu',
  n11:'mun', n12:'mun', n13:'mun', n14:'mun',
  n1:'car', n2:'car', n3:'clu', n4:'leg',

  m1:'mun', m2:'mun', m3:'mun', m4:'mun', m5:'mun', m6:'mun',
  m7:'mun', m8:'mun', m9:'mun', m10:'mun', m11:'mun', m12:'mun',
  m13:'clu', m14:'car', m15:'clu', m16:'per', m17:'car', m18:'per',
  m19:'clu', m20:'car', m21:'per', m22:'per', m23:'car', m24:'car',
  m25:'clu', m26:'leg', m27:'leg', m28:'per', m29:'car', m30:'per',

  j1:'per', j2:'car', j3:'per', j4:'car', j5:'car',
  j6:'per', j7:'per', j8:'per', j9:'car',
  j10:'clu', j11:'per', j12:'clu', j13:'clu',
  j14:'per', j15:'per', j16:'per', j17:'per',
  j18:'per', j19:'per', j20:'per', j21:'per',
  j22:'clu', j23:'clu', j24:'clu', j25:'clu', j26:'clu',
  j27:'car', j28:'car', j29:'car', j30:'clu',

  c1:'clu', c2:'car', c3:'car', c4:'car', c5:'clu', c6:'car',

  x7:'per', x8:'per', x9:'mun', x10:'per', x11:'clu', x12:'mun', x13:'per', x14:'per',
  q1:'car', q2:'car', q3:'car', q4:'clu', q5:'clu', q6:'leg', q7:'leg',
  w1:'clu', w2:'mun', w3:'leg', w4:'clu', w5:'clu', w6:'per',
  z1:'clu', z2:'car', z3:'car', z4:'car', z5:'per',
  k1:'car', k2:'clu', k3:'car', k4:'car',

  oc1:'car', oc2:'car', oc3:'clu', oc4:'per', oc5:'car', oc6:'car', oc7:'clu', oc8:'per', oc9:'car', oc10:'car', oc11:'car', oc12:'clu', oc13:'car', oc14:'leg', oc15:'clu', oc16:'clu', oc17:'car', oc18:'per', oc19:'leg', oc20:'clu', oc21:'car', oc22:'car', oc23:'car', oc24:'car', oc25:'car', oc26:'car', oc27:'clu', oc28:'car', oc29:'clu', oc30:'car', oc31:'clu', oc32:'car', oc33:'clu', oc34:'car', oc35:'clu', oc36:'mun', oc37:'clu', oc38:'clu', oc39:'car', oc40:'clu', oc41:'clu', oc42:'per', oc43:'car', oc44:'clu', oc45:'clu', oc46:'clu', oc47:'per', oc48:'car', oc49:'leg', oc50:'per', oc51:'car', oc52:'leg', oc53:'per', oc54:'per', oc55:'per', oc56:'per', oc57:'per', oc58:'leg', oc59:'per', oc60:'per', oc61:'per', oc62:'clu', oc63:'per', oc64:'car', oc65:'car', oc66:'car', oc67:'per', oc68:'clu', oc69:'leg', oc70:'leg',
  dn1:'per', dn2:'car', dn3:'clu', dn4:'car', dn5:'per', dn6:'per', dn7:'leg', dn8:'leg'
};
const catDe = e => EV_CAT[e.id] || 'car';

const MEM_TOPE = 6;        
const MEM_OLVIDO = 8;      

function pesoMemoria(id, mem, carrera){
  const m = mem && mem[id];
  if(!m) return 2.2;                                   
  const veces = Math.min(m.n || 0, MEM_TOPE);
  const desde = Math.max(0, carrera - (m.c || 0));     
  const castigo = 1 / (1 + veces * 0.9);               
  const perdon = Math.min(1, desde / MEM_OLVIDO);      
  return clamp(castigo + (1 - castigo) * perdon, 0.18, 2.2);
}

function pesoRareza(e, mem, carrera){
  const raro = (e.w || 1) <= 2;
  if(!raro) return 1;
  if(mem && mem[e.id]) return 1;
  return clamp(1 + carrera * 0.14, 1, 3.5);
}

function pickEvents(p, n=3){
  const st = stageOf(p);
  const vistos = new Set(p.seenEvents);
  const unseen = EVENTS.filter(e => !vistos.has(e.id));
  const marcas = e => (!e.req  || [].concat(e.req).every(f=>p.flags[f]))
                   && (!e.veta || ![].concat(e.veta).some(f=>p.flags[f]));
  const fits = e => marcas(e) && (!e.st || e.st.includes(st)) && (!e.when || e.when(p));
  let pool = unseen.filter(fits);
  if(pool.length < n){
    const near = {ini:['asc'], asc:['ini','ple'], ple:['asc','vet'], vet:['ple','oca'], oca:['vet']}[st];
    const yaEsta = new Set(pool);
    const extra = unseen.filter(e => !yaEsta.has(e) && marcas(e) && e.st
                 && e.st.some(s=>near.includes(s)) && (!e.when || e.when(p)));
    pool = pool.concat(extra);
  }
  if(pool.length < n){
    const yaEsta = new Set(pool);
    pool = pool.concat(unseen.filter(e => !yaEsta.has(e) && marcas(e) && (!e.when || e.when(p))));
  }
  if(!pool.length) return [];

  const mem = p.memEv || null, carrera = p.nroCarrera || 0;
  const peso = e => (e.w || 1) * (e.req ? 5 : 1)
                  * pesoMemoria(e.id, mem, carrera)
                  * pesoRareza(e, mem, carrera);

  const out = [], usados = new Set(), cats = new Set();
  const sortear = lista => {
    let total = 0; lista.forEach(e => total += peso(e));
    if(total <= 0) return null;
    let r = R.f() * total;
    for(const e of lista){ r -= peso(e); if(r <= 0) return e; }
    return lista[lista.length - 1];
  };
  while(out.length < Math.min(n, pool.length)){
    const libres = pool.filter(e => !usados.has(e.id));
    if(!libres.length) break;
    const frescos = libres.filter(e => !cats.has(catDe(e)));
    const e = sortear(frescos.length ? frescos : libres);
    if(!e) break;
    usados.add(e.id); cats.add(catDe(e)); out.push(e);
  }
  return out;
}

const MEM_KEY = 'mfc_eventos';
function memoriaLeer(){
  try{
    const d = JSON.parse(localStorage.getItem(MEM_KEY));
    if(!d || typeof d !== 'object' || typeof d.carrera !== 'number') return {carrera:0, ev:{}};
    return {carrera: d.carrera, ev: d.ev && typeof d.ev === 'object' ? d.ev : {}};
  }catch(e){ return {carrera:0, ev:{}}; }
}
function memoriaGuardar(vistos){
  try{
    const d = memoriaLeer();
    d.carrera++;
    [...new Set(vistos || [])].forEach(id=>{
      const m = d.ev[id] || {n:0, c:0};
      m.n++; m.c = d.carrera; d.ev[id] = m;
    });
    localStorage.setItem(MEM_KEY, JSON.stringify(d));
  }catch(e){}
}
function memoriaValida(m, carrera){
  if(m == null) return true;
  if(typeof m !== 'object' || Array.isArray(m)) return false;
  if(!Number.isInteger(carrera) || carrera < 0 || carrera > 100000) return false;
  const ids = Object.keys(m);
  if(ids.length > 600) return false;
  return ids.every(id => {
    const v = m[id];
    return typeof id === 'string' && id.length <= 8 && v && typeof v === 'object'
      && Number.isInteger(v.n) && v.n >= 0 && v.n <= 100000
      && Number.isInteger(v.c) && v.c >= 0 && v.c <= carrera;
  });
}

function applyEffect(p, ef, choiceText){
  const log=[];
  if(!p.mem) p.mem={};
  if(!p.flags) p.flags={};
  ATTRS.forEach(({k,n})=>{ if(ef[k]!=null){
    let d = ef[k];
    if(d > 0){
      const freno = clamp((99 - p.attrs[k]) / 14, 0.25, 1);
      d = Math.max(1, Math.round(d * freno));
    }
    p.attrs[k]=clamp(p.attrs[k]+d,15,99);
    p.pot[k]=clamp(Math.max(p.pot[k],p.attrs[k]),15,99);
    log.push(`${n} ${d>0?'+':''}${d}`);
  } });
  const simple={moral:'Moral',forma:'Forma',fitness:'Estado físico',rep:'Reputación',hype:'Repercusión',fanLove:'Cariño de la hinchada',mgrRel:'Relación con el DT'};
  Object.keys(simple).forEach(k=>{ if(ef[k]!=null){ p[k]=clamp(round(p[k]+ef[k],0),0,100); log.push(`${simple[k]} ${ef[k]>0?'+':''}${ef[k]}`); } });
  if(ef.retiro){ p.ultimaTemporada = true; log.push('Anunciás tu retiro'); }
  if(ef.contrato){ p.contract = Math.max(p.contract, ef.contrato); log.push('Contrato: '+p.contract+' años'); }
  if(ef.capital){
    const antes = p.capital||0;
    p.capital = round(Math.max(0, antes + ef.capital), 2);
    const movido = round(p.capital - antes, 2);
    log.push(`Capital ${movido>=0?'+':'−'}${money0(Math.abs(movido))}`);
  }
  if(ef.wage) p.wage = round(Math.max(1,p.wage*(1+ef.wage/100)),1);
  if(ef.value) p.value = round(Math.max(0.1,p.value*(1+ef.value/100)),1);
  if(ef.trait && !has(p,ef.trait)){ p.traits.push(ef.trait); log.push(`Rasgo nuevo: ${TRAITS[ef.trait].n}`); }
  if(ef.flag) [].concat(ef.flag).forEach(f=>{ p.flags[f]=true; });
  if(ef.unflag) [].concat(ef.unflag).forEach(f=>{ delete p.flags[f]; });
  if(ef.bajaTuClub){
    const club = C(p.club);
    if(enPrimera(club)){
      p.div2 = p.div2 || {};
      p.div2[club.id] = true;
      const sube = CLUBS.filter(c=>c.lg===club.lg && c.id!==club.id && p.div2[c.id])
        .sort((a,b)=>clubPower(b)-clubPower(a))[0];
      if(sube) delete p.div2[sube.id];
      usarDivisiones(p.div2);
      p.timeline.push({y:p.year, k:'{club} desciende', v:{club:club.n}, ic:'⬇️'});
      log.push(`${club.n} → segunda división`);
    }
  }
  if(ef.volver && p.loanFrom){
    const desde = C(p.club);
    const vuelve = cicloVolverDeCesion(p, true);   
    if(vuelve) log.push(`${desde.n} → ${vuelve.n}`);
  }
  if(ef.mem) Object.entries(ef.mem).forEach(([k,v])=>{ p.mem[k] = (p.mem[k]||0) + v; });
  if(ef.special==='reposicion'){
    const map={EXT:'MCO', MCO:'MC', MC:'MCD', MCD:'DFC', DC:'MCO', LAT:'DFC', DFC:'MCD'};
    const np=map[p.pos]; if(np){ p.pos=np; reconvertir(p); log.push(`Nueva posición: ${POSITIONS[np].n}`); }
  }
  recalc(p);
  if(choiceText) p.momentos.push({y:p.year, t:choiceText});
  return log;
}

const KIT = {
  rma:['sol','#F5F6F8','#12356B','RMA'], fcb:['ray','#A50044','#153A73','FCB'],
  atm:['ray','#CE3524','#F2F2F2','ATM'], sev:['sol','#F2F2F2','#D81920','SEV'],
  ath:['ray','#E22B27','#F2F2F2','ATH'], rso:['ray','#0A63AE','#F2F2F2','RSO'],
  val:['sol','#F2F2F2','#1A1A1A','VAL'], vil:['sol','#FCE05B','#0B5199','VIL'],
  bet:['ray','#00A24A','#F2F2F2','BET'], cel:['sol','#8FC7EE','#F2F2F2','CEL'],
  gir:['ray','#D50032','#F2F2F2','GIR'], ray:['ban','#F2F2F2','#E53027','RAY'],
  osa:['sol','#D81E05','#0A346F','OSA'], get:['sol','#005999','#F2F2F2','GET'],
  mal:['ray','#E20613','#1A1A1A','MLL'], ala:['ray','#0761AF','#F2F2F2','ALA'],
  esp:['ray','#0072CE','#F2F2F2','ESP'], lpa:['sol','#FFE400','#0B47A8','LPA'],
  lev:['ray','#004990','#B4053A','LEV'], leg:['ray','#F2F2F2','#0B47A8','LEG'],
  spo:['ray','#E30613','#F2F2F2','SPO'], rzg:['sol','#F2F2F2','#0B47A8','ZAR'],
  rov:['sol','#0B47A8','#F2F2F2','OVI'], rac2:['ray','#F2F2F2','#00A650','RSA'],
  mci:['sol','#77BEE3','#1B2C58','MCI'], liv:['sol','#C8102E','#F6EB61','LIV'],
  ars:['sol','#EF0107','#F2F2F2','ARS'], mun:['sol','#DA291C','#FBE122','MUN'],
  che:['sol','#0A4A9B','#F2F2F2','CHE'], tot:['sol','#F2F2F2','#16265A','TOT'],
  new:['ray','#1E1B1C','#F2F2F2','NEW'], avl:['sol','#9CC4E8','#6B1039','AVL'],
  whu:['sol','#7A263A','#22B8EC','WHU'], eve:['sol','#11399B','#F2F2F2','EVE'],
  nfo:['sol','#DD0000','#F2F2F2','NFO'], bri:['ray','#0057B8','#F2F2F2','BHA'],
  cry:['ray','#1B458F','#C4122E','CRY'], ful:['sol','#F2F2F2','#1A1A1A','FUL'],
  bre:['ray','#E30613','#F2F2F2','BRE'], wol:['sol','#FDB913','#1A1A1A','WOL'],
  lee:['sol','#F2F2F2','#1D428A','LEE'], sou:['ray','#D71920','#F2F2F2','SOU'],
  lei:['sol','#003090','#F2F2F2','LEI'], shu:['ray','#EE2737','#1A1A1A','SHU'],
  nor:['sol','#FFF200','#00A650','NOR'], sun:['ray','#EB172B','#F2F2F2','SUN'],
  der:['sol','#F2F2F2','#1A1A1A','DER'], bir:['sol','#1053A5','#F2F2F2','BIR'],
  juv:['ray','#1A1A1A','#F2F2F2','JUV'], mil:['ray','#FB2020','#1A1A1A','MIL'],
  int:['ray','#0B7CC4','#1A1A1A','INT'], nap:['sol','#1BA5DE','#F2F2F2','NAP'],
  rom:['sol','#93222F','#F0BC42','ROM'], ata:['ray','#2379BE','#1A1A1A','ATA'],
  laz:['sol','#8FD9F5','#F2F2F2','LAZ'], fio:['sol','#61319B','#F2F2F2','FIO'],
  bol:['mit','#D6001C','#1E3260','BOL'], tor:['sol','#8E2020','#F2F2F2','TOR'],
  udi:['ray','#1A1A1A','#F2F2F2','UDI'], sas:['ray','#00A752','#1A1A1A','SAS'],
  gen:['mit','#B4053A','#0B2E63','GEN'], cag:['mit','#AB003A','#0B2E63','CAG'],
  emp:['sol','#00579C','#F2F2F2','EMP'], ver:['mit','#F2C500','#12356B','VER'],
  sam:['fra','#12356B','#F2F2F2','SAM'], lec:['ray','#F2C500','#D2001F','LEC'],
  pal:['sol','#F5B6CD','#1A1A1A','PLM'],
  par:['ban','#F2F2F2','#F2C500','PAR'], ven:['sol','#1A1A1A','#F2A007','VEN'],
  pis:['ray','#12356B','#1A1A1A','PIS'], bar2:['sol','#F2F2F2','#D2001F','BAR'],
  spa:['ray','#12356B','#F2F2F2','SPA'],
  bay:['sol','#DC052D','#F2F2F2','BAY'], bvb:['sol','#FDE100','#1A1A1A','BVB'],
  b04:['sol','#E32221','#1A1A1A','B04'], rbl:['sol','#F2F2F2','#DD0741','RBL'],
  sge:['sol','#1A1A1A','#E1000F','SGE'], vfb:['sol','#F2F2F2','#E32219','VFB'],
  svw:['sol','#1D9053','#F2F2F2','SVW'], fcu:['sol','#EB1923','#FFE500','FCU'],
  wob:['sol','#65B32E','#F2F2F2','WOB'], bmg:['sol','#F2F2F2','#00A752','BMG'],
  scf:['sol','#E2001A','#1A1A1A','SCF'], tsg:['sol','#1C63B7','#F2F2F2','TSG'],
  fcm:['sol','#ED1C24','#F2F2F2','M05'], fca:['ray','#BA3733','#F2F2F2','FCA'],
  kol:['sol','#F2F2F2','#ED1C24','KOL'], hsv:['sol','#F2F2F2','#12356B','HSV'],
  s04:['sol','#004D9D','#F2F2F2','S04'], h96:['sol','#E30613','#1A1A1A','H96'],
  kai:['sol','#E30613','#F2F2F2','FCK'], boc:['sol','#005CA9','#F2F2F2','VFL'],
  psg:['fra','#0E3F70','#DA291C','PSG'], om:['sol','#F2F2F2','#37B6E4','OM'],
  ol:['sol','#F2F2F2','#22539E','OL'],   mon:['mit','#E63946','#F2F2F2','ASM'],
  lil:['sol','#E01E13','#F2F2F2','LIL'], ren:['mit','#1A1A1A','#E23D28','REN'],
  nic:['ray','#C8102E','#1A1A1A','NIC'], len:['ray','#F2C500','#D2001F','LEN'],
  nan:['sol','#F2C500','#00A752','NAN'], str:['sol','#0B47A8','#F2F2F2','STR'],
  mtp:['mit','#F26522','#0B2E63','MTP'], tou:['sol','#5A2D82','#F2F2F2','TOU'],
  bre2:['sol','#E30613','#F2F2F2','BRS'], rei:['ray','#E30613','#F2F2F2','REI'],
  ang:['sol','#F2F2F2','#1A1A1A','ANG'], sce:['sol','#0B77C2','#F2F2F2','BAS'],
  sai:['sol','#00A752','#F2F2F2','ASS'], bor:['sol','#12356B','#8E2020','BOR'],
  cae:['mit','#12356B','#D2001F','CAE'], aja:['sol','#F2F2F2','#0B47A8','AJA'],
  riv:['ban','#F2F2F2','#E1122C','RIV'], bjr:['fra','#12417E','#F2C14E','BOC'],
  rac:['ray','#7CB6E8','#F2F2F2','RAC'], ind:['sol','#D2001F','#F2F2F2','IND'],
  sl:['ray','#0B47A8','#D2001F','SLO'],  est:['ray','#E4002B','#F2F2F2','EDL'],
  vel:['ban','#F2F2F2','#0B47A8','VEL'], tal:['ray','#0B47A8','#F2F2F2','TAL'],
  now:['mit','#D2001F','#1A1A1A','NOB'], roc:['ban','#F2F2F2','#0B47A8','CEN'],
  lan:['sol','#7A1B34','#F2F2F2','LAN'], arg:['sol','#E4002B','#F2F2F2','AAJ'],
  def:['ray','#F2C500','#00A752','DYJ'], hur:['sol','#F2F2F2','#D2001F','HUR'],
  ban:['ray','#00693E','#F2F2F2','BAN'], gim:['ray','#12356B','#F2F2F2','GEL'],
  col:['ray','#D2001F','#1A1A1A','COL'], uni:['ray','#D2001F','#F2F2F2','UNI'],
  god:['ray','#12356B','#F2F2F2','GOD'], ins:['ray','#D2001F','#F2F2F2','INS'],
  ald:['ray','#00693E','#F2C500','ALD'], plt:['ray','#6B3A1E','#F2F2F2','PLA'],
  tem:['sol','#7CB6E8','#F2F2F2','TEM'], tig:['ray','#12356B','#D2001F','TGR'],
  fla:['aro','#D2001F','#1A1A1A','FLA'], pal2:['sol','#04703C','#F2F2F2','PAL'],
  spf:['ban','#F2F2F2','#D2001F','SPF'], cor:['sol','#F2F2F2','#1A1A1A','COR'],
  cam:['ray','#1A1A1A','#F2F2F2','CAM'], flu:['ray','#7A1E3C','#04613C','FLU'],
  gre:['ray','#1187C4','#1A1A1A','GRE'], inter:['sol','#D2001F','#F2F2F2','SCI'],
  bot:['ray','#1A1A1A','#F2F2F2','BOT'], san:['sol','#F2F2F2','#1A1A1A','SAN'],
  cru:['sol','#12356B','#F2F2F2','CRU'], vas:['ban','#F2F2F2','#1A1A1A','VAS'],
  bah:['ray','#F2F2F2','#0B47A8','BAH'], ath2:['ray','#D2001F','#1A1A1A','CAP'],
  for:['ray','#12356B','#D2001F','FOR'], cea:['ray','#1A1A1A','#F2F2F2','CEA'],
  gois:['sol','#00693E','#F2F2F2','GOI'], cori:['ray','#00693E','#F2F2F2','CFC'],
  spt:['ray','#D2001F','#1A1A1A','SPT'], juv2:['ray','#00693E','#F2F2F2','ECJ'],
  vit:['ray','#D2001F','#1A1A1A','VIT'], chap:['sol','#00693E','#F2F2F2','CHA'],
  pon:['ray','#1A1A1A','#F2F2F2','PON'], ava:['ray','#12356B','#F2F2F2','AVA'],
  hil:['sol','#0B5BAE','#F2F2F2','HIL'], nas:['sol','#FFE500','#0B47A8','NAS'],
  itt:['ray','#1A1A1A','#FFE500','ITT'], ahl:['sol','#04773A','#F2F2F2','AHL'],
  shb:['sol','#F2F2F2','#1A1A1A','SHB'], ett:['sol','#00693E','#F2F2F2','ETT'],
  tao:['sol','#F26522','#F2F2F2','TAO'], fat:['sol','#0B47A8','#F2F2F2','FAT'],
  fay:['sol','#D2001F','#F2F2F2','FAY'], raed:['ray','#F2C500','#1A1A1A','RAE'],
  khl:['sol','#12356B','#F2F2F2','KHL'], wed:['ray','#D2001F','#F2F2F2','WED'],
  ryd:['sol','#F2F2F2','#0B47A8','RYD'], ohd:['ray','#F26522','#1A1A1A','OHD'],
  nah:['sol','#C8102E','#F2F2F2','NAH'], jab:['sol','#00693E','#F2F2F2','JAB'],
  mia:['sol','#F5B6CD','#1A1A1A','MIA'], lafc:['sol','#1A1A1A','#C39E6D','LFC'],
  lag:['sol','#F2F2F2','#123471','LAG'], sea:['sol','#5D9741','#0B5BAE','SEA'],
  atl:['ray','#80000A','#1A1A1A','ATL'], nyc:['sol','#6CACE4','#1A1A1A','NYC'],
  rbny:['sol','#F2F2F2','#D2001F','NYR'], por:['sol','#00482B','#F2C500','POR'],
  phi:['sol','#12356B','#B49759','PHI'], aus:['sol','#00B140','#1A1A1A','AUS'],
  orl:['sol','#5A2D82','#F2C500','ORL'], col2:['sol','#FFF200','#1A1A1A','CLB'],
  dal:['sol','#D2001F','#12356B','DAL'], hou:['sol','#F26522','#1A1A1A','HOU'],
  chi:['sol','#D2001F','#12356B','CHI'], sjo:['sol','#0B47A8','#1A1A1A','SJ'],
  ame:['ban','#F2E205','#12356B','AME'], mty:['ray','#12356B','#F2F2F2','MTY'],
  tig2:['ray','#F2A007','#12356B','TIG'], chv:['ray','#C8102E','#F2F2F2','CHV'],
  cru2:['sol','#0B47A8','#F2F2F2','CAZ'], pum:['sol','#12356B','#F2C500','PUM'],
  tol:['ray','#D2001F','#F2F2F2','TOL'], san2:['sol','#00693E','#F2F2F2','STL'],
  pac:['ray','#12356B','#F2F2F2','PAC'], leo:['sol','#00693E','#F2F2F2','LEO'],
  tij:['ray','#D2001F','#1A1A1A','TIJ'], atlas:['ray','#D2001F','#1A1A1A','ATS'],
  nec:['sol','#D2001F','#F2F2F2','NEC'], pue:['ban','#F2F2F2','#12356B','PUE'],
  que:['sol','#1A1A1A','#12356B','QRO'], maz:['sol','#5A2D82','#F2F2F2','MAZ']
};
const LG_COLOR = {ESP:'#E4002B',ENG:'#38003C',ITA:'#0B2E63',GER:'#D20515',FRA:'#DAE021',
  ARG:'#75AADB',BRA:'#009C3B',SAU:'#006C35',USA:'#1B3A6B',MEX:'#006847'};

const FILOSOFIA = {
  rma:'comprar', fcb:'comprar', mci:'comprar', psg:'comprar', mun:'comprar', che:'comprar',
  juv:'comprar', bay:'comprar', hil:'comprar', nas:'comprar', itt:'comprar', mia:'comprar',
  bvb:'vender', rbl:'vender', b04:'vender', sge:'vender', bmg:'vender', ata:'vender',
  gir:'vender', bri:'vender', bre:'vender', sce:'vender', mon:'vender', len:'vender',
  riv:'vender', bjr:'vender', fla:'vender', pal2:'vender', spf:'vender', cam:'vender',
  ath:'cantera', rso:'cantera', aja:'cantera', sai:'cantera', nan:'cantera',
  vel:'cantera', now:'cantera', arg:'cantera', roc:'cantera', tal:'cantera', def:'cantera',
  gre:'cantera', inter:'cantera', cru:'cantera', chv:'cantera', pum:'cantera',
  tem:'obrero', ald:'obrero', plt:'obrero', ins:'obrero', god:'obrero', uni:'obrero', col:'obrero',
  bir:'obrero', der:'obrero', nor:'obrero', spa:'obrero', pis:'obrero', ven:'obrero',
  kai:'obrero', h96:'obrero', cae:'obrero', ang:'obrero',
  sou:'cantera', tsg:'cantera', scf:'cantera', sea:'cantera',   
  nap:'vender', tol:'vender', udi:'vender',                     
  wob:'comprar', nic:'comprar', ahl:'comprar', lafc:'comprar',
  lag:'comprar', tig2:'comprar', mty:'comprar', cru2:'comprar',
  eve:'obrero', nfo:'obrero', ful:'obrero', get:'obrero',
  fcu:'obrero', shb:'obrero'
};
function filosofiaDe(c){
  if(FILOSOFIA[c.id]) return FILOSOFIA[c.id];
  const lg = L(c.lg);
  if(c.tier>=5) return 'comprar';
  if(c.rep < 48) return 'obrero';
  if(lg.cont==='SUD') return c.tier>=3 ? 'vender' : 'cantera';
  if(lg.money>=4 && c.tier>=4) return 'comprar';
  if(c.tier>=3) return 'vender';
  return 'cantera';
}
const FIL_N = {cantera:'De cantera', vender:'Forma y vende', comprar:'Compra hecho', obrero:'Club obrero'};
const FIL_D = {
  cantera:'Creen en los suyos: si sos joven, jugás antes que el que llega.',
  vender:'Te dan lugar para que te luzcas, y escuchan cuando alguien llama.',
  comprar:'Traen hecho lo que necesitan. Al pibe le cuesta el doble entrar.',
  obrero:'Poca plata y mucha paciencia: contratos largos y pocos cambios.'
};

const kitOf = id => KIT[id] || ['sol','#2A3A35','#8BA099','---'];
function lum(hex){
  const n=parseInt(hex.slice(1),16);
  return (0.2126*(n>>16&255) + 0.7152*(n>>8&255) + 0.0722*(n&255))/255;
}
let _bid = 0;
function crest(clubId, size=34){
  const [pat,c1,c2,ab] = kitOf(clubId);
  const id = 'k'+(++_bid);
  const shield = 'M3 3 H37 V25 C37 34 30 39.5 20 42 C10 39.5 3 34 3 25 Z';
  let inner = '';
  if(pat==='ray') inner = [8,16,24,32].map(x=>`<rect x="${x}" y="0" width="4.6" height="44" fill="${c2}"/>`).join('');
  else if(pat==='ban') inner = `<path d="M-4 30 L30 -4 L40 6 L6 40 Z" fill="${c2}"/>`;
  else if(pat==='mit') inner = `<rect x="20" y="0" width="20" height="44" fill="${c2}"/>`;
  else if(pat==='aro') inner = [6,15,24,33].map(y=>`<rect x="0" y="${y}" width="40" height="4.4" fill="${c2}"/>`).join('');
  else if(pat==='fra') inner = `<rect x="0" y="17" width="40" height="8" fill="${c2}"/>`;
  const txtBase = pat==='sol'? c1 : c1;
  const tc = lum(txtBase)>0.55? '#12201C' : '#FFFFFF';
  return `<svg class="crest" viewBox="0 0 40 44" width="${size}" height="${size*1.1}" aria-hidden="true">
    <defs><clipPath id="${id}"><path d="${shield}"/></clipPath></defs>
    <g clip-path="url(#${id})"><rect width="40" height="44" fill="${c1}"/>${inner}</g>
    <path d="${shield}" fill="none" stroke="rgba(255,255,255,.30)" stroke-width="1.6"/>
    <text x="20" y="26" text-anchor="middle" font-size="12.5" font-weight="900"
      fill="${tc}" style="paint-order:stroke;stroke:rgba(0,0,0,.35);stroke-width:2.4px">${ab}</text>
  </svg>`;
}

const NAMES_F = {
  lat:['Matías','Joaquín','Rodrigo','Facundo','Emiliano','Ignacio','Bruno','Tomás','Nicolás','Lautaro','Gonzalo','Iván','Andrés','Camilo','Santino','Damián'],
  ing:['Callum','Declan','Reece','Marcus','Kyle','Owen','Elliot','Nathan','Jude','Terrence','Ashley','Curtis'],
  ger:['Lennart','Fabian','Jonas','Til','Moritz','Sören','Kasper','Emil','Viggo','Rasmus'],
  fra:['Théo','Enzo','Amaury','Bastien','Léandre','Yannick','Corentin','Ludovic'],
  por:['Rúben','Tiago','Vinícius','Everton','Dênis','Éder','Gilmar','Wesley','Anderson','Cauã'],
  afr:['Ibrahima','Youssouf','Kwame','Adewale','Mamadou','Cheikh','Tafari','Zayd'],
  asi:['Haruto','Sota','Jin-ho','Min-jae','Kenta','Riku','Seung-woo','Takumi']
};
const NAMES_L = {
  lat:['Verón','Quintela','Arriaga','Bustamante','Cardozo','Salvatierra','Miranda','Olivares','Requena','Zabaleta','Ferreyra','Aguirre','Cabral','Peralta','Insúa','Bordón'],
  ing:['Whitlock','Harrow','Kingsley','Ashcombe','Merrick','Fenton','Bramley','Radcliffe','Sowerby','Thorne'],
  ger:['Brandhorst','Kellerman','Vogelsang','Reuter','Lindqvist','Hauge','Sørensen','Nyholm'],
  fra:['Delacroix','Fournel','Marchetti','Beauchamp','Lemaitre','Rousseau','Vaugier'],
  por:['Machado','Antunes','Bittencourt','Cavalcante','Rezende','Nogueira','Damasceno','Furtado'],
  afr:['Diomandé','Ndiaye','Bakayoko','Mensah','Okonjo','Traoré','Sissoko','Adeyemi'],
  asi:['Kurosawa','Nakamura','Sakaguchi','Hwang','Yamashita','Fujimori','Baek']
};
const NAT_POOL = [
  ['Argentina','🇦🇷','lat'],['Brasil','🇧🇷','por'],['España','🇪🇸','lat'],['Francia','🇫🇷','fra'],
  ['Inglaterra','🏴','ing'],['Alemania','🇩🇪','ger'],['Portugal','🇵🇹','por'],['Países Bajos','🇳🇱','ger'],
  ['Italia','🇮🇹','lat'],['Uruguay','🇺🇾','lat'],['Senegal','🇸🇳','afr'],['Marruecos','🇲🇦','afr'],
  ['Japón','🇯🇵','asi'],['Croacia','🇭🇷','ger'],['Colombia','🇨🇴','lat'],['Noruega','🇳🇴','ger']
];
const RIVAL_POS = ['DC','EXT','MCO','MC','DFC','LAT','MCD'];

function nuevoDT(year){
  const [nat, flag, pool] = R.pick(NAT_POOL);
  return { name:`${R.pick(NAMES_F[pool])} ${R.pick(NAMES_L[pool])}`, flag, nat, desde:year };
}
function dtDe(p, clubId){
  if(!p.dts) p.dts = {};
  if(!p.dts[clubId]) p.dts[clubId] = nuevoDT(p.year - R.i(0,3));
  return p.dts[clubId];
}
function despidos(p, w){
  const fuera = [];
  LEAGUES.forEach(lg=>{
    const t = w.tablas && w.tablas[lg.id];
    if(!t) return;
    const orden = CLUBS.filter(c=>c.lg===lg.id).slice()
      .sort((a,b)=>clubPower(b)-clubPower(a)).map(c=>c.id);
    t.forEach((fila,i)=>{
      const id = Array.isArray(fila)? fila[0] : fila.id;
      const club = C(id); if(!club) return;
      const esperada = orden.indexOf(id)+1, real = i+1;
      const dt = dtDe(p, id);
      const paciencia = club.tier>=5 ? 2 : club.tier>=4 ? 3 : club.tier>=3 ? 5 : 7;
      if(real - esperada >= paciencia && (p.year - dt.desde) >= 1 && R.chance(0.72)){
        fuera.push({ clubId:id, club:club.n, dt:dt.name, flag:dt.flag,
                     anios: p.year - dt.desde, real, esperada, mio: id===p.club });
        p.dts[id] = nuevoDT(p.year);
      }
    });
  });
  return fuera;
}

const MEDIA_RONDA = {A:'Octavos', B:'Octavos'};
function worldHalf(p, rec){
  const miLg = C(p.club).lg;
  const w = { year:p.year, mitad:true, tablas:{}, tablas2:{}, forma:{}, lideres:{}, eliminados:{}, ronda:{} };
  const enSeg = enSegunda(C(p.club));
  LEAGUES.forEach(lg=>{
    const cl = clubesDe(lg.id);      
    const scored = cl.map(c=>{
      const f = clubPower(c) + R.gauss(0, 7.5);
      w.forma[c.id] = f;
      return { id:c.id, s:f };
    }).sort((a,b)=>b.s-a.s);
    if(lg.id===miLg && !enSeg && rec && rec.ligaPos){
      const i = scored.findIndex(x=>x.id===p.club);
      if(i>=0){ const [yo]=scored.splice(i,1); scored.splice(clamp(rec.ligaPos-1,0,scored.length-1),0,yo); }
    }
    let pts = R.i(34,44);   
    w.tablas[lg.id] = scored.map((x,i)=>{ if(i) pts = Math.max(7, pts - R.i(1,4)); return [x.id, pts]; });
    w.lideres[lg.id] = scored[0].id;

    const ab = lg.id===miLg ? CLUBS.filter(c=>c.lg===lg.id && enSegunda(c)) : [];
    if(ab.length){
      const s2 = ab.map(c=>{
        const f = clubPower(c)*0.82 + R.gauss(0, 7.5);
        w.forma[c.id] = f;
        return { id:c.id, s:f };
      }).sort((a,b)=>b.s-a.s);
      if(lg.id===miLg && enSeg && rec && rec.ligaPos){
        const i = s2.findIndex(x=>x.id===p.club);
        if(i>=0){ const [yo]=s2.splice(i,1); s2.splice(clamp(rec.ligaPos-1,0,s2.length-1),0,yo); }
      }
      let p2 = R.i(30,40);
      w.tablas2[lg.id] = s2.map((x,i)=>{ if(i) p2 = Math.max(6, p2 - R.i(1,4)); return [x.id, p2]; });
    }
    const arriba = scored.slice(0, Math.max(3, Math.ceil(scored.length/3)));
    const [, bandera, pool] = R.pick(NAT_POOL);
    w.goleadores = w.goleadores || {};
    w.goleadores[lg.id] = { name:`${R.pick(NAMES_F[pool])} ${R.pick(NAMES_L[pool])}`,
      flag:bandera, club:C(R.pick(arriba).id).n,
      goles: Math.round(clamp(8 + lg.str + R.gauss(0,3), 5, 22)) };
    const misGoles = lg.id===miLg && !enSeg && rec && rec.comps
      ? ((rec.comps.find(c=>c.n===lg.n) || {}).goals || 0) : 0;
    if(misGoles > w.goleadores[lg.id].goles)
      w.goleadores[lg.id] = {name:p.name, flag:p.flag, club:C(p.club).n, goles:misGoles, yo:true};
  });
  ['EUR','SUD','CON'].forEach(cf=>{
    const pool = CLUBS.filter(c=>L(c.lg).cont===cf);
    if(pool.length < 4) return;
    w.ronda[cf] = MEDIA_RONDA.A;
    const grandes = pool.filter(c=>c.tier>=4);
    if(grandes.length && R.chance(0.55)){
      const caido = weightedPick(grandes, c=>Math.pow(clubPower(c),1.4));
      w.eliminados[cf] = [caido.id];
    } else w.eliminados[cf] = [];
  });
  return w;
}
const POOL_CONF = {EUR:'ger', SUD:'lat', AFR:'afr', ASI:'asi', CON:'lat'};
function nombrePara(natName){
  const fila = NAT_POOL.find(x=>x[0]===natName);
  const nat = NATIONS.find(n=>n.n===natName);
  const pool = fila ? fila[2] : (POOL_CONF[nat && nat.conf] || 'lat');
  return `${R.pick(NAMES_F[pool])} ${R.pick(NAMES_L[pool])}`;
}
function makeRival(){
  const [nat,flag,pool] = R.pick(NAT_POOL);
  const bigs = CLUBS.filter(c=>c.tier>=4);
  return {
    name: `${R.pick(NAMES_F[pool])} ${R.pick(NAMES_L[pool])}`,
    flag, nat, pos:R.pick(RIVAL_POS),
    club: R.pick(bigs).id,
    age: R.i(19,26),
    ovr: R.i(83,92),
    pot: R.i(88,97),
    balones: 0, contis: 0, ligas: 0, goles: 0, debut: null
  };
}
function initRivals(){ return Array.from({length:7}, makeRival); }

function rivalSeason(p, rec){
  const rivals = p.rivals || [];
  if(!rivals.length) return;
  const yoBalon = (rec.awards||[]).some(a=>a.includes('Balón de Oro'));
  const peso = r => Math.pow(Math.max(1, r.ovr - 76), 1.15);
  const pesoBalon = r => peso(r) * ({DC:1, EXT:.85, MCO:.8, MC:.45, MCD:.15, LAT:.12, DFC:.1}[r.pos] || .4);

  rivals.forEach(r=>{
    if(r.debut==null) r.debut = p.year;
    const gpp = {DC:0.62, EXT:0.38, MCO:0.34, MC:0.16, MCD:0.07, LAT:0.06, DFC:0.05}[r.pos] || 0.2;
    r.goles += Math.max(0, Math.round(gpp * R.i(28,40) * (0.7 + (r.ovr-80)/26) + R.gauss(0,2)));
  });

  if(R.chance(0.9)) weightedPick(rivals, peso).ligas++;
  if(R.chance(0.6)) weightedPick(rivals, peso).ligas++;
  if(R.chance(0.85)) weightedPick(rivals, peso).contis++;
  if(!yoBalon){
    const candidatos = rivals.filter(r=>r.ovr>=85);
    if(candidatos.length) weightedPick(candidatos, pesoBalon).balones++;
  }
}

function legadoDe(r){
  return (r.balones||0)*260 + (r.contis||0)*95 + (r.ligas||0)*38 + (r.goles||0)*0.7 + (r.ovr-70)*6;
}

function ageRivals(rivals, p){
  if(p){ p.pases = []; p.retirados = []; p.debutantes = []; }
  rivals.forEach(r=>{
    r.age++;
    if(r.age<=26) r.ovr = clamp(r.ovr + R.i(0,3), 60, Math.min(99,r.pot));
    else if(r.age<=30) r.ovr = clamp(r.ovr + R.i(-1,1), 60, 99);
    else r.ovr = clamp(r.ovr - R.i(1,4), 40, 99);
    if(R.chance(0.16)){
      const bigs=CLUBS.filter(c=>c.tier>=4 && c.id!==r.club);
      if(bigs.length){
        const destino = R.pick(bigs), antes = r.club;
        r.club = destino.id;
        const fee = round(clamp(Math.pow(Math.max(0,r.ovr-62)/10, 2.9) * 1.5
          * (r.age<=25? 1.35 : r.age<=29? 1 : 0.5)
          * (0.85 + L(destino.lg).money*0.09), 4, 260), 0);
        if(p) p.pases.push({name:r.name, flag:r.flag, a:destino.id, de:antes, fee});
      }
    }
  });
  for(let i=rivals.length-1;i>=0;i--){
    const r = rivals[i];
    if(r.age>=35 || r.ovr<74){
      if(p){
        p.leyendas = p.leyendas || [];
        if(legadoDe(r) >= 260 || r.balones)
          p.leyendas.push({name:r.name, flag:r.flag, pos:r.pos, club:r.club,
            balones:r.balones, contis:r.contis, ligas:r.ligas, goles:r.goles,
            pico:r.ovr, desde:r.debut||null, hasta:p.year});
        if(p.leyendas.length > 24) p.leyendas.shift();
        if(r.goles >= 90 || r.balones || r.contis)
          p.retirados.push({name:r.name, flag:r.flag, goles:r.goles, balones:r.balones||0});
      }
      rivals.splice(i,1);
      const pibe = makeRival();
      rivals.push(pibe);
      if(p && pibe.age <= 21) p.debutantes.push({name:pibe.name, flag:pibe.flag, age:pibe.age, club:pibe.club});
    }
  }
  return rivals;
}

function weightedPick(items, wf){
  const tot = items.reduce((s,x)=>s+wf(x),0);
  let r = R.f()*tot;
  for(const x of items){ r -= wf(x); if(r<=0) return x; }
  return items[items.length-1];
}

let _ciclo = {};
function usarCiclos(c){ _ciclo = c || {}; }
function moverCiclos(p){
  if(!p.ciclos) p.ciclos = {};
  CLUBS.forEach(c=>{
    let v = p.ciclos[c.id] || 0;
    v = v*0.86 + R.gauss(0, 5.5);                 
    if(R.chance(0.08)) v += R.gauss(0, 16);       
    const techo = c.tier>=5 ? 11 : c.tier>=4 ? 18 : 27;
    const piso = c.tier>=5 ? -8 : c.tier>=4 ? -15 : -24;
    p.ciclos[c.id] = clamp(round(v,1), piso, techo);
  });
  usarCiclos(p.ciclos);
  return p.ciclos;
}
function clubPower(c){ return c.tier*10 + c.rep*0.35 + (_ciclo[c.id] || 0); }
function clubBase(c){ return c.tier*10 + c.rep*0.35; }

function marcadorFinal(){
  const t = R.f();
  if(t < 0.14) return {a:R.i(0,1), b:R.i(0,1), pen:true,  extra:true};   
  if(t < 0.30) return {a:R.i(1,3), b:R.i(0,2), pen:false, extra:true};   
  const a = R.i(1,4);
  return {a, b: R.i(0, Math.max(0,a-1)), pen:false, extra:false};
}

function worldSeason(p, rec){
  const myClub = C(p.club), myLg = myClub.lg;
  const myTitles = rec.titles || [];
  const w = { year:p.year, tablas:{}, tablas2:{}, campeon:{}, copas:{}, conti:{}, conti2:{}, cwc:null, inter:null,
              goleadores:{}, selecciones:null, balon:null, bota:null };

  const ciclo = p.year % 4;
  const jugue = rec.ntTorneo || null;
  const ganaSel = (elegibles, gane, miTorneo) => {
    if(gane) return {nat:p.nat, flag:p.flag, yo:true};
    const sinMi = (miTorneo && jugue===miTorneo) ? elegibles.filter(n=>n.n!==p.nat) : elegibles;
    const n = weightedPick(sinMi.length ? sinMi : elegibles, x=>Math.pow(x.str,3.1));
    return {nat:n.n, flag:n.f, yo:false};
  };
  const misTitulos = (rec.ntTitles||[]);
  const finalistaSel = (elegibles, campeon) => {
    const otros = elegibles.filter(n=>n.n!==campeon.nat);
    if(!otros.length) return null;
    const n = weightedPick(otros, x=>Math.pow(x.str,2.6));
    return {nat:n.n, flag:n.f};
  };
  if(ciclo===2){
    const camp = ganaSel(NATIONS, misTitulos.some(t=>t.includes('Copa del Mundo')), 'Mundial');
    w.selecciones = {torneo:'Copa del Mundo', mundial:true, campeon:camp,
      sub: finalistaSel(NATIONS, camp), final: marcadorFinal()};
  } else if(ciclo===0){
    const porConf = {};
    ['EUR','SUD','AFR','CON','ASI'].forEach(cf=>{
      const elegibles = NATIONS.filter(n=>n.conf===cf);
      if(!elegibles.length) return;
      const gane = p.conf===cf && misTitulos.some(t=>t.includes(CONF_NAME[cf]));
      const camp = ganaSel(elegibles, gane, p.conf===cf ? CONF_NAME[cf] : null);
      porConf[cf] = {torneo:CONF_NAME[cf], ...camp,
        sub: finalistaSel(elegibles, camp), final: marcadorFinal()};
    });
    w.selecciones = {continental:true, porConf};
  }

  const medio = (p.medio && p.medio.year===p.year) ? p.medio : null;
  LEAGUES.forEach(lg=>{
    const cl = clubesDe(lg.id);      
    const scored = cl.map(c=>({ id:c.id, n:c.n,
      s: medio && medio.forma[c.id]!=null
         ? medio.forma[c.id] + R.gauss(0,5)          
         : clubPower(c) + R.gauss(0,7.5) }))
      .sort((a,b)=>b.s-a.s);
    const yoEnSegunda = enSegunda(myClub);
    if(lg.id===myLg && !yoEnSegunda){
      const i = scored.findIndex(x=>x.id===p.club);
      if(i>=0){ const [me]=scored.splice(i,1); scored.splice(clamp(rec.leaguePos-1,0,scored.length-1),0,me); }
    }
    const ab = lg.id===myLg ? CLUBS.filter(c=>c.lg===lg.id && enSegunda(c)) : [];
    if(ab.length){
      const s2 = ab.map(c=>({ id:c.id,
        s: medio && medio.forma[c.id]!=null
           ? medio.forma[c.id] + R.gauss(0,5)
           : clubPower(c)*0.82 + R.gauss(0,7.5) })).sort((a,b)=>b.s-a.s);
      if(lg.id===myLg && yoEnSegunda){
        const i = s2.findIndex(x=>x.id===p.club);
        if(i>=0){ const [me]=s2.splice(i,1); s2.splice(clamp(rec.leaguePos-1,0,s2.length-1),0,me); }
      }
      let p2 = R.i(68,86);
      w.tablas2[lg.id] = s2.map((x,i)=>{ if(i) p2 = Math.max(14, p2 - R.i(1,5)); return [x.id, p2]; });
    }
    let pts = R.i(74,94);
    w.tablas[lg.id] = scored.map((x,i)=>{
      if(i) pts = Math.max(16, pts - R.i(1,5));
      return [x.id, pts];
    });

    const ganeYo = myTitles.includes(lg.n) && lg.id===myLg;
    if(ganeYo) w.campeon[lg.id] = p.club;
    else if(lg.playoff){
      const ajenos = lg.id===myLg ? scored.filter(x=>x.id!==p.club) : scored;
      const entran = ajenos.slice(0, Math.min(lg.playoff, ajenos.length));
      const peso = {};
      entran.forEach((x,i)=>{ peso[x.id] = Math.pow(entran.length - i, 1.35); });
      w.campeon[lg.id] = (entran.length? weightedPick(entran, x=>peso[x.id]) : scored[0]).id;
    } else w.campeon[lg.id] = (lg.id===myLg && scored[0].id===p.club && scored[1]) ? scored[1].id : scored[0].id;

    const arriba = scored.slice(0, Math.max(3, Math.ceil(scored.length/3)));
    const suClub = C(R.pick(arriba).id);
    const [nat, bandera, pool] = R.pick(NAT_POOL);
    const golesLg = Math.round(clamp(16 + lg.str*2 + R.gauss(0,5), 11, 41));
    const mio = (rec.awards||[]).some(a=>a==='Máximo goleador de la '+lg.n);
    const golesLiga = ((rec.comps||[]).find(c=>c.n===lg.n) || {goals:rec.goals||0}).goals;
    w.goleadores[lg.id] = mio
      ? {name:p.name, flag:p.flag, club:C(p.club).n, goles:golesLiga, yo:true}
      : {name:`${R.pick(NAMES_F[pool])} ${R.pick(NAMES_L[pool])}`, flag:bandera, club:suClub.n, goles:golesLg, yo:false};

    const clCopa = lg.id===myLg ? cl.filter(c=>c.id!==p.club) : cl;
    const cupWinner = myTitles.includes(lg.copa) && lg.id===myLg
      ? myClub : weightedPick(clCopa.length ? clCopa : cl, c=>Math.pow(clubPower(c),2.2));
    const otros = cl.filter(c=>c.id!==cupWinner.id);
    const finalista = otros.length? weightedPick(otros, c=>Math.pow(clubPower(c),1.8)) : cupWinner;
    w.copas[lg.id] = {n:lg.copa, club:cupWinner.n, yo:cupWinner.id===p.club,
      id:cupWinner.id, sub:finalista.n, subId:finalista.id, subYo:finalista.id===p.club,
      final:marcadorFinal()};
  });

  ['EUR','SUD','CON'].forEach(cf=>{
    const caidos = new Set((medio && medio.eliminados && medio.eliminados[cf]) || []);
    const mine = myTitles.includes(CONT_CUP[cf]);
    const vale = c => L(c.lg).cont===cf && enPrimera(c) && !caidos.has(c.id) && (mine || c.id!==p.club);
    let pool = CLUBS.filter(c=>vale(c) && (c.tier>=3 || c.rep>=64));
    if(pool.length < 4) pool = CLUBS.filter(vale);
    if(pool.length < 2) return;   
    const champ = mine ? myClub : weightedPick(pool, c=>Math.pow(clubPower(c),3));
    const resto = pool.filter(c=>c.id!==champ.id);
    const sub = resto.length? weightedPick(resto, c=>Math.pow(clubPower(c),2.4)) : champ;
    const resto2 = resto.filter(c=>c.id!==sub.id);
    const semis = [];
    for(let i=0;i<2 && resto2.length;i++){
      const s = weightedPick(resto2, c=>Math.pow(clubPower(c),2));
      semis.push({n:s.n, id:s.id}); resto2.splice(resto2.indexOf(s),1);
    }
    w.conti[cf] = {n:CONT_CUP[cf], club:champ.n, yo:champ.id===p.club, id:champ.id,
      sub:sub.n, subId:sub.id, subYo:sub.id===p.club, semis, final:marcadorFinal()};
  });

  ['EUR','SUD'].forEach(cf=>{
    if(!CONT_CUP2[cf]) return;
    const enLaGrande = new Set();
    if(w.conti[cf]){
      const g = w.conti[cf];
      enLaGrande.add(g.id); enLaGrande.add(g.subId);
      (g.semis||[]).forEach(s=>enLaGrande.add(s.id));
    }
    const mine = myTitles.includes(CONT_CUP2[cf]);
    const libre = c => !enLaGrande.has(c.id) && enPrimera(c) && (mine || c.id!==p.club);
    let pool = CLUBS.filter(c=>L(c.lg).cont===cf && c.tier>=2 && c.tier<=4 && libre(c));
    if(pool.length < 4) pool = CLUBS.filter(c=>L(c.lg).cont===cf && libre(c));
    if(pool.length < 2) return;
    const champ = mine ? myClub : weightedPick(pool, c=>Math.pow(clubPower(c),1.9));
    const resto = pool.filter(c=>c.id!==champ.id);
    const sub = resto.length? weightedPick(resto, c=>Math.pow(clubPower(c),1.6)) : champ;
    const resto2 = resto.filter(c=>c.id!==sub.id);
    const semis = [];
    for(let i=0;i<2 && resto2.length;i++){
      const s = weightedPick(resto2, c=>Math.pow(clubPower(c),1.5));
      semis.push({n:s.n, id:s.id}); resto2.splice(resto2.indexOf(s),1);
    }
    w.conti2[cf] = {n:CONT_CUP2[cf], club:champ.n, yo:champ.id===p.club, id:champ.id,
      sub:sub.n, subId:sub.id, subYo:sub.id===p.club, semis, final:marcadorFinal()};
  });

  if(p.year % 4 === 1){
    const ciclo4 = [...(p.world||[]).slice(-3), w];
    const plantel = [], via = {};
    Object.entries(CWC_PLAZAS).forEach(([cf, plazas])=>{
      const porTitulo = [...new Set(ciclo4.map(x=>x.conti && x.conti[cf] && x.conti[cf].id).filter(Boolean))]
        .slice(0, plazas);
      porTitulo.forEach(id=>{ via[id]='título continental'; });
      const resto = CLUBS.filter(c=>L(c.lg).cont===cf && !porTitulo.includes(c.id))
        .sort((a,b)=>clubPower(b)-clubPower(a))
        .slice(0, Math.max(0, plazas - porTitulo.length));
      resto.forEach(c=>{ via[c.id]='ranking de cuatro años'; });
      plantel.push(...porTitulo, ...resto.map(c=>c.id));
    });
    const clubes = plantel.map(id=>C(id)).filter(Boolean);
    if(clubes.length >= 4){
      const gane = myTitles.includes(FIFA_CWC);
      const camp = gane? myClub : weightedPick(clubes, c=>Math.pow(clubPower(c),2.6));
      const resto = clubes.filter(c=>c.id!==camp.id);
      const sub = weightedPick(resto, c=>Math.pow(clubPower(c),2.2));
      const resto2 = resto.filter(c=>c.id!==sub.id);
      const semis = [];
      for(let i=0;i<2 && resto2.length;i++){
        const s = weightedPick(resto2, c=>Math.pow(clubPower(c),1.9));
        semis.push({n:s.n, id:s.id}); resto2.splice(resto2.indexOf(s),1);
      }
      w.cwc = {n:FIFA_CWC, club:camp.n, id:camp.id, yo:camp.id===p.club,
        sub:sub.n, subId:sub.id, subYo:sub.id===p.club, semis, final:marcadorFinal(),
        plantel: clubes.map(c=>({id:c.id, n:c.n, cf:L(c.lg).cont, via:via[c.id]}))};
      if(camp.id===p.club && !gane){
        p.honours.push({y:p.year, n:'🌐 '+FIFA_CWC, club:myClub.n, tipo:'fifa'});
        p.cwc = (p.cwc||0)+1;
      }
    }
  }

  {
    const camp = cf => w.conti[cf];
    const con = camp('CON'), sud = camp('SUD'), eur = camp('EUR');
    if(con && sud && eur){
      const pot = o => Math.pow(Math.max(1, clubPower(C(o.id))), 2.2);
      const cruce = (a, b, ronda) => {
        const gana = R.f() < pot(a)/(pot(a)+pot(b)) ? a : b;
        return {ronda, gana, pierde: gana===a? b : a, final:marcadorFinal()};
      };
      const americas = cruce(con, sud, INTER_RONDAS[0]);
      const laFinal  = cruce(americas.gana, eur, 'FINAL');
      w.inter = {n:FIFA_INTER, escalera:[americas],
        club:laFinal.gana.club, id:laFinal.gana.id, yo:laFinal.gana.id===p.club,
        sub:laFinal.pierde.club, subId:laFinal.pierde.id, subYo:laFinal.pierde.id===p.club,
        final:laFinal.final, byeEuropa:eur.club, byeId:eur.id};
      if(laFinal.gana.id===p.club){
        p.honours.push({y:p.year, n:'🌍 '+FIFA_INTER, club:myClub.n, tipo:'fifa'});
        p.inter = (p.inter||0)+1;
      }
    }
  }

  const yoBalon = (rec.awards||[]).some(a=>a.includes('Balón de Oro'));
  if(yoBalon){
    w.balon = {name:p.name, flag:p.flag, club:myClub.n, yo:true};
  } else {
    const r = weightedPick(p.rivals, x=>Math.pow(Math.max(1,x.ovr-72),3));
    r.balones++;
    w.balon = {name:r.name, flag:r.flag, club:C(r.club).n, yo:false};
  }
  const yoBota = (rec.awards||[]).some(a=>a.includes('Bota de Oro'));
  if(yoBota){
    w.bota = {name:p.name, flag:p.flag, goles:rec.goals, yo:true};
  } else {
    const dels = p.rivals.filter(r=>['DC','EXT','MCO'].includes(r.pos));
    const r = dels.length? weightedPick(dels, x=>Math.pow(Math.max(1,x.ovr-70),3)) : R.pick(p.rivals);
    const enEuropa = L(myClub.lg).cont==='EUR';
    const suba = R.i(1,6), base = R.i(24,41);
    w.bota = {name:r.name, flag:r.flag, goles: enEuropa? Math.max(rec.goals+suba, base) : base, yo:false};
  }
  return w;
}

const SEC = { yo:'yo', liga:'liga', euro:'euro', mundo:'mundo', raro:'raro' };
const CUPO = { yo:2, liga:2, euro:2, mundo:2, raro:1 };

const tit = (s, w, ic, k, v) => ({ s, w, ic, k, v: v||{} });
const cuenta = (n, uno) => n===1 ? uno : (uno==='gol' ? 'goles' : uno+'s');

const campeonLiga = (x, lgId) => {
  if(x.campeon && x.campeon[lgId]) return x.campeon[lgId];
  const t = x.tablas && x.tablas[lgId];
  if(t && t.length) return Array.isArray(t[0])? t[0][0] : t[0].id;
  return (x.palmares && x.palmares.liga && x.palmares.liga[lgId]) || null;
};
const campeonConti = (x, cf) => (x.conti && x.conti[cf] && x.conti[cf].id) || null;
function rachaDe(p, quien, clubId){
  let n = 0;
  for(let i=p.world.length-1;i>=0;i--){
    if(quien(p.world[i]) === clubId) n++; else break;
  }
  return n;
}
function sequiaDe(p, quien, clubId){
  let vistas = 0;
  for(let i=p.world.length-2;i>=0;i--){
    vistas++;
    if(quien(p.world[i]) === clubId) return vistas;
  }
  return vistas ? -vistas : 0;      
}

const CAT_RECORD = ['goles','balones','ligas','contis'];
function recordsEra(p){
  const todos = (p.rivals||[]).concat(p.leyendas||[]);
  const yo = { name:p.name, yo:true, balones:p.balones||0, contis:p.contis||0,
               ligas:p.ligas||0, goles:(p.career&&p.career.goals)||0 };
  const universo = todos.concat([yo]);
  const out = { mio:{} };
  CAT_RECORD.forEach(k=>{
    const m = universo.reduce((a,b)=>((b[k]||0) > (a[k]||0) ? b : a), universo[0]);
    out[k] = { name:m.name, yo:!!m.yo, v:m[k]||0 };
    out.mio[k] = yo[k];
  });
  return out;
}

function gestas(p, w){
  const out = [];
  LEAGUES.forEach(lg=>{
    const t = w.tablas && w.tablas[lg.id];
    if(!t || t.length < 8) return;                 
    const orden = CLUBS.filter(c=>c.lg===lg.id).slice()
      .sort((a,b)=>clubBase(b)-clubBase(a)).map(c=>c.id);
    const campId = Array.isArray(t[0])? t[0][0] : t[0].id;
    const puesto = orden.indexOf(campId) + 1, n = orden.length;
    if(puesto > Math.ceil(n/2)){
      const hondura = (puesto - n/2) / (n/2);
      out.push({tipo:'ligaSorpresa', clubId:campId, club:C(campId).n, liga:lg.n, puesto,
                rareza: Math.round(clamp(hondura*72 + lg.str*5, 0, 100))});
    }
    const bajan = t.length>=8 ? 2 : t.length>=6 ? 1 : 0;
    t.slice(t.length-bajan).forEach(f=>{
      const id = Array.isArray(f)? f[0] : f.id, c = C(id);
      if(c && c.tier>=4) out.push({tipo:'granDesciende', clubId:id, club:c.n, liga:lg.n,
                                   rareza: c.tier>=5 ? 98 : 82});
    });
  });
  ['EUR','SUD','CON'].forEach(cf=>{
    const c = w.conti && w.conti[cf]; if(!c) return;
    const pool = CLUBS.filter(x=>L(x.lg).cont===cf);
    if(pool.length < 6) return;                    
    const fuerzas = pool.map(clubBase).sort((a,b)=>b-a);
    const campeon = C(c.id); if(!campeon) return;
    const pos = fuerzas.filter(f=>f > clubBase(campeon)).length / fuerzas.length;
    const peso = {EUR:1, SUD:0.72, ASI:0.34, CON:0.30}[cf] || 0.3;
    if(pos > 0.62)
      out.push({tipo:'contiSorpresa', clubId:c.id, club:c.club, copa:CONT_CUP[cf],
                rareza: Math.round(clamp(((pos-0.62)*230 + 42) * peso, 0, 100))});
  });
  if(w.selecciones && w.selecciones.mundial){
    const camp = NATIONS.find(n=>n.n===w.selecciones.campeon.nat);
    if(camp && camp.str<=2) out.push({tipo:'selSorpresa', pais:camp.n, rareza:100});
    const sub = w.selecciones.sub && NATIONS.find(n=>n.n===w.selecciones.sub.nat);
    if(sub && sub.str<=2) out.push({tipo:'selFinalista', pais:sub.n, rareza:74});
  }
  return out.sort((a,b)=>b.rareza-a.rareza);
}

function diarioMitad(p, h, med, fuera){
  const T2 = [], club = C(p.club), lg = L(club.lg);
  const goles = h.goals, asis = h.assists;

  if(goles >= 12) T2.push(tit(SEC.yo, 70+goles, '⚽', '{jug} llega a {n} goles en media temporada', {jug:p.name, n:goles}));
  else if(goles >= 6) T2.push(tit(SEC.yo, 44, '⚽', '{jug} suma {n} goles antes de fin de año', {jug:p.name, n:goles}));
  if(asis >= 8) T2.push(tit(SEC.yo, 46, '🅰️', '{jug} ya reparte {n} asistencias', {jug:p.name, n:asis}));
  if(h.rating >= 7.6) T2.push(tit(SEC.yo, 60, '⭐', '{jug} es la revelación del semestre en {club}', {jug:p.name, club:club.n}));
  if(p.injuryTag && p.injuredWeeks >= 6)
    T2.push(tit(SEC.yo, 58, '🏥', '{jug} se pierde {n} semanas por {lesion}', {jug:p.name, n:p.injuredWeeks, lesion:p.injuryTag}));
  if(h.share <= 18) T2.push(tit(SEC.yo, 40, '🪑', '{jug} apenas juega en {club}', {jug:p.name, club:club.n}));
  if(p.age <= 18 && h.apps >= 8) T2.push(tit(SEC.yo, 62, '🌱', 'A los {edad} años, {jug} ya es habitual en {club}', {edad:p.age, jug:p.name, club:club.n}));
  T2.push(tit(SEC.yo, 12, '📋', '{jug} en el semestre: {pj} {upj} y {n} {ug}',
    {jug:p.name, pj:h.apps, upj:cuenta(h.apps,'partido'), n:goles, ug:cuenta(goles,'gol')}));

  const t = med.tablas[lg.id] || [];
  if(t.length){
    const lider = C(t[0][0]), segundo = t[1] && C(t[1][0]);
    const dif = t[1] ? t[0][1] - t[1][1] : 0;
    if(dif >= 8) T2.push(tit(SEC.liga, 76, '🏆', '{club} se escapa en la {liga}: {n} puntos de ventaja', {club:lider.n, liga:lg.n, n:dif}));
    else if(segundo) T2.push(tit(SEC.liga, 66, '🏁', '{a} y {b} pelean la {liga} punto a punto', {a:lider.n, b:segundo.n, liga:lg.n}));
    const mio = t.findIndex(x=>x[0]===p.club);
    if(mio === 0) T2.push(tit(SEC.liga, 84, '👑', '{club} es campeón de invierno', {club:club.n}));
    else if(mio >= 0 && mio < 4) T2.push(tit(SEC.liga, 54, '📈', '{club} cierra el año {pos}º en la {liga}', {club:club.n, pos:mio+1, liga:lg.n}));
    const ultimo = C(t[t.length-1][0]);
    if(ultimo && ultimo.tier >= 3) T2.push(tit(SEC.raro, 72, '😱', '{club} pasa las fiestas en zona de descenso', {club:ultimo.n}));
  }

  Object.entries(med.eliminados||{}).forEach(([cf, ids])=>{
    (ids||[]).forEach(id=>{
      const c = C(id); if(!c) return;
      const sec = cf==='EUR' ? SEC.euro : SEC.mundo;
      T2.push(tit(sec, 74, '💥', '{club} queda eliminado en {ronda} de la {copa}',
        {club:c.n, ronda:med.ronda[cf]||'octavos', copa:CONT_CUP[cf]}));
    });
  });
  ['EUR','SUD'].forEach(cf=>{
    const l = Object.entries(med.lideres).filter(([id])=>L(id) && L(id).cont===cf && id!==lg.id);
    if(!l.length) return;
    const [lgId, clubId] = R.pick(l);
    const sec = cf==='EUR' ? SEC.euro : SEC.mundo;
    T2.push(tit(sec, 40, '🥇', '{club} manda en la {liga}', {club:C(clubId).n, liga:L(lgId).n}));
  });
  const cracks = (p.rivals||[]).filter(r=>r.ovr>=88);
  if(cracks.length){
    const r = R.pick(cracks);
    T2.push(tit(SEC.mundo, 48, '🌟', '{jug} atraviesa su mejor momento en {club}', {jug:r.name, club:C(r.club).n}));
  }
  if((p.year+1) % 4 === 2 && p.nt.caps > 0)
    T2.push(tit(SEC.mundo, 52, '🌍', '{pais} encamina la clasificación al Mundial', {pais:p.nat}));

  (fuera||[]).slice(0,3).forEach(f=>{
    const cf = L(C(f.clubId).lg).cont;
    T2.push(tit(f.mio ? SEC.yo : cf==='EUR' ? SEC.euro : SEC.mundo, f.mio ? 88 : 68, '🔥',
      f.mio ? '{jug} se queda sin técnico: {club} echa a {dt}' : '{club} despide a {dt}',
      f.mio ? {jug:p.name, club:f.club, dt:f.dt} : {club:f.club, dt:f.dt}));
  });
  const gm = med.goleadores && med.goleadores[lg.id];
  if(gm && gm.yo) T2.push(tit(SEC.yo, 70, '👟', '{jug} cierra el semestre como goleador de la {liga}: {n}', {jug:p.name, liga:lg.n, n:gm.goles}));
  else if(gm) T2.push(tit(SEC.liga, 42, '👟', '{jug} lidera la tabla de goleadores con {n}', {jug:gm.name, n:gm.goles}));
  if(t.length >= 8){
    const abajo = t.slice(Math.ceil(t.length/2)).map(([id])=>C(id)).filter(c=>c && c.tier>=4);
    if(abajo.length) T2.push(tit(SEC.raro, 66, '📉', '{club} pasa el año en la mitad de abajo', {club:R.pick(abajo).n}));
  }
  const sorpresas = Object.entries(med.lideres)
    .map(([lgId, id])=>({lgId, c:C(id), lg:L(lgId)}))
    .filter(x=>x.c && x.c.tier<=2 && x.lg.str>=3 && CLUBS.filter(c=>c.lg===x.lg.id).length>=8);
  if(sorpresas.length){
    const s = R.pick(sorpresas);
    T2.push(tit(SEC.raro, 72, '🤯', 'Sorpresa: {club} es líder de la {liga}', {club:s.c.n, liga:s.lg.n}));
  }
  return T2;
}

function diarioFin(p, rec, w, fuera){
  const T2 = [], club = C(rec.clubId) || C(p.club), lg = L(club.lg);

  (rec.titles||[]).forEach(n=>{
    const peso = n===CONT_CUP[lg.cont] ? 96 : n===lg.n ? 88 : 66;
    T2.push(tit(SEC.yo, peso, '🏆', '{jug} levanta la {comp} con {club}', {jug:p.name, comp:n, club:club.n}));
  });
  (rec.awards||[]).forEach(a=>{
    const peso = a.includes('Balón de Oro') ? 100 : a.includes('Bota de Oro') ? 90 : 62;
    T2.push(tit(SEC.yo, peso, a.includes('Balón')?'👑':'🥇', '{jug} gana {premio}', {jug:p.name, premio:a}));
  });
  if(rec.goals >= 25) T2.push(tit(SEC.yo, 74, '⚽', '{jug} termina la temporada con {n} goles', {jug:p.name, n:rec.goals}));
  if(rec.leaguePos === 1 && !(rec.titles||[]).includes(lg.n))
    T2.push(tit(SEC.yo, 80, '👑', '{club} es campeón de la {liga} con {jug} en el equipo',
      {club:club.n, liga:lg.n, jug:p.name}));
  (rec.ntTitles||[]).forEach(n=>
    T2.push(tit(SEC.yo, 98, '🌍', '{pais} gana la {comp} con {jug} en el equipo', {pais:p.nat, comp:n, jug:p.name})));
  T2.push(tit(SEC.yo, 14, '📋', '{jug} cierra el año con {pj} {upj}, {n} {ug} y {a} {ua}',
    {jug:p.name, pj:rec.apps, upj:cuenta(rec.apps,'partido'),
     n:rec.goals, ug:cuenta(rec.goals,'gol'), a:rec.assists, ua:cuenta(rec.assists,'asistencia')}));

  const t = (w.tablas && w.tablas[lg.id]) || [];
  if(t.length){
    const campeon = C(campeonLiga(w, lg.id) || t[0][0]);
    if(campeon && campeon.id !== p.club){
      const racha = rachaDe(p, x=>campeonLiga(x, lg.id), campeon.id);
      const seca  = sequiaDe(p, x=>campeonLiga(x, lg.id), campeon.id);
      if(racha >= 3)
        T2.push(tit(SEC.liga, 80, '👑', '{club} encadena {n} {liga} seguidas', {club:campeon.n, n:racha, liga:lg.n}));
      else if(seca >= 7)
        T2.push(tit(SEC.liga, 82, '🏆', '{club} rompe una sequía de {n} años en la {liga}', {club:campeon.n, n:seca, liga:lg.n}));
      else
        T2.push(tit(SEC.liga, 72, '🏆', '{club} es campeón de la {liga}', {club:campeon.n, liga:lg.n}));
    }
    const bajan = t.length>=8 ? 2 : t.length>=6 ? 1 : 0;
    t.slice(t.length-bajan).forEach(([id])=>{
      const c = C(id); if(!c) return;
      T2.push(tit(c.tier>=3 ? SEC.raro : SEC.liga, c.tier>=3 ? 82 : 46, '😱',
        '{club} desciende', {club:c.n}));
    });
  }
  const gol = w.goleadores && w.goleadores[lg.id];
  if(gol && !gol.yo) T2.push(tit(SEC.liga, 48, '👟', '{jug} es el goleador de la {liga} con {n}', {jug:gol.name, liga:lg.n, n:gol.goles}));
  const copaMia = w.copas && w.copas[lg.id];
  if(copaMia && !copaMia.yo) T2.push(tit(SEC.liga, 44, '🏵️', '{club} se queda con la {comp}', {club:copaMia.club, comp:copaMia.n}));

  if(w.conti && w.conti.EUR){
    const c = w.conti.EUR;
    const racha = rachaDe(p, x=>campeonConti(x,'EUR'), c.id);
    const seca  = sequiaDe(p, x=>campeonConti(x,'EUR'), c.id);
    if(racha >= 2)
      T2.push(tit(SEC.euro, c.yo? 99 : 96, '🏆', '{club} gana su {n}ª Champions seguida', {club:c.club, n:racha}));
    else if(seca >= 6)
      T2.push(tit(SEC.euro, c.yo? 99 : 96, '🏆', '{club} vuelve a ser campeón de Europa {n} años después', {club:c.club, n:seca}));
    else
      T2.push(tit(SEC.euro, c.yo? 99 : 94, '🏆', '{club} es campeón de Europa', {club:c.club}));
    if(c.sub) T2.push(tit(SEC.euro, 52, '💔', '{club} pierde otra final continental', {club:c.sub}));
  }
  if(w.conti2 && w.conti2.EUR)
    T2.push(tit(SEC.euro, 44, '🏅', '{club} gana la {comp}', {club:w.conti2.EUR.club, comp:w.conti2.EUR.n}));
  if(w.balon && !w.balon.yo)
    T2.push(tit(SEC.euro, 86, '👑', 'Balón de Oro para {jug}', {jug:w.balon.name}));

  ['SUD','ASI','CON'].forEach(cf=>{
    const c = w.conti && w.conti[cf]; if(!c) return;
    T2.push(tit(SEC.mundo, cf==='SUD'? 62 : 40, '🌎', '{club} gana la {comp}', {club:c.club, comp:c.n}));
  });
  if(w.selecciones && w.selecciones.mundial){
    const s = w.selecciones;
    T2.push(tit(SEC.mundo, 100, '🌍', '{pais} es campeón del mundo', {pais:s.campeon.nat}));
    if(s.sub) T2.push(tit(SEC.mundo, 58, '💔', '{pais} pierde la final del Mundial', {pais:s.sub.nat}));
  } else if(w.selecciones && w.selecciones.porConf){
    Object.values(w.selecciones.porConf).slice(0,2).forEach(s=>
      T2.push(tit(SEC.mundo, 50, '🏅', '{pais} gana la {comp}', {pais:s.nat, comp:s.torneo})));
  }
  if(w.cwc) T2.push(tit(SEC.mundo, 88, '🌐', '{club} se corona en el {comp}', {club:w.cwc.club, comp:w.cwc.n}));
  if(w.inter) T2.push(tit(SEC.mundo, 56, '🌍', '{club} gana la {comp}', {club:w.inter.club, comp:w.inter.n}));
  if(w.bota && !w.bota.yo) T2.push(tit(SEC.mundo, 46, '👟', '{jug} gana la Bota de Oro con {n} goles', {jug:w.bota.name, n:w.bota.goles}));

  {
    const ahora = recordsEra(p), antes = p.records;
    if(antes){
      if(ahora.goles.yo && !antes.goles.yo)
        T2.push(tit(SEC.yo, 93, '⚽', '{jug} es el máximo goleador de su generación: {n} goles', {jug:p.name, n:ahora.goles.v}));
      else if(!ahora.goles.yo && ahora.goles.name !== antes.goles.name)
        T2.push(tit(SEC.mundo, 58, '⚽', '{jug} pasa a ser el máximo goleador de la generación', {jug:ahora.goles.name}));
      if(ahora.balones.yo && !antes.balones.yo && ahora.balones.v>=2)
        T2.push(tit(SEC.yo, 97, '👑', 'Nadie de su generación tiene más Balones de Oro que {jug}', {jug:p.name}));
      if(ahora.ligas.yo && !antes.ligas.yo)
        T2.push(tit(SEC.yo, 88, '🥇', '{jug} es el jugador con más ligas de su generación', {jug:p.name}));
    }
    const faltan = ahora.goles.v - ahora.mio.goles;
    if(!ahora.goles.yo && faltan > 0 && faltan <= 30 && ahora.mio.goles >= 60)
      T2.push(tit(SEC.yo, 56, '🎯', '{jug} está a {n} goles del récord de su generación', {jug:p.name, n:faltan}));
  }

  const ge = gestas(p, w);
  if(ge.length && ge[0].rareza >= 55){
    const g = ge[0];
    const peso = 84 + g.rareza*0.16;
    if(g.tipo==='ligaSorpresa')
      T2.push(tit(SEC.raro, peso, '🤯', 'Nadie lo vio venir: {club} es campeón de la {liga}', {club:g.club, liga:g.liga}));
    if(g.tipo==='granDesciende')
      T2.push(tit(SEC.raro, peso, '😱', 'Terremoto: {club} desciende', {club:g.club}));
    if(g.tipo==='contiSorpresa')
      T2.push(tit(SEC.raro, peso, '🤯', '{club} gana la {copa} contra todo pronóstico', {club:g.club, copa:g.copa}));
    if(g.tipo==='selSorpresa')
      T2.push(tit(SEC.raro, peso, '🌍', '{pais} campeón del mundo: la mayor sorpresa que se recuerda', {pais:g.pais}));
    if(g.tipo==='selFinalista')
      T2.push(tit(SEC.raro, peso, '🌍', '{pais} llega a la final del Mundial de la nada', {pais:g.pais}));
  }

  fuera.slice(0, 3).forEach(f=>{
    T2.push(tit(f.mio ? SEC.yo : (L(C(f.clubId).lg).cont==='EUR' ? SEC.euro : SEC.mundo),
      f.mio ? 76 : 58, '🔥',
      f.mio ? '{jug} cambia de técnico: {club} echa a {dt} tras terminar {pos}º'
            : '{club} despide a {dt} tras terminar {pos}º',
      f.mio ? {jug:p.name, club:f.club, dt:f.dt, pos:f.real} : {club:f.club, dt:f.dt, pos:f.real}));
  });

  (p.retirados||[]).forEach(r=>{
    T2.push(tit(SEC.raro, r.balones? 84 : 64, '🎬',
      r.balones ? '{jug} se retira con {n} goles y {b} Balones de Oro'
                : '{jug} se retira después de {n} goles',
      {jug:r.name, n:r.goles, b:r.balones}));
  });
  (p.pases||[]).slice(0,2).forEach(t2=>{
    T2.push(tit(L(C(t2.a).lg).cont==='EUR' ? SEC.euro : SEC.mundo, 60, '💰',
      '{club} ficha a {jug} por {plata}', {club:C(t2.a).n, jug:t2.name, plata:t2.fee}));
  });
  (p.debutantes||[]).slice(0,1).forEach(r=>{
    T2.push(tit(SEC.raro, 54, '🌱', 'A los {edad}, {jug} aparece en {club}',
      {edad:r.age, jug:r.name, club:C(r.club).n}));
  });
  return T2;
}

const TITULARES = 5;
function armarPortada(titulares){
  const orden = titulares.slice().sort((a,b)=>b.w-a.w);
  const elegidos = [], usados = {}, plantillas = new Set();
  const tomar = t => {
    if(plantillas.has(t.k) || elegidos.length >= TITULARES) return;
    plantillas.add(t.k); usados[t.s] = (usados[t.s]||0) + 1;
    elegidos.push(t);
  };
  const locura = orden.find(t => t.s==='raro' && t.w >= 90);
  if(locura) tomar(locura);
  Object.keys(CUPO).forEach(s=>{
    const mejor = orden.find(t => t.s===s && !plantillas.has(t.k));
    if(mejor) tomar(mejor);
  });
  for(const t of orden) if(!elegidos.includes(t)) tomar(t);
  elegidos.sort((a,b)=>b.w-a.w);
  return { titulares: elegidos, top: elegidos.length? elegidos[0].w : 0 };
}

function careerSummary(p){
  const c=p.career;
  const avg = c.ratingN? round(c.rating/c.ratingN,2) : 0;
  const score = legendScore(p);
  const tier = legendTier(score);
  const byType = t=>p.honours.filter(h=>h.tipo===t);
  const clubsPlayed = [...new Set(p.seasons.map(s=>s.club))];
  return {
    score, tier, avg, clubsPlayed,
    ligas:p.ligas, copas:p.copas, contis:p.contis, contis2:p.contis2||0,
    mundiales:p.mundiales, contiSel:p.contiSel,
    balones:p.balones, botas:p.botas, botasOro:p.botasOro||0,
    mvpFinal:p.mvpFinal||0, mvpMundial:p.mvpMundial||0,
    individual:byType('individual'), seleccion:byType('seleccion'),
    goles:c.goals, asist:c.assists, pj:c.apps, motm:c.motm,
    temporadas:c.seasons, peakOvr:p.peakOvr
  };
}


function cicloEventosPorTemporada(p){ return p.dif === 'brutal' ? 3 : 2; }

function cicloDificultad(p, dif){
  p.dif = 'normal';
  p.difComp = 1; p.difOfertas = 1; p.difLesion = 1;
}

function cicloArranque({nat, pos, num, foot, draft, club, dif, memEv, nroCarrera, herencia}){
  relatoSemilla(azarEstado());
  usarDivisiones({});
  const p = createPlayer({name:'x', nat, pos, num, foot, draft, club, herencia:herencia || null});
  iniciarDivisiones(p);
  p.memEv = memEv || null;
  p.nroCarrera = nroCarrera || 0;
  const o = clubOutlook(C(club), p.ovr, p.potOvr, nat);
  if(o.extranjero){ p.adapt = o.adaptacion; p.moral = clamp(p.moral-8, 0, 100); }
  cicloDificultad(p, dif);
  recalc(p); squadUpdate(p);
  return p;
}

function cicloPretemporada(p, foco){
  const growth = develop(p, foco, minutesShare(p));
  startSeasonPlan(p);
  const eventos = pickEvents(p, cicloEventosPorTemporada(p));
  return {growth, eventos};
}

function eventoVigente(p, e){
  const marcas = (!e.req  || [].concat(e.req).every(f => p.flags[f]))
              && (!e.veta || ![].concat(e.veta).some(f => p.flags[f]));
  return marcas && (!e.when || !!e.when(p));
}

function costoDe(o){
  return o && o.ef && typeof o.ef.capital === 'number' && o.ef.capital < 0 ? -o.ef.capital : 0;
}
function opcionPagable(p, o){
  const c = costoDe(o);
  return !c || !!o.todo || (p.capital || 0) + 1e-9 >= c;
}

function cicloDecision(p, e, i){
  p.seenEvents.push(e.id);
  let c = e.c[i] || e.c[0];
  if(!opcionPagable(p, c)) c = e.c.find(o => opcionPagable(p, o)) || c;
  let efectos = c.ef || {}, riesgo = null;
  if(c.tira){
    const antes = p.attrs[c.tira];
    const salio = resolverRiesgo(p, c.tira, c.mas);
    const rama = salio ? c.bien : c.mal;
    efectos = {...efectos};
    for(const [k, v] of Object.entries(rama.ef || {}))
      efectos[k] = (typeof v === 'number' && typeof efectos[k] === 'number') ? efectos[k]+v : v;
    riesgo = {salio, k:c.tira, v:antes};
  }
  const r = {riesgo, log: applyEffect(p, efectos, c.t)};
  if(c.ofr && p.loanFrom && c.ofr.cuando === 'ya' && !c.ofr.prestamo){
    p.ofertaPendiente = c.ofr.t; r.promesa = true;
  } else if(c.ofr){
    if(c.ofr.cuando === 'ya'){
      r.fichaje = ficharPorEvento(p, c.ofr.t, c.ofr.prestamo);
      r.cedido = !!c.ofr.prestamo;
      r.cortaCola = true;
    } else { p.ofertaPendiente = c.ofr.t; r.promesa = true; }
  }
  return r;
}

function cicloMitad(p, n){ return {h: simHalf(p, n)}; }
function cicloPartidos(p, h){ return relato(()=>buildHalf(p, h)); }

function cicloDiciembre(p, h0){
  p.medio = worldHalf(p, h0);
  const fuera = despidos(p, p.medio);
  if(fuera.some(f=>f.mio)) cicloNuevoDT(p);
  cicloDescontarCesion(p);
  const vuelta = cicloVolverDeCesion(p);
  const winter = winterMarket(p);
  return {fuera, winter, vuelta};
}
function cicloDiarioDiciembre(p, h0, fuera){
  return relato(()=>armarPortada(diarioMitad(p, h0, p.medio, fuera)));
}
function cicloNuevoDT(p){
  p.mgrRel = clamp(R.i(38,66), 0, 100); p.mgrFit = R.i(-9,9); p.mgrNuevo = true;
}

function cicloCesion(p, o, mitades){
  p.loanFrom = p.club; p.loanYears = p.clubYears || 0;
  p.club = o.clubId; p.wage = o.wage;
  p.clubYears = 0; p.qual = undefined; p.qualClub = null; p.compRival = null; if(p.flags) delete p.flags.capitan;   
  p.fanLove = 50; p.mgrRel = 62; p.moral = clamp(p.moral+8, 0, 100);
  p.loanTotal = p.loanMitades = (mitades === 2 ? 2 : 1);
  if(L(C(p.club).lg).pais !== p.nat) p.adapt = clamp(p.adapt-30, 0, 100); else p.adapt = 100;   
}

function cicloVolverDeCesion(p, forzado){
  if(!p.loanFrom) return null;
  if(!forzado && p.loanMitades > 0) return null;
  const vuelve = C(p.loanFrom);
  p.club = p.loanFrom; p.loanFrom = null;
  p.loanMitades = 0; p.loanTotal = 0;
  p.clubYears = (p.loanYears || 0) + 1; p.loanYears = 0;
  p.qual = undefined; p.qualClub = null; p.compRival = null; if(p.flags) delete p.flags.capitan;   
  if(L(vuelve.lg).pais === p.nat) p.adapt = 100;
  p.timeline.push({y:p.year, k:'Vuelve de la cesión a {club}', v:{club:vuelve.n}, ic:'↩️'});
  return vuelve;
}

function cicloDescontarCesion(p){
  if(p.loanFrom && p.loanMitades > 0) p.loanMitades--;
}
function cicloPaseInvierno(p, o){
  p.club = o.clubId; p.wage = o.wage; p.contract = o.years;
  p.clubYears = 0; p.loanYears = 0; p.qual = undefined; p.qualClub = null;
  p.compRival = null;   
  if(p.flags) delete p.flags.capitan;   
  p.fanLove = clamp(48+R.i(-6,12), 0, 100); p.mgrRel = clamp(58+R.i(-8,12), 0, 100);
  if(L(C(p.club).lg).pais !== p.nat) p.adapt = clamp(p.adapt-34, 0, 100); else p.adapt = 100;
}

function cicloCerrar(p, mitades){
  const s = finishSeason(p, mitades);
  if(!Array.isArray(p.ruta)) p.ruta = [];
  if(p.ruta[p.ruta.length-1] !== p.club) p.ruta.push(p.club);
  if(!p.rivals) p.rivals = initRivals();
  if(!p.world) p.world = [];
  p.rankPrevio = (p.rivals||[]).slice().sort((x,y)=>legadoDe(y)-legadoDe(x)).map(r=>r.name);
  rivalSeason(p, s);
  const w = worldSeason(p, s);
  p.world.push(w);
  const fuera = despidos(p, w);
  ageRivals(p.rivals, p);
  const movidos = moverDivisiones(p, w.tablas, w.tablas2);
  if(fuera.some(f=>f.mio)) cicloNuevoDT(p);
  p.medio = null;
  return {s, w, fuera, movidos};
}
function cicloDiarioJunio(p, s, w, fuera){
  const portada = relato(()=>armarPortada(diarioFin(p, s, w, fuera)));
  p.records = recordsEra(p);
  return portada;
}

function cicloMercado(p){
  cicloDescontarCesion(p);
  const vuelta = cicloVolverDeCesion(p);
  p.contract--;
  if(p.loanFrom) return {vuelta, cedido:true, ofertas:[], renovar: renewOffer(p)};
  return {vuelta, ofertas: generateOffers(p), renovar: renewOffer(p)};
}
function cicloRenovar(p, renovar){
  p.wage = renovar.wage; p.contract = renovar.years; p.clubYears++;
  p.fanLove = clamp(p.fanLove+4, 0, 100);
}
function cicloFichar(p, o){
  p.club = o.clubId; p.wage = o.wage; p.contract = o.years;
  p.clubYears = 0; p.loanYears = 0; p.qual = undefined; p.qualClub = null;
  p.compRival = null;
  if(p.flags) delete p.flags.capitan;   
  p.fanLove = clamp(48+R.i(-6,12), 0, 100); p.mgrRel = clamp(58+R.i(-8,12), 0, 100);
  p.moral = clamp(p.moral+6, 0, 100);
  if(L(C(p.club).lg).pais !== p.nat) p.adapt = clamp(p.adapt-34, 0, 100); else p.adapt = 100;
}

function cicloSiguiente(p){
  p.age++; p.year++;
  squadUpdate(p);
  const r = retireCheck(p);
  if(r){ p.retired = true; p.retireReason = r; }
  return r;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {famaDe,anioValido,leyendaDeRasgo,ANIO_BASE,FAMA_TECHO,srand,eventoVigente,opcionPagable,costoDe,R,ATTRS,POSITIONS,NATIONS,LEAGUES,CLUBS,LEGENDS,TRAITS,EVENTS,
    NAT_POOL,RIVAL_POS,NAMES_F,NAMES_L,
    createPlayer,recalc,develop,generateOffers,renewOffer,retireCheck,
    legendScore,legendTier,stageOf,squadUpdate,scoutBand,ficharPorEvento,clubParaOferta,peakAgeOf,CURVAS,POS_PEAK,crest,kitOf,KIT,LG_COLOR,filosofiaDe,FIL_N,FIL_D,minutosProyectados,rolPorMinutos,clubComps,compsFor,leagueRank,expectedPos,leagueSize,qualifyFrom,defaultQual,contiSlots,
    buildHalf,runningTotals,COMP_LABEL,CONT_CUP2,mergeComps,contiRivals,
    topesLimpiar,topesLeer,
    simHalf,finishSeason,startSeasonPlan,totalGames,semanasPerdidas,SEMANAS_MITAD,
    startingOptions,clubOutlook,winterMarket,wageFor,interest,
    worldSeason,ageRivals,initRivals,makeRival,rivalSeason,legadoDe,
    careerSummary,DISTINCIONES,distincionesDe,pickEvents,applyEffect,minutesShare,C,L,RETIRE_TXT,
    marketValue,squadLevel,clamp,round,CONT_CUP,CONF_NAME,TIERS,
    FIFA_CWC,FIFA_INTER,CWC_PLAZAS,INTER_RONDAS,clubPower,clubBase,moverCiclos,usarCiclos,
    gestas,recordsEra,CAT_RECORD,
    temple,golesAereos,golesParados,jerarquiaPateador,arrastre,enLetras,
    chanceDeQueSalga,resolverRiesgo,
    nuevoDT,dtDe,despidos,worldHalf,diarioMitad,diarioFin,armarPortada,CUPO,SEC,
    azarEstado,azarRestaurar,relato,relatoSemilla,relatoEstado,relatoRestaurar,
    usarDivisiones,enPrimera,enSegunda,clubesDe,iniciarDivisiones,moverDivisiones,
    CATS,EV_CAT,catDe,pesoMemoria,pesoRareza,memoriaLeer,memoriaGuardar,memoriaValida,
    cicloArranque,cicloDificultad,HEREDABLES,herenciaValida,DINASTIA_MAX_GEN,MARCAS_DE_NACIMIENTO,cicloEventosPorTemporada,cicloPretemporada,
    cicloDecision,cicloMitad,cicloPartidos,cicloDiciembre,cicloDiarioDiciembre,
    cicloNuevoDT,cicloCesion,cicloPaseInvierno,cicloVolverDeCesion,cicloDescontarCesion,cicloCerrar,cicloDiarioJunio,
    cicloMercado,cicloRenovar,cicloFichar,cicloSiguiente,guardarNemesis,nemesisAlBanco};
}

let LANG = 'en';   

const LANG_QUERY = (new URLSearchParams(location.search).get('lang') || '').toLowerCase();
const LANG_DE_RUTA = ['fa','en','es','pt'].includes(LANG_QUERY) ? LANG_QUERY
  : /^\/fa(\/|$)/.test(location.pathname) ? 'fa'
  : /^\/es(\/|$)/.test(location.pathname) ? 'es'
  : /^\/pt(\/|$)/.test(location.pathname) ? 'pt' : 'en';

function rutaDe(l){ return '/?lang=' + encodeURIComponent(l); }

LANG = LANG_DE_RUTA;
try{ localStorage.setItem('mfc_lang', LANG); }catch(e){}
try{ document.documentElement.lang = LANG === 'pt' ? 'pt-BR' : LANG; }catch(e){}
if(LANG === 'fa'){
  try{
    document.documentElement.dir = 'rtl';
    const faStyle = document.createElement('style');
    faStyle.textContent = `html[lang=\"fa\"] body{direction:rtl!important;text-align:right!important;font-family:Tahoma,Arial,sans-serif!important} html[lang=\"fa\"] .langsw,html[lang=\"fa\"] .pos,html[lang=\"fa\"] .num,html[lang=\"fa\"] .score,html[lang=\"fa\"] .crest{direction:ltr!important} html[lang=\"fa\"] input,html[lang=\"fa\"] select,html[lang=\"fa\"] textarea{direction:rtl!important;text-align:right!important} html[lang=\"fa\"] button{font-family:Tahoma,Arial,sans-serif!important}`;
    (document.head || document.documentElement).appendChild(faStyle);
  }catch(e){}
}else{ try{document.documentElement.dir='ltr';}catch(e){} }


const TR = (() => {
  if(LANG === 'en' && typeof EN !== 'undefined')
    return {d:EN, comp:EN_COMP, nat:EN_NAT, award:EN_AWARD, nt:EN_NT, ev:typeof EV_EN !== 'undefined' ? EV_EN : null,
      club:typeof EN_CLUB !== 'undefined' ? EN_CLUB : null};
  if(LANG === 'pt' && typeof PT !== 'undefined')
    return {d:PT, comp:PT_COMP, nat:PT_NAT, award:PT_AWARD, nt:PT_NT, ev:typeof EV_PT !== 'undefined' ? EV_PT : null,
      club:typeof PT_CLUB !== 'undefined' ? PT_CLUB : null,
      fem:typeof PT_FEM !== 'undefined' ? PT_FEM : null, masc:typeof PT_MASC !== 'undefined' ? PT_MASC : null};
  if(LANG === 'fa' && typeof FA !== 'undefined')
    return {d:FA, comp:FA_COMP, nat:FA_NAT, award:FA_AWARD, nt:FA_NT, ev:EV_FA, club:FA_CLUB};
  return null;
})();
if(TR && TR.club && typeof CLUBS !== 'undefined') CLUBS.forEach(c => { if(TR.club[c.n]) c.n = TR.club[c.n]; });

const CONCORDAR = (() => {
  if(!TR || !TR.fem || !TR.masc) return null;
  const lista = xs => xs.slice().sort((a, b) => b.length - a.length).map(x => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
  const F = {do:'da', no:'na', ao:'à', o:'a', pelo:'pela', num:'numa', dum:'duma'};
  const M = {da:'do', na:'no', 'à':'ao', a:'o', pela:'pelo', numa:'num', duma:'dum'};
  const mayus = (w, r) => w[0] === w[0].toUpperCase() ? r[0].toUpperCase() + r.slice(1) : r;
  const L = 'A-Za-zÀ-ÿ';
  return [
    [new RegExp('(^|[^' + L + '])(do|no|ao|o|pelo|num|dum|Do|No|Ao|O|Pelo|Num|Dum)\\s+(' + lista(TR.fem) + ')(?![' + L + '])', 'g'),
      (m, a, art, n) => a + mayus(art, F[art.toLowerCase()]) + ' ' + n],
    [new RegExp('(' + lista(TR.fem) + ')(\\s+(?:(?:é|foi|está|fica|termina|acaba|será|volta a ser|voltou a ser)\\s+)?)(vice-campeão|campeão|eliminado|rebaixado|promovido)(?![' + L + '])', 'g'),
      (m, n, v, adj) => n + v + adj.replace(/ão$/, 'ã').replace(/o$/, 'a')],
    [new RegExp('(^|[^' + L + '])(da|na|à|a|pela|numa|duma|Da|Na|À|A|Pela|Numa|Duma)\\s+(' + lista(TR.masc) + ')(?![' + L + '])', 'g'),
      (m, a, art, n) => a + mayus(art, M[art.toLowerCase()]) + ' ' + n]
  ];
})();
const ES_MASC = ['Brasileirão','USL Championship','Championship','Community Shield',
  "Supporters' Shield",'Trofeo de Campeones','Campeón de Campeones','Trophée des Champions'];
const CONCORDAR_ES = (() => {
  const L = 'A-Za-zÀ-ÿ';
  const lista = ES_MASC.slice().sort((a, b) => b.length - a.length).map(x => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
  return [
    [new RegExp('(^|[^' + L + '])([Ll]a) LaLiga(?![' + L + '])', 'g'), (m, a) => a + 'LaLiga'],
    [new RegExp('(^|[^' + L + '])(de|a|De|A) la (' + lista + ')(?![' + L + '])', 'g'),
      (m, a, p, n) => a + (p.toLowerCase() === 'de' ? (p === 'De' ? 'Del' : 'del') : (p === 'A' ? 'Al' : 'al')) + ' ' + n],
    [new RegExp('(^|[^' + L + '])(la|La) (' + lista + ')(?![' + L + '])', 'g'),
      (m, a, art, n) => a + (art === 'La' ? 'El' : 'el') + ' ' + n]
  ];
})();
function concordar(s){
  if(LANG === 'es' && typeof s === 'string'){ for(const [re, f] of CONCORDAR_ES) s = s.replace(re, f); return s; }
  if(!CONCORDAR || typeof s !== 'string') return s;
  for(const [re, f] of CONCORDAR) s = s.replace(re, f);
  return s;
}
function TPais(n){ return (TR && TR.nat[n]) ? TR.nat[n] : n; }

function T(s, vars){
  let out = (TR && TR.d[s]!=null) ? TR.d[s] : s;
  if(vars) Object.keys(vars).forEach(k=>{ out = out.split('{'+k+'}').join(vars[k]); });
  return concordar(out);
}
function TN(name){            
  if(!TR || !name) return concordar(name);
  if(TR.comp[name]) return TR.comp[name];
  if(TR.nat[name]) return TR.nat[name];
  const f = name.match(/^MVP de la final de la (.+)$/);
  if(f) return LANG==='pt' ? concordar('Craque da final da '+TN(f[1])) : 'Player of the Match, '+TN(f[1])+' final';
  for(const [es,en] of TR.award){
    if(name===es) return en;
    if(es.endsWith(' ') && name.startsWith(es)) return concordar(en + TN(name.slice(es.length)));
  }
  if(TR.nt[name]) return TR.nt[name];
  const m = name.match(/^(Mundial|Eurocopa|Copa América|Copa Africana de Naciones|Copa Oro|Copa Asiática): (.+)$/);
  if(m){                                   
    const torneo = TN(m[1]), fase = TN(m[2]);
    return fase.startsWith(torneo) ? fase : torneo+': '+fase;
  }
  const e = name.match(/^(.+): eliminado$/); if(e) return TN(e[1])+(LANG==='pt' ? ': eliminado' : ': eliminated');
  const q = name.match(/^Eliminatorias \((\d+) PJ, (\d+) G\)$/);
  if(q) return LANG==='pt' ? `Eliminatórias (${q[1]} jogos, ${q[2]} gols)` : `Qualifiers (${q[1]} apps, ${q[2]} goals)`;
  for(const ic of ['🌍 ','🏅 ','🏆 ','🥇 ','⚽ ']){
    if(name.startsWith(ic)) return ic + TN(name.slice(ic.length));
  }
  if(TR.d && TR.d[name]!=null) return concordar(TR.d[name]);
  return name;
}
const POS_ABBR = {DFC:'CB', LAT:'FB', MCD:'DM', MC:'CM', MCO:'AM', EXT:'W', DC:'ST'};
const POS_ABBR_PT = {DFC:'ZAG', LAT:'LAT', MCD:'VOL', MC:'MC', MCO:'MEI', EXT:'PON', DC:'CA'};
const TPOS = pos => LANG==='en' ? (POS_ABBR[pos]||pos) : LANG==='pt' ? (POS_ABBR_PT[pos]||pos) : pos;   
function ord(n){
  if(LANG!=='en') return n+'º';
  const s=['th','st','nd','rd'], v=n%100;
  return n + (s[(v-20)%10] || s[v] || s[0]);
}
const TP = pos => (Object.prototype.hasOwnProperty.call(POSITIONS, pos) ? T(POSITIONS[pos].n) : esc(String(pos || '—')));
const TA = k => { const a = ATTRS.find(a => a.k === k); return a ? T(a.n) : String(k || '—'); };

const S = { p:null, phase:'intro', evQueue:[], evIdx:0, evResult:null,
            posPick:'DC', mktPick:null, lastSeason:null, halves:[], matches:[], simI:0, simTimer:null,
            offers:[], renew:null, winter:null, draftPicks:[], focus:[], lastGrowth:null,
            sheet:null, wlg:null, dif:'normal', startOpts:null, startPick:null,
            vel:(()=>{ try{ return localStorage.getItem('mfc_vel') || 'normal'; }catch(e){ return 'normal'; } })(),
            reg:null, semilla:null, semillaServidor:null, tabla:null, envio:null, rkAbierta:null,
            reto:null, enReto:null };
const $ = id => document.getElementById(id);
try{
  const pre = window.RETO_PRE;
  if(pre && Number.isInteger(pre.semilla) && Date.now() < pre.hasta) S.reto = pre;
}catch(e){}

const SAVE_KEY = 'mfc_save';          

function migrar(d){
  if(!d || !d.p) return d;
  const f = d.p.flags;
  if(f && f.polemico && !f.enLaMira){ f.enLaMira = true; delete f.polemico; }
  if(!d.p.mem) d.p.mem = {};
  return d;
}

const Store = {
  ok:(()=>{ try{ localStorage.setItem('__t','1'); localStorage.removeItem('__t'); return true; }catch(e){ return false; } })(),
  mem:null,
  fallo:false,
  save(){
    if(S.phase!=='pretemporada' && S.phase!=='fin'){
      if(S.p && !this.enCurso){ this.enCurso=true; try{ if(this.ok) localStorage.setItem(SAVE_KEY+'_mitad','1'); }catch(e){} }
      return;
    }
    const d=JSON.stringify({p:S.p, phase:S.phase, dif:'normal', reg:S.reg,
      azar:azarEstado(), relato:relatoEstado()});
    this.mem=d; this.enCurso=false;
    if(!this.ok){ this.fallo=true; return; }
    try{ localStorage.setItem(SAVE_KEY, d); localStorage.removeItem(SAVE_KEY+'_mitad'); this.fallo=false; }
    catch(e){ this.fallo=true; }
  },
  aMedias(){ if(this.enCurso) return true; try{ return this.ok && localStorage.getItem(SAVE_KEY+'_mitad')==='1'; }catch(e){ return false; } },
  load(){ try{
    if(!this.ok) return migrar(JSON.parse(this.mem));
    let raw = localStorage.getItem(SAVE_KEY);
    if(!raw && SAVE_KEY==='mfc_save'){
      const viejo = localStorage.getItem('leyenda_save');
      if(viejo){ localStorage.setItem(SAVE_KEY, viejo); localStorage.removeItem('leyenda_save'); raw = viejo; }
    }
    return migrar(JSON.parse(raw));
  }catch(e){ return null; } },
  clear(){ try{ if(this.ok){
      const raw = localStorage.getItem(SAVE_KEY);
      if(raw) localStorage.setItem(SAVE_KEY+'_roto', raw);
      localStorage.removeItem(SAVE_KEY);
      localStorage.removeItem(SAVE_KEY+'_mitad');
    } }catch(e){} this.mem=null; this.enCurso=false; }
};

function anotar(campo, valor){
  if(!S.reg || !S.reg[campo]) return;
  S.reg[campo].push(valor);
}

const RANKING_URL = 'https://mfc-ranking.tomas-01b.workers.dev';

function errorDelRanking(estado, crudo){
  if(crudo === 'ese nombre es de otro jugador')
    return 'Ese nombre ya lo usa otro jugador en el ranking. Elegí otro.';
  if(crudo === 'ese nombre ya jugó el reto')
    return 'Ese nombre ya tiene su carrera en el reto de esta semana.';
  if(crudo === 'esa carrera ya está en el reto')
    return 'Esta carrera ya está en la tabla de la semana.';
  if(crudo === 'la fama del padre no se pudo comprobar')
    return 'La carrera de tu viejo ya no está en el ranking, así que el servidor no puede comprobar el peso del apellido.';
  if(crudo === 'el reto ya cerró')
    return 'El reto de esa semana ya cerró. El de esta semana te espera en la portada.';
  if(estado === 422)
    return 'Esta carrera empezó con una versión anterior del juego, así que el servidor no la puede comprobar. No es culpa tuya: la próxima sí va a entrar.';
  if(estado === 429)
    return 'Estás mandando demasiado seguido. Esperá un minuto y volvé a probar.';
  if(estado === 409)
    return 'Esta carrera ya está en la tabla.';
  if(crudo === 'nombre no admitido')
    return 'Ese nombre no se puede usar. Probá con otro.';
  if(crudo === 'la semilla venció')
    return 'Esta carrera tardó demasiado y el servidor ya no la puede comprobar.';
  if(crudo === 'semilla no emitida por el servidor')
    return 'El servidor no reconoce esta carrera. Empezá una nueva para poder mandarla.';
  if(estado >= 500)
    return 'El ranking está teniendo problemas. Probá de nuevo en un rato.';
  return 'No se pudo mandar la carrera. Probá de nuevo en un rato.';
}

let llaveSesion = null;
function llaveNombre(){
  try{
    const ya = localStorage.getItem('mfc_llave');
    if(ya && /^[A-Za-z0-9_-]{22,64}$/.test(ya)) return ya;
  }catch(e){}
  if(!llaveSesion){
    const b = new Uint8Array(24);
    (window.crypto || {}).getRandomValues ? crypto.getRandomValues(b) : b.forEach((_, i)=>{ b[i] = Math.random()*256|0; });
    llaveSesion = btoa(String.fromCharCode(...b)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
  }
  try{ localStorage.setItem('mfc_llave', llaveSesion); }catch(e){}
  return llaveSesion;
}

async function rankPedir(ruta, opts){
  const ctrl = new AbortController();
  const corte = setTimeout(()=>ctrl.abort(), 8000);   
  try{
    const r = await fetch(RANKING_URL + ruta, {...opts, signal:ctrl.signal});
    const j = await r.json();
    return r.ok ? j : {error: errorDelRanking(r.status, j && j.error)};
  }catch(e){ return {error:'sin conexión'}; }
  finally{ clearTimeout(corte); }
}

const SEMILLA_FRESCA = 12 * 3600 * 1000;
function rankPedirSemilla(){
  if(S.semillaPidiendo) return;
  S.semillaPidiendo = true;
  rankPedir('/semilla').then(r=>{
    S.semillaPidiendo = false;
    if(Number.isInteger(r.semilla)){ S.semillaServidor = r.semilla; S.semillaHora = Date.now(); S.semillaIntentos = 0; return; }
    if(r.error === 'sin conexión' || /problemas/.test(r.error || '')){
      const n = S.semillaIntentos = (S.semillaIntentos || 0) + 1;
      if(n <= 4) setTimeout(rankPedirSemilla, [3000, 10000, 30000, 90000][n-1]);
    }
  });
}
function semillaAlDia(){
  if(typeof fetch !== 'function') return;
  if(S.semillaServidor == null || Date.now() - (S.semillaHora || 0) > SEMILLA_FRESCA){
    S.semillaIntentos = 0; rankPedirSemilla();
  }
}
if(typeof window !== 'undefined' && window.addEventListener){
  window.addEventListener('online', semillaAlDia);
  document.addEventListener('visibilitychange', () => { if(document.visibilityState === 'visible') semillaAlDia(); });
}

function pedirRetoAhora(){
  const p = window.RETO_P; window.RETO_P = null;
  if(!p) return rankPedir('/reto');
  return Promise.race([p, new Promise(ok => setTimeout(() => ok(null), 8000))])
    .then(r => (r && Number.isInteger(r.semilla)) ? r : rankPedir('/reto'));
}
const RETO_ESPERAS = [3000, 10000, 30000, 90000];
function rankPedirReto(){
  if(S.retoPidiendo) return;
  S.retoPidiendo = true;
  clearTimeout(S.retoOtraVez);
  pedirRetoAhora().then(r=>{
    S.retoPidiendo = false;
    if(!r || !Number.isInteger(r.semilla)){
      if(!S.reto) S.retoFallo = true;
      const n = S.retoIntentos = (S.retoIntentos || 0) + 1;
      if(n <= RETO_ESPERAS.length) S.retoOtraVez = setTimeout(rankPedirReto, RETO_ESPERAS[n-1]);
    } else {
      if(Date.now() >= r.hasta) r = {...r, hasta: Date.now() + 3600000, relojAdelantado: true};
      S.reto = r; S.retoFallo = false; S.retoIntentos = 0;
    }
    pintarReto();
  });
}
function claseSlotReto(){
  return 'reto-slot' + (S.retoFallo ? '' : ' esperando') + (retoJugadoAlgunaVez() ? ' jugo' : '');
}
function pintarReto(){
  const slot = document.getElementById('reto-slot');
  if(!slot) return;
  const habia = !!slot.querySelector('.reto');
  slot.innerHTML = vRetoCard();
  const encender = () => slot.querySelectorAll('.anim').forEach(e => e.classList.add('in'));
  if(habia) encender(); else requestAnimationFrame(encender);
  slot.className = claseSlotReto();
}
function retoVencido(){
  if(!S.reto || Date.now() < S.reto.hasta) return false;
  S.reto = null; S.retoFallo = false; S.retoIntentos = 0;
  rankPedirReto();
  return true;
}
if(typeof window !== 'undefined' && window.addEventListener){
  const otraVez = () => { if(!S.reto && !S.retoPidiendo && typeof fetch === 'function'){ S.retoIntentos = 0; rankPedirReto(); } };
  window.addEventListener('online', otraVez);
  document.addEventListener('visibilitychange', () => { if(document.visibilityState === 'visible'){ otraVez(); retoVencido(); } });
}
function retoLocal(){
  try{
    const d = JSON.parse(localStorage.getItem('mfc_reto') || 'null');
    if(!(d && typeof d==='object' && S.reto && d.semana === S.reto.semana)) return null;
    for(const k of ['puesto','total','puntaje']) if(d[k]!=null && !Number.isFinite(d[k])) delete d[k];
    return d;
  }catch(e){ return null; }
}
function retoJugadoAlgunaVez(){
  try{ const d = JSON.parse(localStorage.getItem('mfc_reto') || 'null'); return !!(d && d.empezado); }catch(e){ return false; }
}
function retoGuardar(cambios){
  try{
    const d = {...(retoLocal() || {semana:S.reto.semana}), ...cambios};
    localStorage.setItem('mfc_reto', JSON.stringify(d));
  }catch(e){}
}
function goReto(){
  if(!S.reto || retoVencido()) return;
  const yo = retoLocal();
  S.enReto = {info:S.reto, practica:!!(yo && yo.empezado)};
  S.volver = null;
  abrirCreacion();
}
function faltaReto(){
  if(!S.reto || window.PRERENDER || S.reto.relojAdelantado) return '';
  const ms = S.reto.hasta - Date.now();
  if(ms <= 0) return '';
  const d = Math.floor(ms/86400000), h = Math.floor(ms/3600000)%24;
  return d ? T('termina en {d} d {h} h', {d, h}) : T('termina en {h} h', {h:Math.max(1,h)});
}
function vRetoCard(){
  if(S.reto && Date.now() >= S.reto.hasta){ setTimeout(retoVencido, 0); return ''; }
  const r = S.reto; if(!r) return '';
  const nac = NATIONS.find(n=>n.n===r.nat);
  const yo = retoLocal();
  const jugado = yo && yo.empezado;
  const resultado = yo && yo.puesto
    ? `<p class="reto-yo">${T('Tu puesto esta semana: <b>#{p}</b> de {t}', {p:yo.puesto, t:Math.max(yo.total||0, r.jugadores||0)})}</p>` : '';
  return `<div class="reto anim" data-hasta="${r.hasta}">
    <div class="reto-top"><span class="reto-tag">🗓 ${T('Reto de la semana')} · ${T('Semana {n}', {n:r.numero})}</span>
      <span class="reto-fin">${faltaReto()}</span></div>
    <p class="reto-quien">${T('Esta semana todos son')} <b>${nac? nac.f : ''} ${esc(TPais(r.nat))} · ${esc(TP(r.pos))}</b>
      <em>${T(r.foot==='Izquierda'?'Zurdo':'Diestro')} · #${r.num}</em></p>
    <p class="reto-txt">${T('Misma semilla para todo el mundo: lo único que cambia son tus decisiones. Una sola vuelta cuenta por semana.')}</p>
    ${resultado}
    <div class="reto-botones">
      <button class="reto-jugar" onclick="goReto()">${jugado ? T('Jugarlo otra vez (práctica)') : T('Jugar el reto')}</button>
      <button class="reto-tabla" onclick="abrirTabla('reto')">${T('Ranking del reto')}${r.jugadores? ' · '+r.jugadores : ''}</button>
    </div>
  </div>`;
}

let _tabla = null;
function abrirTabla(modo, semana){
  let reto = semana || (!S.reto ? 0 : modo === 'reto' ? S.reto.semana : modo === 'anterior' ? S.reto.anterior : 0);
  if(semana && S.reto && semana === S.reto.anterior) modo = 'anterior';
  if(!reto || (modo !== 'reto' && modo !== 'anterior')){ modo = 'historico'; reto = 0; }
  S.rkAbierta = null;
  S.tabla = {cargando:true, filas:null, modo};
  pintarTabla();
  rankPedir('/top?' + (reto ? 'reto=' + reto + '&' : '') + 't=' + Math.floor(Date.now()/15000)).then(r=>{
    if(!S.tabla || S.tabla.modo !== modo) return;      
    S.tabla = {cargando:false, filas:r.top || null, error:r.error, modo, total:r.total};
    pintarTabla();
  });
}
function cerrarTabla(){ S.tabla=null; S.rkAbierta=null; pintarTabla(); }
function pintarTabla(){
  const previo = document.querySelector('.sheet');
  const alto = previo ? previo.scrollTop : 0;
  document.querySelectorAll('.sheet-bg,.sheet').forEach(e=>e.remove());
  if(!S.tabla) return;
  $('app').insertAdjacentHTML('beforeend', vTabla());
  const hoja = document.querySelector('.sheet');
  if(hoja && alto) hoja.scrollTop = alto;
  if(hoja && previo) hoja.classList.add('sin-anim');
  const abierta = hoja && hoja.querySelector('.rkdetalle');
  if(!hoja || !abierta) return;
  const h = hoja.getBoundingClientRect(), a = abierta.getBoundingClientRect();
  if(a.bottom > h.bottom) hoja.scrollTop += Math.min(a.bottom - h.bottom + 12, a.top - h.top - 12);
}
const RECORDS = [
  ['goat',   'GOAT',                f => f.puntaje || 0],
  ['serial', 'Ganador serial',      f => titulosTotales(f)],
  ['gol',    'Goleador histórico',  f => f.goles || 0],
  ['asis',   'El Arquitecto',       f => f.asistencias || 0],
  ['oro',    'Niño de Oro',         f => f.balones || 0],
  ['trota',  'Trotamundos',         f => clubesDe_(f).length],
  ['eterno', 'Eterno',              f => f.edadRetiro || 0],
  ['unclub', 'De un solo club',     f => clubesDe_(f).length === 1 ? (f.temporadas || 0) : -1]
];

const RECORDS_PUESTO = [
  ['nueve',  'DC',  'El nueve'],
  ['ext',    'EXT', 'El desequilibrante'],
  ['engan',  'MCO', 'El enganche'],
  ['cerebro','MC',  'El cerebro'],
  ['ancla',  'MCD', 'El equilibrio'],
  ['muralla','DFC', 'La muralla'],
  ['carril', 'LAT', 'El carrilero']
];
const clubesDe_ = f => String(f.ruta || '').split(',').filter(Boolean);
const TODOS_RECORDS = () => RECORDS.map(([k, t]) => [k, t])
  .concat(RECORDS_PUESTO.map(([k, , t]) => [k, t]));

function recordsDeTabla(filas){
  const duenio = {};
  if(!Array.isArray(filas) || !filas.length) return duenio;
  for(const [clave, , medir] of RECORDS){
    let mejor = -Infinity, quien = -1;
    filas.forEach((f, i) => { const v = medir(f); if(v > mejor){ mejor = v; quien = i; } });
    if(quien >= 0 && mejor > 0) duenio[clave] = quien;
  }
  const conAlgo = new Set(Object.values(duenio));
  for(const [clave, pos] of RECORDS_PUESTO){
    const i = filas.findIndex((f, j) => f.puesto === pos && !conAlgo.has(j));
    if(i >= 0){ duenio[clave] = i; conAlgo.add(i); }
  }
  return duenio;
}

function insignias(f, i, records){
  if(!records) return [];
  return TODOS_RECORDS().filter(([clave]) => records[clave] === i)
    .map(([clave, texto]) => [clave === 'goat' ? 'GOAT' : T(texto), clave]);
}
const chipsInsignia = (f, i, records) => insignias(f, i, records)
  .map(([t,c])=>`<span class="rkbadge ${c}">${esc(t)}</span>`).join('');

function rutaTexto(f){
  const ids = String(f.ruta||'').split(',').map(x=>x.trim()).filter(x=>x && C(x));
  if(!ids.length) return '';
  const nombres = ids.map(id=>esc(C(id).n));
  return nombres.length<=4 ? nombres.join(' → ')
    : nombres[0]+' → '+nombres[1]+' → … → '+nombres[nombres.length-1];
}

function vHeroe(f, abierta, records){
  const club = C(f.club);
  return `<div class="rkheroe ${abierta?'abierta':''}" onclick="rkVer(0)">
    <div class="rkh-top">
      <span class="rkh-pos">1</span>
      <div class="rkh-id">
        <b>${esc(f.nombre)}</b>
        <em>${esc(TPais(f.pais))} · ${TP(f.puesto)}${club? ' · '+esc(club.n):''}${intentosTxt(f)}${genTxt(f)}</em>
      </div>
      ${club? crest(club.id,34):''}
    </div>
    <div class="rkh-pts"><b>${f.puntaje}</b><span>${T('puntos de leyenda')}</span></div>
    ${rutaTexto(f)? `<div class="rkh-ruta">${rutaTexto(f)}</div>`:''}
    <div class="rkh-badges">${chipsInsignia(f, 0, records)}</div>
  </div>`;
}
function vMedio(f, i, abierta, records){
  const club = C(f.club);
  return `<div class="rkmedio ${i===1?'plata':'bronce'} ${abierta?'abierta':''}" onclick="rkVer(${i})">
    <span class="rkpos">${i+1}</span>
    <div class="rkm-id">
      <b>${esc(f.nombre)}</b>
      <em>${esc(TPais(f.pais))} · ${TP(f.puesto)}${intentosTxt(f)}${genTxt(f)}</em>
      ${chipsInsignia(f, i, records)}
      <div class="rkm-nums"><span>${f.partidos||0} ${T('PJ')}</span><span>${f.goles||0} ${T('G')}</span>
        <span>${f.asistencias||0} ${T('A')}</span><span>${titulosTotales(f)} ${ICO.titulos}</span></div>
    </div>
    <span class="rkpts">${f.puntaje}</span>
  </div>`;
}
function rutaVitrina(f){
  const ids = String(f.ruta||'').split(',').map(x=>x.trim()).filter(x=>x && C(x));
  if(ids.length < 2) return '';
  return `<div class="rkruta">${ids.map((id,i)=>
    `${i? '<u></u>':''}<span title="${esc(C(id).n)}">${crest(id,20)}</span>`).join('')}</div>`;
}
function genTxt(f){
  return (f.gen|0) > 1 ? ` · <b class="rkgen">${T('Gen {n}', {n:f.gen|0})}</b>` : '';
}
function vFamiliaFila(f){
  if((f.famGens|0) < 2) return '';
  return `<div class="rkfam">👪 ${T('Dinastía {ap}', {ap:esc(apellidoDe(f.nombre))})} · ${T('{n} generaciones', {n:f.famGens|0})} · <b>${f.famPts|0}</b> ${T('puntos de la familia')}</div>`;
}
function titulosTotales(f){
  return (f.ligas||0) + (f.copas||0) + (f.contis||0) + (f.contis2||0)
       + (f.mundiales||0) + (f.contiSel||0);
}
const ICO = {
  titulos:  '🏆',   
  liga:     '🛡️',
  ascenso:  '⬆️',
  copa:     '🏵️',
  conti:    '⭐',
  conti2:   '✨',
  mundial:  '🌍',
  contiSel: '🏅',
  balon:    '🥇',
  bota:     '👟',
  mvpFinal: '🎯',
  mvpMundial:'🎖️'
};

function resumenVitrina(f){
  const partes = [
    [ICO.titulos, titulosTotales(f), ''],
    [ICO.balon,   f.balones||0,      'oro'],
    [ICO.bota,    f.botas||0,        'oro']
  ].filter(x=>x[1]>0);
  return partes.map(([ic,n,cl])=>`<i class="rkt ${cl}">${ic}<b>${n}</b></i>`).join('');
}

const PALM_ICO = { L:ICO.liga, D:ICO.liga, R:ICO.liga, C:ICO.copa,
                   S:ICO.copa, A:ICO.conti, B:ICO.conti2, N:ICO.contiSel };

function palmaresLista(f){
  if(!f.palmares) return '';
  const filas = String(f.palmares).split('|').map(t=>{
    const [tipo, crudo, anios] = t.split('~');
    if(!crudo) return null;
    const m = /^([^\p{L}\p{N}]+)\s*(.+)$/u.exec(crudo);
    const nombre = m ? m[2] : crudo;
    const ic = m ? m[1].trim() : (PALM_ICO[tipo] || ICO.copa);
    const ys = (anios||'').split(',').filter(Boolean);
    return {ic, nombre, ys};
  }).filter(Boolean);
  if(!filas.length) return '';
  return `<div class="rkpalm">${filas.slice(0, 40).map(x=>
    `<div class="rkpalm-f"><i>${esc(x.ic)}</i><b>${esc(TN(x.nombre))}</b>${
      x.ys.length>1? `<u>×${x.ys.length}</u>`:''}<em>${esc(x.ys.join(', '))}</em></div>`
  ).join('')}</div>`;
}

function vVitrina(f, i, records, sinInsignias){
  const palm = palmaresLista(f);
  const CONTADORES = [
    [ICO.liga,     f.ligas,     'liga',                'ligas'],
    [ICO.copa,     f.copas,     'copa nacional',       'copas nacionales'],
    [ICO.conti,    f.contis,    'copa continental',    'copas continentales'],
    [ICO.conti2,   f.contis2,   'segunda continental', 'segundas continentales'],
    [ICO.mundial,  f.mundiales, 'Mundial',             'Mundiales'],
    [ICO.contiSel, f.contiSel,  'copa continental de selecciones', 'copas continentales de selecciones']
  ];
  const INDIVIDUALES = [
    [ICO.balon,    f.balones,   'Balón de Oro',        'Balones de Oro'],
    [ICO.bota,     f.botas,     'Bota de Oro',         'Botas de Oro']
  ];
  const L = (palm? INDIVIDUALES : CONTADORES.concat(INDIVIDUALES)).filter(x=>x[1]>0);
  const club = C(f.club);
  const chips = sinInsignias ? '' : chipsInsignia(f, i, records);
  return `<div class="rkdetalle">
    ${chips? `<div class="rkh-badges">${chips}</div>`:''}
    ${vFamiliaFila(f)}
    <div class="rknums">
      <span><b>${f.goles||0}</b>${T('Goles')}</span>
      <span><b>${f.asistencias||0}</b>${T('Asistencias')}</span>
      <span><b>${f.partidos||0}</b>${T('Partidos')}</span>
      <span><b>${f.temporadas||0}</b>${T('Temporadas')}</span>
      <span><b>${f.mediaMax||0}</b>${T('Media máxima')}</span>
      ${f.edadRetiro? `<span><b>${f.edadRetiro}</b>${T('Se retiró a los')}</span>`:''}
    </div>
    ${rutaVitrina(f)}
    ${palm}
    ${L.length? `<div class="rkvitrina">${L.map(([ic,n,uno,varios])=>
      `<span><i>${ic}</i><b>${n}</b> ${T(n===1?uno:varios)}</span>`).join('')}</div>`
      : (palm? '' : `<p class="rkvacia">${T('Sin títulos. La carrera fue la carrera.')}</p>`)}
    ${club? `<div class="rkclub">${crest(club.id,22)}<span>${T('Se retiró en')} <b>${esc(club.n)}</b></span></div>`:''}
  </div>`;
}
const intentosTxt = f => f.intentos > 1 ? ' · ' + T('{n} carreras', {n:f.intentos}) : '';
function rkVer(i){ S.rkAbierta = S.rkAbierta===i? null : i; pintarTabla(); }

function vTabla(){
  const t = S.tabla;
  let cuerpo;
  if(t.cargando) cuerpo = `<p class="empty">${T('Cargando…')}</p>`;
  else if(!t.filas) cuerpo = `<p class="empty">${T('No se pudo conectar con el ranking. El juego funciona igual.')}</p>`;
  else if(!t.filas.length) cuerpo = `<p class="empty">${t.modo==='historico'
      ? T('Todavía no hay ninguna carrera en la tabla. La primera puede ser la tuya.')
      : t.modo==='anterior' ? T('Nadie mandó su carrera en el reto de la semana pasada.')
      : T('Nadie mandó todavía su carrera de esta semana. La primera puede ser la tuya.')}</p>`;
  else cuerpo = `<div class="rktabla">${(()=>{
    const records = recordsDeTabla(t.filas);
    return t.filas.map((f,i)=>{
      const abierta = S.rkAbierta===i;
      if(i===0) return `<div class="rkfila">${vHeroe(f, abierta, records)}${
        abierta? vVitrina(f, i, records, true) : ''}</div>`;
      if(i<3)   return `<div class="rkfila">${vMedio(f, i, abierta, records)}${
        abierta? vVitrina(f, i, records) : ''}</div>`;
      return `<div class="rkfila">
      <div class="rkrow ${abierta?'abierta':''}" onclick="rkVer(${i})">
        <span class="rkpos">${i+1}</span>
        <span class="rkname"><b>${esc(f.nombre)}</b><em>${esc(TPais(f.pais))} · ${TP(f.puesto)}${intentosTxt(f)}${genTxt(f)}</em>
          ${
            chipsInsignia(f, i, records)}</span>
        <span class="rktrofeos">${resumenVitrina(f)}</span>
        <span class="rkpts">${f.puntaje}</span>
      </div>
      ${abierta? vVitrina(f, i, records) : ''}</div>`;
    }).join('');
  })()}</div>
    ${t.modo!=='historico' && t.total ? `<p class="rknota">${t.total === 1 ? T(t.modo==='anterior' ? 'Una sola carrera en el reto de la semana pasada.' : 'Una sola carrera en el reto de esta semana, por ahora.')
      : t.total===1 ? T(t.modo==='anterior' ? 'Una carrera en el reto de la semana pasada.' : 'Una carrera en el reto de esta semana.')
      : T(t.modo==='anterior' ? '{n} carreras en el reto de la semana pasada.' : '{n} carreras en el reto de esta semana.', {n:t.total})}</p>` : ''}
    ${t.modo==='historico' ? `<p class="rknota">${T('Cada nombre aparece una vez, con su mejor carrera.')}</p>` : ''}
    <p class="rknota">${T('Cada carrera de la tabla la volvió a jugar el servidor para comprobar el puntaje. Es una tabla pública: el nombre que elegiste, tu país, tu puntuación y el resumen de la carrera.')}</p>`;
  const reto = t.modo !== 'historico';
  const nSemana = id => id ? id % 100 : '';
  const pestanas = reto && S.reto ? `<div class="rktabs">${[
      ['reto', T('Semana {n} · en curso', {n:S.reto.numero})],
      ['anterior', T('Semana {n} · cerrada', {n:nSemana(S.reto.anterior)})]
    ].map(([m, n])=>`<button class="${t.modo===m?'on':''}" onclick="abrirTabla('${m}')">${n}</button>`).join('')}</div>` : '';
  return `<div class="sheet-bg rk-bg" onclick="cerrarTabla()"></div>
    <div class="sheet rk-hoja"><div class="grab"></div>
      <h3>${reto ? '🗓 ' + T('Ranking del reto semanal') : T('Ranking mundial')}<button onclick="cerrarTabla()">×</button></h3>${pestanas}${cuerpo}</div>`;
}

function linajeDeEnvio(){
  if(!S.p) return undefined;
  if(!S.p.linajeId){ S.p.linajeId = (S.p.linaje && S.p.linaje.id) || nuevoLinajeId(); try{ Store.save(); }catch(e){} }
  return S.p.linajeId;
}
function nombreParaTabla(n){
  n = (n||'').trim().replace(/\s+/g, ' ');
  if([...n].length <= 24) return n;
  const t = n.split(' ');
  const corto = t.length > 2 ? t[0] + ' ' + t[t.length-1] : n;
  return [...corto].slice(0, 24).join('').trim();
}
async function enviarAlRanking(){
  const inp = $('rk_nombre');
  const nombre = (inp? inp.value : nombreParaTabla(S.p.name)).trim();
  if(nombre.length < 2){ S.envio = {estado:'error', msg:'Poné un nombre de al menos dos letras.', nombre}; render(); return; }
  S.envio = {estado:'yendo', nombre}; render();
  const r = await rankPedir('/enviar', {
    method:'POST', headers:{'content-type':'application/json'},
    body: JSON.stringify({nombre, puntaje: legendScore(S.p), registro: S.reg, llave: llaveNombre(),
      linaje: (S.reg && S.reg.reto) ? undefined : linajeDeEnvio()})
  });
  S.envio = r.ok ? {estado:'listo', puesto:r.puesto, puntaje:r.puntaje, reto:r.reto||0, total:r.total||0,
                    nombre, mejor:r.superada? r.mejor : 0}
                 : {estado:'error', msg:r.error || 'no se pudo', nombre};
  if(r.ok && r.reto && S.reto && r.reto === S.reto.semana) retoGuardar({puesto:r.puesto, total:r.total, puntaje:r.puntaje});
  medir('ranking_submit', r.ok ? {result:'ok', rank:r.puesto, weekly:!!r.reto} : {result:'rejected', weekly:!!(S.reg && S.reg.reto)});
  render();
}

function motivoNoRankeable(){
  if(!S.reg) return 'Esta carrera empezó antes de que existiera el ranking.';
  if(S.reg.propia) return 'Esta carrera empezó sin conexión, así que el servidor no puede comprobarla.';
  if(S.reg.practica) return 'Ya habías jugado el reto de esta semana: esta vuelta fue de práctica y no entra en la tabla.';
  return null;
}

const esc = s => String(s==null?'':s).replace(/[&<>"]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const barColor = v => v>=88?'var(--elite)':v>=78?'var(--great)':v>=66?'var(--good)':v>=52?'var(--ok)':'var(--low)';
function money(v){
  if(v>=10) return `US$${Math.round(v)}M`;
  if(v>=1)  return `US$${v.toFixed(1)}M`;
  return `US$${Math.round(v*1000)}K`;
}
const chip = (t,c='') => `<span class="chip ${c}">${t}</span>`;
const statBox = (l,v) => `<div class="sbox"><b>${v}</b><span>${l}</span></div>`;
function meter(l,v){ return `<div class="meter"><span>${l}</span><i><u style="width:${v}%;background:${barColor(v)}"></u></i><b>${v}</b></div>`; }
function attrBar(k,n,v,band,clave){
  const lo=Math.max(band.lo,v), hi=Math.max(band.hi,lo+1);
  return `<div class="attr ${clave?'clave':''}"><span class="attr-n">${n}</span><span class="attr-v" style="color:${barColor(v)}">${v}</span>
    <span class="bar"><i style="width:${v}%;background:${barColor(v)}"></i>
      <u style="width:${clamp(lo-v,0,99)}%"></u><o style="width:${clamp(hi-lo,0,99)}%"></o></span></div>`;
}
function ligaTxt(club, conPais){
  const lg = L(club.lg);
  if(!enSegunda(club)) return TN(lg.n);
  return T('Segunda división') + (conPais? ' · ' + TPais(lg.pais) : '');
}
function clubAccent(id){
  try{
    const [,c1,c2] = kitOf(id);
    const sat = h => { const m=/^#?([0-9a-f]{6})$/i.exec(h||''); if(!m) return -1;
      const n=parseInt(m[1],16), r=(n>>16&255)/255, g=(n>>8&255)/255, b=(n&255)/255;
      const mx=Math.max(r,g,b), mn=Math.min(r,g,b), l=(mx+mn)/2;
      return (mx===mn || l<0.16 || l>0.9) ? -1 : (mx-mn)/(1-Math.abs(2*l-1)); };
    const best = [c1,c2].sort((a,b)=>sat(b)-sat(a))[0];
    return sat(best) > 0.2 ? best : 'var(--line2)';
  }catch(e){ return 'var(--line2)'; }
}
function pitchTxt(o){
  if(!o.pv) return T(o.pitch);
  if(/ya ganaste todo/.test(o.pitch) && S.p){
    const cur = C(S.p.club);
    const gano = (S.p.honours||[]).some(h=>cur && h.club===cur.n && h.tipo!=='individual' && h.tipo!=='seleccion');
    if(!gano) return T('«El técnico te pidió personalmente.»');
  }
  const v = {...o.pv};
  if(v.copa) v.copa = TN(v.copa);
  if(v.pos){ v.puesto = TP(v.pos).toLowerCase(); delete v.pos; }
  return T(o.pitch, v);
}
const stars = n => `<span class="stars">${'★'.repeat(n)}${'☆'.repeat(5-n)}</span>`;
function TFX(l){
  if(!TR) return l;
  const m=l.match(/^(.+?) ([+-]?\d+)$/);
  if(m) return T(m[1])+' '+m[2];
  const c=l.match(/^Contrato: (\d+) años$/);
  if(c) return T(c[1]==='1' ? 'Contrato: {n} año' : 'Contrato: {n} años', {n:c[1]});
  const t=l.match(/^Rasgo nuevo: (.+)$/); if(t) return T('Rasgo nuevo: {x}', {x:T(t[1])});
  const p=l.match(/^Nueva posición: (.+)$/); if(p) return T('Nueva posición: {x}', {x:T(p[1])});
  const b=l.match(/^(.+) → segunda división$/); if(b) return T('{club} → segunda división', {club:b[1]});
  return T(l);
}
function pickLang(l){
  if(l === LANG) return;
  const aMedias = S.p && CHROME.includes(S.phase) && S.phase !== 'pretemporada';
  if(aMedias && !(S.langAviso && S.langAviso.l === l && Date.now() - S.langAviso.t < 6000)){
    S.langAviso = {l, t:Date.now()};
    toast(T('Cambiar de idioma recarga el juego y te devuelve al arranque de esta temporada. Tocá otra vez para cambiar.'), 4500);
    return;
  }
  try{ localStorage.setItem('mfc_lang', l); }catch(e){}
  location.assign(rutaDe(l) + location.hash);
}
const langBtn = () => `<span class="langsw">${['es','en','pt','fa'].map(l=>
  `<button class="${LANG===l?'on':''}" onclick="pickLang('${l}')">${l.toUpperCase()}</button>`).join('')}</span>`;
const menuBtn = () => `<button class="salirtop" onclick="irAlMenu()"
  title="${T('Volver al menú principal')}" aria-label="${T('Volver al menú principal')}"
  ><span class="sfl">←</span><span class="stx">${T('Menú')}</span></button>`;

const SCREENS = { intro:vIntro, create:vCreate, draft:vDraft, inicio:vInicio,
  pretemporada:vPre, evento:vEvento, sim:vSim, invierno:vInvierno,
  resultado:vResultado, seleccion:vSeleccion, mundo:vMundo, mercado:vMercado, fin:vFin,
  diario:vDiario };
const CHROME = ['pretemporada','evento','sim','diario','invierno','resultado','seleccion','mundo','mercado'];

let _scrollPend = null;
function desplazar(top){
  const nuevo = !_scrollPend;
  _scrollPend = {top};
  if(!nuevo) return;
  const aplicar = () => { const p = _scrollPend; _scrollPend = null;
    if(p && window.scrollY !== p.top) window.scrollTo({top:p.top, behavior:'instant'}); };
  if(typeof requestAnimationFrame === 'function') requestAnimationFrame(aplicar); else aplicar();
}
let _barraH = null, _barraRO = null, _barraObs = null;
function ponerBarraH(h){
  if(h === _barraH) return;
  _barraH = h;
  document.documentElement.style.setProperty('--topbar-h', h + 'px');
}
function medirBarra(barra){
  if(!barra){ if(_barraRO && _barraObs){ _barraRO.disconnect(); _barraObs = null; } ponerBarraH(0); return; }
  if(typeof ResizeObserver !== 'function'){ ponerBarraH(barra.offsetHeight); return; }
  if(!_barraRO) _barraRO = new ResizeObserver(es => {
    for(const e of es){ const b = e.borderBoxSize && e.borderBoxSize[0];
      ponerBarraH(Math.round(b ? b.blockSize : e.target.getBoundingClientRect().height)); }
  });
  if(_barraObs === barra) return;
  _barraRO.disconnect(); _barraRO.observe(barra); _barraObs = barra;
}
let _lastPhase = null;
let _ultimoRender = 0;
const TOQUE_FANTASMA = 350;
document.addEventListener('click', e => {
  if(!e.isTrusted || Date.now() - _ultimoRender > TOQUE_FANTASMA) return;
  const b = e.target && e.target.closest && e.target.closest('.choice, .big');
  if(b){ e.preventDefault(); e.stopPropagation(); }
}, true);
function sinReto(t){ return t.replace(/<!--reto-->[\s\S]*?<!--\/reto-->/, '<!--reto-->'); }
function huellaTexto(t){
  let h = 0x811c9dc5;
  for(let i = 0; i < t.length; i++){ h ^= t.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; }
  return h.toString(16);
}
function render(){
  const withChrome = S.p && CHROME.includes(S.phase);
  const nueva = S.phase !== _lastPhase;
  const y = (nueva || _scrollPend) ? 0 : window.scrollY;

  const htmlApp = (withChrome? vTop() : '') + SCREENS[S.phase]() + (withChrome? vNav() : '') + vSheet();
  const app = $('app');
  window.ULTIMO_HTML_APP = htmlApp;
  if(app.dataset.pre && app.dataset.pre === huellaTexto(sinReto(htmlApp))) pintarReto();
  else { app.innerHTML = htmlApp; _ultimoRender = Date.now(); }
  delete app.dataset.pre;
  $('app').classList.toggle('con-nav', withChrome);
  document.body.classList.toggle('jugando', S.phase !== 'intro');

  medirBarra(document.querySelector('.topbar'));

  if(nueva){
    _lastPhase = S.phase;
    desplazar(0);
    requestAnimationFrame(()=>document.querySelectorAll('.anim')
      .forEach((e,i)=>setTimeout(()=>e.classList.add('in'), i*50)));
  } else {
    document.querySelectorAll('.anim').forEach(e=>{ e.style.transition='none'; e.classList.add('in'); });
    if(!_scrollPend) desplazar(y);
  }
  if(S.phase==='sim') startTicker();
}

function medir(nombre, datos){
  try{ if(window.MFC_GA && typeof gtag === 'function') gtag('event', nombre, datos || {}); }catch(e){}
}
function finDeCarreraMedido(p){
  try{
    const pts = legendScore(p), tier = legendTier(pts);
    medir('career_end', {verdict: tier && tier.t, score: pts, seasons: p.career.seasons,
      position: p.pos, retire_reason: p.retireReason || 'auto'});
  }catch(e){}
}
function avisoCookies(){
  if(!window.MFC_GA || !window.mfcConsentPendiente || !mfcConsentPendiente()) return '';
  return `<div class="aviso-cookies anim">
    <p>${T('Usamos Google Analytics, con cookies, para contar visitas y ver qué partes del juego se juegan. Podés aceptarlo o rechazarlo.')}
      <a href="${{en:'/privacy/', es:'/es/privacidad/', pt:'/pt/privacidade/'}[LANG]}">${T('Leé la política de privacidad')}</a></p>
    <div class="aviso-botones">
      <button class="ghost" onclick="window.mfcConsent&&mfcConsent(false)">${T('Rechazar')}</button>
      <button class="ghost si" onclick="window.mfcConsent&&mfcConsent(true)">${T('Aceptar')}</button>
    </div></div>`;
}

function vIntro(){
  const sv = Store.load();
  return `<div class="intro">
    <div class="hero">
      <div class="floods"><i></i><i></i><i></i><i></i></div>
      <div class="hero-crest">${crestHero()}</div>
    </div>
    <h2 class="title"><span class="t1">MY FOOTBALL</span><span class="t2">CAREER</span></h2>
    <p class="sub">${T('Simulador de carrera futbolística')}</p>
    <div class="hero-stats">
      <span><b>${CLUBS.length}</b>${T('clubes reales')}</span>
      <span><b>${LEAGUES.length}</b>${T('ligas del mundo')}</span>
    </div>
    <p class="blurb">${T('No jugás los partidos. Tomás las decisiones que deciden quién terminás siendo: el pibe que se quemó a los veinte, el ídolo de una tribuna, o el nombre que se discute para siempre.')}</p>
    <p class="dif-lbl">${T('Elegí a qué ritmo lo querés vivir')}</p>
    <div class="dif-row">
      ${['rapida','normal','intensa'].map(v=>`<button class="dif ${S.vel===v?'sel':''}" data-vel="${v}" onclick="setVel('${v}')">
        <b>${T({rapida:'⚡ Express',normal:'⚽ Estándar',intensa:'🧠 Inmersivo'}[v])}</b>
        <span>${T({rapida:'El año en un bloque, sin pausas ni diario',normal:'Dos mitades y el ritmo clásico',intensa:'Partido a partido, sin apuro, con el diario entero'}[v])}</span></button>`).join('')}
    </div>
    <p class="dif-pie">${T('Las mismas decisiones y las mismas reglas en los tres: lo que cambia es cuánto se detiene la pantalla. Una sola tabla para todos.')}</p>
    <button class="big" onclick="goCreate()">${T('Empezar una carrera')}</button>
    <!--reto--><div id="reto-slot" class="${claseSlotReto()}">${vRetoCard()}</div><!--/reto-->
    ${saveUtil(sv)? `<button class="ghost" onclick="continueSave()">${T('Continuar')} — ${esc(sv.p.name)}, ${(S.volver? S.volver.p : sv.p).age} ${T('años')}</button>
    ${sv.phase !== 'fin' && !S.volver && Store.aMedias()
      ? `<p class="dif-pie">${T('Al continuar volvés al arranque de la temporada: la carrera se guarda decisión por decisión, no partido por partido.')}</p>`
      : ''}`:''}
    ${!saveUtil(sv) && herenciaLeer() ? (h => `<button class="ghost" onclick="retomarDinastia()">👪 ${T('Seguir la dinastía {ap}', {ap:esc(h.linaje.apellido)})} · ${T('Generación {n}', {n:h.gen})}</button>`)(herenciaLeer()) : ''}
    <button class="ghost" onclick="abrirTabla()">🌍 ${T('Ranking mundial')}</button>
    ${langBtn()}
    ${avisoCookies()}
  </div>`;
}
function crestHero(){
  return `<svg viewBox="0 0 100 116" width="104" height="120" aria-hidden="true">
    <defs><linearGradient id="hg" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#1D2A24"/><stop offset="1" stop-color="#0C1411"/></linearGradient></defs>
    <path d="M6 6H94V64C94 88 76 103 50 111C24 103 6 88 6 64Z" fill="url(#hg)" stroke="var(--gold)" stroke-width="3.5"/>
    <text x="50" y="74" text-anchor="middle" font-size="42" font-weight="900"
      fill="var(--gold)" font-family="Inter,Arial" letter-spacing="-2">10</text>
  </svg>`;
}

const PITCH = [
  {k:'DC',  x:50, y:10},
  {k:'EXT', x:15, y:27}, {k:'MCO', x:50, y:27}, {k:'EXT', x:85, y:27},
  {k:'MC',  x:35, y:48}, {k:'MC',  x:65, y:48},
  {k:'MCD', x:50, y:63},
  {k:'LAT', x:13, y:80}, {k:'DFC', x:38, y:80}, {k:'DFC', x:62, y:80}, {k:'LAT', x:87, y:80}
];
function vPitch(){
  return `<div class="pitch" id="pitch">
    <div class="pitch-lines"></div>
    ${PITCH.map((s,i)=>`<button type="button" class="ppos" data-pk="${s.k}"
        style="left:${s.x}%;top:${s.y}%" onclick="pickPos('${s.k}')">${TPOS(s.k)}</button>`).join('')}
  </div>`;
}
function pickPos(k){
  S.posPick = k;
  const sel = $('f_pos'); if(sel) sel.value = k;
  document.querySelectorAll('.ppos').forEach(el=>el.classList.toggle('sel', el.dataset.pk===k));
  const info = $('posinfo');
  if(info){
    const P = POSITIONS[k];
    const claves = ATTRS.slice().sort((a,b)=>(P.w[b.k]||0)-(P.w[a.k]||0)).slice(0,3).map(a=>TA(a.k));
    info.innerHTML = `<b>${T(P.n)}</b> · ${T('se juzga por')} ${claves.join(', ')}`;
  }
}

function setVel(v){
  S.vel = v;
  try{ localStorage.setItem('mfc_vel', v); }catch(e){}
  document.querySelectorAll('.dif').forEach(el=>el.classList.toggle('sel', el.dataset.vel===v));
}
function goCreate(){ S.enReto = null; S.volver = null; S.herencia = null; abrirCreacion(); }
function abrirCreacion(){ S.phase='create'; render(); if(!S.enReto) pickPos(S.posPick || 'DC'); }

function vCreateReto(){
  const r = S.enReto.info, nac = NATIONS.find(n=>n.n===r.nat);
  return `<div class="pane">
    <h2 class="h2 anim">${T('Reto de la semana')} · ${T('Semana {n}', {n:r.numero})}</h2>
    <p class="lead anim">${S.enReto.practica
      ? T('Ya jugaste la vuelta que cuenta. Ésta es de práctica: se juega igual, pero no entra en la tabla.')
      : T('El jugador es el mismo para todo el mundo. Vos sólo le ponés el nombre: el resto lo deciden tus decisiones.')}</p>
    <div class="card reto-ficha anim">
      <span>${T('Nacionalidad')}<b>${nac? nac.f : ''} ${esc(TPais(r.nat))}</b></span>
      <span>${T('Posición')}<b>${esc(TP(r.pos))}</b></span>
      <span>${T('Pie hábil')}<b>${T(r.foot)}</b></span>
      <span>${T('Dorsal')}<b>#${r.num}</b></span>
    </div>
    <div class="form anim">
      <label>${T('Nombre')} <input id="f_name" maxlength="26" placeholder="${T('Ej: Julián Ferreyra')}"
        value="${esc(S.nombre||'')}" oninput="tecleaNombre(this.value)"></label>
    </div>
    <button class="big arriba anim ${(S.nombre||'').trim()?'':'off'}" id="bnombre"
      onclick="goDraft()">${T('Siguiente: Draft de Leyendas')}</button>
    <p class="avisonombre ${(S.nombre||'').trim()?'ok':''}">${T('Ponele un nombre: va a aparecer en los titulares de toda tu carrera.')}</p>
    <button class="ghost" onclick="S.enReto=null;S.phase='intro';render()">${T('Volver')}</button>
  </div>`;
}
function vCreate(){
  if(S.enReto) return vCreateReto();
  if(S.herencia) return vCreateHeredero();
  return `<div class="pane">
    <h2 class="h2 anim">${T('Tu jugador')}</h2>
    <p class="lead anim">${T('Los datos básicos. Lo importante viene después.')}</p>
    <div class="pitchwrap anim">
      <span class="campo-lbl">${T('Posición')}</span>
      ${vPitch()}
      <p class="pos-info" id="posinfo"></p>
    </div>
    <div class="form anim">
      <label>${T('Nombre')} <input id="f_name" maxlength="26" placeholder="${T('Ej: Julián Ferreyra')}"
        value="${esc(S.nombre||'')}" oninput="tecleaNombre(this.value)"></label>
      <label>${T('Nacionalidad')} <select id="f_nat">${NATIONS.slice().sort((a,b)=>TPais(a.n).localeCompare(TPais(b.n))).map(n=>`<option value="${n.n}">${n.f} ${esc(TPais(n.n))}</option>`).join('')}</select></label>
      <select id="f_pos" class="oculto" aria-hidden="true">${Object.entries(POSITIONS).map(([k,v])=>`<option value="${k}">${T(v.n)} (${TPOS(k)})</option>`).join('')}</select>
      <label>${T('Dorsal')} <input id="f_num" type="number" min="1" max="99" value="10"></label>
      <label>${T('Pie hábil')} <select id="f_foot"><option>${T('Derecha')}</option><option>${T('Izquierda')}</option></select></label>
    </div>
    <button class="big arriba anim ${(S.nombre||'').trim()?'':'off'}" id="bnombre"
      onclick="goDraft()">${T('Siguiente: Draft de Leyendas')}</button>
    <p class="avisonombre ${(S.nombre||'').trim()?'ok':''}">${T('Ponele un nombre: va a aparecer en los titulares de toda tu carrera.')}</p>
    <button class="ghost" onclick="S.phase='intro';render()">${T('Volver')}</button>
  </div>`;
}

function tecleaNombre(v){
  S.nombre = v;
  const b = $('bnombre'); if(b) b.classList.toggle('off', !v.trim());
  const a = document.querySelector('.avisonombre'); if(a) a.classList.toggle('ok', !!v.trim());
}
function apellidoDe(nombre){
  const t = (nombre||'').trim().split(/\s+/).filter(Boolean);
  return t.length > 1 ? t[t.length-1] : (t[0] || '');
}
function nombreConApellido(nombre, apellido){
  const n = (nombre||'').trim();
  if(!apellido) return n;
  return n.toLowerCase().endsWith(apellido.toLowerCase()) ? n : (n + ' ' + apellido).slice(0, 40);
}
function clubIdoloDe(p){
  const n = {};
  (p.seasons||[]).forEach(x => { if(x.clubId) n[x.clubId] = (n[x.clubId]||0) + 1; });
  const ids = Object.keys(n).filter(id => C(id));
  return ids.length ? ids.sort((a,b) => n[b]-n[a])[0] : p.club;
}
function generacionDe(p){
  const pts = legendScore(p), tier = legendTier(pts);
  const ss = p.seasons || [];
  return {name:p.name, nat:p.nat, pos:p.pos, score:pts, tier:tier ? tier.t : '',
    club:clubIdoloDe(p), traits:(p.traits||[]).filter(t => HEREDABLES.includes(t)),
    desde: ss.length ? ss[0].year : p.year, hasta: ss.length ? ss[ss.length-1].year : p.year,
    goles: p.career ? p.career.goals : 0, pico: p.peakOvr || p.ovr || 0,
    gen: p.dinastia ? p.dinastia.gen : 1};
}
function nuevoLinajeId(){
  try{
    const a = new Uint8Array(8); crypto.getRandomValues(a);
    return [...a].map(x => x.toString(16).padStart(2,'0')).join('');
  }catch(e){
    let t = ''; for(let i=0;i<16;i++) t += Math.floor(Math.random()*16).toString(16);
    return t;
  }
}
function puedeSeguirDinastia(p){
  return !!p && (p.dinastia ? p.dinastia.gen : 1) < DINASTIA_MAX_GEN;
}
function sinMandarAlRanking(){
  return !!S.p && !motivoNoRankeable() && !(S.envio && S.envio.estado === 'listo');
}
function anioDelHijo(y){
  const a = y + (((ANIO_BASE - y) % 4) + 4) % 4;
  return anioValido(a) ? a : ANIO_BASE;
}
function seguirDinastia(){
  const p = S.p;
  if(!puedeSeguirDinastia(p)) return;
  if(sinMandarAlRanking() && !S.dynAviso){
    S.dynAviso = true; render();
    const rk = document.querySelector('.rank-fin');
    if(rk && rk.scrollIntoView) rk.scrollIntoView({block:'center', behavior:'smooth'});
    return;
  }
  S.dynAviso = false;
  const yo = generacionDe(p);
  if(!p.linajeId) p.linajeId = (p.linaje && p.linaje.id) || nuevoLinajeId();
  const linaje = p.linaje
    ? {apellido:p.linaje.apellido, id:p.linajeId, gens:p.linaje.gens.concat([yo])}
    : {apellido:apellidoDe(p.name), id:p.linajeId, gens:[yo]};
  const enTabla = !!(S.envio && S.envio.estado === 'listo' && !S.envio.reto);
  S.herencia = {linaje, padre:yo, gen:linaje.gens.length + 1,
    fama: enTabla ? famaDe(yo.score) : 0, famaPerdida: enTabla ? 0 : famaDe(yo.score),
    club:yo.club, rasgo: yo.traits.length === 1 ? yo.traits[0] : null,
    anio: anioDelHijo(p.year), v:29};
  herenciaGuardar(S.herencia);
  Store.clear();
  S.p = null; S.reg = null; S.envio = null; S.sheet = null; S.tabla = null;
  S.nombre = ''; S.draftPicks = []; S.enReto = null;
  S.posPick = yo.pos;
  window.scrollTo(0, 0);
  abrirCreacion();
}
const HERENCIA_KEY = SAVE_KEY + '_herencia';
function herenciaGuardar(h){ try{ if(Store.ok && h) localStorage.setItem(HERENCIA_KEY, JSON.stringify(h)); }catch(e){} }
function herenciaOlvidar(){ try{ if(Store.ok) localStorage.removeItem(HERENCIA_KEY); }catch(e){} }
function herenciaLeer(){
  try{
    const h = Store.ok && JSON.parse(localStorage.getItem(HERENCIA_KEY));
    if(!h || !h.linaje || !Array.isArray(h.linaje.gens) || !h.linaje.gens.length || !h.padre
       || !h.padre.name || !Number.isInteger(h.gen) || h.gen < 2 || h.gen > DINASTIA_MAX_GEN || !C(h.club)) return null;
    if(h.rasgo && !HEREDABLES.includes(h.rasgo)) h.rasgo = null;
    if(!Array.isArray(h.padre.traits)) h.padre.traits = [];
    if(h.v !== 29){ h.fama = 0; h.famaPerdida = 0; delete h.anio; h.v = 29; }
    if(!Number.isInteger(h.fama) || h.fama < 0 || h.fama > 3) h.fama = 0;
    if(h.anio !== undefined && !anioValido(h.anio)) delete h.anio;
    return h;
  }catch(e){ return null; }
}
function retomarDinastia(){
  const h = herenciaLeer(); if(!h) { render(); return; }
  S.herencia = h; S.enReto = null; S.nombre = ''; S.draftPicks = [];
  S.posPick = h.padre.pos || S.posPick;
  window.scrollTo(0, 0);
  abrirCreacion();
}
function herenciaArranque(){
  const h = S.herencia;
  if(!h || S.enReto || !h.rasgo) return null;
  const r = {gen:h.gen, rasgo:h.rasgo, fama:h.fama, club:h.club};
  if(anioValido(h.anio)) r.anio = h.anio;
  return r;
}
function vCreateHeredero(){
  const h = S.herencia, nac = NATIONS.find(n=>n.n===h.padre.nat);
  return `<div class="pane">
    <span class="tagline anim">${T('Dinastía {ap}', {ap:esc(h.linaje.apellido)})} · ${T('Generación {n}', {n:h.gen})}</span>
    <h2 class="h2 anim">${T('Tu hijo')}</h2>
    <p class="lead anim">${T('Hijo de {padre}, {tier}. El apellido entra a la cancha antes que vos.',
      {padre:'<b>'+esc(h.padre.name)+'</b>', tier:esc(T(h.padre.tier))})}</p>
    ${vFamaApellido(h)}
    <div class="pitchwrap anim">
      <span class="campo-lbl">${T('Posición')}</span>
      ${vPitch()}
      <p class="pos-info" id="posinfo"></p>
    </div>
    <div class="form anim">
      <label>${T('Nombre')} <input id="f_name" maxlength="26" placeholder="${T('Ej: Julián')}"
        value="${esc(S.nombre||'')}" oninput="tecleaNombre(this.value)"></label>
      <label>${T('Nacionalidad')} <select id="f_nat" disabled><option value="${esc(h.padre.nat)}">${nac?nac.f:''} ${esc(TPais(h.padre.nat))}</option></select></label>
      <select id="f_pos" class="oculto" aria-hidden="true">${Object.entries(POSITIONS).map(([k,v])=>`<option value="${k}">${T(v.n)} (${TPOS(k)})</option>`).join('')}</select>
      <label>${T('Dorsal')} <input id="f_num" type="number" min="1" max="99" value="10"></label>
      <label>${T('Pie hábil')} <select id="f_foot"><option>${T('Derecha')}</option><option>${T('Izquierda')}</option></select></label>
    </div>
    <button class="big arriba anim ${(S.nombre||'').trim()?'':'off'}" id="bnombre"
      onclick="goDraft()">${T('Siguiente: la herencia y el draft')}</button>
    <p class="avisonombre ${(S.nombre||'').trim()?'ok':''}">${T('El apellido ya lo tenés: {ap}. Falta el nombre.', {ap:esc(h.linaje.apellido)})}</p>
    ${''}
    <button class="ghost" onclick="S.herencia=null;S.phase='intro';render()">${T('Volver')}</button>
  </div>`;
}
function vFamaApellido(h){
  if(h.fama > 0) return `<p class="dyn-fama anim">${T('El peso del apellido')}: <b class="gold">${'★'.repeat(h.fama)}${'☆'.repeat(3-h.fama)}</b> · ${T('un techo un poco más alto en todo y más prensa desde el primer día.')}</p>`;
  if(h.famaPerdida > 0) return `<p class="dyn-fama anim">${T('La carrera de tu viejo no está en el ranking, así que el apellido no pesa: arrancás sin la fama de la familia.')}</p>`;
  return '';
}
function vHerenciaRasgo(h){
  const opciones = h.padre.traits.length ? h.padre.traits : LEGENDS.map(l => l.trait);
  return `<div class="herencia anim">
    <span class="tagline">${T('Lo que heredás de tu viejo')}</span>
    <p class="lead">${T('Elegí un rasgo de {padre}. Lo traés de nacimiento, y por eso robás una sola leyenda.', {padre:esc(h.padre.name)})}</p>
    <div class="hrasgos">${opciones.map(t => `<button class="hrasgo ${h.rasgo===t?'sel':''}" onclick="pickRasgo('${t}')">
      <b>${T(TRAITS[t].n)}</b>${(lh => lh ? `<em class="hboost">+${lh.boost} ${TA(lh.attr)}</em>` : '')(leyendaDeRasgo(t))}<span>${T(TRAITS[t].d)}</span></button>`).join('')}</div>
  </div>`;
}
function pickRasgo(t){
  if(!S.herencia || !HEREDABLES.includes(t)) return;
  S.herencia.rasgo = t;
  S.draftPicks = S.draftPicks.filter(id => (LEGENDS.find(l => l.id === id) || {}).trait !== t);
  render();
}
function vDinastia(p){
  const yo = generacionDe(p);
  const gens = (p.linaje ? p.linaje.gens : []).concat([yo]);
  const total = gens.reduce((a, g) => a + (g.score || 0), 0);
  const pierde = sinMandarAlRanking();
  const seguir = puedeSeguirDinastia(p)
    ? (pierde ? `<p class="rk-fine dyn-aviso">${T('Antes de seguir, mandá esta carrera al ranking: cuando empiece tu hijo ya no se va a poder mandar, la familia no la va a sumar en la tabla y tu hijo no va a cargar con la fama del apellido.')}</p>` : '')
      + `<button class="ghost dyn-seguir" onclick="seguirDinastia()">${T(pierde && S.dynAviso ? 'Seguir sin mandarla' : 'Seguir la dinastía con tu hijo')}</button>` : '';
  if(gens.length < 2) return `<div class="card dinastia anim">
      <span class="tagline">${T('Dinastía')}</span>
      <p class="narr">${T('Tu carrera terminó, tu apellido no. Tu hijo arranca con un rasgo tuyo, tu club esperándolo y la prensa comparándolo con vos.')}</p>
      ${seguir}</div>`;
  return `<div class="card dinastia anim">
    <span class="tagline">${T('Dinastía {ap}', {ap:esc(p.linaje.apellido)})} · ${T('{n} generaciones', {n:gens.length})}</span>
    <div class="dyn-gens">${gens.map((g, i) => `<div class="dyn-g ${i===gens.length-1?'yo':''}">
      <i>${i+1}</i><span><b>${esc(g.name)}</b><em>${g.desde}–${g.hasta} · ${esc(T(g.tier))}</em></span><u>${g.score}</u></div>`).join('')}</div>
    <div class="dyn-total"><span>${T('Puntos de la familia')}</span><b>${total}</b></div>
    ${seguir}</div>`;
}

let _pending = null;
function goDraft(){
  if(!(S.nombre||'').trim()) return;      
  const r = S.enReto && S.enReto.info;
  _pending = r ? { name:(S.nombre||'').trim(), nat:r.nat, pos:r.pos, num:r.num, foot:r.foot }
    : { name:(S.nombre||'').trim(), nat:$('f_nat').value,
    pos:$('f_pos').value, num:+$('f_num').value||10, foot:$('f_foot').value };
  if(!r && S.herencia){
    _pending.name = nombreConApellido(_pending.name, S.herencia.linaje.apellido);
    _pending.nat = S.herencia.padre.nat;
  }
  S.draftPicks=[]; S.phase='draft'; render();
}
const DRAFT_N = () => (S.herencia && !S.enReto) ? 1 : 2;
function vDraft(){
  const n = DRAFT_N();
  const her = (S.herencia && !S.enReto) ? S.herencia : null;
  return `<div class="pane">
    ${her ? vHerenciaRasgo(her) : ''}
    <h2 class="h2 anim">${T('Draft de Leyendas')}</h2>
    <p class="lead anim">${T('Ocho maneras de ser inolvidable. De cada una robás <b>una sola cosa</b>. Elegí <b>{n}</b>. Lo que no elijas no lo vas a tener nunca.',{n})}</p>
    <div class="legends">
      ${LEGENDS.map(l=>{
        const sel = S.draftPicks.includes(l.id);
        const an = TA(l.attr);
        const repite = her && her.rasgo === l.trait;
        return `<button class="legend anim ${sel?'sel':''} ${repite?'repite':''}" data-lg="${l.id}" ${repite?'disabled':''} onclick="pickLegend('${l.id}')">
          <div class="lg-top"><span class="lg-flag">${l.ic}</span><span class="lg-pos">${TPOS(l.pos)}</span></div>
          <h3>${esc(T(l.n))}</h3><span class="lg-era">${esc(T(l.sub))}</span>
          <p>${esc(T(l.desc))}</p>
          <div class="lg-steal"><b>+${l.boost} ${an}</b><span>${T(TRAITS[l.trait].n)}</span></div>
          <div class="lg-trait">${T(TRAITS[l.trait].d)}</div></button>`;
      }).join('')}
    </div>
    <div class="draft-bar"><span>${S.draftPicks.length} / ${n} ${T('elegidos')}</span>
      <button class="big ${draftListo()?'':'off'}" onclick="goInicio()">${T('Elegir dónde empezar')}</button></div>
  </div>`;
}
function pickLegend(id){
  const n=DRAFT_N(), i=S.draftPicks.indexOf(id);
  if(i>=0) S.draftPicks.splice(i,1); else if(S.draftPicks.length<n) S.draftPicks.push(id);
  document.querySelectorAll('.legend').forEach(el=>
    el.classList.toggle('sel', S.draftPicks.includes(el.dataset.lg)));
  const cont = document.querySelector('.draft-bar > span');
  if(cont) cont.textContent = `${S.draftPicks.length} / ${n} ${T('elegidos')}`;
  const btn = document.querySelector('.draft-bar .big');
  if(btn) btn.classList.toggle('off', !draftListo());
}
function draftListo(){
  return S.draftPicks.length===DRAFT_N() && (!S.herencia || S.enReto || !!S.herencia.rasgo);
}

function goInicio(){
  if(!draftListo()) return;
  S.semilla = S.enReto ? S.enReto.info.semilla : (S.semillaServidor || (Date.now()%2147483647));
  S.semillaEsDelServidor = !S.enReto && S.semillaServidor != null && S.semilla === S.semillaServidor;
  srand(S.semilla);
  const antes = azarEstado();
  const tmp = createPlayer({..._pending, draft:S.draftPicks, herencia:herenciaArranque()});
  S.startOpts = startingOptions(_pending.nat, _pending.pos, tmp.attrs, tmp.pot);
  azarRestaurar(antes);
  const hc = herenciaArranque();
  if(hc){
    const i = S.startOpts.findIndex(o=>o.club.id===hc.club);
    if(i >= 0) S.startOpts[i].padre = true;
    else S.startOpts.unshift({club:C(hc.club), propio:true, padre:true, ...clubOutlook(C(hc.club), tmp.ovr, tmp.potOvr, _pending.nat)});
  }
  S.startOvr = tmp.ovr; S.startPot = tmp.potOvr;
  S.startPick = null; S.startAll = false; S.startLg = null; S.phase='inicio'; render();
}
function verTodos(){ S.startAll = !S.startAll; if(!S.startLg) S.startLg = LEAGUES.find(l=>l.pais===_pending.nat)?.id || LEAGUES[0].id; render(); }
function setStartLg(id){ S.startLg = id; render(); }
function pickAnyClub(id){
  const c = C(id);
  S.startOpts = S.startOpts.filter(o=>!o.propio || o.padre);
  S.startOpts.push({club:c, propio:true, ...clubOutlook(c, S.startOvr, S.startPot, _pending.nat)});
  S.startPick = S.startOpts.length-1;
  S.startAll = false; render();
}
function vTodosLosClubes(){
  const lg = LEAGUES.find(l=>l.id===S.startLg) || LEAGUES[0];
  const cl = CLUBS.filter(c=>c.lg===lg.id).slice().sort((a,b)=>b.rep-a.rep);
  return `<div class="pane">
    <h2 class="h2 anim">${T('Elegí cualquier club del mundo')}</h2>
    <p class="lead anim">${T('Están todos disponibles. Nadie te lo va a impedir: si entrás por la puerta grande, vas a tener que ganarte el lugar contra un plantel que ya está armado.')}</p>
    <div class="wsel">${LEAGUES.map(l=>
      `<button class="lgtab ${l.id===S.startLg?'on':''}${l.pais===_pending.nat?' mia':''}" onclick="setStartLg('${l.id}')">${esc(TN(l.n))}</button>`).join('')}</div>
    <div class="clubgrid">${cl.map(c=>{
      const o = clubOutlook(c, S.startOvr, S.startPot, _pending.nat);
      return `<button class="cpick anim" onclick="pickAnyClub('${c.id}')">
        ${crest(c.id,30)}
        <span class="cpn"><b>${esc(c.n)}</b><em>${stars(c.tier)}</em></span>
        <span class="cpm" style="color:${barColor(o.mins)}">${o.mins}%<i>${T('minutos')}</i></span></button>`;
    }).join('')}</div>
    <button class="big" onclick="verTodos()">${T('Volver a las recomendadas')}</button>
  </div>`;
}
function vInicio(){
  if(S.startAll) return vTodosLosClubes();
  return `<div class="pane">
    <h2 class="h2 anim">${T('¿Dónde empezás?')}</h2>
    <p class="lead anim">${T('Todos te quieren en las inferiores. Ninguna opción es gratis: en un grande te cuesta más entrar pero ganás todo; en un chico jugás desde el primer día pero nadie te mira.')}</p>
    <div class="offers">
      ${S.startOpts.map((o,i)=>`<div class="offer anim ${S.startPick===i?'stay':''}" style="--club:${clubAccent(o.club.id)}" data-si="${i}" role="button" tabindex="0" onclick="pickStart(${i})">
        <div class="of-top">${crest(o.club.id,36)}<b>${esc(o.club.n)}</b>${stars(o.club.tier)}</div>
        <span class="of-lg">${esc(ligaTxt(o.club))} · ${esc(TPais(L(o.club.lg).pais))}${o.extranjero?' · '+T('EXTERIOR'):''}${o.padre?' · <b class="gold">'+T('EL CLUB DE TU VIEJO')+'</b>':''}</span>
        <div class="of-nums" style="margin-top:11px">
          <span>${T('Minutos')}<b>~${o.mins}%</b></span>
          <span>${T('Dificultad')}<b>${T(o.dificultad<20?'Baja':o.dificultad<45?'Media':'Alta')}</b></span>
          <span>${T('Vidriera')}<b>${T(o.exposicion<45?'Poca':o.exposicion<72?'Media':'Máxima')}</b></span>
        </div>
        <div class="row" style="margin-bottom:6px">${o.pros.map(t=>chip('+ '+esc(T(t)),'pos')).join('')}</div>
        <div class="row" style="margin-bottom:0">${o.cons.map(t=>chip('− '+esc(T(t)),'neg')).join('')}</div>
      </div>`).join('')}
    </div>
    <button class="ghost anim" onclick="verTodos()">${T('Ver todos los clubes')}</button>
    <button class="big ${S.startPick==null?'off':''}" onclick="startCareer()">${T('Firmar mi primer contrato')}</button>
  </div>`;
}
function pickStart(i){
  S.startPick = i;
  document.querySelectorAll('.offer[data-si]').forEach(el=>
    el.classList.toggle('stay', +el.dataset.si===i));
  const btn = document.querySelector('.pane > .big');
  if(btn) btn.classList.remove('off');
}

function startCareer(){
  if(S.startPick==null) return;
  const o = S.startOpts[S.startPick];
  const rec = S.enReto ? {ev:null, carrera:0} : memoriaLeer();
  const arranque = {nat:_pending.nat, pos:_pending.pos, num:_pending.num,
    foot:_pending.foot, draft:S.draftPicks, club:o.club.id, dif:'normal',
    memEv:rec.ev, nroCarrera:rec.carrera};
  const herencia = S.enReto ? null : herenciaArranque();
  if(herencia) arranque.herencia = herencia;
  S.p = cicloArranque(arranque);
  S.p.name = _pending.name;
  const dinastia = herencia ? S.herencia : null;
  S.p.linajeId = (dinastia && dinastia.linaje.id) || nuevoLinajeId();
  if(dinastia){
    S.p.linaje = dinastia.linaje;
    S.p.padre = {...dinastia.padre};
    S.p.timeline.push({y:S.p.year, k:'Hijo de {padre}', v:{padre:dinastia.padre.name}, ic:'👪'});
  }
  S.herencia = null;
  if(!S.enReto) herenciaOlvidar();
  const delServidor = !S.enReto && !!S.semillaEsDelServidor;
  S.reg = {semilla:S.semilla, propia:S.enReto ? false : !delServidor, ...arranque,
    decisiones:[], focos:[], invierno:[], mercado:[], retiro:[]};
  if(S.enReto){
    S.reg.reto = S.enReto.info.semana;
    S.reg.retoN = S.enReto.info.numero;           
    if(S.enReto.practica) S.reg.practica = true;
    else retoGuardar({empezado:true});
  }
  else if(delServidor){ if(S.semillaServidor === S.semilla) S.semillaServidor = null; S.semillaIntentos = 0; rankPedirSemilla(); }
  S.enReto = null;
  S.envio = null; S.dynAviso = false;
  S.mktPick = null; S.colgar = false; S.volver = null;
  S.phase='pretemporada'; Store.save(); render();
  medir('career_start', {position: S.p.pos, nationality: S.p.nat, speed: S.vel,
    ranked: !S.reg.propia && !S.reg.practica, weekly: !!S.reg.reto,
    generation: S.p.dinastia ? S.p.dinastia.gen : 1});
  if(dinastia) medir('dynasty_start', {generation: S.p.dinastia.gen, fame: S.p.dinastia.fama});
}
function saveUtil(d){
  const p = d && d.p;
  if(!p || typeof p !== 'object') return false;
  if(typeof p.name !== 'string' || !POSITIONS[p.pos]) return false;
  if(!p.attrs || typeof p.attrs !== 'object' || !p.pot) return false;
  if(!p.career || typeof p.career.seasons !== 'number') return false;
  if(!C(p.club)) return false;
  const mal = (k, ok) => p[k] !== undefined && !ok(p[k]);
  const arr = Array.isArray, obj = x => x && typeof x === 'object' && !Array.isArray(x);
  if(mal('seasons',arr) || mal('honours',arr) || mal('timeline',arr) || mal('diarios',arr)
     || mal('traits',arr) || mal('flags',obj)) return false;
  return true;
}
function continueSave(){
  S.mktPick = null; S.colgar = false; S.startPick = null;
  if(S.volver && S.volver.p===S.p){ S.phase = S.volver.phase; S.volver = null; render(); return; }
  S.volver = null;
  const d=Store.load();
  if(!saveUtil(d)){
    Store.clear(); S.phase='intro'; render();
    toast(T('No se pudo leer la partida guardada. Se conservó una copia por si se puede recuperar.'));
    return;
  }
  S.p=d.p; S.dif='normal'; S.reg=d.reg||null;
  if(Number.isInteger(d.azar)) azarRestaurar(d.azar); else S.reg = null;
  if(Number.isInteger(d.relato)) relatoRestaurar(d.relato);
  const p=S.p;
  if(p.adapt==null) p.adapt=100;
  if(!p.curva) p.curva='normal';
  if(p.compRival===undefined) p.compRival=null;
  if(p.mgrFit==null) p.mgrFit=0;
  if(p.difComp==null){ p.difComp=1; p.difOfertas=1; p.difLesion=1; }
  if(typeof p.capital !== 'number' || !isFinite(p.capital)) p.capital = 0;
  if(!Array.isArray(p.ruta) || !p.ruta.length) p.ruta = [p.club];
  for(const k of ['seasons','honours','timeline','diarios','traits']) if(p[k]===undefined) p[k] = [];
  if(p.flags===undefined) p.flags = {};
  if(p.div2) usarDivisiones(p.div2); else iniciarDivisiones(p);
  p.dif = 'normal';
  if(p.loanMitades == null) p.loanMitades = p.loanFrom ? 1 : 0;
  if(p.loanTotal == null) p.loanTotal = p.loanMitades;
  if(!Array.isArray(p.world) || p.world.some(w=>!w || typeof w!=='object')) p.world=[];
  const rivalOk = r => r && typeof r==='object' && typeof r.name==='string' && C(r.club);
  if(!Array.isArray(p.rivals) || !p.rivals.length || !p.rivals.every(rivalOk)) p.rivals=initRivals();
  if(!p.ciclos || typeof p.ciclos!=='object' || Array.isArray(p.ciclos)) p.ciclos={};
  if(p.nemesis && (typeof p.nemesis!=='object' || typeof p.nemesis.name!=='string')) p.nemesis=null;
  if(p.nemesis===undefined) p.nemesis=null;
  if(!Number.isFinite(p.loanMitades) || p.loanMitades<0) p.loanMitades = p.loanFrom?1:0;
  if(!Number.isFinite(p.loanTotal) || p.loanTotal<p.loanMitades) p.loanTotal = p.loanMitades;
  if(p.loanFrom && !C(p.loanFrom)){ p.loanFrom=null; p.loanMitades=0; p.loanTotal=0; }
  if(!p.pot0 || typeof p.pot0 !== 'object') p.pot0 = {...p.pot};
  if(!p.resto || typeof p.resto !== 'object') p.resto = {};
  if(!Number.isFinite(p.reconversion) || p.reconversion < 0) p.reconversion = 0;

  if(!Number.isFinite(p.loanYears) || p.loanYears < 0) p.loanYears = 0;
  if(!p.loanFrom) p.loanYears = 0;
  if(p.attrs && p.attrs.aer==null){
    const w = POSITIONS[p.pos].w;
    p.attrs.aer = clamp(Math.round(22 + p.attrs.fis*0.42 + w.aer*45), 20, 90);
    p.pot.aer   = clamp(p.attrs.aer + 14, 30, 99);
    p.attrs.com = clamp(Math.round(34 + (p.career.seasons||0)*1.6 + (p.honours||[]).length*0.8), 18, 90);
    p.pot.com   = clamp(p.attrs.com + 16, 30, 99);
    recalc(p);
  }
  if(p.attrs && p.attrs.peg==null){
    const w = POSITIONS[p.pos].w;
    p.attrs.peg = clamp(Math.round(20 + p.attrs.pas*0.30 + w.peg*40), 15, 90);
    p.pot.peg   = clamp(p.attrs.peg + 14, 30, 99);
    p.attrs.lid = clamp(Math.round(30 + clamp(p.age-19,0,14)*1.5 + Math.min(p.clubYears||0,8)*1.2
                        + (p.traits.includes('capitan')||p.traits.includes('lider')?10:0)), 15, 90);
    p.pot.lid   = clamp(p.attrs.lid + 16, 30, 99);
    recalc(p);
  }
  S.focus = (S.focus||[]).filter(k=>ATTRS.some(a=>a.k===k));
  usarCiclos(p.ciclos || {});
  S.phase = d.phase==='fin'?'fin':'pretemporada'; render();
}

const STEP_ORDER = ['pretemporada','evento','sim','diario','invierno','resultado','mundo','mercado'];
const STEP_NAME = {pretemporada:'Pretemporada', evento:'Decisiones', sim:'Temporada',
  diario:'Noticias', invierno:'Mercado corto', resultado:'Balance', seleccion:'Selección',
  mundo:'El mundo', mercado:'Mercado largo'};
const T_ROL = {'Figura del equipo':1,'Titular indiscutido':1,'Rotación de lujo':1,'Suplente con proyección':1,'Titular':1,'Rotación':1};
function vTop(){
  const p=S.p, c=C(p.club);
  const fase = S.phase==='seleccion' ? 'resultado'
             : (S.phase==='diario' && S.diario && S.diario.edicion==='fin') ? 'resultado'
             : S.phase;
  const idx = STEP_ORDER.indexOf(fase);
  return `<div class="topbar">
    ${Store.fallo? `<div class="avisoguardado">${T('No se está pudiendo guardar en este navegador: si cerrás la pestaña, se pierde la carrera.')}</div>`:''}
    ${S.p.nemesisAqui? `<div class="avisonem">${T('Tu nuevo técnico es {dt}. Ya trabajaste con él, y no terminó bien.', {dt:esc(S.p.nemesis.name)})}</div>`:''}
    ${
      motivoNoRankeable()? `<div class="avisorank">${T('Esta carrera no va a entrar en el ranking mundial.')}</div>`:''}
    <div class="pcard" style="--club:${clubAccent(p.club)}">
      <div class="ovrbox"><span>${T('MEDIA')}</span><b style="color:${barColor(p.ovr)}">${p.ovr}</b>${
        (()=>{ const ss=p.seasons||[]; const ant=ss.length? ss[ss.length-1].ovr : null;
          if(ant==null || ant===p.ovr) return '';
          const sube = p.ovr>ant;
          return `<i class="ovrtend ${sube?'sube':'baja'}">${sube?'▲':'▼'}${Math.abs(p.ovr-ant)}</i>`;
        })()}</div>
      <div class="pmain">
        <div class="pchips">
          <span class="pchip n">${p.flag}<span class="pnat"> ${esc(TPais(p.nat))}</span></span>
          <span class="pchip pos">#${p.num} ${TPOS(p.pos)}</span>
          ${p.loanFrom? `<span class="pchip">${T('CEDIDO')}</span>`:''}
        </div>
        <div class="pname">${esc(p.name)}</div>
        <div class="pclub">${crest(p.club,20)}<b>${esc(c.n)}</b><em class="pfil">${T(FIL_N[filosofiaDe(c)])}</em></div>
      </div>
      <div class="pside">
        <div><span>${T('EDAD')}</span><b>${p.age}</b></div>
        <div><span>${T('VALOR')}</span><b>${money(p.value)}</b></div>
        <div><span>${T('CAPITAL')}</span><b>${money(p.capital||0)}</b></div>
      </div>
    </div>
    <div class="steps">${STEP_ORDER.map((s,i)=>
      `<div class="step ${i<idx?'done':i===idx?'now':''}" title="${T(STEP_NAME[s]||'')}"></div>`).join('')}</div>
    <div class="steplbl">
      <b>${T(STEP_NAME[S.phase]||'')} <em>${idx+1}/${STEP_ORDER.length}</em></b>
      <span><i class="sedad">${p.age} ${T('años')} · </i>${p.year}/${(p.year+1)%100}${
        S.vel==='rapida'? ` · <em class="velchip">${T('Express')}</em>`:''
      } ${menuBtn()}${langBtn()}</span></div>
  </div>`;
}
const NAV_ICO = (() => {
  const s = d => `<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
  return {
    perfil:   s('<circle cx="12" cy="8" r="3.6"/><path d="M4.5 20c1.2-3.6 4-5.4 7.5-5.4s6.3 1.8 7.5 5.4"/>'),
    carrera:  s('<path d="M4 19h16"/><path d="M5 15l4.5-4.5 3.5 3 6-6.5"/><path d="M15 7h4v4"/>'),
    noticias: s('<rect x="3.5" y="4.5" width="14" height="15" rx="2"/><path d="M17.5 9h3v8.5a2 2 0 0 1-2 2h-1"/><path d="M7 8.5h7M7 12h7M7 15.5h4"/>'),
    vitrina:  s('<path d="M8 4h8v5a4 4 0 0 1-8 0V4z"/><path d="M8 6H5v1.5A3 3 0 0 0 8 10.5M16 6h3v1.5a3 3 0 0 1-3 3"/><path d="M12 13v3.5M8.5 20h7M9.5 20c0-1.8 1.1-3.5 2.5-3.5s2.5 1.7 2.5 3.5"/>'),
    torneos:  s('<path d="M12 3.5l7 2.6v5.4c0 4.3-3 7.4-7 9-4-1.6-7-4.7-7-9V6.1l7-2.6z"/><path d="M12 8.5l1.2 2.4 2.6.4-1.9 1.8.5 2.6-2.4-1.3-2.4 1.3.5-2.6-1.9-1.8 2.6-.4z"/>'),
    mundo:    s('<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17"/><path d="M12 3.5c2.4 2.4 3.6 5.2 3.6 8.5s-1.2 6.1-3.6 8.5c-2.4-2.4-3.6-5.2-3.6-8.5S9.6 5.9 12 3.5z"/>')
  };
})();
function vNav(){
  const items=[['perfil','Perfil'],['carrera','Carrera'],['noticias','Diario'],
    ['vitrina','Vitrina'],['torneos','Copas'],['mundo','Mundo']];
  return `<div class="nav">${items.map(([k,n])=>
    `<button class="${S.sheet===k?'on':''}" onclick="openSheet('${k}')"><i>${NAV_ICO[k]}</i>${T(n)}</button>`).join('')}</div>`;
}
const NAV_KEYS = ['perfil','carrera','noticias','vitrina','torneos','mundo'];
function pintarSheet(){
  document.querySelectorAll('.sheet-bg,.sheet').forEach(e=>e.remove());
  if(S.sheet) $('app').insertAdjacentHTML('beforeend', vSheet());
  document.querySelectorAll('.nav button').forEach((b,i)=>
    b.classList.toggle('on', NAV_KEYS[i]===S.sheet));
}
function openSheet(k){ S.sheet = S.sheet===k? null : k; pintarSheet(); }
function closeSheet(){ S.sheet=null; pintarSheet(); }

function vSheet(){
  if(!S.sheet || !S.p) return '';
  const titles={perfil:T('Perfil del jugador'),carrera:T('Carrera'),noticias:T('El diario'),
    vitrina:T('Vitrina'),torneos:T('Torneos y copas'),mundo:T('El mundo')};
  const body={perfil:sPerfil,carrera:sCarrera,noticias:sNoticias,vitrina:sVitrina,
    torneos:sTorneos,mundo:sMundo}[S.sheet];
  return `<div class="sheet-bg" onclick="closeSheet()"></div>
    <div class="sheet"><div class="grab"></div>
      <h3>${titles[S.sheet]}<button onclick="closeSheet()">×</button></h3>${body()}</div>`;
}

function sPerfil(){
  const p=S.p;
  const W = POSITIONS[p.pos].w;
  return `${vRadiografia(p)}
    <div class="sect">${T('Atributos')} <em>${T('los de arriba son los que definen tu puesto')}</em></div>
    <div class="attrs">${ATTRS.slice().sort((x,y)=>(W[y.k]||0)-(W[x.k]||0))
      .map(a=>attrBar(a.k,TA(a.k),p.attrs[a.k],scoutBand(p,a.k),(W[a.k]||0)>=0.22)).join('')}</div>
    <p class="empty" style="margin-top:9px">${T('La zona rayada es lo que estiman los ojeadores. Tu techo real nunca se conoce.')}</p>
    <div class="sect">${T('Estado')}</div>
    <div class="meters">${meter(T('Moral'),p.moral)}${meter(T('Forma'),p.forma)}${meter(T('Estado físico'),p.fitness)}
      ${meter(T('Reputación'),p.rep)}${meter(T('Hinchada'),p.fanLove)}${meter(T('Relación con el DT'),p.mgrRel)}
      ${p.adapt<100? meter(T('Adaptación'),p.adapt):''}</div>
    <div class="sect">${T('Contrato')}</div>
    <div class="stats">${statBox(T('Valor'),money(p.value))}${statBox(T('Sueldo'),money(p.wage))}
      ${statBox(T('Años'),p.contract)}${statBox(T('Selección'),p.nt.caps+' '+T('PJ'))}
      ${statBox(T('Goles sel.'),p.nt.goals)}${statBox(T('En el club'),p.clubYears+'a')}</div>
    <div class="sect">${T('Maduración')}</div>
    <div class="newsbox" style="margin-bottom:0"><span class="rc-i">${{precoz:'⚡',normal:'📈',tardio:'🌱'}[p.curva||'normal']}</span>
      <div><b>${T(CURVAS[p.curva||'normal'].n)}</b><span>${T(CURVAS[p.curva||'normal'].d)}</span></div></div>
    <div class="sect">${T('Rasgos')}</div>
    <div class="traits">${p.traits.length? p.traits.map(t=>
      `<span class="tr">${T(TRAITS[t].n)}<em>${esc(T(TRAITS[t].d))}</em></span>`).join('')
      : `<i class="empty">${T('Sin rasgos todavía.')}</i>`}</div>
    <div class="salir">
      <button onclick="irAlMenu()">${T('Volver al menú principal')}</button>
      <span>${T('La partida queda guardada. Podés retomarla cuando quieras.')}</span>
    </div>`;
}
function vRadiografia(p){
  const W = POSITIONS[p.pos].w;
  const usados = ATTRS.filter(a=>(W[a.k]||0)>=0.10);
  const orden = (usados.length>=2 ? usados : ATTRS).slice().sort((x,y)=>
    (p.attrs[y.k]-p.attrs[x.k]) || ((W[y.k]||0)-(W[x.k]||0)));
  const fuerte = orden[0], flojo = orden[orden.length-1];
  const nivel = p.ovr>=86? 'De los mejores del mundo en tu puesto'
              : p.ovr>=79? 'Titular en cualquier equipo grande'
              : p.ovr>=71? 'Buen jugador de primera división'
              : p.ovr>=63? 'Todavía te falta para el nivel de arriba'
              : 'Estás lejos del nivel que querés';
  return `<div class="radio">
    <b>${T(nivel)}</b>
    <span>${T('Te destaca')} <em class="pos">${TA(fuerte.k)}</em> · ${T('te pesa')} <em class="neg">${TA(flojo.k)}</em></span>
  </div>`;
}

function irAlMenu(){
  Store.save();
  S.volver = (S.phase!=='pretemporada' && S.phase!=='fin' && S.p) ? {phase:S.phase, p:S.p} : null;
  S.sheet = null;
  S.phase = 'intro';
  render();
}

function vFamiliaPanel(p){
  if(!p.linaje || !p.linaje.gens || !p.linaje.gens.length) return '';
  const gens = p.linaje.gens;
  return `<div class="sect">${T('Dinastía {ap}', {ap:esc(p.linaje.apellido)})}</div>
    <div class="dyn-gens panel">${gens.map((g, i) => {
      const c = C(g.club);
      return `<div class="dyn-g">
        <i>${i+1}</i>${c? crest(c.id, 26) : ''}
        <span><b>${esc(g.name)}</b><em>${g.desde}–${g.hasta} · ${esc(T(g.tier))}${c? ' · '+esc(c.n) : ''}</em>
          <em>${g.goles|0} ${T('goles')} · ${T('Media máxima')}: ${(g.pico|0) || '—'}</em></span>
        <u>${g.score|0}</u></div>`;
    }).join('')}
      <div class="dyn-g yo"><i>${gens.length+1}</i>${crest(p.club, 26)}
        <span><b>${esc(p.name)}</b><em>${T('En curso')}</em></span><u>${legendScore(p)}</u></div>
    </div>
    <div class="sect">${T('Tu carrera')}</div>`;
}
function sCarrera(){
  const p=S.p;
  if(!p.seasons.length) return vFamiliaPanel(p) + `<p class="empty">${T('Todavía no terminaste una temporada.')}</p>`;
  let prev=null;
  const rows = p.seasons.map(s=>{
    const mudanza = prev && prev!==s.clubId; prev=s.clubId;
    const tro = s.titles.length? ICO.titulos.repeat(Math.min(3,s.titles.length)) : '';
    return `<div class="crow ${mudanza?'move':''}">
      <div class="cage">${s.age}</div>
      <div class="cclub">${crest(s.clubId,24)}<b>${esc(s.club)}</b></div>
      <div class="covr"><b style="color:${barColor(s.ovr)}">${s.ovr}</b></div>
      <div class="cnum">${s.apps}</div><div class="cnum">${s.goals}</div><div class="cnum">${s.assists}</div>
      ${tro? `<span class="ctro">${tro}</span>`:''}</div>`;
  }).join('');
  return `${vFamiliaPanel(p)}<div class="chead"><span>${T('EDAD')}</span><span>${T('CLUB')}</span><span>${T('MEDIA')}</span><span>${T('PJ')}</span><span>${T('G')}</span><span>${T('A')}</span></div>${rows}`;
}
const TROPHY_DEFS = [
  [ICO.balon,     'Balón de Oro',    p=>p.balones],
  [ICO.bota,      'Bota de Oro',     p=>p.botasOro||0],
  [ICO.mundial,   'Mundial',         p=>p.mundiales],
  [ICO.contiSel,  'Continental sel.',p=>p.contiSel],
  [ICO.conti,     'Copas continent.',p=>p.contis],
  ['🌐',          'Mundial de Clubes',p=>p.cwc||0],
  ['🌍',          'Intercontinental', p=>p.inter||0],
  [ICO.liga,      'Ligas',           p=>p.ligas],
  [ICO.ascenso,   'Segundas ganadas',p=>p.segundas||0],
  [ICO.copa,      'Copas nacionales',p=>p.copas],
  [ICO.mvpFinal,  'MVP de finales',  p=>p.mvpFinal||0],
  [ICO.mvpMundial,'MVP del Mundial', p=>p.mvpMundial||0]
];
function sVitrina(){
  const p=S.p;
  const boxes = TROPHY_DEFS.map(([ic,n,f])=>{ const v=f(p);
    return `<div class="tbox ${v?'has':''}"><i>${ic}</i><b>${v}</b><span>${T(n)}</span></div>`; }).join('');
  const g={}; p.honours.forEach(h=>{ (g[h.n]=g[h.n]||[]).push(h.y); });
  const list = Object.entries(g).sort((a,b)=>b[1].length-a[1].length)
    .map(([n,ys])=>`<div class="hon"><b>${esc(TN(n))}</b><span>×${ys.length}</span><em>${ys.slice(0,6).join(', ')}${ys.length>6?'…':''}</em></div>`).join('');
  return `<div class="tgrid">${boxes}</div>
    <div class="sect">${T('Todo lo ganado')}</div>
    ${list || `<p class="empty">${T('La vitrina está vacía. Por ahora.')}</p>`}`;
}
function sTorneos(){
  const p=S.p;
  if(!p.world||!p.world.length) return `<p class="empty">${T('Todavía no terminó ninguna temporada.')}</p>`;
  if(!S.tGrupo) S.tGrupo='ligas';
  const grupos = [
    ['ligas',    ICO.liga,    T('Ligas')],
    ['conti',    ICO.conti,   T('Copas')],
    ['selecciones', ICO.mundial, T('Selecciones')]
  ];
  return `<div class="tgrupos">${grupos.map(([k,ic,n])=>
      `<button class="tgr ${S.tGrupo===k?'on':''}" onclick="setTGrupo('${k}')"><i>${ic}</i>${n}</button>`).join('')}</div>
    <div id="tbody">${
      S.tGrupo==='ligas' ? tLigas(p) : S.tGrupo==='conti' ? tConti(p) : tSelecciones(p)}</div>`;
}
function setTGrupo(k){ S.tGrupo=k; S.wYear=null; pintarSheet(); }

function tLigas(p){
  const w = p.world[p.world.length-1];
  if(!S.wlg) S.wlg=C(p.club).lg;
  const miLiga = C(p.club).lg;
  return `<div class="wsel">${LEAGUES.map(l=>
      `<button class="lgtab ${l.id===S.wlg?'on':''}${l.id===miLiga?' mia':''}" onclick="setWlg('${l.id}')">${esc(TN(l.n))}</button>`).join('')}</div>
    ${worldTables(w)}
    <div class="sect">${T('Campeones de la liga, año por año')}</div>
    <div class="palmares">${p.world.slice().reverse().map(x=>{
      const t = (x.tablas && x.tablas[S.wlg]) || [];
      const id = (x.campeon && x.campeon[S.wlg])
                 || (t.length ? (Array.isArray(t[0])? t[0][0] : t[0].id)
                              : (x.palmares && x.palmares.liga && x.palmares.liga[S.wlg]));
      if(!id) return '';
      const club = C(id), mio = id===p.club;
      const gol = x.goleadores && x.goleadores[S.wlg];
      return `<div class="pal ${mio?'mio':''}"><b>${x.year}</b>${crest(id,20)}
        <span>${esc(club? club.n : '—')}</span>
        ${gol? `<em>${ICO.bota} ${esc(gol.name)} ${gol.goles}</em>`:''}</div>`;
    }).join('')}</div>`;
}

function marcador(f){
  if(!f) return '';
  return `${f.a}<i>–</i>${f.b}`;
}
function comoTermino(f){
  if(!f) return '';
  return f.pen ? T('en penales') : f.extra ? T('en la prórroga') : '';
}

function llave(camp, campId, sub, subId, final, semis, yoCamp, yoSub){
  const modo = comoTermino(final);
  return `<div class="llave">
    <div class="lafinal">
      <span class="fetiq">${T('FINAL')}</span>
      <div class="fgana ${yoCamp?'mio':''}">
        ${crest(campId,34)}
        <div><b>${esc(camp)}</b><em>${ICO.titulos} ${T('campeón')}</em></div>
        <span class="fgol">${final? final.a : ''}</span>
      </div>
      <div class="fpierde ${yoSub?'mio':''}">
        ${crest(subId,26)}
        <div><b>${esc(sub)}</b><em>${T('subcampeón')}</em></div>
        <span class="fgol">${final? final.b : ''}</span>
      </div>
      ${modo? `<div class="fmodo">${modo}</div>`:''}
    </div>
    ${semis && semis.length? `<div class="semis"><span>${T('Eliminados en semifinales')}</span>
      ${semis.map(s=>`<b>${crest(s.id,18)}${esc(s.n)}</b>`).join('')}</div>`:''}
  </div>`;
}

function filaFinal(year, camp, res, sub, mio){
  const modo = comoTermino(res);
  return `<div class="palf ${mio?'mio':''}">
    <b>${year}</b>
    <span class="pgana">${esc(camp)}</span>
    <u>${marcador(res)}${modo? `<em>${modo}</em>`:''}</u>
    <span class="perd">${esc(sub||'—')}</span>
  </div>`;
}

function catalogoCopas(p){
  const w = p.world[p.world.length-1], cat = [];
  const hubo = f => p.world.some(f);
  ['EUR','SUD','ASI','CON'].forEach(cf=>{
    if(!(w.conti && w.conti[cf])) return;
    cat.push({k:'A:'+cf, gr:'conti', n:CONT_CUP[cf], get:x=>x.conti && x.conti[cf],
      fmt:'Fase de liga, eliminatorias a ida y vuelta y final a partido único.',
      clas:'Entran los primeros puestos de cada liga de la confederación, y el campeón defiende su plaza.'});
  });
  ['EUR','SUD'].forEach(cf=>{
    if(!hubo(x=>x.conti2 && x.conti2[cf])) return;
    cat.push({k:'B:'+cf, gr:'conti2', n:CONT_CUP2[cf], get:x=>x.conti2 && x.conti2[cf],
      fmt:'Fase de grupos, eliminatorias a ida y vuelta y final a partido único.',
      clas:'Entran los que quedaron justo debajo de la zona de la copa grande y el campeón de la copa nacional. Sin gigantes, cualquiera puede ganarla.'});
  });
  if(hubo(x=>x.cwc))
    cat.push({k:'CWC', gr:'fifa', n:FIFA_CWC, get:x=>x.cwc, cada4:true,
      fmt:'Cada cuatro años. Dieciséis clubes en cuatro grupos de cuatro; pasan dos por grupo y desde cuartos es eliminación directa.',
      clas:'Las plazas se ganan a lo largo de un ciclo de cuatro años: primero los campeones continentales de esos cuatro años, y el resto por ranking.',
      extra:x=>vPlantelCWC(x, p)});
  if(hubo(x=>x.inter))
    cat.push({k:'INTER', gr:'fifa', n:FIFA_INTER, get:x=>x.inter,
      fmt:'Todos los años, y no hay grupos: es una escalera de eliminación directa a partido único.',
      clas:'Juegan los campeones vigentes de cada confederación. El campeón de Europa no juega la escalera: espera directamente en la final.',
      extra:x=>vEscaleraInter(x)});
  LEAGUES.forEach(l=>{
    if(!(w.copas && w.copas[l.id])) return;
    cat.push({k:'N:'+l.id, gr:'nac', n:l.copa, get:x=>x.copas && x.copas[l.id],
      fmt:'Eliminación directa de principio a fin. Un mal día y se terminó.',
      clas:'Entran todos los clubes del país, sin importar la categoría.'});
  });
  return cat;
}
function vPlantelCWC(x, p){
  if(!x.cwc || !x.cwc.plantel) return '';
  const CF = {EUR:'Europa', SUD:'Sudamérica', ASI:'Asia', CON:'Norteamérica'};
  return `<div class="sect">${T('Los dieciséis clasificados')}</div>
    <div class="cwcgrid">${['EUR','SUD','ASI','CON'].map(cf=>{
      const los = x.cwc.plantel.filter(c=>c.cf===cf);
      if(!los.length) return '';
      return `<div class="cwccf"><span class="cfn">${T(CF[cf])} <em>${los.length}</em></span>
        ${los.map(c=>`<div class="cwcrow ${c.id===p.club?'mio':''}">${crest(c.id,20)}
          <b>${esc(c.n)}</b><em>${T(c.via)}</em></div>`).join('')}</div>`;
    }).join('')}</div>`;
}
function vEscaleraInter(x){
  if(!x.inter || !x.inter.escalera) return '';
  return `<div class="sect">${T('El camino hasta la final')}</div>
    <div class="escalera">${x.inter.escalera.map(e=>
      `<div class="esc"><span class="escr">${TN(e.ronda)}</span>
        <div class="escg">${crest(e.gana.id,22)}<b>${esc(e.gana.club)}</b></div>
        <div class="escp">${crest(e.pierde.id,18)}<span>${esc(e.pierde.club)}</span></div></div>`).join('')}
      <div class="esc bye"><span class="escr">${T('Clasificado directo a la final')}</span>
        <div class="escg">${crest(x.inter.byeId,22)}<b>${esc(x.inter.byeEuropa)}</b></div></div>
    </div>`;
}
function tConti(p){
  const cat = catalogoCopas(p);
  if(!cat.length) return `<p class="empty">${T('Todavía no terminó ninguna temporada.')}</p>`;
  if(!S.tCopa || !cat.some(c=>c.k===S.tCopa)) S.tCopa = cat[0].k;
  const sel = cat.find(c=>c.k===S.tCopa);
  const GRUPO = {conti:'Continentales', conti2:'Segundas copas', fifa:'Entre continentes', nac:'Nacionales'};

  const selector = `<div class="wsel">${['conti','conti2','fifa','nac'].map(gr=>{
    const los = cat.filter(c=>c.gr===gr);
    if(!los.length) return '';
    return `<span class="wsg">${T(GRUPO[gr])}</span>` + los.map(c=>
      `<button class="lgtab ${S.tCopa===c.k?'on':''}" onclick="setTCopa('${c.k}')">${esc(TN(c.n))}</button>`).join('');
  }).join('')}</div>`;

  const historia = p.world.slice().reverse().filter(x=>sel.get(x));
  if(!historia.length) return `${selector}<p class="empty">${T('Esta copa todavía no se jugó.')}</p>`;
  const act = sel.get(historia[0]);
  const cuenta = {};
  historia.forEach(x=>{ const n=sel.get(x).club; cuenta[n]=(cuenta[n]||0)+1; });
  const rey = Object.entries(cuenta).sort((a,b)=>b[1]-a[1])[0];
  const mias = historia.filter(x=>sel.get(x).yo).length;
  const prox = sel.cada4? (p.year % 4 === 1 ? p.year : p.year + ((1 - p.year%4) + 4) % 4) : null;

  return `${selector}
    <p class="formato">${T(sel.fmt)}</p>
    <p class="clasifica"><span>${T('Cómo se entra')}</span>${T(sel.clas)}</p>
    ${sel.cada4? `<div class="proximo"><span>${T('Edición más reciente')}</span><b>${historia[0].year}</b>
      ${prox>p.year? `<span>${T('próxima')}</span><b>${prox}</b>`:''}</div>`:''}
    ${llave(act.club, act.id, act.sub, act.subId, act.final, act.semis, act.yo, act.subYo)}
    ${sel.extra? sel.extra(historia[0]) : ''}
    <div class="cresumen">
      <div><b>${historia.length}</b><span>${T('ediciones')}</span></div>
      <div><b>${rey[1]}</b><span>${esc(rey[0])}</span></div>
      ${mias? `<div class="mio"><b>${mias}</b><span>${T('tuyas')}</span></div>`:''}
    </div>
    <div class="sect">${T('Todas las finales')}</div>
    <div class="palmares">${historia.map(x=>{
      const c=sel.get(x);
      return filaFinal(x.year, c.club, c.final, c.sub, c.yo||c.subYo);
    }).join('')}</div>`;
}
function setTCopa(k){ S.tCopa=k; pintarSheet(); }

function tSelecciones(p){
  const conMundial = p.world.filter(x=>x.selecciones && x.selecciones.mundial);
  const conConti   = p.world.filter(x=>x.selecciones && x.selecciones.continental);
  const proximo = (() => {
    const y = p.year, c = y % 4;
    if(c===2) return null;
    const haciaMundial = (2 - c + 4) % 4, haciaConti = (0 - c + 4) % 4;
    return haciaMundial <= haciaConti
      ? {n:TN('Copa del Mundo'), y:y + haciaMundial}
      : {n:TN(CONF_NAME[p.conf]), y:y + haciaConti};
  })();
  const aviso = proximo? `<div class="proximo"><span>${T('Próximo torneo')}</span><b>${esc(proximo.n)} ${proximo.y}</b></div>`:'';

  if(!conMundial.length && !conConti.length)
    return `${aviso}<p class="empty">${T('Todavía no se jugó ningún torneo de selecciones.')}</p>`;

  const finalSel = (c, f) => filaFinal(c.year,
    c.campeon.flag+' '+TPais(c.campeon.nat), f,
    c.sub? c.sub.flag+' '+TPais(c.sub.nat) : null, c.yo);

  return `${aviso}
    <p class="formato">${T('Fase de grupos, eliminatorias y final. Cada cuatro años.')}</p>
    ${conMundial.length? `<div class="sect">${ICO.mundial} ${TN('Copa del Mundo')}</div>
      <div class="palmares">${conMundial.slice().reverse().map(x=>
        finalSel({year:x.year, campeon:x.selecciones.campeon, sub:x.selecciones.sub, yo:x.selecciones.campeon.yo},
                 x.selecciones.final)).join('')}</div>`:''}
    ${conConti.length? ['EUR','SUD','AFR','CON','ASI'].map(cf=>{
      const h = conConti.filter(x=>x.selecciones.porConf && x.selecciones.porConf[cf]);
      if(!h.length) return '';
      return `<div class="sect">${ICO.contiSel} ${esc(TN(CONF_NAME[cf]))}</div>
        <div class="palmares">${h.slice().reverse().map(x=>{
          const c=x.selecciones.porConf[cf];
          return finalSel({year:x.year, campeon:c, sub:c.sub, yo:c.yo}, c.final);
        }).join('')}</div>`;
    }).join('') : ''}`;
}

function sMundo(){
  const p=S.p;
  if(!p.world||!p.world.length) return `<p class="empty">${T('Todavía no terminó ninguna temporada.')}</p>`;
  return vGeneracion(p) + vDuelo(p) + vRecords(p) + vHistoria(p) + vLeyendas(p);
}

function vGeneracion(p){
  const orden = (p.rivals||[]).slice().sort((a,b)=>legadoDe(b)-legadoDe(a));
  if(!orden.length) return '';
  const previo = p.rankPrevio || [];
  const mov = (nombre, i) => {
    const antes = previo.indexOf(nombre);
    if(!previo.length) return '';
    if(antes < 0) return `<span class="mov nuevo">${T('NUEVO')}</span>`;
    if(antes > i) return `<span class="mov sube">↑${antes-i}</span>`;
    if(antes < i) return `<span class="mov baja">↓${i-antes}</span>`;
    return `<span class="mov igual">–</span>`;
  };
  const logros = r => [
    r.balones? `<b>${ICO.balon} ${r.balones}×</b> ${T('Balón de Oro')}`:'',
    r.contis?  `<b>${ICO.conti} ${r.contis}×</b> ${T('continental')}`:'',
    r.ligas?   `<b>${ICO.liga} ${r.ligas}×</b> ${T('liga')}`:'',
    r.goles?   `<b>⚽ ${r.goles}</b> ${T('goles')}`:''
  ].filter(Boolean).join('<i>·</i>');

  const uno = orden[0], resto = orden.slice(1);
  return `<div class="sect">${T('Los mejores de tu era')}</div>
    <p class="empty" style="margin-bottom:12px">${T('Ordenados por lo que ganaron, no por su media. Contra ellos competís por ser el mejor de la historia.')}</p>
    <div class="rey">
      <div class="rey-luz"></div>
      <div class="rey-cab">${crest(uno.club,40)}
        <div><b><span class="corona">👑</span>${uno.flag} ${esc(uno.name)}</b>
        <em>${TPOS(uno.pos)} · ${uno.age} ${T('años')} · ${esc(C(uno.club).n)}</em></div>
        <span class="rey-ovr" style="color:${barColor(uno.ovr)}">${uno.ovr}</span></div>
      <div class="rey-logros">${logros(uno) || T('Todavía sin palmarés. Le sobra tiempo.')}</div>
    </div>
    <div class="ranking">
      ${resto.map((r,i)=>`<div class="rk">
        <span class="rk-n">${i+2}</span>${crest(r.club,24)}
        <div class="rk-txt"><b>${r.flag} ${esc(r.name)}</b>
          <span class="rk-quien">${TPOS(r.pos)} · ${r.age} ${T('años')} · ${esc(C(r.club).n)}</span>
          ${logros(r)? `<span class="rk-logros">${logros(r)}</span>`:''}</div>
        ${mov(r.name, i+1)}
        <span class="rk-ovr" style="color:${barColor(r.ovr)}">${r.ovr}</span>
      </div>`).join('')}
    </div>`;
}

function vDuelo(p){
  const orden = (p.rivals||[]).slice().sort((a,b)=>legadoDe(b)-legadoDe(a));
  if(!orden.length || !p.seasons.length) return '';
  const r = orden[0], s = careerSummary(p);
  const filas = [
    [T('Balón de Oro'), p.balones||0, r.balones||0],
    [T('Continentales ganadas'), s.contis||0, r.contis||0],
    [T('Ligas ganadas'), s.ligas||0, r.ligas||0],
    [T('Goles'), s.goles||0, r.goles||0],
    [T('MEDIA'), p.ovr, r.ovr]
  ];
  const gano = filas.filter(f=>f[1]>f[2]).length, perdi = filas.filter(f=>f[1]<f[2]).length;
  return `<div class="sect">${T('Tu gran rival')}</div>
    <div class="duelo">
      <div class="duelo-cab">
        <div class="dl"><b>${T('VOS')}</b><em>${esc(p.name)}</em></div>
        <span class="dvs">${gano>perdi? T('vas ganando') : gano<perdi? T('te lleva ventaja') : T('empate')}</span>
        <div class="dl der"><b>${r.flag}</b><em>${esc(r.name)}</em></div>
      </div>
      ${filas.map(([n,a,b])=>`<div class="dfila">
        <span class="dv ${a>b?'gana':a<b?'pierde':''}">${a}</span>
        <span class="dn">${n}</span>
        <span class="dv ${b>a?'gana':b<a?'pierde':''}">${b}</span></div>`).join('')}
    </div>`;
}

function vRecords(p){
  const todos = (p.rivals||[]).concat(p.leyendas||[]);
  if(!todos.length) return '';
  const s = careerSummary(p);
  const yo = {name:p.name, flag:p.flag, balones:p.balones||0, contis:s.contis||0, ligas:s.ligas||0, goles:s.goles||0};
  const universo = todos.concat([yo]);
  const top = k => universo.reduce((a,b)=>((b[k]||0)>(a[k]||0)?b:a), universo[0]);
  const R_ = [
    [ICO.balon, T('Más Balones de Oro'), 'balones'],
    [ICO.conti, T('Más continentales'),   'contis'],
    [ICO.liga,  T('Más ligas'),           'ligas'],
    ['⚽',      T('Más goles'),           'goles']
  ];
  return `<div class="sect">${T('Récords de tu era')}</div>
    <div class="records">${R_.map(([ic,n,k])=>{
      const m = top(k); const mio = m.name===p.name;
      return `<div class="rec ${mio?'yo':''}"><i>${ic}</i>
        <b>${m[k]||0}</b><span>${n}</span>
        <em>${mio? T('vos') : (m.flag||'')+' '+esc(m.name)}</em></div>`;
    }).join('')}</div>`;
}

function vHistoria(p){
  return `<div class="sect">${T('Historia del fútbol')}</div>
    <div class="anios">${p.world.slice().reverse().map(w=>{
      const abierto = S.wYear===w.year;
      const campeones = LEAGUES.map(l=>{
        const t=(w.tablas&&w.tablas[l.id])||[]; if(!t.length) return null;
        const id = Array.isArray(t[0])? t[0][0] : t[0].id;
        return {liga:TN(l.n), club:C(id)};
      }).filter(Boolean);
      return `<div class="anio ${abierto?'abierto':''}" onclick="verAnio(${w.year})">
        <div class="anio-cab"><b>${w.year}</b>
          <span>${ICO.balon} ${esc(w.balon.name)}${w.balon.yo?' · '+T('vos'):''}</span>
          <i>${abierto?'−':'+'}</i></div>
        ${abierto? `<div class="anio-det">
          <div class="hfila oro"><span>${ICO.balon} ${T('Balón de Oro')}</span><b>${w.balon.flag} ${esc(w.balon.name)}</b></div>
          <div class="hfila"><span>${ICO.bota} ${T('Bota de Oro')}</span><b>${w.bota.flag} ${esc(w.bota.name)} · ${w.bota.goles}</b></div>
          ${Object.values(w.conti).map(c=>`<div class="hfila ${c.yo?'mio':''}">
            <span>${ICO.conti} ${esc(TN(c.n))}</span><b>${esc(c.club)}</b></div>`).join('')}
          ${campeones.map(c=>`<div class="hfila ${c.club&&c.club.id===p.club?'mio':''}">
            <span>${ICO.liga} ${esc(c.liga)}</span><b>${esc(c.club? c.club.n : '—')}</b></div>`).join('')}
        </div>`:''}
      </div>`;
    }).join('')}</div>`;
}
function verAnio(y){ S.wYear = S.wYear===y? null : y; pintarSheet(); }

function vLeyendas(p){
  const l = (p.leyendas||[]).slice().sort((a,b)=>legadoDe(b)-legadoDe(a));
  if(!l.length) return '';
  return `<div class="sect">${T('Leyendas retiradas')}</div>
    <p class="empty" style="margin-bottom:10px">${T('Se fueron mientras vos seguías jugando.')}</p>
    ${l.slice(0,10).map(r=>`<div class="rk retirado">
      <span class="rk-n">★</span>${crest(r.club,24)}
      <div class="rk-txt"><b>${r.flag} ${esc(r.name)}</b>
        <span class="rk-quien">${TPOS(r.pos)} · ${r.desde? r.desde+'–'+r.hasta : T('retirado')} · ${esc((C(r.club)||{}).n||'')}</span>
        <span class="rk-logros">${[r.balones?ICO.balon+' '+r.balones:'', r.contis?ICO.conti+' '+r.contis:'', r.ligas?ICO.liga+' '+r.ligas:'', r.goles?'⚽ '+r.goles:''].filter(Boolean).join(' · ')}</span></div>
      <span class="rk-ovr" style="color:var(--dim2)">${r.pico}</span>
    </div>`).join('')}`;
}

function vPre(){
  const p=S.p, c=C(p.club);
  const share = Math.round(minutesShare(p)*100);
  const rol = share>72?['🔥','Titular indiscutido','El equipo es tuyo.']
            : share>48?['✅','Titular alternante','Jugás casi siempre, pero te rotan.']
            : share>26?['🔄','Rotación','Entrás y salís del once.']
            : share>11?['🪑','Suplente','Vas a tener que ganártelo.']
            : ['❄️','Fuera de los planes','No te tienen en cuenta.'];
  rol[1]=T(rol[1]); rol[2]=T(rol[2]);
  const riv = p.compRival;
  return `<div class="pane">
    <div class="rolecard anim"><span class="rc-i">${rol[0]}</span>
      <div><b>${rol[1]}</b><span>${rol[2]} · ${share}% ${T('de los minutos en')} ${esc(c.n)}</span></div></div>
    ${enSegunda(c)? `<div class="newsbox anim alerta"><span class="rc-i">⬇️</span><div>
      <b>${T('Segunda división')}</b>
      <span>${T('{club} juega la segunda categoría. No hay copas continentales y la vidriera es otra: lo que hagas acá lo ve mucha menos gente.', {club:esc(c.n)})}</span>
      </div></div>`:''}
    ${p.loanFrom? `<div class="newsbox anim"><span class="rc-i">🔁</span><div>
      <b>${T('Cedido en {club}', {club:esc(c.n)})}</b>
      <span>${T('Seguís perteneciendo a {duenio}. {queda}', {duenio:esc(C(p.loanFrom).n),
        queda: p.loanMitades>=2? T('Te queda una temporada de cesión.') : T('Volvés en junio.')})}</span>
      </div></div>`:''}
    ${p.mgrNuevo? `<div class="newsbox anim"><span class="rc-i">🎓</span><div>
      <b>${T('Nuevo entrenador')}</b><span>${T(p.mgrFit>4?'Te tiene fe desde el primer día.':p.mgrFit<-4?'No parece convencido con vos.':'Todavía no sabe qué esperar de vos.')}</span></div></div>`:''}
    ${riv? `<div class="newsbox anim ${riv.nuevo?'alerta':''}"><span class="rc-i">⚔️</span><div>
      <b>${riv.nuevo? T('El club fichó a alguien para tu puesto') : T('Seguís peleando el puesto')}</b>
      <span>${riv.flag||''} ${esc(riv.name)} · ${riv.age} ${T('años')} · ${T('MEDIA')} <b style="color:${barColor(riv.ovr)}">${riv.ovr}</b>
      ${p.ovr>riv.ovr? '· '+T('le llevás ventaja') : p.ovr<riv.ovr-2? '· '+T('está por encima tuyo') : '· '+T('están parejos')}</span></div></div>`:''}
    <h2 class="h2 anim">${T('¿En qué ponés las horas extra?')}</h2>
    <p class="lead anim">${T('Elegí <b>dos</b> aspectos. Se entrenan casi al doble de velocidad.')}</p>
    <div class="focus">
      ${ATTRS.slice().sort((x,y)=>(POSITIONS[p.pos].w[y.k]||0)-(POSITIONS[p.pos].w[x.k]||0)).map(a=>{
        const sel=S.focus.includes(a.k), v=p.attrs[a.k], w=POSITIONS[p.pos].w[a.k];
        const pat = PATEADOR[p.pos]||0;
        const peso = a.k==='com'? 'pesa en las noches grandes'
                   : a.k==='lid'? 'no te mejora a vos: mejora al equipo'
                   : a.k==='peg'? (pat>=.7? 'las faltas pueden ser tuyas' : pat>=.45? 'alguna falta te va a tocar' : 'casi nunca pateás vos')
                   : w>=0.22? 'clave en tu puesto' : w>=0.13? 'importante' : w>=0.06? 'secundario' : 'casi no lo usás';
        const col  = (w>=0.22 || a.k==='com' || a.k==='lid' || (a.k==='peg'&&pat>=.7))? 'var(--gold2)'
                   : (w>=0.13 || (a.k==='peg'&&pat>=.45))? 'var(--dim)' : 'var(--dim2)';
        return `<button class="fbtn anim ${sel?'sel':''} ${w>=0.22?'clave':''}" data-fk="${a.k}" onclick="toggleFocus('${a.k}')">
          <b>${TA(a.k)}</b><span class="fv" style="color:${barColor(v)}">${v}</span>
          <em style="color:${col}">${T(peso)}</em>
          <span class="fbar"><u style="width:${v}%;background:${barColor(v)}"></u></span></button>`;
      }).join('')}
    </div>
    <button class="big ${S.focus.length===2?'':'off'}" onclick="startSeason()">${T('Arrancar la temporada')}</button>
    ${vColgar(p)}
  </div>`;
}

const EDAD_COLGAR = 30;
function vColgar(p){
  if(p.age < EDAD_COLGAR) return '';
  if(S.colgar) return `<div class="colgar-box anim">
    <p>${T('Se termina acá. No hay vuelta atrás: la carrera se cierra con lo que hiciste hasta hoy y pasás al balance final.')}</p>
    <div class="colgar-btns">
      <button class="ghost" onclick="S.colgar=false;render()">${T('Seguir jugando')}</button>
      <button class="big peligro" onclick="colgarBotines()">${T('Sí, me retiro')}</button>
    </div></div>`;
  return `<button class="ghost colgar" onclick="S.colgar=true;render()">${T('Colgar los botines')}</button>`;
}
function colgarBotines(){
  const p = S.p;
  S.colgar = false;
  anotar('retiro', p.career.seasons);
  p.retired = true;
  p.retireReason = 'decision';
  S.phase = 'fin';
  if(!S.memGuardada){ memoriaGuardar(p.seenEvents); S.memGuardada = true; finDeCarreraMedido(p); }
  Store.save(); render();
}
function toggleFocus(k){
  const i=S.focus.indexOf(k);
  if(i>=0) S.focus.splice(i,1); else if(S.focus.length<2) S.focus.push(k);
  document.querySelectorAll('.fbtn').forEach(el=>
    el.classList.toggle('sel', S.focus.includes(el.dataset.fk)));
  const btn = document.querySelector('.pane > .big');
  if(btn) btn.classList.toggle('off', S.focus.length!==2);
}

function startSeason(){
  if(S.focus.length!==2) return;
  const p=S.p;
  anotar('focos', S.focus.slice());
  const pre = cicloPretemporada(p, S.focus);
  S.lastGrowth = pre.growth;
  S.halves=[];
  S.evQueue = pre.eventos; S.evIdx=0; S.evResult=null;
  if(S.evQueue.length){ S.phase='evento'; } else runFirstHalf();
  Store.save(); render();
}
function runFirstHalf(){ prepareHalf(0); S.phase='sim'; }
function prepareHalf(n){
  const h = cicloMitad(S.p, n).h;
  S.halves[n]=h; S.matches = cicloPartidos(S.p, h); S.simI=0; S.simHalf=n;
}

function vEvento(){
  const e = evLang(S.evQueue[S.evIdx]);
  if(S.evResult){
    return `<div class="pane">
      <div class="card evcard result anim"><span class="tagline">${T('Tu decisión')}</span><h3>${esc(e.t)}</h3>
        <p class="choice-made">“${esc(S.evResult.choice)}”</p>
        ${S.evResult.riesgo? `<div class="tirada ${S.evResult.riesgo.salio?'ok':'no'}">
          <b>${S.evResult.riesgo.salio? T('Salió') : T('No salió')}</b>
          <span>${TA(S.evResult.riesgo.k)} ${S.evResult.riesgo.v}</span></div>`:''}
        <p class="outcome">${esc(S.evResult.text)}</p>
        ${S.evResult.fichaje? `<div class="fichaje">${crest(S.evResult.fichaje.id,40)}
          <div><span>${S.evResult.cedido? T('Cedido a') : T('Nuevo club')}</span><b>${esc(S.evResult.fichaje.n)}</b>
          <em>${esc(TN(L(S.evResult.fichaje.lg).n))} · ${S.evResult.cedido? T('vuelve a tu club al final de la temporada') : T('Sueldo')+' '+money(S.p.wage)+'/'+T('año')}</em></div></div>`:''}
        ${S.evResult.promesa? `<div class="promesa">${T('Quedó una puerta abierta. En el próximo mercado vas a tener esa oferta sobre la mesa.')}</div>`:''}
        <div class="fx">${S.evResult.log.map(l=>`<span class="${l.includes('-')?'neg':'pos'}">${esc(TFX(l))}</span>`).join('')}</div>
      </div><button class="big" onclick="nextEvent()">${T('Seguir')}</button></div>`;
  }
  return `<div class="pane">
    <div class="card evcard anim"><span class="tagline">${T(STAGE_LABEL[stageOf(S.p)])} · ${S.evIdx+1} ${T('de')} ${S.evQueue.length}</span>
      <h3>${esc(e.t)}</h3>
      <p class="narr">${esc(e.d)}</p></div>
    <div class="choices">${e.c.map((c,i)=>{
      const tira = S.evQueue[S.evIdx].c[i].tira;
      const orig = S.evQueue[S.evIdx].c[i];
      if(!opcionPagable(S.p, orig))
        return `<button class="choice anim bloqueada" disabled>${esc(c.t)}
          <em class="riesgo">${T('No te alcanza: cuesta {x}', {x:money(costoDe(orig))})}</em></button>`;
      return `<button class="choice anim ${tira?'arriesga':''}" onclick="choose(${i})">${esc(c.t)}
        ${tira? `<em class="riesgo">${T('lo decide tu {atr}', {atr:TA(tira).toLowerCase()})} · ${
          Math.round(chanceDeQueSalga(S.p, tira, c.mas||0)*100)}%</em>`:''}</button>`;
    }).join('')}</div>
  </div>`;
}
const STAGE_LABEL = {ini:'Los primeros pasos', asc:'El salto', ple:'Plenitud', vet:'Veteranía', oca:'El último tramo'};
function evLang(e){
  const p=S.p;
  if(TR && TR.ev && TR.ev[e.id]){
    const x=TR.ev[e.id];
    const d=(typeof x.d==='function'? x.d(p) : x.d).split('{club}').join(C(p.club).n)
      .split('{lesion}').join(p.injuryTag? T(p.injuryTag) : T('una lesión seria'))
      .split('{edad}').join(enLetras(p.age,LANG));
    if(!CONCORDAR) return {t:x.t, d, c:x.c};
    const r = o => o && {...o, r:concordar(o.r)};
    return {t:concordar(x.t), d:concordar(d), c:x.c.map(o => ({...o, t:concordar(o.t), r:concordar(o.r), bien:r(o.bien), mal:r(o.mal)}))};
  }
  return {t:e.t, d:(typeof e.d==='function'? e.d(p) : e.d), c:e.c};
}
function choose(i){
  const e=S.evQueue[S.evIdx], loc=evLang(e).c[i]||e.c[i];
  anotar('decisiones', i);
  const r = cicloDecision(S.p, e, i);
  const texto = r.riesgo
    ? ((r.riesgo.salio? loc.bien : loc.mal) || {}).r || loc.r
    : loc.r;
  S.evResult = {choice:loc.t, text:texto, log:r.log, riesgo:r.riesgo,
    fichaje:r.fichaje, cedido:r.cedido, promesa:r.promesa};
  if(r.cortaCola) S.evQueue = S.evQueue.slice(0, S.evIdx + 1);
  render();
}
function nextEvent(){
  S.evIdx++; S.evResult=null;
  while(S.evIdx < S.evQueue.length && !eventoVigente(S.p, S.evQueue[S.evIdx])) S.evIdx++;
  if(S.evIdx>=S.evQueue.length) runFirstHalf();
  Store.save(); render();
}

function compRows(comps){
  return `<div class="comps">${comps.filter(c=>c.apps>0 || c.goals>0).map(c=>`
    <div class="comprow"><span class="cname">${esc(TN(c.n))}</span>
      <span class="cstat"><b>${c.apps}</b>${T('PJ')}</span>
      <span class="cstat"><b>${c.goals}</b>${T('G')}</span>
      <span class="cstat"><b>${c.assists}</b>${T('A')}</span></div>`).join('')
    || `<div class="comprow"><span class="cname">${T('Sin minutos en el primer equipo')}</span></div>`}</div>`;
}
function veredictoMitad(h){
  if(!h.apps) return 'No sumaste un solo minuto en el primer equipo.';
  const r=h.rating;
  if(r>=7.6) return 'Estás jugando el mejor fútbol de tu vida. Todo el mundo habla de vos.';
  if(r>=7.1) return 'Rendimiento alto y sostenido. El técnico te pone siempre.';
  if(r>=6.7) return 'Vas bien. Cumplís, aunque todavía no explotaste.';
  if(r>=6.3) return 'Media temporada gris. Ni bien ni mal, y eso ya es un problema.';
  return 'No te está saliendo nada. Se te viene una segunda mitad cuesta arriba.';
}
function vSim(){
  const p=S.p, n=S.simHalf, h=S.halves[n], c=C(p.club), cp=compsFor(p,c);
  const torneos = [cp.liga, cp.copa].concat(cp.conti?[cp.conti]:[]);
  return `<div class="pane">
    <div class="simhead">
      <h2>${T(n===0?'Primera mitad':'Segunda mitad')} · ${p.year}</h2>
    </div>
    <p class="lead anim" style="margin-bottom:12px">${torneos.map(t=>chip(esc(TN(t)))).join('')}</p>
    <div class="tick">
      <div class="tk" id="tk_pj"><b>0</b><span>${T('Partidos')}</span></div>
      <div class="tk" id="tk_g"><b>0</b><span>${T('Goles')}</span></div>
      <div class="tk" id="tk_a"><b>0</b><span>${T('Asist.')}</span></div>
      <div class="tk" id="tk_r"><b>—</b><span>${T('Nota')}</span></div>
    </div>
    <div class="simbar"><u id="simbar" style="width:0%"></u></div>
    <div class="reslbl" id="reslbl"></div>
    <div class="feed" id="feed"></div>
    <div id="resumen" class="hide">${vResumenMitad(h, n)}</div>
    <button class="big" id="simnext" onclick="simNext()">${T(n===0?'Mercado de invierno':'Balance de la temporada')}</button>
  </div>`;
}
function vResumenMitad(h, n){
  const p=S.p, c=C(p.club), cp=compsFor(p,c);
  return `<div class="sect">${T(n===0?'Balance de media temporada':'Balance de la segunda mitad')}</div>
    <p class="lead">${T(veredictoMitad(h))}</p>
    ${p.injuryTag && n===0? `<div class="alert">🩹 ${esc(T(p.injuryTag))} — ${p.injuredWeeks} ${T('semanas de baja')}</div>`:''}
    <div class="posbox">${crest(p.club,34)}
      <div><span>${esc(TN(cp.liga))}</span><b>${ord(h.ligaPos)}${LANG==='en'?'':' '+T('puesto')} · ${h.ligaPts} ${T('pts')} ${T('en')} ${h.ligaPj} ${T('fechas')}</b></div>
      <em>${h.ligaPos===1?ICO.liga:h.ligaPos<=4?'↑':h.ligaPos>=17?'⚠️':''}</em></div>
    <div class="row">${compRows(h.comps)}</div>`;
}
const RITMOS = {intensa:130, normal:58, rapida:0};
const ritmo = () => RITMOS[S.vel] != null ? RITMOS[S.vel] : RITMOS.normal;
function stopTicker(){ if(S.simTimer){ clearTimeout(S.simTimer); S.simTimer=null; } }
function startTicker(){
  stopTicker();
  if(!$('feed')) return;
  if(!S.matches.length){ finishTicker(); return; }
  if(S.simI > 0){
    const hechos = S.simI; S.simI = 0;
    while(S.simI < hechos) pushMatch(S.simI++);
    if(S.simI >= S.matches.length){ finishTicker(); return; }
  }
  const step = () => {
    if(S.simI>=S.matches.length){ finishTicker(); return; }
    pushMatch(S.simI++);
    S.simTimer = setTimeout(step, ritmo());
  };
  step();
}
function pushMatch(i){
  const m=S.matches[i], feed=$('feed'); if(!feed) return;
  const big = m.decisiva;
  const el=document.createElement('div');
  el.className = `mrow ${m.res==='G'?'win':m.res==='E'?'draw':'loss'}${big?' big':''}${m.reserva?' res':''}${m.noJugado?' nop':''}`;
  const MOTIVO = {banco:'BANCO', lesion:'LESIÓN', fuera:'NO CITADO'};
  const aporte = m.noJugado
    ? `<span class="mcontrib"><s class="out">${T(MOTIVO[m.motivo])}</s></span>`
    : `<span class="mcontrib">${m.g?`<s>⚽ ${m.g}</s>`:''}${m.a?`<s class="as">🅰 ${m.a}</s>`:''}</span>`;
  el.innerHTML = `<span class="mcomp">${T(COMP_LABEL[m.comp])}</span>${crest(m.opp,22)}
    <span class="mopp">${esc(m.oppN)}<em>${m.home?({en:'H',pt:'C'}[LANG]||'L'):({en:'A',pt:'F'}[LANG]||'V')}${m.ronda&&m.comp==='conti'?' · '+esc(TN(m.ronda)):''}</em></span>
    <span class="mscore">${m.gf}-${m.ga}</span>${aporte}`;
  feed.insertBefore(el, feed.firstChild);
  const t = runningTotals(S.matches, i);
  setTk('tk_pj', t.pj, false); setTk('tk_g', t.g, m.g>0 && !m.reserva); setTk('tk_a', t.a, m.a>0 && !m.reserva);
  setTk('tk_r', t.pj? t.rat.toFixed(2):'—', false);
  const rl=$('reslbl');
  if(rl){
    const partes=[];
    if(t.rpj)    partes.push(`${T('Reserva')}: <b>${t.rpj}</b> ${T('PJ')} · <b>${t.rg}</b> ${T('Goles')}`);
    if(t.banco)  partes.push(`<b>${t.banco}</b> ${T('en el banco')}`);
    if(t.lesion) partes.push(`<b>${t.lesion}</b> ${T('por lesión')}`);
    if(t.fuera)  partes.push(`<b>${t.fuera}</b> ${T('sin ser citado')}`);
    rl.innerHTML = partes.join(' · ');
  }
  const bar=$('simbar'); if(bar) bar.style.width = ((i+1)/S.matches.length*100)+'%';
}
function setTk(id, val, bump){
  const el=$(id); if(!el) return;
  el.querySelector('b').textContent = val;
  if(bump){ el.classList.remove('bump'); void el.offsetWidth; el.classList.add('bump'); }
}
function simNext(){
  if(S.simI < S.matches.length){
    stopTicker();
    while(S.simI<S.matches.length) pushMatch(S.simI++);
    finishTicker();
    return;
  }
  afterHalf();
}
function finishTicker(){
  stopTicker();
  const bar=$('simbar'); if(bar) bar.style.width='100%';
  const r=$('resumen'); if(r) r.classList.remove('hide');
}
function afterHalf(){
  stopTicker();
  if(S.simHalf===0){
    const dic = cicloDiciembre(S.p, S.halves[0]);
    S.winter = dic.winter;
    S.vueltaCesion = dic.vuelta;
    const portada = cicloDiarioDiciembre(S.p, S.halves[0], dic.fuera);
    const debut = titularDebutHeredero(S.p, S.halves[0]);
    if(debut){ portada.titulares = [debut].concat(portada.titulares).slice(0, 5); }
    if(portada.titulares.length >= 3){
      S.diario = {edicion:'mitad', year:S.p.year, ...portada};
      guardarDiario(S.p, S.diario);
      S.phase = S.vel === 'rapida' ? 'invierno' : 'diario';
      if(S.vel === 'rapida') S.diario = null;
    } else S.phase = 'invierno';
    if(S.vel === 'rapida' && S.phase === 'invierno'
       && !S.winter.prestamos.length && !S.winter.traspasos.length && !S.vueltaCesion){
      continueSecondHalf(); return;
    }
  }
  else closeSeason();
  Store.save(); render();
}
function titularDebutHeredero(p, h){
  if(!p || !p.dinastia || !p.padre || (p.career && p.career.seasons > 0)) return null;
  const jugo = h && h.apps > 0;
  return {k: jugo ? 'Debuta el hijo de {padre}: {nombre} juega en la primera de {club}'
                  : '{nombre}, el hijo de {padre}, arranca en las inferiores de {club}',
    v:{padre:p.padre.name, nombre:p.name, club:C(p.club).n}, w:99, s:'yo', ic:'👪'};
}
function guardarDiario(p, d){
  if(!p.diarios) p.diarios = [];
  p.diarios.push({edicion:d.edicion, year:d.year, titulares:d.titulares});
  while(p.diarios.length > 40) p.diarios.shift();
}
function cerrarDiario(){
  S.phase = S.diario.edicion==='mitad' ? 'invierno' : 'resultado';
  S.diario = null; Store.save(); render();
}

function titTxt(t){
  const v = {...t.v};
  ['comp','copa','liga','premio'].forEach(k=>{ if(v[k]) v[k] = TN(v[k]); });
  ['upj','ug','ua'].forEach(k=>{ if(v[k]) v[k] = T(v[k]); });
  if(v.ronda) v.ronda = TN(v.ronda);
  if(v.lesion) v.lesion = T(v.lesion);
  if(v.pais) v.pais = TPais(v.pais);
  const out = T(t.k, v);
  return LANG==='en' ? out.replace(/\b(\d+)th\b/g, (m, n)=>ord(+n)) : out;
}
const SEC_DIARIO = {yo:'Vos', liga:'Tu liga', euro:'El mundo', mundo:'El mundo', raro:'Sorpresas'};
function vPortada(d, año){
  const esMitad = d.edicion==='mitad';
  return `<div class="diario periodico">
    <div class="dcab"><span>${esMitad? T('Titulares de mitad de temporada') : T('Titulares de fin de temporada')}</span>
      <b>${año}/${(año+1)%100}</b></div>
    <ul class="dbreves">${d.titulares.map((t,i)=>
      `<li class="${i===0?'dlead':''} ${i===0 && t.w>=90 ?'locura':''} ${t.s==='yo'?'dyo':''}"><i>${t.ic}</i><span>${
        SEC_DIARIO[t.s]? `<small class="dsec">${T(SEC_DIARIO[t.s])}</small>`:''}${esc(titTxt(t))}</span></li>`).join('')}</ul>
  </div>`;
}
function vDiario(){
  return `<div class="pane">
    <div class="anim">${vPortada(S.diario, S.p.year)}</div>
    <button class="big anim" onclick="cerrarDiario()">${T('Seguir')}</button>
  </div>`;
}
const FILTROS = [
  ['todo', 'Todo',       null],
  ['yo',   'Vos',        s=>s==='yo'],
  ['liga', 'Tu liga',    s=>s==='liga'],
  ['mundo','El mundo',   s=>s==='euro' || s==='mundo'],
  ['raro', 'Sorpresas',  s=>s==='raro']
];
function setFiltroNews(k){ S.fnews = k; pintarSheet(); }
function sNoticias(){
  const p = S.p, arch = (p.diarios||[]).slice().reverse();
  if(!arch.length) return `<p class="empty">${T('Todavía no salió ninguna edición.')}</p>`;
  if(!S.fnews) S.fnews = 'todo';
  const f = (FILTROS.find(x=>x[0]===S.fnews) || FILTROS[0])[2];
  const filtradas = arch.map(d=>({...d, titulares: f? d.titulares.filter(t=>f(t.s)) : d.titulares}))
                        .filter(d=>d.titulares.length);
  return `<div class="wsel">${FILTROS.map(([k,n])=>{
      const cuantas = arch.reduce((a,d)=>a + (FILTROS.find(x=>x[0]===k)[2]
        ? d.titulares.filter(t=>FILTROS.find(x=>x[0]===k)[2](t.s)).length : d.titulares.length), 0);
      return `<button class="lgtab ${S.fnews===k?'on':''}" onclick="setFiltroNews('${k}')">${T(n)} <em>${cuantas}</em></button>`;
    }).join('')}</div>
    ${filtradas.length? filtradas.map(d=>vPortada(d, d.year)).join('')
      : `<p class="empty">${T('Nada en esta sección todavía.')}</p>`}`;
}

function vInvierno(){
  const w=S.winter, p=S.p;
  return `<div class="pane">
    <button class="big arriba anim" onclick="continueSecondHalf()">${T(w.mensaje&&!w.prestamos.length&&!w.traspasos.length?'Seguir la temporada':'Quedarme donde estoy')}</button>
    <h2 class="h2 anim">${T('Mercado de invierno')}</h2>
    <p class="lead anim">${T('Ventana corta. Casi nadie se mueve, pero a veces cambia una carrera.')}</p>
    ${S.vueltaCesion? `<div class="newsbox anim"><span class="rc-i">↩️</span><div>
      <b>${T('Se terminó la cesión')}</b>
      <span>${T('Volvés a {club}. Lo que hiciste prestado es lo que van a mirar.', {club:esc(S.vueltaCesion.n)})}</span>
      </div></div>`:''}
    ${w.mensaje? `<div class="card anim"><p class="narr">${esc(T(w.mensaje))}</p></div>`:''}
    <div class="offers">
      ${w.prestamos.map((o,i)=>`<div class="offer anim" style="--club:${clubAccent(o.clubId)}">
        <div class="of-top">${crest(o.clubId,34)}<b>${esc(o.club)}</b><span class="pchip">${T('CESIÓN')}</span></div>
        <span class="of-lg">${esc(ligaTxt(C(o.clubId),true))}</span>
        <p class="of-p">${esc(pitchTxt(o))}</p>
        <div class="of-nums"><span>${T('Minutos')}<b>~${o.minutos}%</b></span><span>${T('Sueldo')}<b>${money(o.wage)}</b></span>
          <span>${T('Duración')}<b>${T(o.duracion)}</b></span></div>
        <button onclick="takeLoan(${i})">${T('Aceptar la cesión')}</button></div>`).join('')}
      ${w.traspasos.map((o,i)=>`<div class="offer anim" style="--club:${clubAccent(o.clubId)}">
        <div class="of-top">${crest(o.clubId,34)}<b>${esc(o.club)}</b>${stars(o.tier)}</div>
        <span class="of-lg">${esc(ligaTxt(C(o.clubId),true))} · ${T('prestigio')} ${o.rep}</span>
        <p class="of-p">${esc(pitchTxt(o))}</p>
        <div class="of-nums"><span>${T('Sueldo/año')}<b>${money(o.wage)}</b></span><span>${T('Minutos')}<b>~${o.min}%</b></span>
          <span>${T('Rol')}<b>${esc(T(o.rol))}</b></span></div>
        <button onclick="winterMove(${i})">${T('Fichar ahora')}</button></div>`).join('')}
    </div>
  </div>`;
}
function takeLoan(i){
  const p=S.p, o=S.winter.prestamos[i], from=C(p.club).n;
  anotar('invierno', ['c', i]);
  cicloCesion(p, o, o.mitades);
  p.timeline.push({y:p.year, k:'Cedido de {a} a {b}', v:{a:from,b:o.club}, ic:'🔁'});
  continueSecondHalf();
}
function winterMove(i){
  const p=S.p, o=S.winter.traspasos[i], from=C(p.club).n;
  anotar('invierno', ['p', i]);
  cicloPaseInvierno(p, o);
  p.timeline.push({y:p.year, k:'{a} → {b} ({fee})', v:{a:from,b:o.club,fee:money(o.fee)}, ic:'✈️'});
  continueSecondHalf();
}
function continueSecondHalf(){
  if(S.reg && S.reg.invierno.length < S.reg.focos.length) anotar('invierno', ['q', 0]);
  prepareHalf(1); S.phase='sim'; Store.save(); render();
}
function closeSeason(){
  const p=S.p;
  const fin = cicloCerrar(p, S.halves);
  S.lastSeason = fin.s;
  medir('season_end', {season: p.career.seasons, age: p.age, speed: S.vel,
    ranked: !!(S.reg && !S.reg.propia && !S.reg.practica), weekly: !!(S.reg && S.reg.reto),
    generation: p.dinastia ? p.dinastia.gen : 1});
  const s = fin.s;
  if(s.titles.length) p.timeline.push({y:p.year, tn:s.titles, ic:ICO.titulos});
  if(s.awards.some(a=>a.includes('Balón de Oro'))) p.timeline.push({y:p.year, k:'Balón de Oro', ic:ICO.balon});
  const w = fin.w;
  S.diario = {edicion:'fin', year:p.year, ...cicloDiarioJunio(p, s, w, fin.fuera)};
  guardarDiario(p, S.diario);
  const fuera = fin.fuera;
  if(p.world.length>1){
    const vieja = p.world[p.world.length-2];
    if(!vieja.palmares){
      vieja.palmares = {liga:{}, copa:{}};
      LEAGUES.forEach(lg=>{
        const t = vieja.tablas && vieja.tablas[lg.id];
        if(t && t.length) vieja.palmares.liga[lg.id] = Array.isArray(t[0])? t[0][0] : t[0].id;
        const c = vieja.copas && vieja.copas[lg.id];
        if(c) vieja.palmares.copa[lg.id] = c.id;
      });
    }
    delete vieja.tablas; delete vieja.copas;
  }
  if(S.vel === 'rapida'){ S.diario = null; S.phase = 'resultado'; }
  else S.phase = 'diario';
}

function vResultado(){
  const s=S.lastSeason, p=S.p, g=S.lastGrowth||{};
  const grown = ATTRS.filter(a=>Math.abs(g[a.k]||0)>=1).map(a=>`${a.n} ${g[a.k]>0?'+':''}${g[a.k]}`);
  const bigAward = s.awards.find(a=>a.includes('Balón de Oro')) || s.awards.find(a=>a.includes('Bota de Oro'));
  return `<div class="pane">
    <h2 class="h2 anim">${T('Temporada')} ${s.year}/${(s.year+1)%100}</h2>
    <p class="lead anim">${s.clubes.map(esc).join(' → ')} · ${s.leaguePos===1?`<b class="gold">${T('Campeón de liga')}</b>`:`${ord(s.leaguePos)} ${T('en la liga')}`} · ${s.share}% ${T('de los minutos')}</p>
    ${vGesta(s, bigAward)}
    ${s.injury? `<div class="alert anim">🩹 ${esc(T(s.injury))} (${s.injuryWeeks} ${T('sem.')})</div>`:''}
    <div class="stats anim">
      ${statBox(T('Partidos'),s.apps)}${statBox(T('Goles'),s.goals)}${statBox(T('Asistencias'),s.assists)}
      ${statBox(T('Nota media'),s.rating)}${statBox(T('Figuras'),s.motm)}${statBox(T('MEDIA'),s.ovr)}</div>
    <div class="row anim"><h4>${T('Por competición')}</h4>${compRows(s.comps||[])}</div>
    ${s.resApps? `<div class="row anim"><h4>${T('Reserva')}</h4>${chip(s.resApps+' '+T('PJ'))}${chip(s.resGoals+' '+T('Goles'))}</div>`:''}
    ${s.titles.length? `<div class="row anim"><h4>${T('Títulos')}</h4>${s.titles.map(t=>chip(esc(TN(t)),'gold')).join('')}</div>`:''}
    ${s.awards.length? `<div class="row anim"><h4>${T('Premios individuales')}</h4>${s.awards.map(t=>chip(esc(TN(t)),'silver')).join('')}</div>`:''}
    ${vPorQueCreciste(p)}
    <div class="row anim"><h4>${T('Evolución')}</h4>${grown.length? grown.map(t=>chip(TFX(t), t.includes('-')?'neg':'pos')).join('') : chip(T('Sin cambios'))}</div>
    <button class="big anim" onclick="afterResult()">${T(s.ntTorneo? 'Ver la campaña de la selección' : 'Cómo terminó todo')}</button>
  </div>`;
}
function vPorQueCreciste(p){
  if(!p.devWhy) return '';
  const cara = {despegue:'🚀', bien:'📈', flojo:'➖', perdido:'🧊'}[p.devWhy] || '📈';
  const titulo = {despegue:'Temporada de despegue', bien:'Creciste bien',
                  flojo:'Creciste poco', perdido:'Año perdido'}[p.devWhy];
  let causa = {lesion:'La lesión te frenó en seco.',
                 minutos:'Sin minutos no se crece: lo que más pesa es jugar.',
                 moral:'La cabeza no estuvo donde tenía que estar.',
                 tecnico:'El técnico no te dio lugar.',
                 trabajo:'Todo se alineó: minutos, cabeza y trabajo.'}[p.devCausa] || '';
  if(p.devCausa==='trabajo' && (p.devWhy==='flojo' || p.devWhy==='perdido'))
    causa = 'No hubo un freno claro: a veces el cuerpo tarda en responder.';
  return `<div class="newsbox devbox dev-${p.devWhy} anim ${p.devWhy==='perdido'?'alerta':''}">
    <span class="rc-i">${cara}</span><div>
    <b>${T(titulo)}</b>
    <span>${T(causa)}</span></div></div>`;
}

function vGesta(s, bigAward){
  const conti  = (s.titles||[]).find(t=>/Champions|Libertadores|Europa|Sudamericana|AFC|CONCACAF/i.test(t));
  const balon  = (s.awards||[]).find(a=>a.includes('Balón de Oro'));
  const liga   = s.leaguePos===1;
  const mundo  = (s.ntTitles||[]).find(t=>/Mundo|World/i.test(t));
  const gesta = mundo  ? {ic:ICO.mundial, k:'mundial', t:mundo,  d:'Campeón del mundo. Nada de lo que hagas después va a borrar esto.'}
              : balon  ? {ic:ICO.balon, k:'balon',   t:balon,  d:'El mejor del planeta este año. Sos vos.'}
              : conti  ? {ic:'🌟', k:'conti',   t:conti,  d:'La noche que te va a sobrevivir.'}
              : liga   ? {ic:ICO.liga, k:'liga',    t:'Campeón de liga', d:'Una liga entera por delante de todos.'}
              : bigAward? {ic:ICO.mvpFinal, k:'premio', t:bigAward, d:'La temporada de tu vida hasta ahora.'}
              : null;
  if(!gesta) return '';
  return `<div class="gesta ${gesta.k} anim">
    <div class="gesta-luz"></div>
    <div class="confeti">${Array.from({length:14},(_,i)=>`<i style="--i:${i}"></i>`).join('')}</div>
    <i class="gesta-ic">${gesta.ic}</i>
    <b>${esc(TN(gesta.t))}</b>
    <span>${T(gesta.d)}</span>
  </div>`;
}

function afterResult(){ S.phase = S.lastSeason.ntTorneo? 'seleccion' : 'mundo'; if(S.phase==='mundo') S.wlg=C(S.p.club).lg; Store.save(); render(); }

function vSeleccion(){
  const s=S.lastSeason, p=S.p;
  const campeon = (s.ntTitles||[]).length>0;
  return `<div class="pane">
    <div class="verdict anim" style="padding:28px 16px 24px">
      <span class="v-score">${esc(TN(s.ntTorneo))} ${s.year}</span>
      <h2 class="v-tier" style="font-size:clamp(24px,7vw,40px)">${p.flag} ${esc(TPais(p.nat))}</h2>
      <p class="v-desc">${campeon? '<b class="gold">'+esc(s.ntTitles.map(TN).join(' · '))+'</b>' : esc(TN(s.nt))}</p>
    </div>
    <div class="stats anim">
      ${statBox(T('Partidos'),s.ntCaps)}${statBox(T('Goles'),s.ntGoals)}${statBox(T('Total PJ'),p.nt.caps)}
      ${statBox(T('Total goles'),p.nt.goals)}${statBox(T('Rol'),T(p.nt.status))}${statBox(T('Debut'),p.nt.debut||'—')}</div>
    ${s.awards.filter(a=>a.includes('Mundial')).length? `<div class="row anim"><h4>${T('Premios del torneo')}</h4>
      ${s.awards.filter(a=>a.includes('Mundial')).map(a=>chip(esc(TN(a)),'gold')).join('')}</div>`:''}
    <button class="big anim" onclick="S.phase='mundo';S.wlg=C(S.p.club).lg;render()">${T('Cómo terminó todo')}</button>
  </div>`;
}

function setWlg(id){
  S.wlg=id;
  const el=$('wbody'); if(el) el.innerHTML = worldTables(S.p.world[S.p.world.length-1]);
  document.querySelectorAll('.lgtab').forEach(b=>b.classList.toggle('on', b.dataset.lg===S.wlg));
}
function worldTables(w, conCopas){
  const p=S.p, lg=L(S.wlg);
  const t=(w.tablas&&w.tablas[S.wlg])||[];
  const copa=w.copas&&w.copas[S.wlg], cont=w.conti[lg.cont];
  const gol=w.goleadores&&w.goleadores[S.wlg];
  const [plazasA, plazasB] = contiSlots(lg);
  const desciende = t.length>=8 ? 2 : t.length>=6 ? 1 : 0;

  const camp = (w.campeon && w.campeon[S.wlg]) || (t.length? (Array.isArray(t[0])?t[0][0]:t[0].id) : null);
  const zona = pos =>
    lg.playoff && pos <= lg.playoff ? (pos <= plazasA ? 'conti' : 'playoff')
    : pos <= plazasA ? 'conti'
    : pos <= plazasA + plazasB && CONT_CUP2[lg.cont] ? 'conti2'
    : pos > t.length - desciende ? 'baja' : '';

  const filas = t.map((r, i) => {
    const [id, pts] = Array.isArray(r) ? r : [r.id, r.pts];
    const club = C(id), pos = i + 1, yo = id === p.club;
    const esCampeon = id === camp;
    return `<div class="trow ${zona(pos)} ${yo?'yo':''}${esCampeon?' champ':''}">
      <span class="tp">${pos}</span>${crest(id,22)}
      <span class="tn">${esc(club? club.n : id)}${esCampeon?' '+ICO.titulos:''}</span>
      <span class="tpts">${pts}</span></div>`;
  }).join('');

  const leyenda = [
    plazasA ? `<span class="lz conti">${esc(TN(CONT_CUP[lg.cont]))}</span>` : '',
    plazasB && CONT_CUP2[lg.cont] ? `<span class="lz conti2">${esc(TN(CONT_CUP2[lg.cont]))}</span>` : '',
    lg.playoff ? `<span class="lz playoff">${T('Playoffs')}</span>` : '',
    desciende ? `<span class="lz baja">${T('Descenso')}</span>` : ''
  ].filter(Boolean).join('');

  const t2 = (w.tablas2 && w.tablas2[S.wlg]) || [];
  const filas2 = t2.map((r, i) => {
    const [id, pts] = Array.isArray(r) ? r : [r.id, r.pts];
    const club = C(id), pos = i + 1, yo = id === p.club;
    return `<div class="trow ${pos<=2?'sube':''} ${yo?'yo':''}">
      <span class="tp">${pos}</span>${crest(id,22)}
      <span class="tn">${esc(club? club.n : id)}</span>
      <span class="tpts">${pts}</span></div>`;
  }).join('');

  return `<div class="tabla">${filas}</div>
    ${leyenda? `<div class="tleyenda">${leyenda}</div>`:''}
    ${t2.length? `<div class="tsub">${T('Segunda división')}</div>
      <div class="tabla">${filas2}</div>
      <div class="tleyenda"><span class="lz sube">${T('Ascenso')}</span></div>`:''}
    <div class="wcups">
      ${gol? `<div class="wcup ${gol.yo?'yo':''}"><i style="font-style:normal;font-size:19px">${ICO.bota}</i>
        <div><span>${T('Goleador de la liga')}</span><b>${gol.flag} ${esc(gol.name)}</b>
        <em>${gol.goles} ${T('goles')} · ${esc(gol.club)}</em></div></div>`:''}
      ${conCopas && copa? `<div class="wcup ${copa.yo?'yo':''}"><i style="font-style:normal;font-size:19px">${ICO.copa}</i>
        <div><span>${esc(TN(copa.n))}</span><b>${esc(copa.club)}</b></div></div>`:''}
      ${conCopas && cont? `<div class="wcup ${cont.yo?'yo':''}"><i style="font-style:normal;font-size:19px">${ICO.conti}</i>
        <div><span>${esc(TN(cont.n))}</span><b>${esc(cont.club)}</b></div></div>`:''}
    </div>`;
}
function worldBlock(w, compact){
  return `<div id="wbody">${worldTables(w, true)}</div>
    <div class="wgrid">
      <div class="wbig ${w.balon.yo?'yo':''}"><span>${T('Balón de Oro')} ${w.year}</span>
        <b>${w.balon.flag} ${esc(w.balon.name)}</b><em>${esc(w.balon.club)}</em></div>
      <div class="wbig ${w.bota.yo?'yo':''}"><span>${T('Bota de Oro')} ${w.year}</span>
        <b>${w.bota.flag} ${esc(w.bota.name)}</b><em>${w.bota.goles} ${T('goles')}</em></div>
    </div>
    ${compact?'':`<div class="row"><h4>${T('Campeones continentales')}</h4>
      ${Object.values(w.conti).map(c=>chip(`${esc(TN(c.n))}: ${esc(c.club)}`, c.yo?'gold':'')).join('')}</div>`}`;
}
function vMundo(){
  const p=S.p, w=p.world[p.world.length-1];
  if(!S.wlg) S.wlg=C(p.club).lg;
  return `<div class="pane">
    <h2 class="h2 anim">${T('Así terminó {y}',{y:w.year})}</h2>
    <p class="lead anim">${T('Cómo terminó tu liga y quién se llevó lo grande. El resto del planeta, en Torneos.')}</p>
    <div class="anim">${worldBlock(w,false)}</div>
    <button class="ghost anim" onclick="openSheet('torneos')" style="margin-bottom:4px">${T('Ver todas las competiciones')}</button>
    ${p.world.length>1? `<div class="row anim"><h4>${T('Balón de Oro, últimos años')}</h4>
      ${p.world.slice(-8).reverse().map(x=>chip(`${x.year}: ${esc(x.balon.name)}`, x.balon.yo?'gold':'')).join('')}</div>`:''}
    <button class="big anim" onclick="toMarket()">${T('Mercado de verano')}</button>
  </div>`;
}

function toMarket(){
  const retiro = cicloSiguiente(S.p);
  if(retiro){
    S.phase = 'fin';
    if(!S.memGuardada){ memoriaGuardar(S.p.seenEvents); S.memGuardada = true; finDeCarreraMedido(S.p); }
    Store.save(); render(); return;
  }
  const mk = cicloMercado(S.p);
  S.vueltaCesion = mk.vuelta;
  S.sigueCedido = !!mk.cedido;
  S.offers = mk.ofertas;
  S.renew  = mk.renovar;
  S.mktPick = null;
  S.phase='mercado'; Store.save(); render();
}
function vMercado(){
  const p=S.p, c=C(p.club), forced=p.contract<=0;
  if(S.sigueCedido) return `<div class="pane">
    <button class="big arriba anim" onclick="anotar('mercado',-1);nextSeason()">${T('Seguir la cesión')}</button>
    <h2 class="h2 anim">${T('Mercado de verano')}</h2>
    <div class="newsbox anim"><span class="rc-i">🔁</span><div>
      <b>${T('Seguís cedido en {club}', {club:esc(c.n)})}</b>
      <span>${T('Tu cesión dura otra temporada. Mientras tanto seguís perteneciendo a {duenio}, así que las ofertas que lleguen las escucha tu club dueño, no vos.', {duenio:esc(C(p.loanFrom).n)})}</span>
      </div></div>
    <p class="lead anim">${T('Valés')} <b>${money(p.value)}</b>.</p>
  </div>`;
  if(S.mktPick!=null && S.mktPick!=='stay' && !S.offers[S.mktPick]) S.mktPick = null;
  const sel = S.mktPick;
  const acaN = p.clubYears + (S.vueltaCesion ? 0 : 1);
  return `<div class="pane">
    <button class="big arriba anim ${sel==null?'off':''}" onclick="confirmarMercado()">${
      sel==null ? T('Elegí una opción') :
      sel==='stay' ? T('Renovar con {c}',{c:esc(c.n)}) :
      T('Fichar por {c}',{c:esc(S.offers[sel].club)})}</button>
    <h2 class="h2 anim">${T('Mercado de verano')}</h2>
    <p class="lead anim">${forced? T('Tu contrato con {c} se termina. Hay que decidir.',{c:esc(c.n)})
      : p.contract===1 ? T('Te queda un año en {c}.',{c:esc(c.n)}) : T('Te quedan {n} años en {c}.',{n:p.contract,c:esc(c.n)})} ${T('Valés')} <b>${money(p.value)}</b>.</p>
    <div class="offers">
      <div class="offer renovar anim ${sel==='stay'?'elegida':''}" style="--club:${clubAccent(p.club)}" data-mk="stay" role="button" tabindex="0" onclick="pickMkt('stay')">
        <div class="of-top">${crest(p.club,34)}<b>${esc(c.n)}</b><span class="pchip">${T('RENOVAR')}</span></div>
        <span class="of-lg">${esc(ligaTxt(c))} · ${acaN} ${T(acaN===1 ? 'temporada acá' : 'temporadas acá')}</span>
        <p class="of-p">${T(acaN>=4?'«Acá construiste algo. No lo tires.»':'«Todavía tenemos cosas por hacer juntos.»')}</p>
        <div class="of-nums"><span>${T('Sueldo/año')}<b>${money(S.renew.wage)}</b></span>
          <span>${T('Años')}<b>${S.renew.years}</b></span><span>${T('Hinchada')}<b>${p.fanLove}</b></span></div></div>
      ${S.offers.map((o,i)=>`<div class="offer anim ${o.prometida?'prometida':''} ${sel===i?'elegida':''}" style="--club:${clubAccent(o.clubId)}" data-mk="${i}" role="button" tabindex="0" onclick="pickMkt(${i})">
        <div class="of-top">${crest(o.clubId,34)}<b>${esc(o.club)}</b>${stars(o.tier)}</div>
        <span class="of-lg">${esc(ligaTxt(C(o.clubId),true))} · ${T('prestigio')} ${o.rep}${o.prometida?' · <b class="gold">'+T('la oferta que esperabas')+'</b>':''}</span>
        <p class="of-p">${esc(pitchTxt(o))}</p>
        <div class="of-nums"><span>${T('Sueldo/año')}<b>${money(o.wage)}</b></span>
          <span>${T('Minutos')}<b>~${o.min}%</b></span><span>${T('Rol')}<b>${esc(T(o.rol))}</b></span></div></div>`).join('')}
      ${!S.offers.length? `<div class="offer empty-of anim">${T('No llamó nadie. Silencio absoluto.')}</div>`:''}
    </div>
  </div>`;
}
function pickMkt(k){
  S.mktPick = k;
  const c = C(S.p.club);
  document.querySelectorAll('.offer[data-mk]').forEach(el=>
    el.classList.toggle('elegida', el.dataset.mk === String(k)));
  const btn = document.querySelector('.pane > .big');
  if(btn){
    btn.classList.remove('off');
    btn.textContent = k==='stay' ? T('Renovar con {c}',{c:c.n})
                                 : T('Fichar por {c}',{c:S.offers[k].club});
  }
}
function confirmarMercado(){
  if(S.mktPick==null || (S.mktPick!=='stay' && !S.offers[S.mktPick])) return;
  const k = S.mktPick; S.mktPick = null;
  if(k==='stay') stay(); else transfer(k);
}

function stay(){ anotar('mercado', -1); cicloRenovar(S.p, S.renew); nextSeason(); }
function transfer(i){
  const p=S.p, o=S.offers[i], from=C(p.club).n;
  anotar('mercado', i);
  cicloFichar(p, o);
  p.timeline.push({y:p.year, k:'{a} → {b} ({fee})', v:{a:from,b:o.club,fee:money(o.fee)}, ic:'✈️'});
  nextSeason();
}
function nextSeason(){
  S.focus=[]; S.colgar = false;
  S.phase = 'pretemporada';
  Store.save(); render();
}

function vFin(){
  const p=S.p, s=careerSummary(p);
  const first=p.seasons[0], last=p.seasons[p.seasons.length-1];
  const boxes = TROPHY_DEFS.filter(([ic,n,f])=>f(p)).map(([ic,n,f])=>{ const v=f(p);
    return `<div class="tbox has"><i>${ic}</i><b>${v}</b><span>${T(n)}</span></div>`; }).join('')
    || `<p class="empty">${T('Sin títulos. La carrera fue la carrera.')}</p>`;
  const rango = RANGO_CLASE[s.tier.t] || 'medio';
  return `<div class="pane final">
    <div class="carnet ${rango} anim">
      <div class="carnet-luz"></div>
      <span class="carnet-rango">${T(s.tier.t)}</span>
      <div class="carnet-nombre">${crest(p.club,42)}
        <div><b>${esc(p.name)}</b><em>${p.flag} ${esc(TPais(p.nat))} · ${TP(p.pos)} · #${p.num}</em></div></div>
      <div class="carnet-nums">
        <span><b>${s.peakOvr}</b>${T('Media máxima')}</span>
        <span><b>${s.goles}</b>${T('Goles')}</span>
        <span><b>${s.asist}</b>${T('Asistencias')}</span>
        <span><b>${s.temporadas}</b>${T('Temporadas')}</span>
      </div>
      <div class="carnet-pie"><span>${S.envio && S.envio.estado==='listo'
          ? (S.envio.reto ? `#${S.envio.puesto}/${S.envio.total} · ${T('Semana {n}', {n:S.reg.retoN||''})}` : `#${S.envio.puesto} ${T('en el mundo')}`)
          : `${first?first.year:p.year} — ${last?last.year:p.year}`}</span>
        <b>${s.score} ${T('puntos de leyenda')}</b></div>
    </div>
    <p class="v-desc anim">${esc(T(s.tier.d))}</p>
    ${vRanking(s)}
    ${vLegado(p, s)}
    <div class="card obit anim">
      <p class="retire">${esc(T(RETIRE_TXT[p.retireReason]||''))}</p></div>
    ${''}
    <div class="stats tres anim">${statBox(T('Partidos'),s.pj)}${statBox(T('Nota media'),s.avg)}${statBox(T('Clubes'),s.clubsPlayed.length)}</div>
    <div class="row anim"><h4>${T('Vitrina')}</h4><div class="tgrid">${boxes}</div></div>
    ${vDistinciones(p, s)}
    ${vCurve()}
    <div class="row anim"><h4>${T('Clubes')}</h4>${s.clubsPlayed.map(c=>chip(esc(c))).join('')}</div>
    ${p.timeline.length? `<div class="row anim"><h4>${T('Línea de tiempo')}</h4>${p.timeline.map(t=>
      `<div class="tl-i"><span>${t.y}</span><i>${t.ic}</i><b>${esc(t.tn? t.tn.map(x=>TN(x)).join(' · ') : t.k? T(t.k, t.v) : (t.t||''))}</b></div>`).join('')}</div>`:''}
    ${vDinastia(p)}
    <button class="big anim" onclick="descargarCarnet()">${T('Compartir esta pantalla')}</button>
    <button class="ghost" onclick="copyCard()">${T('Copiar el resumen en texto')}</button>
    <button class="ghost" onclick="copiarEnlace()">${T('Copiar el enlace a esta carrera')}</button>
    <button class="ghost" onclick="Store.clear();location.reload()">${T('Jugar otra carrera')}</button>
  </div>`;
}
function vDistinciones(p, s){
  const d = distincionesDe(p, s);
  if(!d.length){
    const larga = (s.temporadas || 0) >= 12;
    return `<div class="row anim"><h4>${T('Lo que te ganaste')}</h4>
      <p class="v-vacio">${larga
        ? T('Ni títulos ni marcas. {n} temporadas de oficio, {pj} partidos y un vestuario que siempre te hizo lugar. La mayoría no llega ni a eso.', {n:s.temporadas, pj:s.pj})
        : T('La carrera terminó antes de dejar una marca. Pasa, y pasa mucho más seguido de lo que se cuenta.')}</p></div>`;
  }
  return `<div class="row anim"><h4>${T('Lo que te ganaste')}</h4>
    <div class="distins">${d.map(x=>`<div class="distin">
      <b>${esc(T(x.n))}</b><span>${esc(T(x.d))}</span></div>`).join('')}</div></div>`;
}

function vRanking(s){
  const e = S.envio;
  if(e && e.estado==='listo' && e.reto){
    return `<div class="rank-fin hecho anim">
      <span class="rk-lbl">${T('Tu puesto en el reto de la semana')}</span>
      <b class="rk-pos">#${e.puesto}</b>
      <span class="rk-pie">${T('de {t} · {p} puntos de leyenda', {t:e.total, p:e.puntaje})}</span>
      <button class="ghost" onclick="abrirTabla('reto', ${e.reto|0})">${T('Ver la tabla de la semana')}</button></div>`;
  }
  if(e && e.estado==='listo'){
    return `<div class="rank-fin hecho anim">
      <span class="rk-lbl">${T('Tu puesto en el mundo')}</span>
      <b class="rk-pos">#${e.puesto}</b>
      <span class="rk-pie">${e.puntaje} ${T('puntos de leyenda')}</span>
      ${
        e.mejor? `<p class="rk-fine">${T('Tu mejor carrera como {n} sigue en la tabla, con {p} puntos. Cada nombre aparece una vez, con su mejor carrera.', {n:esc(e.nombre), p:e.mejor})}</p>`:''}
      <button class="ghost" onclick="abrirTabla()">${T('Ver la tabla')}</button></div>`;
  }
  const motivo = motivoNoRankeable();
  if(motivo){
    return `<div class="rank-fin anim">
      <p class="rk-no">${T(motivo)}</p>
      <button class="ghost" onclick="abrirTabla()">${T('Ver el ranking mundial')}</button></div>`;
  }
  const yendo = e && e.estado==='yendo';
  const reto = S.reg && S.reg.reto;
  return `<div class="rank-fin anim">
    <span class="rk-lbl">${reto ? T('Reto de la semana') + ' · ' + T('Semana {n}', {n:S.reg.retoN||''}) : T('Ranking mundial')}</span>
    <p class="rk-txt">${reto
      ? T('Mandá tu carrera a la tabla de esta semana. Todos jugaron el mismo jugador con la misma semilla: lo que te separa del resto son tus decisiones.')
      : T('Podés mandar esta carrera a la tabla mundial. El servidor la vuelve a jugar entera para comprobar el puntaje, así que nadie puede inventarse un número.')}</p>
    <input id="rk_nombre" maxlength="24" value="${esc(e && e.nombre != null ? e.nombre : nombreParaTabla(S.p.name))}" placeholder="${T('Con qué nombre aparecés')}">
    ${e && e.estado==='error'? `<p class="rk-err">${esc(T(e.msg))}</p>`:''}
    <button class="big" onclick="enviarAlRanking()" ${yendo?'disabled':''}>${
      yendo? T('Mandando…') : T('Mandar mi carrera al ranking')}</button>
    <p class="rk-fine">${T('Se guardan y son públicos: ese nombre, tu país, tu puntuación y el resumen de la carrera —títulos, goles, los clubes por los que pasaste y a qué edad colgaste—.')}</p>
    <button class="ghost" onclick="abrirTabla()">${T('Sólo ver la tabla')}</button></div>`;
}

const RANGO_CLASE = {
  'INMORTAL':'inmortal', 'LEYENDA GLOBAL':'leyenda', 'CLASE MUNDIAL':'mundial',
  'ESTRELLA':'estrella', 'ÍDOLO DE CLUB':'idolo',
  'PROFESIONAL SÓLIDO':'medio', 'OBRERO DEL FÚTBOL':'medio', 'PROMESA TRUNCA':'trunca'
};

function vLegado(p, s){
  const l = [];
  if(p.mundiales)  l.push([ICO.mundial, p.mundiales, 'Mundial ganado', 'Mundiales ganados']);
  if(p.balones)    l.push([ICO.balon, p.balones,   'Balón de Oro',   'Balones de Oro']);
  if(s.contis)     l.push(['🌟', s.contis,    'copa continental','copas continentales']);
  if(s.ligas)      l.push([ICO.liga, s.ligas,     'liga',           'ligas']);
  if(p.botasOro)   l.push([ICO.bota, p.botasOro,  'Bota de Oro',    'Botas de Oro']);
  if(p.mvpFinal)   l.push([ICO.mvpFinal, p.mvpFinal,  'MVP de una final','MVP de finales ganados']);
  if(!l.length) return `<div class="legado vacio anim"><p>${T('Sin vitrina. La carrera fue la carrera: los partidos, los viajes, el vestuario.')}</p></div>`;
  return `<div class="legado anim">
    <h4>${T('Lo que te sobrevive')}</h4>
    ${l.slice(0,6).map(([ic,n,uno,varios])=>`<div class="leg-i"><i>${ic}</i>
      <b>${n}</b><span>${T(n===1?uno:varios)}</span></div>`).join('')}
  </div>`;
}

function vCurve(){
  const p=S.p; if(p.seasons.length<3) return '';
  const W=560,H=140,pad=8;
  const vals=p.seasons.map(s=>s.ovr), mn=Math.min(...vals)-3, mx=Math.max(...vals)+2;
  const pts=vals.map((v,i)=>[pad+i*(W-pad*2)/(vals.length-1), H-pad-((v-mn)/(mx-mn))*(H-pad*2)]);
  const d=pts.map((q,i)=>(i?'L':'M')+q[0].toFixed(1)+','+q[1].toFixed(1)).join(' ');
  return `<div class="row curve anim"><h4>${T('Curva de nivel')}</h4>
    <svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none">
      <path d="${d} L${W-pad},${H} L${pad},${H} Z" fill="url(#grd)" opacity=".22"/>
      <path d="${d}" fill="none" stroke="var(--gold)" stroke-width="2.5" stroke-linejoin="round"/>
      <defs><linearGradient id="grd" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="var(--gold)"/><stop offset="100%" stop-color="transparent"/></linearGradient></defs>
    </svg></div>`;
}
function cssDeLaPagina(){
  let css = '';
  for(const h of document.styleSheets){
    try{ for(const r of h.cssRules) css += r.cssText + '\n'; }catch(e){}
  }
  return css;
}
function varsDeRoot(){
  try{
    const nombres = [];
    for(const hoja of document.styleSheets){
      for(const regla of hoja.cssRules || []){
        if(!regla.style || !/(^|,)\s*:root\s*$/.test(regla.selectorText || '')) continue;
        for(const prop of regla.style) if(prop.startsWith('--')) nombres.push(prop);
      }
    }
    return nombres.length ? nombres : null;
  }catch(e){ return null; }
}

function pantallaFinalComoSVG(){
  const nodo = document.querySelector('.pane.final');
  if(!nodo) return null;
  const copia = nodo.cloneNode(true);
  copia.querySelectorAll('button, input, .rank-fin .ghost').forEach(e => e.remove());
  copia.querySelectorAll('.anim').forEach(e => e.classList.remove('anim'));
  const pie = document.createElement('p');
  pie.setAttribute('style', 'text-align:center;color:#7B9187;font-weight:700;'
    + 'font-size:15px;margin:22px 0 4px;letter-spacing:.02em');
  pie.textContent = 'myfootballcareer.io';
  copia.appendChild(pie);

  const an = Math.min(720, Math.max(380, nodo.getBoundingClientRect().width || 480));
  const envoltorio = document.createElement('div');
  envoltorio.setAttribute('xmlns', 'http://www.w3.org/1999/xhtml');
  const raiz = getComputedStyle(document.documentElement);
  const VARS = varsDeRoot() || ['--bg','--surface','--surface2','--surface3','--line',
    '--line2','--txt','--dim','--dim2','--gold','--gold2','--plata','--bronce','--card',
    '--ink','--elite','--great','--good','--ok','--low','--low2','--neg','--r','--r2',
    '--safe-b','--safe-t'];
  const declaradas = VARS.map(v => {
    const val = raiz.getPropertyValue(v).trim();
    return val ? `${v}:${val}` : '';
  }).filter(Boolean).join(';');
  envoltorio.setAttribute('style', `${declaradas};width:${an}px;background:#080B0A;`
    + `color:#EEF4F0;padding:18px 16px 8px;font-family:system-ui,-apple-system,sans-serif`);
  envoltorio.appendChild(copia);

  const alto = Math.ceil(Math.max(
    nodo.scrollHeight,
    nodo.getBoundingClientRect().height,
    copia.children.length * 110
  ) + 90);
  return { an, alto, svg:
    `<svg xmlns="http://www.w3.org/2000/svg" width="${an}" height="${alto}">`
    + `<foreignObject width="100%" height="100%">`
    + `<style>${cssDeLaPagina()}</style>`
    + new XMLSerializer().serializeToString(envoltorio)
    + `</foreignObject></svg>` };
}
function descargarCarnet(){
  const d = pantallaFinalComoSVG();
  if(!d) return copyCard();
  const esc = 2;   
  const img = new Image();
  const url = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(d.svg);
  const rendirse = () => { toast(T('No se pudo generar la imagen')); copyCard(); };
  img.onerror = rendirse;
  img.onload = () => {
    try{
      const cv = document.createElement('canvas');
      cv.width = d.an*esc; cv.height = d.alto*esc;
      const x = cv.getContext('2d');
      x.fillStyle = '#080B0A'; x.fillRect(0, 0, cv.width, cv.height);
      x.drawImage(img, 0, 0, cv.width, cv.height);
      const nombre = `${S.p.name.replace(/[^\w]+/g,'_')}.png`;
      const bajar = () => { const a = document.createElement('a');
        a.download = nombre; a.href = cv.toDataURL('image/png'); a.click();
        toast(T('Carnet guardado')); };
      if(navigator.share && navigator.canShare && cv.toBlob){
        cv.toBlob(b => {
          if(!b) return bajar();
          const f = new File([b], nombre, {type:'image/png'});
          if(!navigator.canShare({files:[f]})) return bajar();
          navigator.share({files:[f], title:S.p.name,
            text:`${S.p.name} — ${T(careerSummary(S.p).tier.t)} · ${enlaceCarrera()}`}).catch(()=>{});
        }, 'image/png');
      } else bajar();
    }catch(e){ rendirse(); }
  };
  img.src = url;
}
function momentosClave(p, tope){
  const t = p.timeline || [];
  const texto = m => m.tn ? m.tn.map(x=>TN(x)).join(' · ') : m.k ? T(m.k, m.v) : (m.t || '');
  const armar = l => l.filter(Boolean).map(m => ({ y:m.y, ic:m.ic || '', txt:texto(m) }));
  if(t.length <= tope) return armar(t);
  const peso = m => (m.tn ? 3 + m.tn.length : 0) + (String(m.ic||'').includes('✈') ? 2 : 0);
  const medio = t.slice(1, -1).map((m,i)=>[m,i]).sort((a,b)=>peso(b[0])-peso(a[0]))
    .slice(0, tope-2).sort((a,b)=>a[1]-b[1]).map(x=>x[0]);
  return armar([t[0], ...medio, t[t.length-1]]);
}
function resumenTexto(){
  const p = S.p, s = careerSummary(p);
  const desde = p.seasons[0] ? p.seasons[0].year : p.year;
  const hasta = p.seasons.length ? p.seasons[p.seasons.length-1].year : p.year;
  const L = [];
  const bloque = (titulo, filas) => {
    if(!filas.length) return;
    L.push('', titulo.toUpperCase(), ...filas);
  };

  L.push(`⚽ ${p.name}`);
  L.push(`${p.flag} ${TPais(p.nat)} · ${T(POSITIONS[p.pos].n)} · #${p.num}`);
  L.push(`${desde} – ${hasta} · ${T('retirado a los')} ${p.age}`);
  L.push('', `${T('VEREDICTO')}: ${T(s.tier.t)}`);
  L.push(`“${T(s.tier.d)}”`);

  if(S.envio && S.envio.estado === 'listo' && S.envio.reto){
    L.push('', `${(T('Reto de la semana') + ' · ' + T('Semana {n}', {n:S.reg.retoN||''})).toUpperCase()}: #${S.envio.puesto} / ${S.envio.total}`);
    L.push(`${s.score} ${T('puntos de leyenda')}`);
  } else if(S.envio && S.envio.estado === 'listo'){
    L.push('', `${T('Tu puesto en el mundo').toUpperCase()}: #${S.envio.puesto}`);
    L.push(`${s.score} ${T('puntos de leyenda')}`);
  } else {
    L.push('', `${s.score} ${T('puntos de leyenda')}`);
  }

  const leg = [];
  if(p.mundiales) leg.push(`${ICO.mundial} ${p.mundiales} ${T(p.mundiales===1?'Mundial ganado':'Mundiales ganados')}`);
  if(p.balones)   leg.push(`${ICO.balon} ${p.balones} ${T(p.balones===1?'Balón de Oro':'Balones de Oro')}`);
  if(s.contis)    leg.push(`🌟 ${s.contis} ${T(s.contis===1?'copa continental':'copas continentales')}`);
  if(s.ligas)     leg.push(`${ICO.liga} ${s.ligas} ${T(s.ligas===1?'liga':'ligas')}`);
  if(p.botasOro)  leg.push(`${ICO.bota} ${p.botasOro} ${T(p.botasOro===1?'Bota de Oro':'Botas de Oro')}`);
  if(p.mvpFinal)  leg.push(`${ICO.mvpFinal} ${p.mvpFinal} ${T(p.mvpFinal===1?'MVP de una final':'MVP de finales ganados')}`);
  bloque(T('Lo que te sobrevive'), leg);

  bloque(T('Números'), [
    `${s.pj} ${T('Partidos')} · ${s.goles} ${T('Goles')} · ${s.asist} ${T('Asistencias')}`,
    `${T('Nota media')} ${s.avg} · ${T('Media máxima')} ${s.peakOvr} · ${s.temporadas} ${T('Temporadas')}`
  ]);

  bloque(T('Vitrina'), TROPHY_DEFS.map(([ic, n, f]) => `${ic} ${T(n)}: ${f(p)}`));

  const dis = distincionesDe(p, s);
  if(dis.length) bloque(T('Lo que te ganaste'), dis.map(d => `${T(d.n)} — ${T(d.d)}`));

  bloque(T('Clubes'), [s.clubsPlayed.join(' · ')]);

  const mom = momentosClave(p, 8);
  bloque(T('Momentos'), mom.map(m => `${m.y}  ${m.ic || ''} ${m.txt}`.trim()));

  L.push('', enlaceCarrera());
  return L.join('\n');
}
const SITIO_URL = 'https://myfootballcareer.io';
function enlaceCarrera(){
  const p = S.p, s = careerSummary(p);
  const desde = p.seasons[0] ? p.seasons[0].year : p.year;
  const hasta = p.seasons.length ? p.seasons[p.seasons.length-1].year : p.year;
  const d = { v:1, n:String(p.name).slice(0, 40), f:p.flag, c:TPais(p.nat), p:T(POSITIONS[p.pos].n),
    y:[desde, hasta], a:p.age, t:T(s.tier.t), d:T(s.tier.d), s:s.score,
    pj:s.pj, g:s.goles, as:s.asist, pk:s.peakOvr, te:s.temporadas,
    tr:TROPHY_DEFS.map(([ic, n, f]) => [ic, T(n), f(p) || 0]).filter(x => x[2] > 0),
    cl:s.clubsPlayed.slice(0, 20),
    r:(S.envio && S.envio.estado === 'listo' && !S.envio.reto) ? S.envio.puesto : 0 };
  if(S.envio && S.envio.estado === 'listo' && S.envio.reto) d.rt = [S.reg.retoN || 0, S.envio.puesto, S.envio.total];
  const b64 = btoa(unescape(encodeURIComponent(JSON.stringify(d))))
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  return SITIO_URL + ({es:'/es/carrera/', pt:'/pt/carreira/'}[LANG] || '/carrera/') + '?c=' + b64;
}
function copiarEnlace(){
  const url = enlaceCarrera();
  if(navigator.share){
    navigator.share({title:S.p.name, url}).catch(()=>{});
    return;
  }
  if(navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(url).then(() => toast(T('Enlace copiado')), () => pegarAMano(url));
  } else pegarAMano(url);
}
function copyCard(){
  const txt = resumenTexto();
  if(navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(txt).then(
      () => toast(T('Resumen copiado')),
      () => pegarAMano(txt));
  } else pegarAMano(txt);
}
function pegarAMano(txt){
  const ta = document.createElement('textarea');
  ta.value = txt;
  ta.setAttribute('style', 'position:fixed;inset:6% 5%;width:90%;height:80%;z-index:99;'
    + 'background:#111A16;color:#EEF4F0;border:1px solid #E8B84B;border-radius:12px;'
    + 'padding:14px;font:13px/1.5 system-ui;white-space:pre');
  ta.readOnly = true;
  ta.onblur = () => ta.remove();
  document.body.appendChild(ta);
  ta.focus(); ta.select();
  toast(T('Copialo a mano: ya está seleccionado'));
}
function toast(t, ms){ document.querySelectorAll('.toast').forEach(x=>x.remove()); const el=document.createElement('div'); el.className='toast'; el.textContent=t;
  document.body.appendChild(el); setTimeout(()=>el.remove(), ms || 2200); }

if(typeof fetch === 'function'){ rankPedirSemilla(); rankPedirReto(); }

if('serviceWorker' in navigator && location.protocol.startsWith('http')){
  const registrar = ()=>{
    navigator.serviceWorker.register('/sw.js').then(() => navigator.serviceWorker.ready).then(reg => {
      const propios = [...document.scripts].map(s => s.src).filter(s => /\/(juego|en|pt)\.[0-9a-f]{10}\.js$/.test(s));
      if(reg && reg.active) reg.active.postMessage({guardar:[location.pathname, ...propios]});
    }).catch(()=>{});
  };
  if(document.readyState === 'complete') registrar();
  else window.addEventListener('load', registrar);
}

document.addEventListener('keydown', e=>{
  const el = e.target;
  if((e.key==='Enter' || e.key===' ') && el && el.matches && el.matches('.offer[role="button"]')){
    e.preventDefault(); el.click();
  }
});

render();
